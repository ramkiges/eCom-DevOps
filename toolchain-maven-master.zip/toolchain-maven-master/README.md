# `apache-maven` RPM Builder

This packages Maven for WSI's CI infrastructure as the RPM `apache-maven`.

This build downloads a tarball of Maven from Artifactory, which must
be installed there manually.  To upgrade the version of Maven, upload
a new tarball into Artifactory and update the version in `pom.xml`.

## Concurrent Safe Local Repository Extensions

The Jenkins build boxes do multiple builds at once, reading from and
writing to the same localrepo.  This is problematic, as Maven has no
built-in mechanism to do that safely, and we believe that we have seen
actual build problems caused by this lack of locking.

The solution suggested by
[TAH-790](https://jira.wsgc.com/browse/TAH-790) is to include these
Maven extensions:

http://takari.io/book/30-team-maven.html#concurrent-safe-local-repository

This involves dropping two jars into the `lib/ext` directory of the
Maven installation.  We get those out of Artifactory; you must install
them there manually for this build to be able to find them.

There are GitHub 'issues' filed against these extensions saying that
they don't play well with Java 1.6.  Although we do use 1.6 in CI, we
have not seen any problems using these extensions with it, and we have
so few repositories using that version of Java that we aren't
concerned.
