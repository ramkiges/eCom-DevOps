# toolchain-jenkins-slave-config
Jenkins Slave Agent Configuration Package

Original Subversion Location: https://repos.wsgc.com/svn/devops/toolchain/jenkins-slave

Subversion depcrecation location: https://repos.wsgc.com/svn/devops/+deprecated/jenkins-slave
