Jenkins Jobs
---
XML files representing Jenkins jobs.

If you push job changes here, run the `JenkinsJobMgr` Jenkins
job to sync them in Jenkins.
