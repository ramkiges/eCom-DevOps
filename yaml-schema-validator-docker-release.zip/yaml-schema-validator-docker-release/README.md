# yaml-schema-validator-docker
A yaml schema validator container using Pykwalify

Usage:

    docker run -it --rm -v ${PWD}:/app -w /app snapshotrepo.wsgc.com/ecommerce-docker-repo/yaml-schema-validator pykwalify -s /schemas/helm-config.yaml -d /app/{path to yaml file to validate}
