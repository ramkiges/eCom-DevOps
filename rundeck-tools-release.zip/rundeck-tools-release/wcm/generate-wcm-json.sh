#!/bin/sh
# https://github.wsgc.com/eCommerce-DevOps/rundeck-tools
# script to generate json files for WCM/AES sync RunDeck job
# expects to be run from the same directory as the json files
# this is one of those "quick, temporary" scripts that probably isn't really temporary

PATH=/apps:/apps/mead-tools:/bin:/usr/bin:/sbin:/usr/sbin:/apps:/usr/local/bin
TIMEOUT="--connect-timeout 30 --max-time 60"

RUNDECK_JSON=/apps/rundeck-json/wcm
AES_SERVERLIST_NONPRD=aes-serverlist-nonprd.json
AES_SERVERLIST_PRD=aes-serverlist-prd.json
MARKET_LIST_NONPRD=wcm-marketlist-nonprd.json

APP_NAME="assortment-export"
KUBE_CLUSTER=ts-sharedplatform-rck-nonprod
KUBE_CONFIG=$HOME/.kube/ciuser/$KUBE_CLUSTER

NODES_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git
PORT=38600
umask 002

BailOut() {
    [ -n "$1" ] && echo "$*"
    echo "Usage: $(basename $0) <env_list>"
    exit 1
}

ENV_LIST=$(cat wcm-environmentlist-nonprd.json | sed "s/[^[:alnum:]]//g")
MARKET_LIST=$(cat $MARKET_LIST_NONPRD | sed "s/[^[:alnum:]]//g")

# clone resource-model repo so we can parse the tags
TMP="/tmp/$(basename $0 | sed -es/\\.sh//g)-$LOGNAME"
rm -rf $TMP
mkdir -p $TMP || BailOut "Can't create $TMP"
git clone --quiet $NODES_REPO $TMP/nodes || BailOut "Can't clone $NODES_REPO"

# create list of aes k8s endpoints
echo "Update $AES_SERVERLIST_NONPRD"
echo "[" > $AES_SERVERLIST_NONPRD
for ep in $(kubectl get namespace | egrep -Ei "ecommerce-assortment-export"|awk '{ print $1 }' | sort)
do
  echo "$ep.services.west.nonprod.wsgc.com," >> $AES_SERVERLIST_NONPRD
done
echo "]" >> $AES_SERVERLIST_NONPRD

# generate server json files for each brand/env
for brand in mg pb pk pt we ws rj gr
do
    unbuffer echo "$brand"

    # loop thru environments
    for env in $ENV_LIST
    do
        for market in $MARKET_LIST
        do
          json=$TMP/$brand-$env-$market.json 
          echo "json: $json"

          # create an option json file for brand-env combinations
          echo "[ " > $json

          # parse tags from rundeck node configs
	        server=$(grep -ihrw "wcm" $TMP/nodes/src/main/resources/wsgc | grep -iw "$brand" | grep -iE ",.*$env\b" | sed -es/\"//g | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }')
	        [ -z "$server" ] && { echo "!!! No servers found for $brand $env"; continue; }
          SC=$(echo $server | xargs -n1 | wc -l)
          [[ $SC -gt 1 ]] && { echo "/// There should be only 1 server for $brand $env ///"; }

          host=$(host $server | grep -i address|awk '{ print $1 }')
          echo "$brand -> $env -> $server ($host)"

          # add server entry as default
          echo "  { name:$server, value:$server, selected:true }," >> $json

          echo "] " >> $json
        done
        echo
    done
done

#ls -l $TMP/*json
sudo cp wcm-environmentlist-nonprd.json  $RUNDECK_JSON
sudo cp $TMP/*.json $RUNDECK_JSON/nonprd
sudo cp $MARKET_LIST_NONPRD $AES_SERVERLIST_NONPRD $AES_SERVERLIST_PRD $RUNDECK_JSON
sudo chown -R rundeck:webadmin $RUNDECK_JSON


