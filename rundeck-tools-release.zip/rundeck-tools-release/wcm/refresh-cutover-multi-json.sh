#!/bin/sh
# https://github.wsgc.com/eCommerce-DevOps/rundeck-tools
# script to generate json files for WCM/AES sync RunDeck job
# expects to be run from the same directory as the json files
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/apps
TIMEOUT="--connect-timeout 30 --max-time 60"

#
AES_SERVERLIST_NONPRD=../aes-serverlist-nonprd.json
#AES_SERVERLIST_PRD=../aes-serverlist-prd.json

# list of environments for which to create options
ENV_LIST=$*

TMP="/tmp/$(basename $0 | sed -es/\\.sh//g)"
NODES_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git
PORT=38600
umask 002

BailOut() {
    [ -n "$1" ] && echo "$*"
    echo "Usage: $(basename $0) <env_list>"
    echo "PASS and USER must be set as environment variables"
    exit 1
}

cd /apps/wcm-cutover-json/$JSON_DIR || BailOut "Unable to cd to /apps/wcm-cutover-json"

[ -z "$ENV_LIST" ] && BailOut "Need env list"
[ -z "$USER" ] && BailOut "Need user"
[ -z "$PASS" ] && BailOut "Need pass"

echo "USER:	$USER"
echo "ENV_LIST:	$ENV_LIST"
echo

# remove any existing json files
#rm -f *.json

# clone resource-model repo so we can parse the tags
rm -rf $TMP
mkdir -p $TMP || BailOut "Can't create $TMP"
git clone --quiet $NODES_REPO $TMP/nodes || BailOut "Can't clone $NODES_REPO"

echo "[ " > cutover.json

# this little trick is so the first element becomes the default
echo "  { name:none, value:none }," >> cutover.json

# create a "cutover-none" file
echo "[  { name:none, value:none } ]" > cutover-none.json

for cutover in Full Global Season SingleGlobal SingleSeasonal
do
	entity_list=""
	echo "  { name:$cutover, value:$cutover }," >> cutover.json

	[ "$cutover" = "SingleGlobal" ] && entity_list="skuSwatch attribute feature measurement video pipmessage article requestableSwatch vascolor vasstyle subsetConfig installationService utilityNeed imageHotspots"
	[ "$cutover" = "SingleSeasonal" ] && entity_list="sku group category checklist typeahead searchbillboard contentlink dynpopup subGroup"

	# this little trick is so the first element becomes the default
	echo "[ " > cutover-$cutover.json
        echo "  { name:none, value:none }," >> cutover-$cutover.json
	for entity in $entity_list
	do
		echo "  { name:$entity, value:$entity }," >> cutover-$cutover.json
	done
	echo "] " >> cutover-$cutover.json
done
echo "] " >> cutover.json

# loop thru brands
for brand in mg pb pk pt we ws rj gr
do
    unbuffer echo "$brand"
    sleep 5

    # loop thru environments
    for env in $ENV_LIST
    do
        # create an option json file for brand-env combinations
        echo "[ " > $brand-$env.json

        # parse tags from rundeck node configs
        SERVER_LIST=$(grep -irw "wcm" $TMP/nodes/src/main/resources/wsgc | grep -iw "$brand" | grep -iw "$env" | sed -es/\"//g | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }')
        [ -z "$SERVER_LIST" ] && echo "!!! No servers found for $brand $env !!!"
        for server in $SERVER_LIST
        do
            host=$(host $server | grep -i address|awk '{ print $1 }')
            echo "-----------------------------------------"

	          # add server entry as default
            echo "  { name:$server, value:$server, selected:true }," >> $brand-$env.json

            # add an 'all' entry
            echo "[ 'all' ]" > $brand-all-$env-$server.json 

            # grab list of markets from WCM server
            for market in $(curl -s -u "$USER:$PASS" GET "http://$server:$PORT/markets/resolver?brand=$brand" 2>/dev/null | jq .markets[].shortName | sed -es/\"//g | sort)
            do
                unbuffer echo "			$market"
                echo "$brand -> $market -> $env -> $server ($host)"

                # create json file with list of seasons
                echo "[ " > $brand-$market-$env-$server.json

                # add an 'all' option
                echo "  { name:all, value:all }," >> $brand-$market-$env-$server.json

                # debugging output
                unbuffer echo "***"
                echo curl -s -u "$USER:\$PASS" $TIMEOUT GET "http://$server:$PORT/seasons/resolver?noGlobalCatalog=true&brand=$brand&market=$market"
                unbuffer curl -s -u "$USER:$PASS" $TIMEOUT GET "http://$server:$PORT/seasons/resolver?noGlobalCatalog=true&brand=$brand&market=$market"
                unbuffer echo "***"
                unbuffer echo

                # grab list of seasons from WCM server
                echo "Seasons for $brand/$market/$env - $server:"
                echo "  { name:none, value:none, selected:true }," >> $brand-$market-$env-$server.json
                for season in $(curl -s -u "$USER:$PASS" $TIMEOUT GET "http://$server:$PORT/seasons/resolver?noGlobalCatalog=true&brand=$brand&market=$market" 2>/dev/null | jq .seasons[].shortName | sed -es/\"//g | sort)
                do
                    unbuffer echo "			$season"
                    echo "{ "name":"$season", "value":"$season" }," >> $brand-$market-$env-$server.json
                done

                echo "] " >> $brand-$market-$env-$server.json
                echo
            done
        done

        echo "] " >> $brand-$env.json
        echo
    done
done
