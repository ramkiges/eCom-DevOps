#!/bin/sh
# returns the AES server for a given brand, environ and market
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin
export PATH

APP_NAME="assortment-export"

BailOut() {
  [[ -n $1 ]] && echo "$*" >&2
  echo "Usage: $(basename $0) <brand> <environ> [market]" >&2
  exit 1;
}

# convert values to lower case
brand=$(echo "$1" | tr "[:upper:]" "[:lower:]")
environ=$(echo "$2" | tr "[:upper:]" "[:lower:]")
market=$(echo "$3" | tr "[:upper:]" "[:lower:]")

[[ "$environ" = "uat1" ]] && environ=uat

[[ "$environ" = "prdrk" ]] && AES_EXTENSION="services.west.wsgc.com" || AES_EXTENSION="services.west.nonprod.wsgc.com"

# market is optional - the default would be "usa"
[[ -z $brand ]] || [[ -z $environ ]] && BailOut

if [[ "$environ" = "prdrk" ]]
then
  case $market in
  can ) aes=ecommerce-$APP_NAME-$brand-ca-prod.$AES_EXTENSION ;;
  * ) aes=ecommerce-$APP_NAME-$brand-prod.$AES_EXTENSION ;;
  esac
else
  case $market in
  can ) aes=ecommerce-$APP_NAME-$brand-ca$environ.$AES_EXTENSION ;;
  * ) aes=ecommerce-$APP_NAME-$brand-$environ.$AES_EXTENSION ;;
  esac
fi


# validating the aes server name with pattern. If the pattern matches then the aes server name will be printed.
[[ "$aes" = *"ecommerce-$APP_NAME-$brand"* ]] && echo "$aes"

exit 0
