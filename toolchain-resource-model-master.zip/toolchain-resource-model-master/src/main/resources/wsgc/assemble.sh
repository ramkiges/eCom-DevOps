#!/bin/bash

#
# assemble the various rundeck resource-xml files into a large one and uplaod to artifactory where rundeck then consumes using its API
#

#
# GUARDRAIL CONSTANTS
#
GR_UNIX_OPERATING_SYSTEM_FAMILY_ID=2
GR_LINUX_OPERATING_SYSTEM_ID=241
GR_SERVER_NODE_TYPE="SV"
GR_DEFAULT_ENVIRONMENT_ID=2
GR_SSH_MEDIUM_USERNAME=imageuser
GR_DEFAULT_CONNECTION_MANAGER_GROUP_ID=1
GR_SSH_MEDIUM_TYPE=3

nodeHasTag() {
   if [[ $# -ne 2 ]]
   then
      echo "ERROR, nodeHasTag(), wrong number of args: $#, requires 2" 1>&2
      return 1
   fi
      
   _tags="$1"
   _tag="$2"

   for t in $(echo ${_tags}|tr ',' ' ')
   do
      if [[ ${t} == ${_tag} ]]
      then
         return 0
      fi
   done
   return 1
}

# from authoritative rundeck resources.xml file extract nodes matching desired tag
dumpNodes2GRCSV() {
   rxml="$1"
   tag=
   if [[ $# -eq 2 ]]
   then
      tag="$2"
   fi

   #TODO: "short description": "${desc}"

   echo "name,nodetype,mediumtype,mediumhostname,mediumusername,mediumpassword,connectionmanagergroupid,operatingsystemfamilyid,operatingsystemid" 
   for name in $(xmlstarlet sel -t -m '/project/node' -v '@name' -n "${rxml}"); do
      if [[ -n "${tag}" ]]
      then
         tags=$(xmlstarlet sel -t -m "/project/node[@name='${name}']" -v '@tags' $rxml)
         if ! nodeHasTag "${tags}" "${tag}"
         then
            continue
         fi
      fi
      desc=$(xmlstarlet sel -t -m "/project/node[@name='${name}']" -v '@description'  $rxml)
      cat <<!
${name},${GR_SERVER_NODE_TYPE},${GR_SSH_MEDIUM_TYPE},${name},${GR_SSH_MEDIUM_USERNAME},null,${GR_DEFAULT_CONNECTION_MANAGER_GROUP_ID},${GR_UNIX_OPERATING_SYSTEM_FAMILY_ID},${GR_LINUX_OPERATING_SYSTEM_ID}
!
   done
}
 
#
# check all input resource-xml files for xml validity and potential duplicates
#
checkInputResourceXmls() {

   #
   # ensure all files are valid xml
   #
   for x in $(find . -name resources.xml); do
      xmlstarlet fo $x >/dev/null || { echo file $x xml is broken 1>&2; exit 1; }
   done

   #
   # for each encountered project/node, obtain the value of the "name" attribute
   # then ensure there is exactly one occurance of this named node
   #
   for x in $(find . -name resources.xml); do
      for n in $(xmlstarlet sel -t -m '/project/node'  -v '@name' -n $x); do
         n1=$(xmlstarlet sel -t -m "/project/node[@name='${n}']/@name" -v . $x)
         if [[ "${n}" != "${n1}" ]]
         then
            echo "name $n may be non unique in file $x, cannot continue" 1>&2
            exit 1
         fi
      done
   done
}

#
# loop thru each resources-xml file and  assemble them into one generated resources-xml file
#
assembleInputs() {

   cat <<!
<?xml version="1.0" encoding="UTF-8"?>
<project>
!

   for x in $(find . -name resources.xml); do
      xmlstarlet sel -t -m '/project/node' -c . -n $x
   done

   cat <<!
</project>
!
}


 
#
# check resources-xml for validity and duplicates
#
checkResourcesXml() {
   input=$1

   if ! xmlstarlet fo $input >/dev/null
   then
      echo "produced invalid xml file, see $input" 2>&1
      exit 1
   fi

   for n in $(xmlstarlet sel -t -m '/project/node'  -v '@name' -n $input); do
      xn=$(xmlstarlet sel -t -m "/project/node[@name='${n}']/@name" -v . ${input})
      if [[ $n != $xn ]]
      then
         echo fail node $n see input file $input
         echo xmlstarlet sel -t -m "/project/node[@name='${n}']/@name" $input
         exit 1
      fi
   done
}

DEFAULT_FORMAT=resourcexml

if [[ $# -eq 0 ]]
then
   FORMAT=$DEFAULT_FORMAT
else
   FORMAT=$1
fi

#tempory resources file
resourcesXmlTmp=$(mktemp)

# ensure all inputs are valid
checkInputResourceXmls

# assemble the inputs
assembleInputs > $resourcesXmlTmp 

# check results
checkResourcesXml $resourcesXmlTmp

# output the resources-xml file

#
# produce output in desired format
#
case $FORMAT in
   "resourcexml")
      cat $resourcesXmlTmp
      ;;
   "guardrailcsv")
      dumpNodes2GRCSV ${resourcesXmlTmp} guardrail_node
      ;;
   *)
      echo "invalid format $FORMAT" 1>&2
      exit 1
      ;;
esac



# delete temp file
rm -f $resourcesXmlTmp

