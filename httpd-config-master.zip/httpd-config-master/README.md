### httpd-config

Builder for the wsgc-httpd RPM package, which creates
/etc/logrotate.d/wsgc-httpd, ensures the presence of the apache and
webadmin users, and points /etc/httpd/logs to /var/log/weblogs/httpd.
