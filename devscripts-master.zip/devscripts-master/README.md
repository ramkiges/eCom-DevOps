# Developer Support Scripts & Tool Installer

This project provides common utility scripts to support developers, both
basic executable scripts as well as managed installs of tool distributions.

The goal is that developers can get the latest scripts and latest versions
of tools easily by checking out the current trunk and running setup. The
following instructions cover both initial setup and ongoing updates.

### Installing and Updating

When you want to install these scripts for the first time, or when you want
to update your installation do the following steps:

1) Checkout (or update your existing checkout) the dev scripts installers
   into a temp directory

   `git clone git@github.wsgc.com:eCommerce-DevOps/devscripts.git /tmp/devscripts`

2) Run the setup script:

   `/tmp/devscripts/setupdevscripts`

3) Remove the installers

   `rm -rf /tmp/devscripts`

### Additional First Time Setup

The very first time you set this up you need to add `$HOME/bin/devscripts` to
your path.

For bash users (most of you), add the following to your `~/.bashrc` file
(creating the file if it doesn't exist).
```
if [[ -d "$HOME/bin/devscripts" ]] ; then
    PATH="$PATH:$HOME/bin/devscripts"
fi
```
Secondly, if you don't have a `~/.bash_profile`, or you do have one but it
doesn't yet include your bashrc, add this to your `~/.bash_profile`:
```
if [[ -f ~/.bashrc ]]; then
    source ~/.bashrc
fi
```
Note this doesn't update your **current** shell, you'd need to execute
source `~/.bashrc` for that to take effect.

If you're using a shell other than bash then you'll have to do the
appropriate equivalent setup to include the devscripts directory in
your path.
