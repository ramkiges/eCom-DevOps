Typical webapps like tomcat require the following flag passed to java startup:

   -javaagent:/apps/apmagents/appagent/javaagent.jar

FOR OSGI Adobe CQ Support, see:

   http://community.appdynamics.com/t5/AppDynamics-Discussions/Problem-in-installing-appdynamic-agent-on-Adobe-CQ-5-6/td-p/8328

which says:

add:

org.osgi.framework.bootdelegation=com.singularity,com.singularity.*,com.appdynamics.*, com.appdynamics,com.yourkit.*, ${org.apache.sling.launcher.bootdelegation}
 
to:
 
{install_dir}/crx-quickstart/launchpad/sling.properties

however, this file does not exist until the stupid thing is already running.
How do we preconfigure it so that it comes up right the FIRST time?
