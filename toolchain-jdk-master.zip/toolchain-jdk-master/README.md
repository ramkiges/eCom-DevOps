# toolchain-jdk

This repository builds the various RPMs that will be used to install
Java on Linux boxes in the CI environment.

There's no auto-builder for this: you manually enter one of the
directories and run the `build.sh` script, and then manually upload
the RPM to the production Artifactory, in the `ext-release-local`
repository, in the `com/oracle/wsgc-jdk<n>` directory, e.g.:

 `com/oracle/wsgc-jdk8/1.8.0.45.x86_64/wsgc-jdk8-1.8.0.45.x86_64.rpm`

Note: It may be necessary to manually trigger an update of the YUM
metadata and remove the cached copies from ecyumrk1v and ecyumab1v
before attempting to install the package anywhere.

### Creating a New Builder (or Version of a Builder): Oracle JDKs

We use Oracle for Java 1.8 and earlier.

Grab the `.bin` version of the JDK from Oracle.  Grab the JCE policy
file for your version of Java.  Upload those to their expected names
in the `com/oracle/jdk` (_not_ `wsgc-jdk`) area of the
`ext-release-local` repository on the production Artifactory instance.

The `jce_policy` file goes in the `com/oracle/jce_policy` directory.

### Creating a New Builder (or Version of a Builder): Open JDK

It is anticipated that from Java 11 onward, we will be using Open JDK.

https://confluence.wsgc.com/display/ES/OpenJDK+Packaging+and+Migration

See the OpenJDK 11 builders for details.

### A Note on Certificates

Each JDK tarball includes the default certificates file in
`jdk/jre/lib/security/cacerts`.  

Currently we modify that to include WSI-signed root and intermediate 
certificates in order to make them implicitly available to all java 
applications.  This modified file is located in Artifactory in the 
`ext-release-local` repository, in the `com/oracle/cacerts-wsi/<x>`
directory, eg: 
 `com/oracle/cacerts-wsi/8/cacerts-wsi-8.zip`

If you need to create this from the defaults:

Copy `jdk/jre/lib/security/cacerts` into `src`, and locate your
`keytool` program in the `bin` directory of the Java that you're
wanting to install.

List the certs: `$KEYTOOL -list -keystore cacerts`

Import a certificate: `$KEYTOOL -keystore cacerts -importcert -alias
<alias> -file <file.cer>`

The default password for the cacerts file in all Oracle Java
installations is `changeit`.  Don't change it.

Name the modified file `src/cacerts-wsi`, zip it, and upload to 
Artifactory as above so the build script can find it.

### `/apps/jdk*` Symlinks

For the jdk1.6 and jdk1.7 dirs, their builds include the following
symlinks:

```
 /apps/jdk6 -> /apps/jdk1.6.0_45
 /apps/jdk7 -> /apps/jdk1.7.0_60
```

These symlinks allow a script to point `JAVA_HOME` to `/apps/jdk7`
without having to concern itself with the exact version, in case it
doesn't care.

Version 1.8 is more complicated, because this repo has many
directories that build packages that install JDK 1.8 variants, and we
want to be able to install more than one on the same box.  They can't
all install an `/apps/jdk8` symlink without conflicting with each
other.

Our solution is to have each such package be named `wsgc-jdk8-<N>`,
where `<N>` is the specific release number of the `1.8.0`
distribution, and for none of them to install an `/apps/jdk8` symlink.

The symlink will be managed by a package that manages _only_ the
symlink, with a package dependency on the version of Java it wants to
symlink to.  That dependency will be one of the `wsgc-jdk8-<N>`
packages, which may have already been installed, or will be brought in
by the symlink package if not.

Historically, the `wsgc-jdk8` package (built in the `8/jdk1.8` dir)
has been that for Java 1.8, except that instead of depending on the
relevant package to install Java, it installs it itself.

There are three things wrong with the way it does that:

1. By installing Java itself, it conflicts with any other package that
installs that same version of Java.
2. It manages the symlink using scriptlets, so RPM doesn't know it
owns that link.
3. Its scriptlets have a bug where they remove the script during an
upgrade of the package.

Because of (3), we can't upgrade `wsgc-jdk8` to a version of it that
fixes its ills without losing the symlink, so for machines that have
installed it, we consider them legacy installs and we won't bother
upgrading them.

The package `wsgc-jdk8-ci` is considered a proper replacement of
`wsgc-jdk8`.  It doesn't install Java by itself, but rather lets a
dependency handle that, and it lets RPM manage the symlink as a normal
part of its installation, allowing this to conflict with other
packages that try to install the same symlink.  The version of Java
this package depends on should be the most common version that is used
in production.

We consider the `8/jdk1.8` directory broken, and freeze it from
further change.

The `8/jdk1.8-latest` directory (building `wsgc-jdk8-latest`) is
similar to `jdk1.8`, in that it depends on a version of JDK 8 and
installs a symlink to it.  This version may or may not be the same as
that of `wsgc-jdk8`; its purpose is to enable us to run our own
scripts on a newer Java version than prod without interfering with
users of `wsgc-jdk8`.

This symlink-with-depends approach is continued for Java 11 and later.
