#!/bin/sh

RPM=$(ls RPMS/x86_64/wsgc-jdk8-202-1.8.0-202*rpm)

[[ -z $RPM ]] && exit 1

POM=$(echo $RPM | sed -es/\.rpm/\.pom/g)

cat > $POM << EOF
<?xml version="1.0" encoding="UTF-8"?>
<project xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd" xmlns="http://maven.apache.org/POM/4.0.0"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.oracle</groupId>
  <artifactId>wsgc-jdk8-202</artifactId>
  <version>1.8.0.202</version>
  <packaging>rpm</packaging>
  <description>Artifactory auto generated POM</description>
</project>
EOF

artifact-upload $RPM com/oracle/wsgc-jdk8-202/1.8.0.202
artifact-upload $POM com/oracle/wsgc-jdk8-202/1.8.0.202

