#!/bin/bash

JDK_ARCH=x86_64
JDK_VERSION=8
JDK_RELEASE=202
JDK_BUILD=14
JDK_DISTRO_VERSION=1.${JDK_VERSION}.0-${JDK_RELEASE}.${JDK_ARCH}
JCE_POLICY_VERSION=8
LOCAL_RELEASE=6

#FROM:
#http://download.oracle.com/otn-pub/java/jdk/${JDK_VERSION}u${JDK_RELEASE}-b${JDK_BUILD}/jdk-${JDK_VERSION}u${JDK_RELEASE}-linux-x64.tar.gz
#https://artifactory.wsgc.com/artifactory/ext-release-local/com/oracle/jdk/1.8.0-45.x86_64/jdk-1.8.0-45.x86_64-x64.tar.gz

if [[ "$(uname -p)" != "${JDK_ARCH}" ]]
then
    echo "uname -p (processor type) does not match defined JDK_ARCH: ${JDK_ARCH} " 1>&2
    exit 1
fi

rm -rf {BUILD,RPMS,SRPMS,SOURCES}
mkdir -p ./{BUILD,RPMS,SOURCES,SRPMS}

if [ ! -f SOURCES/jdk-${JDK_ARCH}.tar.gz ]
then
    # groupId: com.oracle
    # artifactId: jdk
    # version: 1.8.0-45.x86_64
    # filetype: tar.gz
    curl -k -o SOURCES/jdk-${JDK_ARCH}.tar.gz https://artifactory.wsgc.com/artifactory/ext-release-local/com/oracle/jdk/${JDK_DISTRO_VERSION}/jdk-${JDK_DISTRO_VERSION}.tar.gz
fi

if [ ! -f SOURCES/jce_policy.zip ]
then
    # groupId: com.oracle
    # artifactId: jce_policy
    # version: 8
    # filetype: zip
    curl -k -o SOURCES/jce_policy.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/oracle/jce_policy/${JCE_POLICY_VERSION}/jce_policy-${JCE_POLICY_VERSION}.zip
fi

if [ ! -f SOURCES/cacerts-wsi.zip ]
then
    # groupId: com.oracle
    # artifactId: cacerts-wsi.zip
    # version: 8
    # filetype: zip
    curl -k -o SOURCES/cacerts-wsi.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/oracle/cacerts-wsi/${JDK_VERSION}/cacerts-wsi-${JDK_VERSION}.zip
fi

if [ ! -f SOURCES/README ]
then
    cp src/README SOURCES/README
fi

rpmbuild --define="_topdir ${PWD}" --define="jdk_version ${JDK_VERSION}" --define="jdk_fullversion 1.${JDK_VERSION}.0" --define="local_release ${LOCAL_RELEASE}" --define="jdk_release ${JDK_RELEASE}" --define="jdk_arch ${JDK_ARCH}" -bb SPECS/wsgc-jdk8-$JDK_RELEASE.spec

