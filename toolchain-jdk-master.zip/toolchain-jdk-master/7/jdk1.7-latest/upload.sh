#!/bin/sh

JDK_VERSION=$(grep "^JDK_VERSION=" build.sh | awk -F= '{ print $2 }')

# massage the RPM name to fit our standards
ARTIFACT="wsgc-jdk${JDK_VERSION}-latest"
DST="com/oracle/$ARTIFACT"
RPM="$ARTIFACT.rpm"

# move the RPM to top-level directory and rename it to match our standard
cp $(find RPMS -name "*.rpm" 2>/dev/null) $RPM || echo "Can't find the new RPM"

# command line one would use to upload
artifactory-upload $RPM $DST

