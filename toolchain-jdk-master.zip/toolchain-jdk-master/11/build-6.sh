#!/bin/bash

export JDK_RELEASE=6
export LOCAL_RELEASE=4

cd openjdk11-n

./build.sh
