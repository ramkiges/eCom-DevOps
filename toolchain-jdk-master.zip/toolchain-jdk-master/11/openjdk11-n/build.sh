#!/bin/bash
#
# build.sh
#
# Caller must set JDK_RELEASE and LOCAL_RELEASE before calling us.
#
# LOCAL_RELEASE should be 0 for the first packaging of a given JDK_RELEASE,
# and then incremented for each updating of that JDK_RELEASE, should there
# be one.
#
# https://confluence.wsgc.com/display/ES/OpenJDK+Packaging+and+Migration
# source: https://adoptopenjdk.net/releases.html?variant=openjdk11&jvmVariant=hotspot

set -e
set -o nounset

JDK_VERSION=11.0
JDK_BUILD=10
JDK_ARCH=x86_64
JDK_DISTRO_VERSION=${JDK_VERSION}.${JDK_RELEASE}_${JDK_BUILD}.${JDK_ARCH}
JDK_GROUP=adoptopenjdk
JDK_LINK=$(echo $JDK_VERSION | awk -F\. '{ print $1 }')
JCE_POLICY_VERSION=11
WSI_CACERTS_VERSION=11

Die() {
    [ -n "$1" ] && echo "$*" >&2
    exit 1
}

[[ "$(uname -p)" != "${JDK_ARCH}" ]] && Die "uname -p (processor type) does not match defined JDK_ARCH: ${JDK_ARCH}"

# Clean up.
rm -rf BUILD RPMS SOURCES SRPMS
mkdir -p BUILD RPMS SOURCES SRPMS
rm -rf *.rpm

if [[ ! -f SOURCES/openjdk-${JDK_ARCH}.tar.gz ]]; then
    # groupId: com.adoptopenjdk
    # artifactId: jdk
    # version: 
    # filetype: tar.gz
    curl -qk -o SOURCES/openjdk-${JDK_ARCH}.tar.gz https://artifactory.wsgc.com/artifactory/ext-release-local/com/$JDK_GROUP/openjdk/${JDK_DISTRO_VERSION}/openjdk-${JDK_DISTRO_VERSION}.tar.gz || Die "Download of openjdk-${JDK_DISTRO_VERSION}.tar.gz failed"
    gunzip -t SOURCES/openjdk-${JDK_ARCH}.tar.gz || Die "File openjdk-${JDK_ARCH}.tar.gz is not valid"
fi

if [[ ! -f SOURCES/jce_policy.zip ]]; then
    # groupId: com.adoptopenjdk
    # artifactId: jce_policy
    # version: 11
    # filetype: zip
    curl -qk -o SOURCES/jce_policy.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/$JDK_GROUP/jce_policy/${JCE_POLICY_VERSION}/jce_policy-${JCE_POLICY_VERSION}.zip
    unzip -t SOURCES/jce_policy.zip || Die "File jce_policy.zip is not valid"
fi

if [[ ! -f SOURCES/cacerts-wsi.zip ]]; then
    # groupId: com.adoptopenjdk
    # artifactId: cacerts-wsi.zip
    # version: 11
    # filetype: zip
    curl -qk -o SOURCES/cacerts-wsi.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/$JDK_GROUP/cacerts-wsi/${WSI_CACERTS_VERSION}/cacerts-wsi-11.zip
    unzip -t SOURCES/cacerts-wsi.zip || Die "File cacerts-wsi.zip is not valid"
fi

[[ -f SOURCES/README ]] || cp src/README SOURCES/README

rpmbuild \
    --define="_topdir ${PWD}" \
    --define="jdk_release_dir openjdk-${JDK_VERSION}.${JDK_RELEASE}_${JDK_BUILD}" \
    --define="jdk_build ${JDK_BUILD}" \
    --define="jdk_link ${JDK_LINK}" \
    --define="jdk_version ${JDK_VERSION}" \
    --define="jdk_fullversion ${JDK_VERSION}" \
    --define="local_release ${LOCAL_RELEASE}" \
    --define="jdk_release ${JDK_RELEASE}" \
    --define="jdk_arch ${JDK_ARCH}" \
    -bb SPECS/wsgc-openjdk11-n.spec

ARTIFACT="wsgc-openjdk${JDK_LINK}-${JDK_VERSION}.${JDK_RELEASE}"
DST="com/adoptopenjdk/wsgc-openjdk${JDK_LINK}-${JDK_RELEASE}/${JDK_VERSION}.${JDK_RELEASE}"
RPM="$ARTIFACT.rpm"

# Move the RPM to top-level directory and rename it to match our standard.
cp $(find RPMS -name "*.rpm" 2>/dev/null) $RPM || Die "Can't find the new RPM"

# Command line one could use to upload.
echo artifactory-upload $RPM $DST
