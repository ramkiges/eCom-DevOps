#!/bin/bash -e

KEYSTORE="SOURCES/cacerts-wsi"

CERTS=$(keytool -list -keystore "$KEYSTORE"  -storepass changeit | grep 'trustedCertEntry' | cut -d',' -f1 | grep -e '^wsgc' -e '^wsi')

if [[ "$CERTS" == "" ]]; then
    echo "Did not find any WSI certs" 1>&2
    exit 1
fi

echo "Certs:" $CERTS 1>&2

JCERTS=
JCERTSFILE=$(find . -type f -name cacerts | tail -1)
if [[ "$JCERTSFILE" == "" ]]; then
    echo "Unable to find java certs." 1>&2
    exit 2
fi

echo "Java Certs: $JCERTSFILE" 1>&2

umask 0022

if [[ -f "${JCERTSFILE}-orig" ]]; then
    echo "Original certs file already exists..." 1>&2
else
    echo "Making backup as ${JCERTSFILE}-orig" 1>&2
    CERTDIR=$(dirname "$JCERTSFILE")
ls -ld $CERTDIR
    if [[ -w "$CERTDIR" ]]; then
        cp "${JCERTSFILE}" "${JCERTSFILE}-orig"
    else
        echo "Unable to write to ${CERTDIR}; Using sudo..." 1>&2
        sudo cp "${JCERTSFILE}" "${JCERTSFILE}-orig"
    fi
fi

TEMPCERTS=$(mktemp)
cp "$JCERTSFILE" "$TEMPCERTS"

ANYIMPORT=0

JCERTS=$(keytool -list -keystore "$TEMPCERTS" -storepass changeit | grep 'trustedCertEntry' | cut -d',' -f1 | grep -e '^wsgc' -e '^wsi' || true)

for cert in $CERTS; do
    echo "Checking '$cert'" 1>&2
    if [[ $(echo "$JCERTS" | grep -F "$cert" || true) != "" ]]; then
        echo "  Already present." 1>&2
        continue;
    fi
    echo "  Not present." 1>&2

    TEMPCERT=$(mktemp)

    keytool -exportcert -keystore "$KEYSTORE" -storepass changeit -alias "$cert" > $TEMPCERT
    keytool -noprompt -importcert -keystore "$TEMPCERTS" -storepass changeit -alias "$cert" -file "$TEMPCERT"

    rm -f "$TEMPCERT"

    ANYIMPORT="1"
done

if [[ "$ANYIMPORT" == "1" ]]; then
    echo "Changes were made.. replacing cacerts" 1>&2

    if [[ -w "$JCERTSFILE" ]]; then
        cp -f "${TEMPCERTS}" "${JCERTSFILE}"
    else
        echo "Unable to write to ${CERTDIR}; Using sudo..." 1>&2
        sudo cp -f "${TEMPCERTS}" "${JCERTSFILE}"
    fi
fi

rm -f "$TEMPCERTS"

exit 0
