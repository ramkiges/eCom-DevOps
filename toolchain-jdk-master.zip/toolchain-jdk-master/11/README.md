# Open JDK 11 builders

For all the releases `<n>` of Open JDK 11 that we currently install,
there should be a `build-<n>.sh` builder in this directory.  These
builders use the script and source file in `openjdk11-n` to build
their given release.

The resulting RPMs install themselves in `/apps/openjdk11.0.<n>`.  To
generate a symlink `/apps/jdk11` that points to a specific install,
build in the `jdk11-symlink` directory, customizing it for the desired
release.

This allows us to install as many releases on a box as we want, and
for users who want a symlink that points to the "current" prod/CI
release of Open JDK 11, they can install the symlink package, and
point their `JAVA_HOME` to `/apps/jdk11`, without worrying about what
that specific release is.
