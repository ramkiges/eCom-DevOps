#!/bin/sh

RELEASE=$(grep JDK_RELEASE build*sh | awk -F= '{ print $2 }')

artifact-upload openjdk11-n/wsgc-openjdk11*.rpm com/adoptopenjdk/wsgc-openjdk11-$RELEASE/11.0.$RELEASE

