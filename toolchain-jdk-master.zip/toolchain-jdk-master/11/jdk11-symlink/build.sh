#!/bin/bash

set -o nounset
set -e

# Increment this when releasing a new version of this package.
# This is the primary determiner of whether this is seen by rpm
# as a newer package than another version of us.
PACKAGE_VERSION=2

JDK_ARCH=x86_64
JDK_VERSION=11
JDK_RELEASE=6

if [[ $(uname -p) != $JDK_ARCH ]]; then
    echo "uname -p (processor type) does not match defined JDK_ARCH: $JDK_ARCH" >&2
    exit 1
fi

rm -rf BUILD RPMS SRPMS SOURCES
mkdir -p BUILD RPMS SOURCES SRPMS

rpmbuild --define="_topdir $PWD" \
         --define="package_version $PACKAGE_VERSION" \
         --define="jdk_version $JDK_VERSION" \
         --define="jdk_release $JDK_RELEASE" \
         --define="jdk_arch $JDK_ARCH" \
         -bb SPECS/wsgc-jdk11.spec
