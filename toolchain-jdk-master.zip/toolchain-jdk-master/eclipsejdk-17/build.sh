#!/bin/bash
# https://confluence.wsgc.com/pages/editpage.action?pageId=126648457
# source: https://adoptopenjdk.net/releases.html?variant=openjdk11&jvmVariant=hotspot

JDK_VERSION=17.0
JDK_RELEASE=4
JDK_BUILD=1+1
JDK_ARCH=x86_64
JDK_DISTRO_VERSION=${JDK_VERSION}.${JDK_RELEASE}.${JDK_BUILD}
#JDK_GROUP1=adoptium
JDK_GROUP=adoptopenjdk
JDK_LINK=$(echo $JDK_VERSION | awk -F\. '{ print $1 }')

JCE_POLICY_VERSION=11

WSI_CACERTS_VERSION=17

LOCAL_RELEASE=0

Die() {
    [ -n "$1" ] && echo "$*"
    exit 1
}

[[ "$(uname -p)" != "${JDK_ARCH}" ]] && Die "uname -p (processor type) does not match defined JDK_ARCH: ${JDK_ARCH} " 1>&2

# clean up
rm -rf {BUILD,RPMS,SRPMS,SOURCES}
mkdir -p ./{BUILD,RPMS,SOURCES,SRPMS}
rm -rf *.rpm *.pom

if [ ! -f SOURCES/openjdk-${JDK_ARCH}.tar ]
then
    # groupId: com.adoptopenjdk
    # artifactId: jdk
    # version: 
    # filetype: tar.gz
    curl -qk -o SOURCES/openjdk-${JDK_ARCH}.tar https://artifactory.wsgc.com/artifactory/ext-release-local/net/adoptium/temurin/jdk-${JDK_DISTRO_VERSION}.tar || Die "Download of openjdk-${JDK_DISTRO_VERSION}.tar failed"
    gzip  SOURCES/openjdk-${JDK_ARCH}.tar || Die "File openjdk-${JDK_ARCH}.tar is not valid"
fi
#3https://artifactory.wsgc.com/artifactory/ext-release-local/com/adoptopenjdk/openjdk/17.0.2.x86_64/openjdk-17.0.2.x86_64.tar.gz
#https://artifactory.wsgc.com/artifactory/ext-release-local/net/adoptium/temurin/jdk-17.0.4.1+1.tar
if [ ! -f SOURCES/jce_policy.zip ]
then
    # groupId: com.adoptopenjdk
    # artifactId: jce_policy
    # version: 11
    # filetype: zip
    curl -qk -o SOURCES/jce_policy.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/$JDK_GROUP/jce_policy/${JCE_POLICY_VERSION}/jce_policy-${JCE_POLICY_VERSION}.zip
    unzip -t SOURCES/jce_policy.zip || Die "File jce_policy.zip is not valid"
fi


if [ ! -f SOURCES/cacerts-wsi.zip ]
then
    # groupId: com.adoptopenjdk
    # artifactId: cacerts-wsi.zip
    # version: 17
    # filetype: zip
    curl -qk -o SOURCES/cacerts-wsi.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/$JDK_GROUP/cacerts-wsi/${WSI_CACERTS_VERSION}/cacerts-wsi-17.zip
    unzip -t SOURCES/cacerts-wsi.zip || Die "File cacerts-wsi.zip is not valid"
fi
#https://artifactory.wsgc.com/artifactory/ext-release-local/com/adoptopenjdk/cacerts-wsi/17/cacerts-wsi-17.zip
[ -f SOURCES/README ] || cp src/README SOURCES/README

rpmbuild \
    --define="_topdir ${PWD}" \
    --define="jdk_release_dir jdk-${JDK_VERSION}.${JDK_RELEASE}.${JDK_BUILD}" \
    --define="jdk_build ${JDK_BUILD}" \
    --define="jdk_link ${JDK_LINK}" \
    --define="jdk_version ${JDK_VERSION}" \
    --define="jdk_fullversion ${JDK_VERSION}" \
    --define="local_release ${LOCAL_RELEASE}" \
    --define="jdk_release ${JDK_RELEASE}" \
    --define="jdk_arch ${JDK_ARCH}" \
    -bb SPECS/wsgc-openjdk17-$JDK_RELEASE.spec

ARTIFACT="wsgc-jdk${JDK_LINK}-${JDK_VERSION}.${JDK_RELEASE}"
DST="com/adoptopenjdk/wsgc-jdk${JDK_LINK}-${JDK_RELEASE}/${JDK_VERSION}.${JDK_RELEASE}"
RPM="$ARTIFACT.rpm"

# move the RPM to top-level directory and rename it to match our standard
cp $(find RPMS -name "*.rpm" 2>/dev/null) $RPM || Die "Can't find the new RPM"

# command line one would use to upload
echo artifactory-upload $RPM $DST
