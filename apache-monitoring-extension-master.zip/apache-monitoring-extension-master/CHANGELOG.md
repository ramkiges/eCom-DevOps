# AppDynamics Extensions Apache CHANGELOG

## 2.0.4 - Jan 4, 2021
1. Updated to appd-exts-commons 2.2.4

## 2.0.3 - Jul 15, 2020
1. Fixed issue for useSSL flag

## 2.0.2 - Apr 28, 2020
1. Moved to commons 2.2.2 version

## 2.0.1 - Oct 23, 2018
1. Fixed phaser bug.

## 2.0.0 - May 14, 2018
1. Moved Apache Status Monitor to 2.0.0 framework
2. Moved metrics configurations from config.yml to metrics.xml
3. Moved customStats from config.yml to metrics.xml

### 1.0.0
1. Initial open source release
