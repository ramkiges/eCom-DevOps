#!/usr/bin/env python3

"""
Take config from 'etcd-syncapp-config' service as an input in json format.

Sample args     json          : { 'etcd_syncapp_config' : { 'customerMfe' : { 'uri' : 'getUrl(services.ecom-app-shop)' } }, 'pkg_branch' : 'eCommerce-Tahoe/all-nonprod-session', 'pkg_version' : '' }
                manifest_env  : qa32
Add new services with auto-generated links to the values.yaml from 'etcd-syncappconfig-helm-config' repo. 
Delete services from values.yaml from 'etcd-syncappconfig-helm-config' repo if they are no longer present in the current config.
"""

import io
import os
import re
import sys
import json
import requests
import ruamel.yaml
from urllib3.exceptions import InsecureRequestWarning

from modules import utils

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True
yaml.width = 250

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

etcd_syncapp = json.loads(sys.argv[1])
config = json.loads(etcd_syncapp['etcd_syncapp_config'])
etcd_branch = etcd_syncapp['helm_config_pkg_branch']
etcd_version = etcd_syncapp['helm_config_pkg_version']
manifest_env = sys.argv[2]

user = utils.getCredential('jenkins', 'user')
password = utils.getCredential('jenkins', 'password')

with open(f'../../manifest/env-manifest/{manifest_env}/services-manifest.yaml', 'r') as stream:
    manifest = yaml.load(stream)

if 'pkg_branch' in manifest['services']['etcd-syncapp-config']['packaging']:
    print(f'Checking for services to be added/deleted for etcd-syncapp-config for branch {etcd_branch}')
    os.chdir('../../etcd-syncappconfig-helm-config')

    with open(f'config/{manifest_env}/values.yaml', 'r') as stream:
        values = yaml.load(stream)

    with open('config/values.yaml', 'r') as stream:
        common_values = yaml.load(stream)

    # create a list of services in the remote common config
    remote_common_values = []
    for service in common_values['services']:
        remote_common_values.append(service)

    # create a list of services in the remote config
    remote_values = []
    for service in values['services']:
        remote_values.append(service)

    # create a list of services in the current config
    current_values = []
    for service, v in config.items():
        current_values.append(service)

    # based on lists of services create sets for adding and deleting
    service_add = set(current_values) - set(remote_values).union(set(remote_common_values))
    all_current_services_in_repo = set(remote_values).union(set(remote_common_values))
    service_del = set(remote_values).union(set(remote_common_values)) - set(current_values)
    output_values = values

    print(f'New services to be added to env {manifest_env} values.yaml: {service_add}')
    print(f'Services to be deleted from env {manifest_env} values.yaml: {service_del}')

    # create new list of services without the one being deleted
    if service_del != set():
        out = yaml.load('services: {}')
        for item in values['services']:
            if item not in service_del:
                dump = io.StringIO('')
                yaml.dump(values['services'][item], dump)
                out['services'][f'{item}'] = yaml.load(dump.getvalue())
        dump = io.StringIO('')
        yaml.dump(out['services'], dump)
        output_values['services'] = yaml.load(dump.getvalue())

    for service, link in config.items():
        if (service in all_current_services_in_repo or service in service_add) and service not in service_del:
            print(f'Service check in process for {service}')
            for uri, pointer in link.items():
                # geting service name from sample like: 'getUrl(services.delivery-gateway)'
                current_name = ''.join(re.findall('.*\(services\.(.*)\).*', pointer))                  

                if service == 'dp' or service == 'dpStoreEndpoint':
                    if service not in output_values['services']:
                        output_values['services'][service] = {}
                    output_values['services'][service][uri] = pointer
                else:
                    if current_name not in manifest['services']:
                        sys.exit(
                            f'The service {current_name} needs to be defined in the manifest '
                            'along with adding it to the etcd-syncapp-config')
                    else:
                        current_env = manifest['services'][current_name]['configuration']['services-collection-manifest']

                    with open(f'../manifest/services-collection-manifest/{current_env}/services-manifest.yaml', 'r') as stream:
                        current_manifest = yaml.load(stream)

                    if current_name not in current_manifest['services']:
                        sys.exit(
                            f'{current_name} needs to be defined in the {current_env} services-collection-manifest '
                            'before it can be added to the etcd-syncapp-config')

                    service_name = current_manifest['services'][current_name]['name']
                    service_org = current_manifest['services'][current_name]['org']
                    new_link = utils.generate_config_url(service_name, current_env, service_org, pointer)

                uriKey = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES.get(service, 'uri')
                if service in all_current_services_in_repo and service not in ['dp', 'dpStoreEndpoint']:
                    if service in remote_values:
                        current_link = values['services'][service][uriKey]
                    else:
                        current_link = common_values['services'][service][uriKey]

                    if new_link != current_link:
                        output_values['services'][service] = {uri: new_link}
                        print(
                            f'Service {service} to be overriden in etcd-syncapp repo values.yaml for '
                            f'env {manifest_env} from old uri {current_link} to new uri as {new_link}')

                if service in service_add:
                    output_values['services'][service] = {uri: new_link}
                    print(
                        f'New service {service} to be added in etcd-syncapp repo values.yaml for '
                        f'env {manifest_env} with uri as {new_link}')

    with open(f'config/{manifest_env}/values.yaml', 'w') as stream:
        yaml.dump(output_values, stream)
