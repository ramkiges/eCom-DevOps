#!/usr/bin/env python3

import sys
import argparse
import yaml
import re
import os
from modules import utils


def check_helm_endpoints(env):
    path = utils.ENV_MANIFEST_PATH.format(env=env)

    with open(f'../{path}', 'r') as file:
        env_manifest = yaml.safe_load(file)['services']

    endpoints_validation_output = ""
    apps_to_check = []
    for app_title, app_entry in env_manifest.items():
        if not bool(re.match(r'(etcd-syncapp-config|frontend)', app_title)):
            apps_to_check.append({'app_name': app_title, 'subscribed_env': env_manifest[app_title]['configuration']['services-collection-manifest']})

    for obj in apps_to_check:
        app_name, subscribedEnv = obj['app_name'], obj['subscribed_env']

        subscribedManifestPath = f'../{utils.SERVICES_MANIFEST_PATH.format(env=subscribedEnv)}'
        if not os.path.exists(subscribedManifestPath):
            endpoints_validation_output += f"There exists no {subscribedEnv} instance of service '{app_name}' in " \
                                           f"services_collection manifest. Please fix your env-manifest to subscribe to " \
                                           f"correct instance of {app_name} \n\n"
            continue

        with open(subscribedManifestPath, 'r') as file:
            services_manifest = yaml.safe_load(file)

        properties = services_manifest['services'][app_name].get('configuration', {})
        endpoints = {}
        if properties:
            utils.getAllProperties('', properties, endpoints)
            for key, url in endpoints.items():
                serviceName, serviceEnv = utils.extractServiceNameAndEnv(url)
                if not serviceName:
                    endpoints_validation_output += f"Could not extract service name and env name from helm config url " \
                                                   f"{url} with key as {key} defined by the service '{app_name}' subscribed to " \
                                                   f"{subscribedEnv}. Manifest only supports ecom based helm config " \
                                                   f"urls in helm config. For non ecom helm config urls update directly" \
                                                   f"in helm config repo \n\n"
                else:
                    correctEnv, servicePresent = False, serviceName in env_manifest
                    if not servicePresent:
                        endpoints_validation_output += f"env-manifest for {env} should define service '{serviceName}' subscribed " \
                                                       f"to env {serviceEnv} as referenced by helm-config-property uri " \
                                                       f"in \nname: {app_name}\n  services-collection-manifest: " \
                                                       f"{subscribedEnv}\n  {key}: {url}\n\n"
                        continue

                    manifestServiceEnv = env_manifest[serviceName]['configuration']['services-collection-manifest']
                    if serviceName in utils.SERVICE_NAME_ENV_MAPPING:
                        if manifestServiceEnv in utils.SERVICE_NAME_ENV_MAPPING[serviceName]:
                            manifestServiceEnv = utils.SERVICE_NAME_ENV_MAPPING[serviceName][manifestServiceEnv]['manifest_env']

                    if manifestServiceEnv == serviceEnv:
                        correctEnv = True

                    if not correctEnv:
                        endpoints_validation_output += f"The service {serviceName} in {env} env-manifest should be subscribed " \
                                                       f"to a correct instance.\nManifest defines the env as \n" \
                                                       f"name: {serviceName}\n  services-collection-manifest: " \
                                                       f"{manifestServiceEnv}\nbut helm-config property uri has env {serviceEnv} " \
                                                       f"referenced by \nname: {app_name}\n services-collection-manifest: {subscribedEnv}\n  " \
                                                       f"{key}: {url}\n\n"

    return endpoints_validation_output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--env_changed', type=str, required=True)
    parser.add_argument('--manifest_type', type=str, required=True)
    args = parser.parse_args()

    env_changed = args.env_changed
    manifest_type = args.manifest_type

    if manifest_type == 'env-manifest':
        check_result = check_helm_endpoints(env_changed)
        if check_result:
            print("WARNING: There are below asymmetrical config that needs to be fixed:\n")
            print(check_result)
    else:
        sys.exit(0)
