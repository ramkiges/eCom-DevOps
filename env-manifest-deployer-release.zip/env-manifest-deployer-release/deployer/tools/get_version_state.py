#!/usr/bin/env python3

import json
import sys
from modules import processing_utils, utils

input = sys.stdin.read()
input_json = json.loads(input)
namespace = input_json.get('namespace')
app_org = input_json.get('app_org')
package_type = input_json.get('type')
name = input_json.get('name') 
module_name = input_json.get('module_name')
package_version = input_json.get('package_version')
app_env = input_json.get('app_env')
protected_env = input_json.get('protected_env')

if name == "etcd-syncapp-config":
    output = {}
    if package_version != "":
        output["helm_version_exist"] = str(utils.check_git_branch('git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/etcd-syncappconfig-helm-config.git', f'{package_version}'))
    else:
        output["helm_version_exist"] = "False"
    output["app_name"] = name
    output["app_org"] = app_org
    output["app_namespace"] = namespace
else:
    output = processing_utils.get_packaging_version(namespace, app_org, package_type, name, module_name, package_version, protected_env)
    output["package_version"] = package_version
    output["app_name"] = name
    output["app_org"] = app_org
    output["app_namespace"] = namespace
    
print(json.dumps(output))
