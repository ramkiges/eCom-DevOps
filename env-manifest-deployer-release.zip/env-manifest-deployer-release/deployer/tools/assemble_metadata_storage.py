#!/usr/bin/env python3

"""
The script assembles a unified dictionary containing all applications that have at least one subscriber 
and flags `require_fixed_versions` and `protected` for the apps from subscribers as well

Example output data:

    "uat": {
        "ecom-app-registry": {
            "require_fixed_versions": true,
            "protected": false
        },
        "ecom-app-phygital": {
            "require_fixed_versions": false,
            "protected": false
        }
    }

Example run:
    python3 tools/assemble_metadata_storage.py --env_manifest_location ../manifest/env-manifest
"""

import argparse
import os
import yaml
import json
import re
from modules import utils


def update_metadata_flags(metadata_flags, parent_env, client_env, app_title, protected, require_fixed_versions):

    if parent_env not in metadata_flags:
        metadata_flags[parent_env] = {}
    
    if app_title not in metadata_flags[parent_env]:
        metadata_flags[parent_env][app_title]= {
            'require_fixed_versions': {
                'value': False,
                'subs': []
            }, 
            'protected': {
                'value': False,
                'subs': []
            }
        }

    if require_fixed_versions:
        metadata_flags[parent_env][app_title]['require_fixed_versions']['value'] = True
        # metadata_flags[parent_env][app_title]['require_fixed_versions']['subs'].append(client_env)
    if protected:
        metadata_flags[parent_env][app_title]['protected']['value'] = True
        # metadata_flags[parent_env][app_title]['protected']['subs'].append(client_env)


def main(env_manifest_location):

    metadata_flags = {}
    env_list = []

    for item, _, _ in os.walk(f'{env_manifest_location}/'):
        if os.path.isdir(item):
            if os.path.basename(item):
                env_list.append(os.path.basename(item))

    for env_name in env_list:
        env_manifest = {}
        env_manifest_path = f"../{utils.ENV_MANIFEST_PATH.format(env=env_name)}"
            
        with open(env_manifest_path, 'r') as stream:
            env_manifest = yaml.safe_load(stream)

        protected = env_manifest.get('metadata', {}).get('protected', False)
        require_fixed_versions = env_manifest.get('metadata', {}).get('require_fixed_versions', False)

        for app_title, app_entry in env_manifest['services'].items():
            if  not bool(re.match(r'(etcd-syncapp-config|frontend)', app_title)):
                parent_env = app_entry['configuration']['services-collection-manifest']
                update_metadata_flags(metadata_flags, parent_env, env_name, app_title, protected, require_fixed_versions)

    return metadata_flags


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--env_manifest_location', type=str, required=True, help='The directory where all env-manifests are stored')
    args = parser.parse_args()

    metadata_flags = main(args.env_manifest_location)

    with open(utils.METADATA_FLAGS_FILENAME, 'w') as file:
        file.write(json.dumps(metadata_flags, indent=2))
