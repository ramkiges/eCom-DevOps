#!/usr/bin/env python3
"""
Module to compare the helm endpoints defined in a manifest against the actual endpoints
defined in the helm config git tag or repo branch and perform the validations.
The output returned consists of the drift details if the endpoints does not match during
the config drift state.
The output also contains the validation text string which is empty if all validations are
successful else it contains the messages for the failed validations.
"""
import copy
import json
import sys
import ruamel.yaml
import os
import subprocess
from modules import utils
import time

# ruamel yaml supports having comments in the yaml file when auto generating the yaml files which pyyaml does not
# support. It's needed to keep the comments in the values.yaml files which already exists and is auto updated by
# the env-manifest tooling elsewhere (not in this script). Since Pyyaml does not support that, we decided to use
# ruamel yaml everywhere in the project
yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True


def getActualHelmEndPoints(app_name, app_env, properties, helm_config_pkg_version, helm_config_pkg_branch, repo_path):
    """
    Get the actual helm endpoints from the helm config released tag or branch and compare it with the one
    from manifest. If they do not match, it's a drift and can be used in the config drift stage by adding
    the drift details to the output.
    For the non-drift stage when terraform plan is run, it also performs the below validations and adds the details
    to the output.
    1. If helm config released version is used, the helm endpoints in manifest should match the one from the released tag
    2. If helm config branch is used, the service within the helm endpoint should be defined in the manifest and the env
    should match in the owner as well as in consumer manifests
    """

    isHelmEndPointsUpdated = False
    valuesFiles = [os.path.join(f'{repo_path}/config', 'values.yaml')]

    envValueFile = os.path.join(f'{repo_path}/config', app_env, 'values.yaml')
    if os.path.exists(envValueFile):
        valuesFiles.append(envValueFile)

    # combining the common and env values.yaml
    values = utils.readCombinedYaml(valuesFiles)

    # Drift details with key as the helm property consisting of drift and value as current and actual value
    # for the helm endpoint. It only consists of properties for which the current value and actual value are different.
    # {"applicationProperties:favorites.service.uri" : { "Current": <favpropvalue>, "Actual": <favpropvalue1> }}
    driftDetails = {}

    # This consists of details in the same format as driftDetails except that it consists of all helm config endpoints
    allServiceDetails = {}
    for propKeyPath, propValue in properties.items():
        valuesObj = copy.deepcopy(values)
        propKeys = propKeyPath.split(":")
        for propKey in propKeys:
            if propKey in valuesObj:
                valuesObj = valuesObj[propKey]
            else:
                valuesObj = ""
                break

        key = ".".join(propKeys)
        if propValue != valuesObj:
            isHelmEndPointsUpdated = True  # to update the trigger value
            driftDetails[key] = {"Current": propValue, "Actual": valuesObj}

        allServiceDetails[key] = {"Current": propValue, "Actual": valuesObj}

    # Adding the drift details to output, so it can directly be used in the drift computation script.
    output["driftDetails"] = json.dumps(driftDetails)

    if (helm_config_pkg_branch or helm_config_pkg_version) and len(allServiceDetails) > 0:
        service_validation_output = ""
        serviceNameEnvVisited = {}
        for helmUrlKey, helmUrlValue in allServiceDetails.items():
            manifestHelmUrl = helmUrlValue["Current"]
            # extracting service name and env from the helm endpoint
            serviceName, serviceEnv = utils.extractServiceNameAndEnv(manifestHelmUrl)
            if not serviceName:
                service_validation_output += f"Could not extract service name and env name from helm config url " \
                                             f"{manifestHelmUrl} with key as {helmUrlKey}\n"
                continue

            serviceNameEnv = f"{serviceName}_{serviceEnv}"
            if serviceNameEnv not in serviceNameEnvVisited:  # avoid duplication
                # perform validations
                service_validation_output += utils.serviceValidationCheckForAllConsumers(
                    serviceName, serviceEnv, manifestHelmUrl, helmUrlKey, app_name, app_env)
                serviceNameEnvVisited[serviceNameEnv] = True

        output["validation_check"] = service_validation_output

    return isHelmEndPointsUpdated


def getAndCompareActualHelmEndpointsConfig(app_name, app_env, helm_config_pkg_branch,
                                           helm_config_pkg_version, properties):
    """Compare the helm endpoints in the manifest with the source and perform validations"""

    repo_path = utils.checkoutrepo(app_name, app_env, helm_config_pkg_branch, helm_config_pkg_version, "helm")
    return getActualHelmEndPoints(
        app_name, app_env, properties, helm_config_pkg_version, helm_config_pkg_branch, repo_path)


input = sys.stdin.read()
input_json = json.loads(input)

app_name = input_json.get("app_name")
module_name = input_json.get("module_name")
helm_config_pkg_branch = input_json.get("helm_config_pkg_branch")
helm_config_pkg_version = input_json.get("helm_config_pkg_version")
app_org = input_json.get("app_org")
app_env = input_json.get("app_env")
helm_endpoints_configuration = input_json.get("helm_endpoints_configuration")

# Initializing output variables.
output = {
    "helm_endpoints_configuration": helm_endpoints_configuration,
    "validation_check": "",  # default validation check is success
    "is_validation_failures": "false"  # default validation check is success
}

# Read from terraform state and initialize trigger value to what the state has currently to avoid unnecessary trigger of resource
trigger = ""
configuration = {}
isUpdateTrigger = False
if os.path.exists("terraform.tfstate"):
    cmd = "terraform show -json terraform.tfstate"
    cmd = cmd.split()

    subprocessArgs = {
        'args': cmd,
        'check': False,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }

    try:
        result = subprocess.run(**subprocessArgs)
        outtext = result.stdout
        if outtext and outtext != "":
            tfstate = json.loads(outtext)
            child_modules = tfstate["values"]["root_module"]["child_modules"]
            for child_module in child_modules:
                if child_module.get("address", "") == f"module.helm-services-module[\"{module_name}\"]":
                    if "resources" in child_module:
                        for resource in child_module["resources"]:
                            if "helm_config_endpoint_update" in resource["address"]:
                                trigger = resource["values"]["triggers"].get("trigger", "")
                                configuration = resource["values"]["triggers"].get("helm_endpoints_configuration", {})
    except subprocess.CalledProcessError as err:
        sys.exit(f"Exception when calling subprocess: {err.stderr}")


helm_endpoints_config_obj = yaml.load(helm_endpoints_configuration)
if len(helm_endpoints_config_obj) != 0:
    properties = {}
    utils.getAllProperties("", helm_endpoints_config_obj, properties)
    if helm_endpoints_configuration != configuration:
        isUpdateTrigger = getAndCompareActualHelmEndpointsConfig(
            app_name, app_env, helm_config_pkg_branch, helm_config_pkg_version, properties)
    if isUpdateTrigger:
        trigger = str(time.time()) # update the trigger value

output["trigger"] = trigger

validation_check = output["validation_check"]
if validation_check != "":
    output["is_validation_failures"] = "true"

print(json.dumps(output))
