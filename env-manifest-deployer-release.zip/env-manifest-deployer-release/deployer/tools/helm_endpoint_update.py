#!/usr/bin/env python3
"""
Module to compute the helm endpoints to be deleted from the packaging repo and also the helm endpoints to be
added and updated to the packaging repo and perform the updates.
Arguments:
    Arg 1: endpoint yaml config string:
    Arg 2: Packaging branch path: eCommerce-Kubernetes-Bedrock/ecom-app-shop-helm-config/release
    Arg 3: App env: qa32
    Arg 4: Module name: ecom-app-shop
    Arg 5: App type: helm or legacy-helm
"""
import json
import sys
import os
import subprocess
import time

from modules import utils
import copy
import ruamel.yaml

yaml = ruamel.yaml.YAML()
yaml.preserve_quotes = True
yaml.allow_duplicate_keys = True

app_type = sys.argv[5]

endpoints_configuration = yaml.load(sys.argv[1])
if app_type == "helm":
    helm_endpoints_config_obj = yaml.load(endpoints_configuration["helm_endpoints_configuration"])
else:
    helm_endpoints_config_obj = yaml.load(endpoints_configuration["legacy_endpoints_configuration"])
packaging_branch_path = sys.argv[2]
app_env = sys.argv[3]
module_name = sys.argv[4]


def find_deleted_endpoints(module_name, properties):
    """
    Finds the helm endpoints which are deleted from the manifest by comparing the terraform current state properties
    with the one from manifest
    """

    deletedKeys = set()
    if os.path.exists("terraform.tfstate"):
        cmd = "terraform show -json terraform.tfstate"
        cmd = cmd.split()

        subprocessArgs = {
            'args': cmd,
            'check': False,
            'encoding': 'UTF-8',
            'universal_newlines': True,
            'capture_output': True
        }

        try:
            result = subprocess.run(**subprocessArgs)
            outtext = result.stdout
            if outtext and outtext != "":
                tfstate = json.loads(outtext)
                child_modules = tfstate["values"]["root_module"]["child_modules"]
                for child_module in child_modules:
                    if app_type == "helm":
                        if child_module.get("address", "") == f"module.helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "helm_config_endpoint_update" in resource["address"]:
                                        # get current helm endpoints from terraform state
                                        current_state_helm_endpoints_configuration = resource["values"]["triggers"]["helm_endpoints_configuration"]
                                        current_state_helm_endpoints_configuration = json.loads(current_state_helm_endpoints_configuration)

                                        # flatten the properties into the map
                                        current_properties = {}
                                        utils.getAllProperties("", current_state_helm_endpoints_configuration, current_properties)

                                        # Diff will give the deleted endpoints
                                        deletedKeys = set(current_properties.keys()).difference(properties.keys())
                    else:
                        if child_module.get("address", "") == f"module.legacy-helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "legacy_config_endpoint_update" in resource["address"]:
                                        # get current helm endpoints from terraform state
                                        current_state_helm_endpoints_configuration = resource["values"]["triggers"]["legacy_endpoints_configuration"]
                                        current_state_helm_endpoints_configuration = json.loads(current_state_helm_endpoints_configuration)

                                        # flatten the properties into the map
                                        current_properties = {}
                                        utils.getAllProperties("", current_state_helm_endpoints_configuration, current_properties)

                                        # Diff will give the deleted endpoints
                                        deletedKeys = set(current_properties.keys()).difference(properties.keys())
        except subprocess.CalledProcessError:
            sys.exit(f"Exception when calling subprocess: {subprocess.CalledProcessError.stderr}")
    return deletedKeys


def update_helm_config_endpoints(packaging_branch_path, app_env, properties, deletedKeysPaths):
    """
    Add/Update and delete helm config endpoints from the helm repo branch based on the manifest update and push the
    changes
    """
    helm_config_org = packaging_branch_path.split('/')[0]
    helm_config_repo = packaging_branch_path.split('/')[1]
    helm_config_branch = packaging_branch_path.split('/')[2]

    repo_clone_dir = f'../../temp_dir_{app_env}_{helm_config_repo}'
    if os.path.isdir(repo_clone_dir):
        # Start from clean slate
        print(f"Deleting old copy of {repo_clone_dir} dir")
        subprocess.run(['rm', '-rf', repo_clone_dir])

    os.mkdir(repo_clone_dir)
    os.chdir(repo_clone_dir)
    subprocess.run(['git', 'clone', f'git@github.wsgc.com:{helm_config_org}/{helm_config_repo}.git'])
    os.chdir(helm_config_repo)
    subprocess.run(['git', 'checkout', helm_config_branch])

    if app_type == "helm":
        valuesFilePath = "config"
    else:
        valuesFilePath = "src/main/helm/config"
    valuesFiles = [os.path.join(valuesFilePath, 'values.yaml')]

    envValueFile = os.path.join(valuesFilePath, app_env, 'values.yaml')
    if os.path.exists(envValueFile):
        valuesFiles.append(envValueFile)

    # combine common and env values.yaml file
    values = utils.readCombinedYaml(valuesFiles)

    # Check for the helm endpoints which are added/updated and add to the dictionary
    add_updated_keys = {}
    for propKeyPath, propValue in properties.items():
        valuesObj = copy.deepcopy(values)
        propKeys = propKeyPath.split(":")
        for propKey in propKeys:
            if propKey in valuesObj:
                valuesObj = valuesObj[propKey]
            else:
                valuesObj = ""
                break

        if propValue != valuesObj:
            print(f"Adding to add update key {propKeyPath}: {propValue}")
            add_updated_keys[propKeyPath] = propValue

    if os.path.exists(envValueFile):
        with open(envValueFile, 'r') as stream:
            envValues = yaml.load(stream)
    else:
        envValues = {}

    print(f"Helm endpoints to be deleted: {deletedKeysPaths}")
    for deletedKeysPath in deletedKeysPaths:
        deletedKeys = deletedKeysPath.split(":")
        # Delete the keys from env values
        envValues = delete_keys_from_dict(envValues, deletedKeys)

    print(f"Helm endpoints to be added/updated: {add_updated_keys}")
    # Add the new/updated keys to the env values
    createDictForAddUpdateKeys(envValues, add_updated_keys)

    utils.run(['git', 'remote', '-v'])
    utils.run(['git', 'branch'])
    if deletedKeysPaths or add_updated_keys:
        # Write the updated values back to env values.yaml file
        with open(envValueFile, 'w') as stream:
            yaml.dump(envValues, stream)
        diffOut = utils.run(['git', 'diff'])
        if (diffOut and deletedKeysPaths) or add_updated_keys:
            # If there is diff perform push
            if app_type == "helm" and utils.isBedrockGHEOrgName(helm_config_org) and \
                    utils.isReleaseBranchName(helm_config_branch):
                utils.bumpHelmConfigVersion()
                utils.run(['git', 'add', 'project.yaml'])
            utils.run(['git', 'add', envValueFile])
            commitMsg = f'[Auto-update] helm config endpoints updated for {app_env} from manifest commit'
            utils.run(['git', 'commit',  '-m', commitMsg])
            retryLimit = 5
            for i in range(retryLimit):
                try:
                    utils.run(['git', 'pull', '--prune'], exitOnError=False)
                    utils.run(['git', 'push', 'origin', 'HEAD'], exitOnError=False)
                except Exception as e:
                    if i == retryLimit - 1:
                        sys.exit(1)
                    else:
                        time.sleep(2)
                        continue
    else:
        print('Skipping push as there are no changes in helm-config repo to push')


def delete_keys_from_dict(envValues, deletedKeys):
    """
    Delete the given keys present in deletedKeys from the envValues dictionary.
    Loops recursively over nested dictionaries.
    """
    envValues_copy = envValues.copy()  # Used as iterator to avoid the 'DictionaryHasChanged' error
    deletedKeys_copy = deletedKeys.copy()
    for key in deletedKeys:
        if key in envValues_copy:
            if isinstance(envValues_copy[key], dict):
                deletedKeys_copy.remove(key)
                delete_keys_from_dict(envValues_copy[key], deletedKeys_copy)
                if len(envValues_copy[key]) == 0:
                    del envValues[key]
            if isinstance(envValues_copy[key], str):
                del envValues[key]
    return envValues


def createDictForAddUpdateKeys(envValues, add_updated_keys):
    """
    Create a new dictionary object for the helm endpoints which are added/updated and then perform overrides on the
    current env values
    """
    for propKeyPath, propValue in add_updated_keys.items():
        propKeys = propKeyPath.split(":")
        new_dict = propValue
        for key in reversed(propKeys):
            new_dict = {key: new_dict}
        utils.applyOverrides(values=envValues, overrides=new_dict)


if packaging_branch_path != '' and len(helm_endpoints_config_obj) > 0:
    properties = {}
    # Properties can be any level deep. Recursively iterate over it and flatten it by populating to the dictionary
    utils.getAllProperties("", helm_endpoints_config_obj, properties)
    deletedKeysPaths = find_deleted_endpoints(module_name, properties)

    update_helm_config_endpoints(packaging_branch_path, app_env, properties, deletedKeysPaths)
