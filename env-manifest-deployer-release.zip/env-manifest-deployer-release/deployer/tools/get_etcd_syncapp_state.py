#!/usr/bin/env python3

import re, ruamel.yaml, json, sys, requests, os, time, subprocess
from urllib3.exceptions import InsecureRequestWarning
from modules import utils

'''
Check if configured etcd_syncapp_config branch/version is same as the remote

Check if the urls from etcd-syncapp-config remote repo are same as in current terraform state
(changes made manually outside of the manifest)
'''

yaml = ruamel.yaml.YAML()
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
yaml.allow_duplicate_keys = True

input = sys.stdin.read()
input_json = json.loads(input)

k8s_package_branch = input_json.get('helm_config_pkg_branch')
helm_package_version = input_json.get('helm_config_pkg_version')
app_env = input_json.get('app_env')
etcd_syncapp_config = input_json.get('etcd_syncapp_config')
module_name = input_json.get('module_name')

etcd_syncapp_config = json.loads(etcd_syncapp_config)
if len(etcd_syncapp_config) != 0:
    trigger = ''
    output = {}
    validation_text = ''

    if os.path.exists('terraform.tfstate'):
        cmd = 'terraform show -json terraform.tfstate'
        cmd = cmd.split()

        subprocessArgs = {
            'args': cmd,
            'check': False,
            'encoding': 'UTF-8',
            'universal_newlines': True,
            'capture_output': True
        }

        try:
            result = subprocess.run(**subprocessArgs)
            outtext = result.stdout
            if outtext and outtext != '':
                tfstate = json.loads(outtext)
                child_modules = tfstate['values']['root_module']['child_modules']
                present = False
                update = False
                service = ''
                service_list = []
                for child_module in child_modules:
                    if child_module.get('address', '') == f'module.helm-services-module[\"{module_name}\"]':
                        if 'resources' in child_module:
                            for resource in child_module['resources']:
                                if 'etcd_syncapp_config_update' in resource['address']:
                                    trigger = resource['values']['triggers'].get('trigger', '')
        except subprocess.CalledProcessError as e:
            validation_text += f'Exception when calling subprocess: {e.stdout}\n'

    with open(f'../manifest/env-manifest/{app_env}/services-manifest.yaml', 'r') as stream:
        manifest = yaml.load(stream)

    if 'pkg_branch' in manifest['services']['etcd-syncapp-config']['packaging']:
        k8s_package_branch_path = manifest['services']['etcd-syncapp-config']['packaging']['pkg_branch']
        k8s_package_branch_splits = k8s_package_branch_path.split('/')
        sync_app_org = k8s_package_branch_splits[0]
        sync_app_branch = k8s_package_branch_splits[1]
        repo = 'etcd-syncappconfig-helm-config'

        syncapp_env_values_url = f'https://github.wsgc.com/raw/{sync_app_org}/{repo}/{sync_app_branch}/config/{app_env}/values.yaml'
        syncapp_common_values_url = f'https://github.wsgc.com/raw/{sync_app_org}/{repo}/{sync_app_branch}/config/values.yaml'

        isSuccess, statusCode, fileContent = utils.github_raw_yaml(syncapp_env_values_url)
        if isSuccess or statusCode == 404:  # if env values.yaml does not exist
            if isSuccess:
                values = yaml.load(fileContent)
            else:
                values = None
            isSuccess, statusCode, fileContentCommon = utils.github_raw_yaml(syncapp_common_values_url)
            if isSuccess:
                common_values = yaml.load(fileContentCommon)
                if values:
                    common_values['services'].update(values['services'])
                for service in manifest['services']['etcd-syncapp-config']['config']:
                    if service == 'dp' or service == 'dpStoreEndpoint':
                        for uriName in common_values['services'][service]:
                            remote_url = common_values['services'][service][uriName]
                            new_link = manifest['services']['etcd-syncapp-config']['config'][service][uriName]
                            if remote_url != new_link:
                                output[f'{service}-{uriName}_configured_url'] = new_link
                                output[f'{service}-{uriName}_actual_url'] = remote_url
                        continue

                    if service in utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES:
                        uri = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES[service]
                    else:
                        uri = 'uri'
                    current_service_uri = manifest['services']['etcd-syncapp-config']['config'][service][uri]
                    name = ''.join(re.findall('.*\(services\.(.*)\).*', current_service_uri))

                    if name not in manifest['services']:
                        validation_text += f'The service {name} needs to be defined in the manifest along with adding it to the etcd-syncapp-config\n'

                    elif service in common_values['services']:
                        remote_url = common_values['services'][service][uri]
                        service_env = manifest['services'][name]['configuration']['services-collection-manifest']
                        try:
                            with open(f'../manifest/services-collection-manifest/{service_env}/services-manifest.yaml', 'r') as stream:
                                services_collection = yaml.load(stream)
                        except FileNotFoundError as e:
                            sys.exit(f'services-collection-manifest with env {service_env} does not exist')

                        try:
                            service_name = services_collection['services'][name]['name']
                            service_org = services_collection['services'][name]['org']
                        except KeyError as e:
                            sys.exit(f'service {name} is not defined within {service_env} services-collection-manifest')

                        new_link = utils.generate_config_url(service_name, service_env, service_org, current_service_uri)
                        if remote_url != new_link:
                            output[f'{service}_configured_url'] = new_link
                            output[f'{service}_actual_url'] = remote_url
                if output != {}:
                    output['urls_source'] = f'https://github.wsgc.com/{sync_app_org}/etcd-syncappconfig-helm-config/blob/{sync_app_branch}/config/{app_env}/values.yaml'
                    trigger = str(time.time())
            else:
                validation_text += fileContent
        else:
            validation_text += fileContent

    output['helm_config_pkg_branch'] = k8s_package_branch
    output['helm_config_pkg_version'] = helm_package_version
    output['trigger'] = trigger
    output['validation_text'] = validation_text
    print(json.dumps(output))
else:
    # this output is for any helm service except etcd-syncapp-config
    print(json.dumps({'out':''}))
