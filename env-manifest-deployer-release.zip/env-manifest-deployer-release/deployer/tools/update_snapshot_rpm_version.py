#!/usr/bin/env python3

import sys
import yaml

name = sys.argv[1]
module_name = sys.argv[2]
version = sys.argv[3]
env = sys.argv[4]

with open(f'../../../snapshot/{env}/manifest_snapshot.yaml', 'r') as stream:
    data = yaml.safe_load(stream)

ver = yaml.safe_load(f'pkg_version: {version}')
data['services'][module_name]['packaging'] = ver  
with open(f'../../../snapshot/{env}/manifest_snapshot.yaml','w') as file:
    file.write(yaml.safe_dump(data, sort_keys=False))
