#!/usr/bin/env python3

"""
Description:

    The script checks the env-manifest or services-collection-manifest depending on whether there were changes in them and provides the following scenarios:

    Scenario 1 ( Changes in `env-manifest` with `require_fixed_versions=True` )
    In this scenario, the apps from the env-manifest source branch will be compared with apps the env-manifest from the destination (release) branch. 
    If there are changed or new apps, the corresponding app entries in the `services-collection-manifest` will be checked.

    Scenario 2 ( Changed only `require_fixed_versions` flag in env-manifest from False to True )
    That scenario is similar to scenario 1, but in this case, each app in the source env-manifest will be checked individually.

    Scenario 3 ( Adding new env-manifest with `require_fixed_versions=True` )
    The same as scenario 2, each app in the source env-manifest will be checked individually.

    Scenario 4 ( Changes in services-collection-manifest )
    In this scenario, the apps from the `services-collection-manifest` source branch will be compared with the apps from the `services-collection-manifest` 
    destination (release) branch. 
    If there are any changes or new apps, the script will check the requirement for the app entry in the `metadata_flags` that should be present for import.

    Scenario 5 ( Adding new services-collection-manifest )
    The script will check each app in `services-collection-manifest` and requirements for the app entry in the `metadata_flags`.

Example run:

    python3 tools/fixed_version_checker.py \
        --env_changed caqa1 \
        --manifest_type env-manifest \
        --target_manifests_location /path/to/release/version/env-manifests

    python3 tools/fixed_version_checker.py \
        --env_changed qa29 \
        --manifest_type services-collection-manifest \
        --target_manifests_location /path/to/release/version/env-manifests
"""

import sys
import argparse
import yaml
import os
import re
from modules import utils


def check_app_fixed_version(app_entry: dict) -> dict:
    result = True
    if 'pkg_version' in app_entry['packaging']:
        if app_entry['packaging']['pkg_version'] == 'latest':
            result = False
    else: 
       result = False
    if result:
        print('OK')
    else:
        print(f'ERROR: `{app_entry["name"]}` app has a non-fixed version.')
    return result


def process_env_maniefst(env_name: str, manifest_path: str, target_manifests_location: str):
    
    source_manifest = {}
    target_manifest = {}
    source_require_fixed_versions = False
    target_require_fixed_versions = False
    check_entire_manifest = False
    apps_to_check = []
    result = True

    with open(f'../{manifest_path}', 'r') as file:
        source_manifest = yaml.safe_load(file)

    source_require_fixed_versions = source_manifest.get('metadata', {}).get('require_fixed_versions', False)
    if not source_require_fixed_versions:
        # Fixed version check isn't required for the env-manifest. Gracefully exiting.
        print(f'require_fixed_versions: {source_require_fixed_versions}\nNothing to check, exiting.\n')
        return result

    target_manifest_exists = os.path.exists(f'{target_manifests_location}/{manifest_path}')

    if target_manifest_exists:
        with open(f'{target_manifests_location}/{manifest_path}', 'r') as file:
            target_manifest = yaml.safe_load(file)
        target_require_fixed_versions = target_manifest.get('metadata', {}).get('require_fixed_versions', False)
        if (source_require_fixed_versions != target_require_fixed_versions):
            # Detected a change in `require_fixed_versions` from `False` to `True`. All apps should be checked.
            check_entire_manifest = True
    else:
        # When a file is absent, it means that we are trying to add a new env-manifest, and all apps should be checked.
        check_entire_manifest = True

    if check_entire_manifest:
        for app_title in source_manifest['services']:
            if not bool(re.match(r'(etcd-syncapp-config|frontend)', app_title)):
                apps_to_check.append(
                    {
                        'app_name': app_title, 
                        'env': source_manifest['services'][app_title]['configuration']['services-collection-manifest']
                    }
                )
        result = check_fixed_apps_in_svc_manifest(env_name, apps_to_check)
    else:
        for app_title, app_entry in source_manifest['services'].items():
            if not bool(re.match(r'(etcd-syncapp-config|frontend)', app_title)):
                if app_title not in target_manifest['services']:
                    apps_to_check.append({'app_name': app_title, 'env': source_manifest['services'][app_title]['configuration']['services-collection-manifest']})
                else:
                    if app_entry != target_manifest['services'][app_title]:
                        apps_to_check.append(
                            {
                                'app_name': app_title, 
                                'env': source_manifest['services'][app_title]['configuration']['services-collection-manifest']
                            }
                        )
        result = check_fixed_apps_in_svc_manifest(env_name, apps_to_check)

    return result


def process_svc_maniefst(env_name: str, manifest_path: str, target_manifests_location: str):

    source_manifest = {}
    target_manifest = {}
    result = True
    metadata_flags_path = utils.METADATA_FLAGS_FILENAME
    metadata_flags = {}
    check_entire_manifest = False
    result = True

    with open(f'../{manifest_path}', 'r') as file:
        source_manifest = yaml.safe_load(file)

    with open(f'{metadata_flags_path}', 'r') as file:
        metadata_flags = yaml.safe_load(file)

    if env_name not in metadata_flags:
        # If env has no subscribers at all, there's no point to check it.
        return result

    target_manifest_exists = os.path.exists(f'{target_manifests_location}/{manifest_path}')

    if target_manifest_exists:
        with open(f'{target_manifests_location}/{manifest_path}', 'r') as file:
            target_manifest = yaml.safe_load(file)
    else:
        # When a file is absent, it means that we are trying to add a new env-manifest, and all apps should be checked.
        check_entire_manifest = True

    if check_entire_manifest:
        for app_title, app_entry in source_manifest['services'].items():
            if app_title in metadata_flags[env_name]:
                if metadata_flags[env_name][app_title]['require_fixed_versions']['value']:
                    print(f'\nChecking fixed version requirements for `{app_title}` in `{env_name}` env services-collection-manifest.')
                    check_fixed_result = check_app_fixed_version(app_entry)
                    if not check_fixed_result:
                        result = False
    else:
        for app_title, app_entry in source_manifest['services'].items():
            if app_title in metadata_flags[env_name]:
                if app_title not in target_manifest['services']:
                    if metadata_flags[env_name][app_title]['require_fixed_versions']['value']:
                        print(f'\nChecking fixed version requirements for new `{app_title}` in `{env_name}` env services-collection-manifest.')
                        check_fixed_result = check_app_fixed_version(app_entry)
                        if not check_fixed_result:
                            result = False                  
                else:
                    if app_entry != target_manifest['services'][app_title]:
                        if metadata_flags[env_name][app_title]['require_fixed_versions']['value']:
                            print(f'\nChecking fixed version requirements for existing `{app_title}` in `{env_name}` env services-collection-manifest.')
                            check_fixed_result = check_app_fixed_version(app_entry)
                            if not check_fixed_result:
                                result = False            
    return result


def check_fixed_apps_in_svc_manifest(client_env_name: str, apps_to_check: list):

    result = True

    for app_data in apps_to_check:
        app_env = app_data['env']
        app_name = app_data['app_name']
        manifest_path = f"{utils.SERVICES_MANIFEST_PATH.format(env=app_env)}"
        manifest_body = {}

        with open(f'../{manifest_path}', 'r') as file:
            manifest_body = yaml.safe_load(file)

        print(f'\nChecking `{client_env_name}` env-manifest subscription to env: `{app_env}`, app_name: `{app_name}`.')

        if app_name not in manifest_body['services']:
            print(f'ERROR: No such app `{app_name}` in `{app_env}` services-collection-manifest.')
            result = False
        else:
            check_fixed_result = check_app_fixed_version(manifest_body['services'][app_name])
            if not check_fixed_result:
                result = False
    return result


def main(env_name: str, manifest_type: str, target_manifests_location: str):

    result = True

    print(f'\nChecking the requirements of the `require_fixed_versions` flag in the `{env_name}` env, `{manifest_type}` manifest.')

    if manifest_type == 'env-manifest':
        env_manifest_path = f'{utils.ENV_MANIFEST_PATH.format(env=env_name)}'
        result = process_env_maniefst(env_name, env_manifest_path, target_manifests_location)

    if manifest_type == 'services-collection-manifest':
        svc_manifest_path = f'{utils.SERVICES_MANIFEST_PATH.format(env=env_name)}'
        result = process_svc_maniefst(env_name, svc_manifest_path, target_manifests_location)

    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--env_changed', type=str, required=True)
    parser.add_argument('--manifest_type', type=str, required=True)
    parser.add_argument('--target_manifests_location', type=str, required=True)
    args = parser.parse_args()

    env_changed = args.env_changed
    manifest_type = args.manifest_type
    target_manifests_location = args.target_manifests_location

    check_result = main(env_changed, manifest_type, target_manifests_location)

    if not check_result:
        sys.exit('\nThe fixed versions check is failed.\n')
