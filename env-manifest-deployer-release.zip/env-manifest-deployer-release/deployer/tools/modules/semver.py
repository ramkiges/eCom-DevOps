"""
semver.py
Library of routines for processing Semantic Versions.
"""
import re


class Semver:
    """Representation of a semantic version"""
    regex = r'(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?!\.|\d)(?:-(.+))?'

    def __init__(self, major, minor, patch, extra=None):
        self.major = int(major)
        self.minor = int(minor)
        self.patch = int(patch)
        self.extra = extra

        # major, minor, and patch were all valid ints or
        # we would have thrown a ValueError, but make sure
        # that they don't contain leading zeros either.
        for val in major, minor, patch:
            if isinstance(val, str) and re.match(r'0\d', val):
                raise ValueError('Leading zeros not allowed in semver ({})'.format(val))

    @staticmethod
    def parse(verStr):
        """Return Semver object, or raise ValueError if verStr isn't a semver"""
        match = re.match(r'{}$'.format(Semver.regex), verStr)
        if match:
            return Semver(*match.groups())

        raise ValueError('Cannot parse as semver: {}'.format(verStr))

    def __iter__(self):
        """Enables tuple() and auto-unpacking"""
        return (x for x in (self.major, self.minor, self.patch, self.extra))

    def __eq__(self, other):
        return other is not None and tuple(self) == tuple(other)

    def __lt__(self, other):
        selfNumerics = (self.major, self.minor, self.patch)
        otherNumerics = (other.major, other.minor, other.patch)
        if selfNumerics < otherNumerics:
            return True
        if selfNumerics > otherNumerics:
            return False

        # The numeric parts are the same.
        return (self.extra is not None and
                (other.extra is None or self.extra < other.extra))

    def __gt__(self, other):
        return other < self

    def __str__(self):
        """Print ourselves in a user-friendly way"""
        semverStr = '{}.{}.{}'.format(self.major, self.minor, self.patch)

        if self.extra is not None:
            semverStr += '-{}'.format(self.extra)

        return semverStr

    def __repr__(self):
        return '{}({!r}, {!r}, {!r}, {!r})'.format(type(self).__name__,
                                                   self.major, self.minor, self.patch, self.extra)
