from kubernetes.client.rest import ApiException 
from kubernetes import config 
import kubernetes.client
import ansible_runner
from . import utils
import subprocess
import xmltodict
import warnings
import requests
import json
import time
import yaml
import sys
import os

def validateBranchAndVersion(new_config_job, new_app_job, app_name, out):
    if new_config_job != "":
        if new_app_job != "":
            if '/' in new_app_job:
                branch_path = new_app_job.split('/')
                app_branch_exist = utils.check_jenkins_url(
                    f'https://ecombuild.wsgc.com/jenkins/job/{branch_path[0]}/job/{branch_path[1]}/job/{branch_path[2]}/')
                if app_branch_exist:
                    app_branch_artifact_exist = utils.check_jenkins_url(
                        f'https://ecombuild.wsgc.com/jenkins/job/{branch_path[0]}/job/{branch_path[1]}/job/{branch_path[2]}/lastSuccessfulBuild/artifact/')
                else:
                    app_branch_artifact_exist = False

                if not app_branch_exist:
                    out["app_check_message"] = f'App branch {new_app_job} doesn\'t exist for app {app_name}'
                elif not app_branch_artifact_exist:
                    out["app_check_message"] = f'Successful build artifact for app branch {new_app_job} ' \
                                               f'doesn\'t exist for app {app_name}'
            else:
                app_repo_name = utils.BEDROCK_APP_NAME_REPO_MAPPING.get(app_name, app_name)
                out["app_version_exist"] = str(utils.check_git_branch(
                    f'git@github.wsgc.com:/eCommerce-Bedrock/{app_repo_name}.git', f'{new_app_job}'))
                if out["app_version_exist"] != "True":
                    out["app_check_message"] = f'App version {new_app_job} doesn\'t exist for app {app_name} ' \
                                               f'with app repo name as {app_repo_name}'

        new_config_job = new_config_job.split('/')
        branch_url = 'https://ecombuild.wsgc.com/jenkins/job/{}/job/{}/job/{}/'.format(new_config_job[0], new_config_job[1], new_config_job[2])
        artifact_url = 'https://ecombuild.wsgc.com/jenkins/job/{}/job/{}/job/{}/lastSuccessfulBuild/artifact/'.format(new_config_job[0], new_config_job[1], new_config_job[2])
        out["helm_branch_exist"] = str(utils.check_jenkins_url(branch_url))
        if out["helm_branch_exist"] == "True":
            out["helm_branch_artifact_exist"] = str(utils.check_jenkins_url(artifact_url))
        else:
            out["helm_branch_artifact_exist"] = "False"

def get_helm_version(app_name, module_name, new_config_job, new_app_job, app_env, app_org, protected_env = "false"):

    out = {
        "app_version_exist": "True",
        "helm_branch_exist": "True",
        "helm_branch_artifact_exist": "True",
        "static_deployer_exist": "True",
        "app_check_message": "",
        "update": "",
        "existing_app_job": "",
        "existing_config_job": "",
        "to_test":""
    }

    out["static_deployer_exist"] = str(utils.check_jenkins_url('https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/{}/job/{}/job/{}/'.format(app_org, app_name, app_env)))

    if out["static_deployer_exist"] == "True":
        STATIC_DEPLOYER_JENKINS_URL = "https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job"
        warnings.filterwarnings('ignore')
        user = utils.getCredential('jenkins', 'user')
        password = utils.getCredential('jenkins', 'password')
        request_url = f"{STATIC_DEPLOYER_JENKINS_URL}/{app_org}/job/{app_name}/job/{app_env}/config.xml"
        response_xml = None
        for _ in range(10):
            response = requests.get(request_url, verify=False, auth=(user, password))
            if response.status_code == 200:
                response_xml = response.text
                break
            time.sleep(2)
        if not response_xml:
            sys.exit("Failed to get config.xml")

        # converting the xml config to a python dict
        response_dict = xmltodict.parse(response_xml)

        # get the propertiesContent element of interest that consists of the helm packaging branch currently configured for the job
        propertiesContent = response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info']['propertiesContent']
        # populate the values to a dictionary by splitting on "=".
        # Example of a propertiesContent
        # HELM_PROJECT_CONFIG_JOB=eCommerce-Kubernetes-Bedrock/vertex-lite-helm-config/release
        jobPropertiesKVPair = dict()
        for propertyContent in propertiesContent.split("\n"):
            splits = propertyContent.split("=")
            jobPropertiesKVPair[splits[0]] = splits[1]

        existing_app_job = ""
        existing_config_job = ""

        if "HELM_PROJECT_APP_JOB" in jobPropertiesKVPair:
            existing_app_job = jobPropertiesKVPair['HELM_PROJECT_APP_JOB']
        if "HELM_PROJECT_APP_TAG" in jobPropertiesKVPair:
            existing_app_job = jobPropertiesKVPair['HELM_PROJECT_APP_TAG']
        if "HELM_PROJECT_CONFIG_JOB" in jobPropertiesKVPair:
            existing_config_job = jobPropertiesKVPair['HELM_PROJECT_CONFIG_JOB']

        out["existing_app_job"] = existing_app_job
        out["existing_config_job"] = existing_config_job

        if (existing_app_job != new_app_job) or (existing_config_job != new_config_job):
            out["update"] = "yes"

        trigger = ""
        if os.path.exists("terraform.tfstate"):
            cmd = "terraform show -json terraform.tfstate"
            cmd = cmd.split()

            subprocessArgs = {
                'args': cmd,
                'check': False,
                'encoding': 'UTF-8',
                'universal_newlines': True,
                'capture_output': True
            }

            try:
                result = subprocess.run(**subprocessArgs)
                outtext = result.stdout
                if outtext and outtext != "":
                    tfstate = json.loads(outtext)
                    child_modules = tfstate["values"]["root_module"]["child_modules"]
                    for child_module in child_modules:
                        if child_module.get("address", "") == f"module.helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "static_deployer" in resource["address"]:
                                        trigger = resource["values"]["triggers"]["trigger"]
            except subprocess.CalledProcessError as err:
                sys.exit(f"Exception when calling subprocess: {err.stderr}")

        if (existing_app_job != new_app_job) or (existing_config_job != new_config_job):
            trigger = str(time.time())
            if protected_env == "true":
                out["to_test"] = new_config_job
            validateBranchAndVersion(new_config_job, new_app_job, app_name, out)

        out["trigger"] = trigger

    return out

def validateBranch(new_k8s_job, out):
    if new_k8s_job != '':
        path = new_k8s_job.split('/')
        out["legacy_branch_exist"] = str(
            utils.check_jenkins_url(f'https://ecombuild.wsgc.com/jenkins/job/{path[0]}/job/{path[1]}/job/{path[2]}/'))
        if out["legacy_branch_exist"] == "True":
            out["legacy_branch_artifact_exist"] = str(utils.check_jenkins_url(
                f'https://ecombuild.wsgc.com/jenkins/job/{path[0]}/job/{path[1]}/job/{path[2]}/lastSuccessfulBuild/artifact/'))
        else:
            out["legacy_branch_artifact_exist"] = "False"

def get_legacy_version(app_name, module_name, new_k8s_job, app_env, app_org, protected_env = "false"):

    out = {
        "legacy_branch_exist": "True",
        "legacy_branch_artifact_exist": "True",
        "static_deployer_exist": "True",
        "update": "",
        "existing_k8s_job": "",
        "trigger": "",
        "to_test":""
    }

    out["static_deployer_exist"] = str(utils.check_jenkins_url(f'https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/{app_org}/job/{app_name}/job/{app_env}/'))

    if out["static_deployer_exist"] == "True":
        STATIC_DEPLOYER_JENKINS_URL = "https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job"
        warnings.filterwarnings('ignore')
        user = utils.getCredential('jenkins', 'user')
        password = utils.getCredential('jenkins', 'password')
        request_url = f"{STATIC_DEPLOYER_JENKINS_URL}/{app_org}/job/{app_name}/job/{app_env}/config.xml"
        response_xml = None
        for _ in range(10):
            response = requests.get(request_url, verify=False, auth=(user, password))
            if response.status_code == 200:
                response_xml = response.text
                break
            time.sleep(2)
        if not response_xml:
            sys.exit("Failed to get config.xml")

        # converting the xml config to a python dict
        response_dict = xmltodict.parse(response_xml)

        # get the propertiesContent element of interest that consists of the helm packaging branch currently configured for the job
        propertiesContent = response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info']['propertiesContent']

        # populate the values to a dictionary by splitting on "=".
        jobPropertiesKVPair = dict()
        for propertyContent in propertiesContent.split("\n"):
            splits = propertyContent.split("=")
            jobPropertiesKVPair[splits[0]] = splits[1]

        existing_k8s_job = ""
        if "K8S_PACKAGE_JOB" in jobPropertiesKVPair:
            existing_k8s_job = jobPropertiesKVPair['K8S_PACKAGE_JOB']

        out["existing_k8s_job"] = existing_k8s_job
        if (existing_k8s_job != new_k8s_job):
            out["update"] = "yes"

        trigger = ""
        if os.path.exists("terraform.tfstate"):
            cmd = "terraform show -json terraform.tfstate"
            cmd = cmd.split()

            subprocessArgs = {
                'args': cmd,
                'check': False,
                'encoding': 'UTF-8',
                'universal_newlines': True,
                'capture_output': True
            }

            try:
                result = subprocess.run(**subprocessArgs)
                outtext = result.stdout
                if outtext and outtext != "":
                    tfstate = json.loads(outtext)
                    child_modules = tfstate["values"]["root_module"]["child_modules"]
                    for child_module in child_modules:
                        if child_module.get("address", "") == f"module.legacy-helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "legacy_static_deployer" in resource["address"]:
                                        trigger = resource["values"]["triggers"]["trigger"]
            except subprocess.CalledProcessError as err:
                sys.exit(f"Exception when calling subprocess: {err.stderr}")

        if (existing_k8s_job != new_k8s_job):
            validateBranch(new_k8s_job, out)
            trigger = str(time.time())
            if protected_env == "true":
                out["to_test"] = new_k8s_job

        out["trigger"] = trigger

    return out

def assemble_manifest(manifest_path, create_snapshot = False):
    with open(manifest_path, 'r') as stream:
        manifest = yaml.safe_load(stream)
        env_name = manifest['env']
        result_manifest = {'env': env_name, 'services': {}}

    for service in manifest['services']:
        if 'name' in manifest['services'][service]:
            result_manifest['services'][service] = {}
            result_manifest['services'][service] = manifest['services'][service]
            result_manifest['services'][service]['env'] = env_name
        else:
            result_manifest['services'][service] = {}
            result_manifest['services'][service]['env'] = manifest['services'][service]['configuration']['services-collection-manifest']
            result_manifest['services'][service]['type'] = 'subsc'

    out = json.dumps({"manifest": yaml.safe_dump(result_manifest)})

    if create_snapshot:
        os.makedirs(f"../snapshot/{env_name}/{manifest_path.split('/')[2]}/tmp", exist_ok=True)
        os.makedirs(f"../snapshot/{env_name}/{manifest_path.split('/')[2]}/current", exist_ok=True)

        with open(f"../snapshot/{env_name}/{manifest_path.split('/')[2]}/manifest-snapshot.yaml", 'w') as file:
            file.write(yaml.safe_dump(result_manifest, sort_keys=False))

    return out

def get_packaging_version(namespace, app_org, package_type, app_name, module_name, package_version, protected_env = "false"):

    warnings.filterwarnings('ignore')
    kube_service_account = "svcak8sci"
    if app_org == "edap":
        kube_service_account = "svcaedapci"
    kube_cluster = "ts-sharedplatform-rck-nonprod"
    kube_config = f"~/.kube/{kube_service_account}/{kube_cluster}"

    output = "helmconfigversion" 
    if package_type == "legacy-helm":
        output = "legacypackageversion"

    out = {
        output: "",
        "updated_pointer":"",
        "to_test":""
    }

    if package_type == "helm":
        out["helm_version_exist"] = "True"
    elif package_type == "legacy-helm":
        out["legacy_version_exist"] = "True"

    if namespace == '':
        print(json.dumps(out))
        sys.exit(0)

    with kubernetes.client.ApiClient(config.load_kube_config(config_file = kube_config)) as api_client:
        api_instance = kubernetes.client.CoreV1Api(api_client)
        version = ""
        try:
            api_response = api_instance.list_namespaced_config_map(namespace, pretty=True)
            for item in api_response.items:
                if('kube-info-' in item.metadata.name):
                    cm = item.metadata.name
                    api_response = api_instance.read_namespaced_config_map(cm, namespace, pretty=True)
                    if package_type == 'helm':
                        version = api_response.data.get('helmConfigVersion', "")
                    elif package_type == "legacy-helm":
                        version = api_response.data.get('k8sPackageVersion', "")
                    out[output] = version
                    break
        except ApiException as e:
            sys.exit(f"Exception when calling CoreV1Api: {e}")

    trigger = ""
    if os.path.exists("terraform.tfstate"):
        cmd = "terraform show -json terraform.tfstate"
        cmd = cmd.split()

        subprocessArgs = {
            'args': cmd,
            'check': False,
            'encoding': 'UTF-8',
            'universal_newlines': True,
            'capture_output': True
        }

        try:
            result = subprocess.run(**subprocessArgs)
            outtext = result.stdout
            if outtext and outtext != "":
                tfstate = json.loads(outtext)
                child_modules = tfstate["values"]["root_module"]["child_modules"]  
                for child_module in child_modules:
                    if package_type == 'helm':
                        if child_module.get("address", "") == f"module.helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "helm_deployer" in resource["address"]:
                                        trigger = resource["values"]["triggers"]["trigger"]
                    elif package_type == 'legacy-helm':
                        if child_module.get("address", "") == f"module.legacy-helm-services-module[\"{module_name}\"]":
                            if "resources" in child_module:
                                for resource in child_module["resources"]:
                                    if "legacy_helm_deployer" in resource["address"]:
                                        trigger = resource["values"]["triggers"]["trigger"]
        except subprocess.CalledProcessError as err:
            sys.exit(f"Exception when calling subprocess: {err.stderr}")

    if not version or (version != package_version):
        trigger = str(time.time())
        if package_type == "helm":
            out["helm_version_exist"] = str(
                utils.check_git_branch(
                    f'git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/{utils.MANIFEST_APP_NAME_REPO_MAPPING.get(app_name, app_name)}-helm-config.git',
                    f'{package_version}'))
        elif package_type == "legacy-helm":
            out["legacy_version_exist"] = str(
                utils.check_git_branch(f'git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/{app_name}-k8s-package.git', f'{package_version}'))

        if protected_env == "true":
            out["to_test"] = package_version

    out["trigger"] = trigger

    return out

def get_rpm_current_state(app_name, module_name, rpm_pkg_version, app_org, app_env, app_brand, app_group, is_external_job, update_snapshot = False):
    current_dir = os.getcwd()
    os.chdir(f"{current_dir}/ansible")

    _, runner_obj = ansible_runner.run_command_async(
        executable_cmd='ansible-playbook',
        cmdline_args=["playbooks/get_current_rpm_state.yaml", "--vault-password-file", "~/.vault_pass.txt",
                        "-e", "app_name="+app_name, "-e", "rpm_pkg_version="+rpm_pkg_version, "-e", "app_org="+app_org,
                        "-e", "app_env="+app_env, "-e", "app_brand="+app_brand, "-e", "app_group="+app_group],
        json_mode=True,
        quiet=True
    )

    while runner_obj.status not in ['canceled', 'successful', 'timeout', 'failed']:
        time.sleep(5)
        continue

    if runner_obj.status != 'successful' and runner_obj.rc != 0:
        outputText = f"Exiting as the process to get the current rpm state failed with error: {runner_obj.stderr}"
        outputText += f"\nRunner Object Status: {runner_obj.status}"
        for each_host_event in runner_obj.events:
            if each_host_event['event'] == "runner_on_failed":
                if 'event_data' in each_host_event and 'res' in each_host_event['event_data']:
                    outputText += f"\n{each_host_event['event_data']['res']}"
        sys.exit(outputText)

    current_package_version = ""
    is_process_running = ""
    check_update = ""
    timestamp = str(time.time())

    for each_host_event in runner_obj.events:
        if each_host_event['event'] == "runner_on_ok":
            task_name = each_host_event['event_data']['task']
            if task_name in ['current_package_version', 'is_process_running', 'check_update'] and \
                    len(each_host_event['event_data']['res']['json']['entries']) != 0:
                stdout = each_host_event['event_data']['res']['json']['entries'][0]['log']
                if task_name == 'current_package_version':
                    current_package_version = stdout
                elif task_name == 'is_process_running':
                    process_state = stdout
                    if " is up" in process_state:
                        is_process_running = "true"
                    else:
                        is_process_running = "false"
                elif task_name == 'check_update':
                    if "noarch" in stdout:
                        splits = stdout.split(" ")
                        stdout = splits[0].split(".")[0] + "-" + splits[1] + ".noarch"
                    check_update = stdout

    output = {
        "current_package_version": current_package_version,
        "is_process_running": is_process_running,
        "check_update": check_update,
        "timestamp": timestamp
    }

    os.chdir(f"{current_dir}")
    trigger = ""
    if os.path.exists("terraform.tfstate"):
        cmd = "terraform show -json terraform.tfstate"
        cmd = cmd.split()

        subprocessArgs = {
            'args': cmd,
            'check': False,
            'encoding': 'UTF-8',
            'universal_newlines': True,
            'capture_output': True
        }

        try:
            result = subprocess.run(**subprocessArgs)
            out = result.stdout
            if out and out != "":
                tfstate = json.loads(out)
                child_modules = tfstate["values"]["root_module"]["child_modules"]
                for child_module in child_modules:
                    if child_module.get("address", "") == f"module.vm-services-module[\"{module_name}\"]":
                        if "resources" in child_module:
                            for resource in child_module["resources"]:
                                if "rpm_deployer" in resource["address"]:
                                    trigger = resource["values"]["triggers"]["trigger"]
        except subprocess.CalledProcessError as err:
            sys.exit(f"Exception when calling subprocess: {err.stderr}")

    if (rpm_pkg_version == "latest" and is_external_job == "true") or \
            (rpm_pkg_version != "latest" and rpm_pkg_version != current_package_version):
        trigger = timestamp

    if update_snapshot:
        with open(f'../snapshot/{app_env}/manifest-snapshot.yaml', 'r') as stream:
            data = yaml.safe_load(stream)
            if data['services'][module_name]['packaging']['version'] == 'latest':
                ver = yaml.safe_load(f'version: {current_package_version}')

                with open(f'../snapshot/{app_env}/tmp/{module_name}','w') as file:
                    file.write(yaml.safe_dump(ver, sort_keys=False))

    output["trigger"] = trigger
    output["app_name"] = app_name
    output["rpm_pkg_version"] = rpm_pkg_version
    output["app_org"] = app_org
    output["app_env"] = app_env
    output["app_brand"] = app_brand
    output["app_group"] = app_group

    return output
