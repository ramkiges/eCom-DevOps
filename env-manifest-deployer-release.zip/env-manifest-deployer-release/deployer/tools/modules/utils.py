import sys
import os
import configparser
import re
import subprocess
import time
import requests
from urllib3.exceptions import InsecureRequestWarning
import ruamel.yaml
from .semver import Semver

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

ETCD_SYNCAPP_EXCEPTION_URI_SERVICES = {
    'experimentation': 'baseUri'
}

DOCKER_ORGS = {
    'ecom'         : 'ecommerce',
    'international': 'intl',
    'supplychain'  : 'supplychain',
    'edap'         : 'edap'
}

# Mapping manifest app name to the eCommerce-Kubernetes-Bedrock repo name
MANIFEST_APP_NAME_REPO_MAPPING = {
    'credit-card-orchestration': 'credit-card-orchestration-service',
    'experimentation': 'experimentation-service',
    'inventory-state': 'inventory-state-event-consumer',
    'stored-value-card-orchestration': 'stored-value-card-orchestration-service'
}

# Mapping manifest app name to the eCommerce-Bedrock repo name
BEDROCK_APP_NAME_REPO_MAPPING = {
    'ecom-svc-catalog': 'ecom-svc-catalog-webapp',
    'ecom-svc-registry': 'ecom-svc-registry-webapp',
    'c3': 'c3-service',
    'credit-card-orchestration': 'credit-card-orchestration-service',
    'registryv3': 'registry',
    'delivery-gateway': 'ecom-svc-app-delivery',
    'experiment-proxy': 'experimentation-service',
    'experimentation': 'experimentation-service',
    'favorites': 'favorites-service',
    'inventory-state': 'inventory',
    'oauth': 'oauth-server',
    'pricing': 'pricing-service',
    'pricing-singleuse-batch-generator': 'pricing-service',
    'promo-publisher': 'pricing-service',
    'registryv2': 'registry',
    'salesforceconnector': 'business-sales-connector-service',
    'ecom-svc-content': 'ecom-svc-content-webapp',
    'stored-value-card-orchestration': 'stored-value-card-orchestration-service'
}

# Mapping service name extracted from the helm endpoint url to the manifest name and same for env
SERVICE_NAME_ENV_MAPPING = {
    'webauth': {
        'manifest_name': 'oauth',
    },
    'search-publisher': {
        'manifest_name': 'oss-publisher',
        'qa': {
            'manifest_env': 'qa1',
        }
    },
    'loyalty': {
        'manifest_name': 'loyalty',
        'qa': {
            'manifest_env': 'qa1',
        },
        'uat': {
            'manifest_env': 'uat1',
        }
    },
    'pricing': {
        'manifest_name': 'pricing',
        'qa7': {
            'manifest_env': 'uat',
        }
    },
    'credit-card-orchestration': {
        'manifest_name': 'credit-card-orchestration',
        'develop': {
            'manifest_env': 'dev',
        }
    },
    'registry': {
        'manifest_name': 'registryv3',
    }
}

ENV_MANIFEST_PATH = 'manifest/env-manifest/{env}/services-manifest.yaml'
SERVICES_MANIFEST_PATH = 'manifest/services-collection-manifest/{env}/services-manifest.yaml'
METADATA_FLAGS_FILENAME = 'metadata-flags-dict.json'


def getCredential(section, keyword):
    # Can we read the credential from the environment?
    envVarName = "SCM_TOOLS_CREDENTIAL_{}_{}".format(section, keyword)
    if envVarName in os.environ:
        return os.environ[envVarName]
    configPathname = '~/.credentials'

    # Read credential file only once, caching it as a function attribute.
    try:
        config = getCredential.config
    except AttributeError:
        config = configparser.RawConfigParser()

        config.read(os.path.expanduser(configPathname))
        getCredential.config = config

    try:
        return config.get(section, keyword)
    except (configparser.NoSectionError, configparser.NoOptionError):
        sys.exit("Unable to find '{}' in section [{}] of {}".format(keyword, section, configPathname))


def deriveNamespace(org, name, env):
    app_org = org.lower()
    if app_org in DOCKER_ORGS:
        app_org = DOCKER_ORGS[app_org]
    else:
        app_org = re.sub('[^a-zA-Z0-9]', '', app_org)

    app_name = re.sub('[^-a-zA-Z0-9]', '', name.lower())
    app_env = re.sub('[^a-zA-Z0-9]', '', env.lower())

    out = '{}-{}-{}'.format(app_org, app_name, app_env)

    return out


def run(cmd, printOutput=True, inputStr=None, exitOnError=True, captureOutput=True):
    """
    Print cmd and run it.

    If captureOutput is true, command output is captured and returned.
    Otherwise output flows to stdout/stderr as it happens, and this routine
    doesn't capture or return it.

    If printOutput is true and captureOutput is true, we print the output
    after execution is complete.

    If inputStr is not None, we pass that string to the stdin of the process.

    If exitOnError is true, we exit with an appropriate message when cmd
    fails.  Otherwise we re-raise the subprocess.CalledProcessError exception.

    If cmd is passed as a string instead of an array, it will be split
    on whitespace before being executed.  Use this only for commands defined
    literally whose arguments contain no whitespace.
    """

    # Allow the user to pass a whitespace-separated string instead of a list, for cases where you
    # know the input doesn't have quoting issues (e.g., run('ls /')).
    if isinstance(cmd, str):
        cmd = cmd.strip().split()

    # Print the command as a series of strings, with quotes if an arg
    # contains a space.  This looks more natural than the raw list.
    print(' '.join((f"'{x}'" if ' ' in x else x) for x in cmd))

    subprocessArgs = {
        'args': cmd,
        'check': True,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': captureOutput
    }

    if inputStr is not None:
        subprocessArgs['input'] = inputStr

    try:
        result = subprocess.run(**subprocessArgs)  # pylint: disable=subprocess-run-check
    except subprocess.CalledProcessError as e:
        if captureOutput:
            if e.stdout or e.stderr:
                outputMsg = '  Output was:\n'
                if e.stdout:
                    outputMsg += f'Stdout:\n{e.stdout}'
                if e.stderr:
                    outputMsg += f'Stderr:\n{e.stderr}'
            else:
                outputMsg = '  (There was no output.)\n'
        else:
            outputMsg = '\n'

        print(f'Command failed.{outputMsg}', file=sys.stderr, end='')

        if exitOnError:
            sys.exit(1)

        # The caller has asked to catch exceptions.
        raise e

    if not captureOutput:
        # Output has already printed; nothing left to do.
        return None

    if printOutput:
        print(result.stdout, end='')

    return result.stdout


def generate_config_url(new_name, new_env, new_org, url):
    if '/' in url:
        suffix = url.split('/', 1)[1]
    else:
        suffix = ''

    if 'WS-' in url:
        prefix = 'WS-'
    elif 'rj-' in url:
        prefix = 'rj-'
    else:
        prefix = ''

    if new_name == 'catalog-pb':
        if new_env == 'perf':
            result = f"https://pb-catalog-service-{new_env}.wsgc.com/{suffix}"
        else:
            result = f"https://pb-catalog-service-{new_env}-rk1v.wsgc.com/{suffix}"
    else:
        result = f"https://{prefix}{DOCKER_ORGS[new_org]}-{new_name}-{new_env}.services.west.nonprod.wsgc.com/{suffix}"

    return result


def readCombinedYaml(yamlFiles):
    # Read the YAML files, letting later files override earlier ones
    values = {}

    for yamlFile in yamlFiles:
        theseValues = readYamlFile(yamlFile)

        if theseValues:
            applyOverrides(values=values, overrides=theseValues)

    return values


def applyOverrides(values, overrides):
    """
    Override values in dictionary `values` with the values from `overrides`.
    Recurses into dictionaries, so if `values` is {1: {2: 'a', 3: 'b'}}, and
    `overrides` is {1: {2: 'c'}}, `values` will become {1: {2: 'c', 3: 'b'}}.

    This is like a "deep" version of values.update(theseValues) (which would turn
    values into {1: {2: 'c'}}).

    Modifies the values argument in place; no useful return value.
    """
    for key, overrideValue in overrides.items():
        if key in values:
            if overrideValue is None:
                # The override set a value to null (not the string null, but
                # a bare literal 'null' (without the quotes).
                del values[key]
                continue

            valuesValue = values[key]
            if isinstance(valuesValue, dict) and isinstance(overrideValue, dict):
                # Recurse.
                applyOverrides(valuesValue, overrideValue)
                continue

        values[key] = overrideValue


def readYamlFile(yamlFile):
    """
    Return the contents of yamlFile as a dictionary, dying if it doesn't
    exist or isn't parsable yaml.  Returns None if the file was empty
    (from a yaml perspective; it may have contained blank lines or comments).
    """
    try:
        with open(yamlFile) as f:
            contents = yaml.load(f)
    except FileNotFoundError as e:
        sys.exit(e)
    except:
        sys.exit(f'Error parsing {yamlFile}')

    return contents


def bumpHelmConfigVersion():
    # Update the project.yaml version of this Helm Config project.
    projectYamlFile = 'project.yaml'
    lines = open(projectYamlFile).read().splitlines()

    isVersionUpdated = False
    newVersion = None
    for i, line in enumerate(lines):
        match = re.match(r'version:\s*(\S*)$', line)
        if match:
            helmConfigVersionStr = match.group(1)
            try:
                helmConfigSemver = Semver.parse(helmConfigVersionStr)
            except ValueError:
                sys.exit("Error: unexpected Helm Config version '{}'".format(helmConfigVersionStr))

            if helmConfigSemver.extra is not None:
                sys.exit("Error: Helm Config version '{}' is not a release version".format(helmConfigVersionStr))

            newVersion = Semver(helmConfigSemver.major,
                                helmConfigSemver.minor,
                                helmConfigSemver.patch + 1)

            lines[i] = 'version: {}'.format(newVersion)
            isVersionUpdated = True
            break

    if isVersionUpdated:
        with open(projectYamlFile, 'w') as f:
            f.write(''.join(line + '\n' for line in lines))
    else:
        sys.exit('No version found in {}!'.format(projectYamlFile))

    return newVersion


def isBedrockGHEOrgName(gheOrgName):
    irregularBedrockOrgNames = [
        'ecommerce-devops',
        'platform-data',
        'platform-application',
        'enterprise-services',
        'standards',
    ]

    return gheOrgName.lower().endswith('-bedrock') or gheOrgName.lower() in irregularBedrockOrgNames


def isReleaseBranchName(branchName):
    return 'release' in branchName


def getAllProperties(helm_endpoints_config_key, helm_endpoints_config_obj, properties):
    """
    Properties can be any level deep. Recursively iterate over it and flatten it by populating to the dictionary.

    Example Input
    applicationProperties:
      favorites.service.uri: <favpropvalue>
      oauth.baseUri: <oauthpropvalue>

    Example Output
    {
      "applicationProperties:favorites.service.uri" : <favpropvalue>,
      "applicationProperties:oauth.baseUri" : <oauthpropvalue>,
    }

    """
    if isinstance(helm_endpoints_config_obj, dict):
        for config_key, config_obj in helm_endpoints_config_obj.items():
            if helm_endpoints_config_key != "":
                config_key_path = helm_endpoints_config_key + ":" + config_key
            else:
                config_key_path = config_key
            getAllProperties(config_key_path, config_obj, properties)

    if isinstance(helm_endpoints_config_obj, str):
        properties[helm_endpoints_config_key] = helm_endpoints_config_obj
        return


def extractServiceNameAndEnv(manifestHelmUrl):
    """
    Extract service name and env from the manifest helm endpoint.
    Do some preprocesing of name and env before returning to match the one from manifest.
    Example: webauth as service name extracted needs to be changed to oauth

    Input: https://ecommerce-favorites-qa.services.west.nonprod.wsgc.com/favorites/v3
    Output: favorites, qa

    Input: https://webauth-qa-rk01v.wsgc.com
    Output: oauth, qa
    """
    match = None
    serviceName = None
    serviceEnv = None
    if ("services.west.nonprod.wsgc.com" in manifestHelmUrl) or ("services.west.wsgc.com" in manifestHelmUrl) \
            or ("services.east.wsgc.com" in manifestHelmUrl):
        match = re.match(r"(https:\/\/|http:\/\/|)([A-Za-z0-9]+|.*-ecommerce)-(.*)-([A-Za-z0-9]+)(\.services\.west\.(nonprod\.){0,1}wsgc\.com)", manifestHelmUrl)
        if match:
            serviceName = match.group(3)
            serviceEnv = match.group(4)
    elif re.search(r"rk[0-9]+v(\.wsgc\.com){0,1}", manifestHelmUrl):
        match = re.match(r"(https:\/\/|http:\/\/|)([A-Za-z0-9]+|search-publisher)-([A-Za-z0-9]+|ca-qa)-(rk[0-9]+v(\.wsgc\.com){0,1})", manifestHelmUrl)
        if match:
            serviceName = match.group(2)
            serviceEnv = match.group(3)
    elif ".wsgc.com" in manifestHelmUrl:
        match = re.match(r"(https:\/\/|http:\/\/|)([A-Za-z0-9]+)-([A-Za-z0-9]+)(\.wsgc\.com)", manifestHelmUrl)
        if match:
            serviceName = match.group(2)
            serviceEnv = match.group(3)

    if match:
        if serviceName in SERVICE_NAME_ENV_MAPPING:
            serviceObj = SERVICE_NAME_ENV_MAPPING[serviceName]
            serviceName = serviceObj.get('manifest_name', serviceName)

            if serviceEnv in serviceObj:
                serviceEnvObj = serviceObj[serviceEnv]
                serviceEnv = serviceEnvObj.get('manifest_env', serviceEnv)

    return serviceName, serviceEnv


def serviceValidationForManifest(manifestEnv, manifestContent, serviceName, serviceEnv, manifestHelmUrl, helmUrlKey, appName):
    """
    Performs validation for the service presence in the manifest and that the env of the service matches the
    one defined in the manifest. Return the validation output.

    Example params: 
        manifestEnv: qa17
        manifestContent: the yaml content object
        serviceName: favorites
        serviceEnv: qa
        manifestHelmUrl: https://ecommerce-favorites-qa.services.west.nonprod.wsgc.com/favorites/v3
        helmUrlKey: applicationProperties:favorites.service.uri
        appName: ecom-svc-registry

    Consider the below snippet from qa17 manifest env for ecom-svc-registry app:

    ecom-svc-registry:
        name: ecom-svc-registry
        type: helm
        org: ecom
        packaging:
            pkg_branch: eCommerce-Kubernetes-Bedrock/ecom-svc-registry-helm-config/release
            app_branch: eCommerce-Bedrock/ecom-svc-registry-webapp/release
        configuration:
            applicationProperties:
                favorites.service.uri: https://ecommerce-favorites-qa.services.west.nonprod.wsgc.com/favorites/v3
    """
    service_validation_output = ""
    servicePresent = serviceName in manifestContent['services']
    if servicePresent:
        currentEnv = manifestContent['services'][serviceName]['configuration']['services-collection-manifest']
        if serviceName in SERVICE_NAME_ENV_MAPPING:
            if currentEnv in SERVICE_NAME_ENV_MAPPING[serviceName]:
                currentEnv = SERVICE_NAME_ENV_MAPPING[serviceName][currentEnv]['manifest_env']

        if serviceEnv != currentEnv:
            service_validation_output += f"env-manifest {manifestEnv} consists of service " \
                                         f"{serviceName} with env as {currentEnv} which does not match the " \
                                         f"service {serviceName} referenced by helm config property " \
                                         f"'{helmUrlKey}: {manifestHelmUrl}' in app {appName} " \
                                         f"which has env as {serviceEnv}\n\n"
    else:
        service_validation_output += f"env-manifest {manifestEnv} should define service '{serviceName}' " \
                                     f"with env {serviceEnv}, as referenced by helm config property " \
                                     f"'{helmUrlKey}: {manifestHelmUrl}' in service {appName}\n\n"

    return service_validation_output


def serviceValidationCheckForAllConsumers(serviceName, serviceEnv, manifestHelmUrl, helmUrlKey, appName, appEnv):
    # Perform service validation check within the app manifest and within all of its consumer manifest.
    # Combine the validation output from all checks and return
    service_validation_output = ""
    for subscriberManifestEnv in os.listdir('../manifest/env-manifest'):
        with open(f'../manifest/env-manifest/{subscriberManifestEnv}/services-manifest.yaml', 'r') as stream:
            manifestContent = yaml.load(stream)
            if appName in manifestContent['services']:
                if manifestContent['services'][appName]['configuration']['services-collection-manifest'] == appEnv:
                    service_validation_output += serviceValidationForManifest(
                        subscriberManifestEnv, manifestContent, serviceName,
                        serviceEnv, manifestHelmUrl, helmUrlKey, appName)

    return service_validation_output


def clone_etcd_syncapp_repo(helm_config_branch_path):
    helm_config_branch = helm_config_branch_path.split('/')
    org = helm_config_branch[0]
    branch = helm_config_branch[1]
    repo = 'etcd-syncappconfig-helm-config'
    if os.path.isdir(repo):
        subprocess.run(['rm', '-rf', f'{repo}'])
    subprocess.run(['git', 'clone', f'git@github.wsgc.com:{org}/{repo}.git', '--quiet'])
    os.chdir(f"{repo}")
    subprocess.run(['git', 'checkout', f'{branch}', '--quiet'])


def github_raw_yaml(request_raw_url):
    github_token = getCredential('github', 'ghe_admin_token')
    headers = {"Authorization": f"token {github_token}"}
    raw_page = requests.get(request_raw_url, headers=headers, verify=False)

    retries = 4
    while raw_page.status_code != 200 and retries != 0:
        raw_page = requests.get(request_raw_url, headers=headers, verify=False)
        retries -= 1
        time.sleep(2)

    if raw_page.status_code != 200:
        return False, raw_page.status_code, f"error while getting {request_raw_url}"

    return True, raw_page.status_code, raw_page.text


def check_jenkins_url(check_url):
    check_request = requests.get(check_url, verify=False, auth=(getCredential('jenkins', 'user'), getCredential('jenkins', 'password')))
    retries = 4
    while check_request.status_code != 200 and retries != 0:
        check_request = requests.get(check_url, verify=False, auth=(getCredential('jenkins', 'user'), getCredential('jenkins', 'password')))
        retries -= 1
        time.sleep(2)

    if check_request.status_code != 200:
        return False

    return True


def check_git_branch(repo, branch):
    """
    Check if the branch or tag exist in the passed repo
    args:   repo   : git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/etcd-syncappconfig-helm-config.git
            branch : 1.1.229
    """
    ls = subprocess.run(['git', 'ls-remote', f'{repo}', f'{branch}'], stdout=subprocess.PIPE)
    wc = subprocess.run(["wc", "-l"], input=ls.stdout, stdout=subprocess.PIPE)
    if wc.stdout.decode("utf-8").strip().startswith('1'):
        return True
    else:
        ls = subprocess.run(['git', 'ls-remote', f'{repo}', f'release-{branch}'], stdout=subprocess.PIPE)
        wc = subprocess.run(["wc", "-l"], input=ls.stdout, stdout=subprocess.PIPE)
        if wc.stdout.decode("utf-8").strip().startswith('1'):
            return True
        else:
            return False


def checkoutrepo(app_name, manifest_env, package_config_branch_path, package_release_version, app_type):
    # Checkout the helm/legacy-helm config repo branch or tag and return the path to the repo
    if package_config_branch_path:
        package_config_branch_path_splits = package_config_branch_path.split('/')
        repo_org = package_config_branch_path_splits[0]
        repo_name = package_config_branch_path_splits[1]
        repo_branch = package_config_branch_path_splits[2]
        checkout_cmd = f"git checkout {repo_branch} --quiet".split(' ')
    else:
        repo_org = "eCommerce-Kubernetes-Bedrock"
        if app_type == "helm":
            repo_name = f"{MANIFEST_APP_NAME_REPO_MAPPING.get(app_name, app_name)}-helm-config"
            checkout_cmd = f"git checkout tags/{package_release_version} --quiet".split(' ')
        else:
            repo_name = f"{app_name}-k8s-package"
            checkout_cmd = f"git checkout tags/release-{package_release_version} --quiet".split(' ')

    current_dir = os.getcwd()
    repo_clone_dir = f'../temp_dir_{app_name}_{manifest_env}'
    # Start with clean slate
    if os.path.isdir(repo_clone_dir):
        subprocess.run(['rm', '-rf', repo_clone_dir])
    os.mkdir(repo_clone_dir)
    os.chdir(repo_clone_dir)
    git_url = f"git@github.wsgc.com:{repo_org}/{repo_name}.git"
    cmd = f"git clone {git_url}".split(' ')
    subprocess.run(cmd)
    os.chdir(f"{repo_name}")
    subprocess.run(checkout_cmd)
    os.chdir(current_dir)

    return f"{repo_clone_dir}/{repo_name}"
