#!/usr/bin/env python3

import yaml
import os
import sys

env = sys.argv[1]

with open(f'snapshot/{env}/manifest-snapshot.yaml', 'r') as stream:
    data = yaml.safe_load(stream)

for file in os.listdir(f'snapshot/{env}/tmp'):
    f = os.path.join(f'snapshot/{env}/tmp', file)

    with open(f, 'r') as stream:
        service = yaml.safe_load(stream)

    current = service['pkg_version']
    ver = yaml.safe_load(f'pkg_version: {current}')

    data['services'][file]['packaging'] = ver

with open(f'snapshot/{env}/manifest-snapshot.yaml', 'w') as file:
    file.write(yaml.safe_dump(data, sort_keys=False))
