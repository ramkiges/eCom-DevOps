#!/usr/bin/env python3

import sys, xmltodict

response_xml_path = sys.argv[1]
response_xml = ""
with open(response_xml_path, "r") as f:
    response_xml = f.read()

new_k8s_job = sys.argv[2]

# converting the xml config to a python dict
response_dict = xmltodict.parse(response_xml)

# get the propertiesContent element of interest that consists of the helm packaging branch currently configured for the job
propertiesContent = response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info']['propertiesContent']

# populate the values to a dictionary by splitting on "=".

jobPropertiesKVPair = dict()
for propertyContent in propertiesContent.split("\n"):
    splits = propertyContent.split("=")
    jobPropertiesKVPair[splits[0]] = splits[1]

existing_k8s_job = ""
if "K8S_PACKAGE_JOB" in jobPropertiesKVPair:
    existing_k8s_job = jobPropertiesKVPair['K8S_PACKAGE_JOB']

new_job_properties = f"K8S_PACKAGE_JOB={new_k8s_job}"
response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info']['propertiesContent'] = new_job_properties

if new_k8s_job == "":
    triggers = response_dict['flow-definition']['properties']['org.jenkinsci.plugins.workflow.job.properties.PipelineTriggersJobProperty']['triggers']
    if triggers:
        if 'upstreamProjects' in triggers['jenkins.triggers.ReverseBuildTrigger']:
            triggers['jenkins.triggers.ReverseBuildTrigger']['upstreamProjects'] = ""

new_xml = xmltodict.unparse(response_dict, pretty=True)

print(new_xml)
