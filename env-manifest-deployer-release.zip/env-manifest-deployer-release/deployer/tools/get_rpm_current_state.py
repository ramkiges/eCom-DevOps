#!/usr/bin/env python3

import sys
import json
from modules import processing_utils

input = sys.stdin.read()
input_json = json.loads(input)
app_name = input_json.get("app_name")
module_name = input_json.get("module_name")
rpm_pkg_version = input_json.get("rpm_pkg_version")
app_org = input_json.get("app_org")
app_env = input_json.get("app_env")
app_brand = input_json.get("app_brand")
app_group = input_json.get("app_group")
is_external_job = input_json.get("is_external_job")

output = processing_utils.get_rpm_current_state(app_name, module_name, rpm_pkg_version, app_org, app_env, app_brand, app_group, is_external_job)

print(json.dumps(output))
