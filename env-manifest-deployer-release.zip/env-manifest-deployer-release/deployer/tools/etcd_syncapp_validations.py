#!/usr/bin/env python3

import sys
import ruamel.yaml
import subprocess
import os
import re
from modules import utils

env = sys.argv[1]

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True

with open(f'manifest/env-manifest/{env}/services-manifest.yaml', 'r') as stream:
    manifest = yaml.load(stream)

# handles the validations for the etcd syncapp version
if 'etcd-syncapp-config' in manifest['services']:
    if 'pkg_version' in manifest['services']['etcd-syncapp-config']['packaging']:
        print('Running validations for legacy_package_version_only for etcd-syncapp-config service')
        result_manifest = manifest       
        for service in manifest['services']['etcd-syncapp-config']['config']:
            if service != 'dp' and service != 'dpStoreEndpoint':
                if service in utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES:
                    uri = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES[service]
                else:
                    uri = 'uri'

                pointer = manifest['services']['etcd-syncapp-config']['config'][service][uri]
                name = ''.join(re.findall(".*\(services\.(.*)\).*", pointer))
                if name in manifest['services']:
                    current_env = manifest['services'][name]['configuration']['services-collection-manifest']
                    with open(f'../manifest/services-collection-manifest/{current_env}/services-manifest.yaml', 'r') as stream:
                        services_collection = yaml.load(stream)

                    service_name = services_collection['services'][name]['name']
                    service_org = services_collection['services'][name]['org']
                    new_link = utils.generate_config_url(service_name, current_env, service_org, pointer)
                    result_manifest['services']['etcd-syncapp-config']['config'][service][uri] = new_link
                else:
                    sys.exit(f"Added service {name} isn't present in the current manifest...")

        tag = 'release-'+manifest['services']['etcd-syncapp-config']['packaging']['pkg_version']
        if os.path.isdir('temp_etcd'):
            print(f"Deleting old copy of temp_etcd dir")
            subprocess.run(['rm', '-rf', 'temp_etcd'])

        os.mkdir('temp_etcd')
        os.chdir('temp_etcd')
        cmd = "git clone git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/etcd-syncappconfig-helm-config.git".split(' ')
        subprocess.run(cmd)
        os.chdir("etcd-syncappconfig-helm-config")
        cmd = f"git checkout tags/{tag}".split(' ')
        subprocess.run(cmd)

        with open(f"config/{env}/values.yaml", 'r') as stream:
            values = yaml.load(stream)

        with open("config/values.yaml", 'r') as stream:
            common_values = yaml.load(stream)

        for service in common_values['services']:
            values['services'].update({service:common_values['services'][service]})

        services_divergence = {}
        for service in result_manifest['services']['etcd-syncapp-config']['config']:
            if service == 'dp' or service == 'dpStoreEndpoint':
                temp = {}
                for uriName in common_values['services'][service]:
                    remote_uri = values['services'][service][uriName]
                    manifest_uri = manifest['services']['etcd-syncapp-config']['config'][service][uriName]
                    if remote_uri != manifest_uri:
                        temp[f'manifest_{uriName}'] = manifest_uri
                        temp[f'remote_{uriName}'] = remote_uri
                if temp:
                    services_divergence[service] = temp
            else:
                if service in utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES:
                    uri = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES[service]
                else:
                    uri = 'uri'

                manifest_uri = result_manifest['services']['etcd-syncapp-config']['config'][service][uri]
                remote_uri = values['services'][service][uri]
                if manifest_uri != remote_uri:
                    services_divergence[service] = {'manifest_uri':manifest_uri, 'remote_uri':remote_uri}

        if services_divergence:
            sys.exit(f"Some version doesn't correspond with the remote one. Failing the build...\n{services_divergence}")
        else:
            print('Validation successful for helm_config_version_only for etcd-syncapp-config service')

    if 'pkg_branch' in manifest['services']['etcd-syncapp-config']['packaging']:
        print('Running validations for branch_only_config for etcd-syncapp-config service')
        services_divergence = []
        for service in manifest['services']['etcd-syncapp-config']['config']:
            if service != 'dp' and service != 'dpStoreEndpoint':
                if service in utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES:
                    uri = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES[service]
                else:
                    uri = 'uri'

                name = ''.join(re.findall(".*\(services\.(.*)\).*", manifest['services']['etcd-syncapp-config']['config'][service][uri]))
                if name not in manifest['services']:
                    services_divergence.append(name)
        if services_divergence:
            sys.exit(f"{services_divergence} need to be defined in the manifest before it can be added to the etcd-syncapp-config")
        else:
            print('Validation successful for branch_only_config for etcd-syncapp-config service')
