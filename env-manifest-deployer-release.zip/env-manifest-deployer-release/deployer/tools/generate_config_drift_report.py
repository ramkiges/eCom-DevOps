#!/usr/bin/env python3
"""
Find the config drift(difference between manifest in github vs k8s deployer job or MFE repository)
Script collects all drifts and generates html pages which can be send to the confluence
How to run it: 
python3 tools/get_report.py --path="../manifest/"
How to push an output to the confluence: 
/apps/scripts/env_summary/atlassian-cli-3.2.0/confluence.sh --space "ES" --title "Manifest Config Drift" --action storepage --file output.html --noConvert --verbose
"""
import argparse
import os
import json
import sys
import time

import ruamel.yaml
import warnings
import requests
import xmltodict
import re
import subprocess
from modules import processing_utils, utils

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True

STATIC_DEPLOYER_JENKINS_URL = "https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job"

HTML_TABLE_TEMPLATE_HEAD = f"""<html>
<style>
table, th, td {{
  border:1px solid black;
}}
</style>
<body>
This page is dynamically generated every  2 hours - any manual edits will be lost
<table><tr>
    <td>Env/Manifest type</td>
    <td>Environment which is currently analyzing</td>
  </tr><tr>
    <td>Application Env(Manifest Config)</td>
    <td>Environment defined in manifest</td>
  </tr><tr>
    <td>Application Env(Actual Config)</td>
    <td>Environment on which application is deployed</td>
    </tr></table>
<table>
<tr>
    <th>Manifest Env</th>
    <th>Application</th>
    <td style="text-align:center" colspan="2">Manifest Config</td>
    <td style="text-align:center" colspan="2">Actual Config</td>
</tr>
<tr>
    <th></th>
    <th></th>
    <th>Application Env</th>
    <th>Config Drift</th>
    <th>Application Env</th>
    <th>Config Drift</th>
</tr>"""

HTML_TABLE_TEMPLATE_TAIL = "</table></body></html>"


def add_row(html_template, base_env, app, manifest_env, manifest_content, app_env, jenkins_content, manifest_type):
    print(f"Adding row:{base_env}:{app}:{manifest_env}:{manifest_content}:{app_env}:{jenkins_content}")
    html_template = f"""{html_template}
    <tr><td>{base_env}/{manifest_type}</td>
    <td>{app}</td>
    <td>{manifest_env}</td>
    <td>{manifest_content}</td>
    <td>{app_env}</td>
    <td>{jenkins_content}</td></tr>
    """
    return html_template


def get_actual_config(app_name, app_env, app_org, app_type):
    """
    Get the actual configuration for the static deployer job for helm and legacy-helm apps
    Return execution status, error message if any, config output
    """

    output = {}
    warnings.filterwarnings('ignore')
    user = utils.getCredential('jenkins', 'user')
    password = utils.getCredential('jenkins', 'password')
    request_url = f"{STATIC_DEPLOYER_JENKINS_URL}/{app_org}/job/{app_name}/job/{app_env}/config.xml"
    response_xml = None
    for _ in range(10):
        response = requests.get(request_url, verify=False, auth=(user, password))
        if response.status_code == 200:
            response_xml = response.text
            break
        time.sleep(2)
    if not response_xml:
        return False, "Failed to get config.xml", output

    # converting the xml config to a python dict
    response_dict = xmltodict.parse(response_xml)

    # get the propertiesContent element of interest that consists of the helm packaging branch currently configured for the job
    propertiesContent = response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info'][
        'propertiesContent']
    # populate the values to a dictionary by splitting on "=".
    # Example of a propertiesContent
    # HELM_PROJECT_CONFIG_JOB=eCommerce-Kubernetes-Bedrock/vertex-lite-helm-config/release
    jobPropertiesKVPair = dict()
    for propertyContent in propertiesContent.split("\n"):
        splits = propertyContent.split("=")
        jobPropertiesKVPair[splits[0]] = splits[1]

    if app_type == "helm":
        actual_app_branch = ""
        actual_helm_config_branch = ""
        actual_app_version = ""

        if "HELM_PROJECT_APP_JOB" in jobPropertiesKVPair:
            actual_app_branch = jobPropertiesKVPair['HELM_PROJECT_APP_JOB']
        if "HELM_PROJECT_APP_TAG" in jobPropertiesKVPair:
            actual_app_version = jobPropertiesKVPair['HELM_PROJECT_APP_TAG']
        if "HELM_PROJECT_CONFIG_JOB" in jobPropertiesKVPair:
            actual_helm_config_branch = jobPropertiesKVPair['HELM_PROJECT_CONFIG_JOB']

        output["actual_app_branch"] = actual_app_branch
        output["actual_app_version"] = actual_app_version
        output["actual_helm_config_branch"] = actual_helm_config_branch
        return True, None, output
    elif app_type == "legacy-helm":
        actual_k8s_job = ""
        if "K8S_PACKAGE_JOB" in jobPropertiesKVPair:
            actual_k8s_job = jobPropertiesKVPair['K8S_PACKAGE_JOB']
        output["actual_k8s_job"] =  actual_k8s_job

        return True, None, output


def checkDriftForETCDSyncapp(services, html_template, manifest_env, type):
    """
    Check for the drift for etcd-syncapp service urls
    """
    if "etcd-syncapp-config" in services:
        current_dir = os.getcwd()
        proceedSyncappDriftCheck = True
        packaging = services["etcd-syncapp-config"]["packaging"]

        # Have a clean slate for etcd-syncapp-config clone
        if os.path.isdir('temp_etcd'):
            print(f"Deleting old copy of temp_etcd dir")
            subprocess.run(['rm', '-rf', 'temp_etcd'])
        os.mkdir('temp_etcd')
        os.chdir('temp_etcd')

        if "pkg_branch" in packaging:
            helm_config_pkg_branch = packaging["pkg_branch"]
            path = helm_config_pkg_branch.split('/')
            branch_exists = utils.check_jenkins_url(
                f'https://ecombuild.wsgc.com/jenkins/job/{path[0]}/job/etcd-syncappconfig-helm-config/job/{path[1]}/')
            if not branch_exists:
                html_template = add_row(html_template, manifest_env, "etcd-syncapp-config", manifest_env,
                                        f"helm_config_pkg_branch:{helm_config_pkg_branch}",
                                        manifest_env, f"Branch {helm_config_pkg_branch} does not exist", type)
                proceedSyncappDriftCheck = False
            else:
                utils.clone_etcd_syncapp_repo(helm_config_pkg_branch)

        elif "pkg_version" in packaging:
            tag = packaging['pkg_version']
            cmd = "git clone git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/etcd-syncappconfig-helm-config.git"
            subprocess.run(cmd.split())
            os.chdir("etcd-syncappconfig-helm-config")
            cmd = f"git checkout tags/{tag}"
            try:
                subprocess.run(cmd.split(), check=True)
            except:
                html_template = add_row(html_template, manifest_env, "etcd-syncapp-config", manifest_env,
                                        f"helm_config_pkg_version:{tag}",
                                        manifest_env, f"Version {tag} does not exist")
                proceedSyncappDriftCheck = False

        if proceedSyncappDriftCheck:
            valuesFiles = [os.path.join('config', 'values.yaml')]

            envValueFile = os.path.join('config', manifest_env, 'values.yaml')
            if os.path.exists(envValueFile):
                valuesFiles.append(envValueFile)

            # combining the common and env values.yaml
            values = utils.readCombinedYaml(valuesFiles)

            # Change back to original working dir
            os.chdir(current_dir)

            for service in services['etcd-syncapp-config']['config']:
                if service == 'dp' or service == 'dpStoreEndpoint':
                    for uriName in values['services'][service]:
                        remote_url = values['services'][service][uriName]
                        new_link = services['etcd-syncapp-config']['config'][service][uriName]
                        if (remote_url != new_link):
                            html_template = add_row(html_template, manifest_env,
                                                    "etcd-syncapp-config",
                                                    manifest_env,
                                                    f"{service}[{uriName}] has url {new_link} in manifest",
                                                    manifest_env, f"{service}[{uriName}] has actual url {remote_url} in repo", type)
                else:
                    if service in utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES:
                        uri = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES[service]
                    else:
                        uri = 'uri'

                    current_service_uri = services['etcd-syncapp-config']['config'][service][uri]
                    name = ''.join(re.findall(".*\(services\.(.*)\).*", current_service_uri))
                    if name not in services:
                        html_template = add_row(html_template, manifest_env, "etcd-syncapp-config",
                                                manifest_env,
                                                f"Service '{name}' is present in etcd-syncapp-config service with uri {current_service_uri} but not defined in manifest",
                                                manifest_env, f"N/A", type)
                    else:
                        remote_url = values['services'][service][uri]
                        if services[name]['type'] == 'subsc':
                            current_env = services[name]['configuration']['services-collection-manifest']
                            with open(f'../manifest/services-collection-manifest/{current_env}/services-manifest.yaml', 'r') as stream:
                                services_collection = yaml.load(stream)

                            service_name = services_collection['services'][name]['name']
                            service_org = services_collection['services'][name]['org']
                            new_link = utils.generate_config_url(service_name, current_env, service_org, current_service_uri)
                        else:
                            new_link = utils.generate_config_url(services[name]['name'], manifest_env, services[name]['org'], current_service_uri)

                        if (remote_url != new_link):
                            html_template = add_row(html_template, manifest_env,
                                                    "etcd-syncapp-config",
                                                    manifest_env,
                                                    f"{service} has url {new_link} in manifest",
                                                    manifest_env, f"{service} has actual url {remote_url} in repo", type)

    return html_template


def checkDriftForServices(services, html_template, manifest_env, type):
    """
    Check for drift between all the other services except etcd-syncapp
    """
    for key in services:
        if "env" in services[key]:
            app_env = services[key]["env"]
        else:
            app_env = manifest_env

        if services[key]["type"] == "helm" and key != "etcd-syncapp-config":
            packaging = services[key]["packaging"]
            if "pkg_branch" in packaging:
                manifest_app_branch = packaging.get("app_branch", "")
                manifest_app_version = packaging.get("app_version", "")
                manifest_helm_config_pkg_branch = packaging["pkg_branch"]

                manifest_out_text = ""
                if manifest_app_branch != "":
                    manifest_out_text += f"HELM_PROJECT_APP_JOB: {manifest_app_branch}\n"
                if manifest_app_version != "":
                    manifest_out_text += f"HELM_PROJECT_APP_TAG: {manifest_app_version}\n"
                if manifest_helm_config_pkg_branch != "":
                    manifest_out_text += f"HELM_PROJECT_CONFIG_JOB: {manifest_helm_config_pkg_branch}\n"

                app_org = services[key]["org"]
                app_name = services[key]["name"]
                static_deployer_exists = utils.check_jenkins_url(
                    f'https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/{app_org}/job/{app_name}/job/{app_env}/')
                if static_deployer_exists:
                    is_success, error, output = get_actual_config(app_name, app_env, app_org, "helm")
                    if is_success:
                        actual_app_branch = output["actual_app_branch"]
                        actual_app_version = output["actual_app_version"]
                        actual_helm_config_branch = output["actual_helm_config_branch"]
                        manifest_drift_text = ""
                        actual_drift_text = ""
                        if manifest_app_branch != actual_app_branch:
                            manifest_drift_text += f"HELM_PROJECT_APP_JOB: {manifest_app_branch}\n"
                            actual_drift_text += f"HELM_PROJECT_APP_JOB: {actual_app_branch}\n"
                        if manifest_app_version != actual_app_version:
                            manifest_drift_text += f"HELM_PROJECT_APP_TAG: {manifest_app_version}\n"
                            actual_drift_text += f"HELM_PROJECT_APP_TAG: {actual_app_version}\n"
                        if manifest_helm_config_pkg_branch != actual_helm_config_branch:
                            manifest_drift_text += f"HELM_PROJECT_CONFIG_JOB: {manifest_helm_config_pkg_branch}\n"
                            actual_drift_text += f"HELM_PROJECT_CONFIG_JOB: {actual_helm_config_branch}\n"

                        if manifest_drift_text or actual_drift_text:
                            html_template = add_row(html_template, manifest_env,
                                                    app_name,
                                                    app_env,
                                                    manifest_drift_text,
                                                    app_env, actual_drift_text, type)
                    else:
                        html_template = add_row(html_template, manifest_env,
                                                app_name,
                                                app_env,
                                                manifest_out_text,
                                                app_env, error, type)
                else:
                    html_template = add_row(html_template, manifest_env,
                                            app_name,
                                            app_env,
                                            manifest_out_text,
                                            app_env, "Static deployer does not exist.", type)
        elif services[key]["type"] == "legacy-helm":
            packaging = services[key]["packaging"]
            if "pkg_branch" in packaging:
                manifest_k8s_pkg_branch = packaging["pkg_branch"]

                manifest_out_text = ""
                if manifest_k8s_pkg_branch != "":
                    manifest_out_text += f"K8S_PACKAGE_JOB: {manifest_k8s_pkg_branch}"

                app_org = services[key]["org"]
                app_name = services[key]["name"]
                static_deployer_exists = utils.check_jenkins_url(
                    f'https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/{app_org}/job/{app_name}/job/{app_env}/')
                if static_deployer_exists:
                    is_success, error, output = get_actual_config(app_name, app_env, app_org, "legacy-helm")
                    if is_success:
                        actual_k8s_job = output["actual_k8s_job"]
                        manifest_drift_text = ""
                        actual_drift_text = ""
                        if manifest_k8s_pkg_branch != actual_k8s_job:
                            manifest_drift_text += f"K8S_PACKAGE_JOB: {manifest_k8s_pkg_branch}"
                            actual_drift_text += f"K8S_PACKAGE_JOB: {actual_k8s_job}"

                        if manifest_drift_text or actual_drift_text:
                            html_template = add_row(html_template, manifest_env, app_name, app_env,
                                                    manifest_drift_text, app_env, actual_drift_text, type)
                    else:
                        html_template = add_row(html_template, manifest_env, app_name, app_env,
                                                manifest_out_text, app_env, error, type)
                else:
                    html_template = add_row(html_template, manifest_env, app_name, app_env,
                                            manifest_out_text, app_env, "Static deployer does not exist.", type)

    return html_template


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", type=str, required=True)
    args = parser.parse_args()
    html_template_out = ""

    for type in os.listdir(args.path):
        for env in os.listdir(f'{args.path}/{type}'):
            try:
                print(f"{type} {env} is in progress for drift checking")
                manifest_content = processing_utils.assemble_manifest(f'{args.path}/{type}/{env}/services-manifest.yaml')
                content_yaml = yaml.load(json.loads(manifest_content)["manifest"])

                html_template_out = checkDriftForETCDSyncapp(content_yaml["services"], html_template_out, env, type)

                html_template_out = checkDriftForServices(content_yaml["services"], html_template_out, env, type)

                pattern = f"""<tr><td>{env}</td>"""
                count = len(re.findall(pattern, html_template_out))
                if count > 0:
                    merged_pattern = f"<tr><td rowspan='{count}'>{env}</td>"
                    html_template_out = html_template_out.replace(pattern, merged_pattern, 1)
                    html_template_out = html_template_out.replace(pattern, "<tr>")
            except Exception as e:
                print('Comparison skipped due to error', e)

    complete_html_output = f"{HTML_TABLE_TEMPLATE_HEAD}{html_template_out}{HTML_TABLE_TEMPLATE_TAIL}"
    with open("output.html", "w") as f:
        f.write(complete_html_output)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        # Don't dump stack, just exit.
        sys.exit(' Interrupted by user')
