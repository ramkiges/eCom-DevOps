#!/usr/bin/env python3

import argparse
import yaml
import yamale
import json
import sys
from modules import utils


def check_schema(manifest_body: dict, manifest_type: str, env_name: str):
    schema_file_path = "./schema.yaml"
    env_schema_file_path = f"../manifest/{env_name}-{manifest_type}-schema.yaml"
    result = ""

    for app_title, app_entry in manifest_body["services"].items():
        if app_title == "etcd-syncapp-config":
            result += f"  {app_title}: include('etcd_syncapp_config')\n"
        elif ('type' not in app_entry) and ('configuration' in app_entry):      
            result += f"  {app_title}: include('subscription')\n"
        else:
            if app_entry['type'] == 'helm':
                result += f"  {app_title}: include('helm')\n"
            elif app_entry['type'] == 'vm':
                result += f"  {app_title}: include('vm')\n"
            elif app_entry['type'] == 'legacy-helm':
                result += f"  {app_title}: include('legacy')\n"
            

    with open(schema_file_path, 'r+') as file:
        schema_template = file.read()

    with open(env_schema_file_path, 'w') as file:
        file.write("services:\n" + result + schema_template)

    schema = yamale.make_schema(env_schema_file_path)
    data = yamale.make_data(content=str(manifest_body))

    try:
        yamale.validate(schema, data)
        print(f'{manifest_type}: Passed')
    except ValueError as e:
        print(f'{manifest_type}: Failed!\n{str(e)}')
        print('\nFor detailed information about the manifest formatting, please refer to the documentation.'
              '\nhttps://confluence.wsgc.com/x/moBMKQ')




def main(env_name: str, env_manifest_changed: bool, svc_manifest_changed: bool):

    if env_manifest_changed:
        env_manifest = {}
        env_manifest_path = f"../{utils.ENV_MANIFEST_PATH.format(env=env_name)}"
        with open(env_manifest_path) as stream:
            env_manifest = yaml.safe_load(stream)
        check_schema(env_manifest, 'env-manifest', env_name)

    if svc_manifest_changed:
        services_manifest = {}
        svc_manifest_path = f"../{utils.SERVICES_MANIFEST_PATH.format(env=env_name)}"
        with open(svc_manifest_path) as stream:
            services_manifest = yaml.safe_load(stream)

            all_names = [services_manifest['services'][service]['name'] for service in services_manifest['services']]            
            if len(all_names) > len(set(all_names)):
                not_unique_names = [
                    service for service in services_manifest['services']
                    if all_names.count(services_manifest['services'][service]['name']) > 1]
                sys.exit(f'Services defined with same names are not allowed: {not_unique_names}')

        check_schema(services_manifest, 'services-collection-manifest', env_name)

    if not env_manifest_changed and not svc_manifest_changed:
        print('No modified manifests have been detected.')


if __name__ == "__main__":
    """
    `--manifests_changed` example: '{"env-manifest": true, "services-collection-manifest": true}'
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, required=True, help='Environment name')
    parser.add_argument('--manifests_changed', type=str, required=True)
    args = parser.parse_args()

    env_changed = args.env
    manifests_changed = json.loads(args.manifests_changed)   

    main(env_changed, manifests_changed['env-manifest'], manifests_changed['services-collection-manifest'])
