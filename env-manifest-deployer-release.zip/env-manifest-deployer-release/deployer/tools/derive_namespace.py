#!/usr/bin/env python3

import sys
from modules import utils
import json

input = sys.stdin.read()
input_json = json.loads(input)

app_org = input_json.get("org")
app_name = input_json.get("name")
app_env = input_json.get("env")

out = utils.deriveNamespace(app_org, app_name, app_env)

output = {
    "out": out
}

print(json.dumps(output))
