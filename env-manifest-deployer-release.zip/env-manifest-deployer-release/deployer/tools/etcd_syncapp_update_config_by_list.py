#!/usr/bin/env python3

"""
The script selectively updates `etcd-syncapp-config` entries based on services-collection-manifest entry.
Example run:
    python3 tools/etcd_syncapp_branch.py \
        --env_name qa29 \
        --app_list "ecom-app-customer"

Could accept a comma-separated list of app names.
Example run:
    python3 tools/etcd_syncapp_branch.py \
        --env_name qa29 \
        --app_list "experimentation,ecom-svc-catalog,ecom-svc-registry,ecom-app-config-all"
"""

import sys
import ruamel.yaml 
import os
import argparse
import re
from modules import utils

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True
yaml.width = 250


def find_syncapp_config_by_app(app_name: str, etcd_syncapp_config: dict):
    """
    Accepts `services-collection-manifest` pointer app name and returns associated list `etcd-syncapp-config` entries. 
    """
    result = []
    for service_title, service_entry in etcd_syncapp_config.items():
        for url_entry in service_entry.values():
            if app_name in url_entry:
                result.append(service_title)
    return result
    

def update_etcd_syncapp_config(service_name: str, url_key: str, url_value: dict, target_config: dict, common_config: dict):
    if service_name not in target_config:
        if service_name in common_config:
            if common_config[service_name][url_key] == url_value:
                print('Already presents in common config, skip')
            else:
                print(f'Added new config: {url_key} = {url_value}')
                target_config[service_name] = {}
                target_config[service_name][url_key] = url_value
    else:
        if target_config[service_name][url_key] == url_value:
            print(f'No changes')
        else:
           print(f'Updated from: {target_config[service_name][url_key]}\nUpdated to:   {url_value}')
           target_config[service_name][url_key] = url_value
    

def main(env_name: str, app_list: list):

    env_manifest_path = utils.ENV_MANIFEST_PATH.format(env=env_name)
    manifest_etcd_syncapp_config = {}

    repo_etcd_syncapp = 'etcd-syncappconfig-helm-config'
    repo_etcd_syncapp_config_path = f'{repo_etcd_syncapp}/config/{env_name}/values.yaml'
    repo_common_etcd_syncapp_config_path = f'{repo_etcd_syncapp}/config/values.yaml'
    repo_syncconfig = {}
    repo_common_syncconfig = {}
    repo_etcd_syncapp_config = {}
    repo_common_etcd_syncapp_config = {}

    affeted_syncapp_services = []

    if not os.path.exists(f'../{repo_etcd_syncapp}'):
        print(f'Cloned repository `{repo_etcd_syncapp}` cannot be found locally')
        sys.exit(1)

    with open(f'../{env_manifest_path}', 'r') as stream:
        env_manifest = yaml.load(stream)

    with open(f'../{repo_etcd_syncapp_config_path}', 'r') as stream:
        repo_syncconfig = yaml.load(stream)
    repo_etcd_syncapp_config = repo_syncconfig['services']

    with open(f'../{repo_common_etcd_syncapp_config_path}', 'r') as stream:
        repo_common_syncconfig = yaml.load(stream)
    repo_common_etcd_syncapp_config = repo_common_syncconfig['services']

    if 'etcd-syncapp-config' in env_manifest['services']:
        manifest_etcd_syncapp_config = env_manifest['services']['etcd-syncapp-config']['config']
    else:
        print(f'No `etcd-syncapp-config` in `{env_manifest_path}`, nothing to do')
        sys.exit(0)

    for app_name in app_list:
        affeted_syncapp_services += find_syncapp_config_by_app(app_name, manifest_etcd_syncapp_config)

    if not affeted_syncapp_services:
        print(f'\nRequested `services-collection-manifest` entries:\n{app_list}\nHave no effect on the manifest`s `etcd-syncapp-config`.')
        sys.exit(0)

    for service in affeted_syncapp_services:
        print(f'\nProcessing `{service}` etcd-syncapp-config entry...')
        uriKey = utils.ETCD_SYNCAPP_EXCEPTION_URI_SERVICES.get(service, 'uri')
        pointer = manifest_etcd_syncapp_config[service][uriKey]
        current_app_title = ''.join(re.findall('.*\(services\.(.*)\).*', pointer))
        current_env = env_manifest['services'][current_app_title]['configuration']['services-collection-manifest']
        current_svc_manifest_path = utils.SERVICES_MANIFEST_PATH.format(env=current_env)
        
        with open(f'../{current_svc_manifest_path}', 'r') as stream:
            current_svc_manifest = yaml.load(stream)

        if current_app_title not in current_svc_manifest['services']:
            sys.exit(
                f'`{current_app_title}` needs to be defined in the `{current_env}` services-collection-manifest '
                'before it can be added to the etcd-syncapp-config')
                        
        service_name = current_svc_manifest['services'][current_app_title]['name']
        service_org = current_svc_manifest['services'][current_app_title]['org']
        new_link = utils.generate_config_url(service_name, current_env, service_org, pointer)
        update_etcd_syncapp_config(service, uriKey, new_link, repo_etcd_syncapp_config, repo_common_etcd_syncapp_config)

    with open(f'../{repo_etcd_syncapp_config_path}', 'w') as file:
        yaml.dump(repo_syncconfig, file)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--env_name', help='An environment of the etcd-syncapp-config', required=True)
    parser.add_argument('--app_list', help='The list of service names from etcd-syncapp-config', required=True)
    args = parser.parse_args()

    env_name = args.env_name
    app_list = (args.app_list).split(',')

    main(env_name, app_list)
