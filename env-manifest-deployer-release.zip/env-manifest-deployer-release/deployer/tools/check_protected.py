#!/usr/bin/env python3

import json
import sys
from modules import utils

input = sys.stdin.read()
input_json = json.loads(input)
name = input_json.get('module_name')
env = input_json.get('app_env')
out = {'protected': 'false'}
if name != 'etcd-syncapp-config':
    with open(utils.METADATA_FLAGS_FILENAME, 'r') as stream:
        flags = json.load(stream).get(env, {}).get(name, {}).get('protected', {})
        out['protected'] = 'true' if flags.get('value', False) else 'false'

print(json.dumps(out))
