#!/usr/bin/env python3

import json
import sys
from modules import processing_utils

input = sys.stdin.read()
input_json = json.loads(input)

app_name = input_json.get("app_name")
module_name = input_json.get("module_name")
new_k8s_job = input_json.get("k8s_package_branch")
app_env = input_json.get("app_env")
app_org = input_json.get("app_org")
protected_env = input_json.get("protected_env")

output = processing_utils.get_legacy_version(app_name, module_name, new_k8s_job, app_env, app_org, protected_env)
output["k8s_package_branch"] = new_k8s_job
output["app_name"] = app_name
output["app_env"] = app_env
output["app_org"] = app_org

print(json.dumps(output))
