#!/usr/bin/env python3

import argparse
import json
import sys
import os
import subprocess
from deepmerge import always_merger

parser = argparse.ArgumentParser()
parser.add_argument('--tfplanpath', type=str, required=True)
args = parser.parse_args()
terraformPlanPath = args.tfplanpath

resource_changes = []
config_drifts = {}


def config_drifts_constructor(app_name: str,
                              changed_resource_name: str,
                              changed_module_name: str,
                              app_resource_address: str,
                              current_terraform_after_state: dict) -> dict:

    helm_pointers = [
        'static_deployer',
        'helm_deployer',
        'helm-uninstall',
        'helm_config_endpoint_update',
        'etcd_syncapp_config_update']
    legacy_helm_pointers = [
        'legacy_static_deployer',
        'legacy_helm_deployer',
        'legacy_config_endpoint_update']
    vm_pointers = ['rpm_deployer']
    ignore_pointers = ['helm-uninstall']
    app_type = "unrecognized"

    if current_terraform_after_state is None:
        current_terraform_state = "Application doesn't exist in terraform state yet"
    else:
        current_terraform_state = current_terraform_after_state["triggers"]
        current_terraform_state.pop("trigger", "")
    if any(element in changed_resource_name for element in helm_pointers):
        app_type = 'helm'
    if any(element in changed_resource_name for element in vm_pointers):
        app_type = 'vm'
    if any(element in changed_resource_name for element in legacy_helm_pointers):
        app_type = 'legacy-helm'
    if any(element in changed_resource_name for element in ignore_pointers):
        return None

    result = {
        app_name: {
            'type': app_type,
            'app_resource_address': app_resource_address,
            'changed_resource_name': changed_resource_name,
            'changed_module_name': changed_module_name,
            'child_resource_addresses': '',
            'current_terraform_state': current_terraform_state,
            'actual_resource_configs': [],
            'actual_resource_config_merged': {}
        }
    }
    return result


def get_related_child_resource_addresses(tfplan_child_modules: list,
                                         pattern_module_name: str,
                                         pattern_app_resource_address: str,
                                         app_name: str) -> list:
    dependent_resources = []
    found_child_resource_list = []
    for module in tfplan_child_modules:
        if module["address"] == pattern_module_name:
            found_child_resource_list = module["resources"]
            for child_resource in found_child_resource_list:
                if child_resource["address"] == pattern_app_resource_address:
                    found_child_resource_depends = child_resource["depends_on"]
                    for resource_dep in found_child_resource_depends:
                        if "module" in resource_dep:
                            prefix = resource_dep.split(".data")[0]
                            suffix = resource_dep.split(".data")[1]
                            dependent_resource = prefix + \
                                '["' + app_name + '"]' + '.data' + suffix
                            dependent_resources.append(dependent_resource)
    return dependent_resources


def get_actual_resource_config(tfplan_child_modules: list,
                               pattern_module_name: str,
                               pattern_app_resource_address: str,
                               app_type: str) -> dict:
    found_child_resource_list = []
    result = {}
    hide_result_keys = [
        'existing_config_job',
        'existing_app_job',
        'existing_k8s_job',
        'app_namespace',
        'dry_run_flag',
        'is_process_running',
        'current_package_version',
        'check_update',
        'timestamp',
        'trigger',
        'out',
        'app_branch',
        'app_version',
        'update'
    ]
    for module in tfplan_child_modules:
        if module["address"] == pattern_module_name:
            found_child_resource_list = module["resources"]
            for child_resource in found_child_resource_list:
                if child_resource["address"] == pattern_app_resource_address:
                    result = child_resource["values"]["result"].copy()
                    if app_type == 'helm':
                        if "existing_config_job" in result:
                            result["helm_config_pkg_branch"] = result["existing_config_job"]
                        if "existing_app_job" in result:
                            result["app_branch/app_version"] = result["existing_app_job"]
                    elif app_type == 'vm':
                        if "rpm_pkg_version" in result:
                            result["rpm_pkg_version"] = result["current_package_version"]
                    elif app_type == 'legacy-helm':
                        if "existing_k8s_job" in result:
                            result["k8s_package_branch"] = result["existing_k8s_job"]
                    for key in hide_result_keys:
                        if key in result:
                            result.pop(key, "")
    return result


def display_endpoint_resource_config_drift(drift_info, type):
    if drift_info["child_resource_addresses"]:
        if "driftDetails" in drift_info["actual_resource_config_merged"]:
            driftDetails = drift_info["actual_resource_config_merged"][
                "driftDetails"]
            driftDetails = json.loads(driftDetails)
            for helmUrlKey, helmUrlValue in driftDetails.items():
                print(
                    "Helm Endpoint Url Key: " + helmUrlKey +
                    "\nHelm Endpoint Current Url in terraform state: " +
                    helmUrlValue["Current"] +
                    "\nHelm Endpoint Actual Url: " +
                    helmUrlValue["Actual"])
    else:
        print("Current terraform state: \n" +str(drift_info["current_terraform_state"]))
        print("")
        endpoints_config = ""
        if type == "helm" and "helm_endpoints_configuration" in drift_info[
                "actual_resource_config_merged"]:
            endpoints_config = drift_info["actual_resource_config_merged"][
                "helm_endpoints_configuration"]
        elif type == "legacy-helm" and "legacy_endpoints_configuration" in drift_info[
                "actual_resource_config_merged"]:
            endpoints_config = drift_info["actual_resource_config_merged"][
                "legacy_endpoints_configuration"]

        print(
            "Actual resource Config: \nEndpoints configuration: \n" +
            endpoints_config)


def display_config_drifts(drift_info: dict):
    if "null_resource.etcd_syncapp_config_update[0]" in drift_info["app_resource_address"]:
        print("-------------------------------------------------------------")
        display_etcd_syncapp_config(drift_info)
    else:
        print("-------------------------------------------------------------")
        print("App Module name having drift: " + drift_info["changed_module_name"])
        print("Drift details:\n")
        if "null_resource.helm_config_endpoint_update" in drift_info["app_resource_address"]:
            display_endpoint_resource_config_drift(drift_info, "helm")
        elif "null_resource.legacy_config_endpoint_update" in drift_info["app_resource_address"]:
            display_endpoint_resource_config_drift(drift_info, "legacy-helm")
        else:
            print(
                "Current terraform state:\n"
                f"{prettify_output(drift_info['current_terraform_state'])}\n"
                "Actual resource Config:\n"
                f"{prettify_output(drift_info['actual_resource_config_merged'])}")


def prettify_output(info):
    params = {
        'app_name': 'Name', 'app_env': 'Env', 'app_org': 'Org', 'helm_config_pkg_branch': 'Config branch',
        'helm_config_pkg_version': 'Config version', 'k8s_package_branch': 'Config branch',
        'legacy_package_version': 'Config version', 'rpm_pkg_version': 'Package version',
        'helmconfigversion': 'Config version', 'legacypackageversion': 'Config version',
        'app_branch': 'App branch', 'app_version': 'App version',
        'app_branch/app_version': 'App branch/version'
    }
    out = ""
    for key in params:
        if key in info:
            out += f"  {params[key]}: {info[key]}\n"

    return out


def display_etcd_syncapp_config(drift_info):
    print(
        "App resource name having drift: etcd-syncapp-config\n"
        "Drift details:\n"
        "Current terraform state:")
    urls_out = False
    for key, value in drift_info["actual_resource_config_merged"].items():
        if 'configured_url' in key:
            urls_out = True
            print(f"{key.split('_', 1)[0]} : {value}")
    branch = drift_info["current_terraform_state"]["helm_config_pkg_branch"]
    if branch != '' and branch != drift_info["actual_resource_config_merged"][
            "helm_config_pkg_branch"]:
        print(f"helm_config_pkg_branch : {branch}")
    version = drift_info["current_terraform_state"]["helm_config_pkg_version"]
    if version != '' and version != drift_info["actual_resource_config_merged"][
            "helm_config_pkg_version"]:
        print(f"helm_config_pkg_version : {version}")
    print("\nActual resource Config:")
    for key, value in drift_info["actual_resource_config_merged"].items():
        if 'actual_url' in key:
            print(f"{key.split('_', 1)[0]} : {value}")
        if 'helm_config_pkg_branch' in key and value != '' and value != branch:
            print(f"{key} : {value}")
        if 'helm_config_pkg_version' in key and value != '' and value != version:
            print(f"{key} : {value}")
    if urls_out:
        print(
            "\nSource:\nurls : "
            f"{drift_info['actual_resource_config_merged']['urls_source']}")

if os.path.exists(terraformPlanPath):
    cmd = "terraform show -json " + terraformPlanPath
    cmd = cmd.split()

    subprocessArgs = {
        'args': cmd,
        'check': False,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }

    tfplan = None
    try:
        result = subprocess.run(**subprocessArgs)
        out = result.stdout
        if out and out != "":
            tfplan = json.loads(out)
    except subprocess.CalledProcessError as e:
        sys.exit(f"Exception when calling subprocess: {e.stdout}")

    if tfplan:
        resource_changes = tfplan["resource_changes"]
        for resource_change in resource_changes:
            for action in resource_change["change"]["actions"]:
                if action != "no-op":
                    """
                    split app_name example:
                    module.helm-services-module[\"ecom-app-shop\"] --> ecom-app-shop
                    """
                    app_name = resource_change[
                        "module_address"].split('["')[1].split('"]')[0]
                    changed_resource_name = resource_change["name"]

                    resource_config_drift = config_drifts_constructor(
                        app_name=app_name,
                        changed_resource_name=changed_resource_name,
                        changed_module_name=resource_change["module_address"],
                        app_resource_address=resource_change["address"],
                        current_terraform_after_state=resource_change["change"]["after"])
                    if resource_config_drift is not None:
                        config_drifts = always_merger.merge(
                            config_drifts, resource_config_drift)

        for drift_app_name, drift_app_info in config_drifts.items():
            child_resource_addresses = get_related_child_resource_addresses(
                tfplan_child_modules=tfplan[
                    "prior_state"]["values"]["root_module"]["child_modules"],
                pattern_module_name=drift_app_info["changed_module_name"],
                pattern_app_resource_address=drift_app_info["app_resource_address"],
                app_name=drift_app_name)
            drift_app_info["child_resource_addresses"] = child_resource_addresses
            actual_resource_config = {}

            if drift_app_info["child_resource_addresses"] != []:
                for child_resource_address in drift_app_info["child_resource_addresses"]:
                    actual_resource_config = {}
                    actual_resource_config = get_actual_resource_config(
                        tfplan_child_modules=tfplan[
                            "prior_state"]["values"]["root_module"]["child_modules"],
                        pattern_module_name=drift_app_info["changed_module_name"],
                        pattern_app_resource_address=child_resource_address,
                        app_type=drift_app_info["type"])
                    drift_app_info["actual_resource_configs"].append(
                        actual_resource_config)

            else:
                for resource_change in resource_changes:
                    if resource_change["address"] == drift_app_info["app_resource_address"]:
                        actual_resource_config = resource_change["change"][
                            "after"]["triggers"].copy()
                        if "trigger" in actual_resource_config:
                            actual_resource_config.pop("trigger", "")
                        drift_app_info["actual_resource_configs"].append(
                            actual_resource_config)

            if drift_app_info["actual_resource_configs"] != []:
                for actual_config in drift_app_info["actual_resource_configs"]:
                    drift_app_info["actual_resource_config_merged"] = always_merger.merge(
                        drift_app_info["actual_resource_config_merged"], actual_config)

            display_config_drifts(drift_app_info)
