#!/usr/bin/env python3

import sys
from modules import processing_utils
import json

input_json = json.load(sys.stdin)
manifest_path = input_json['manifest_path']
output = processing_utils.assemble_manifest(manifest_path)

print(output)
