#!/usr/bin/env python3
"""
Log the helm endpoint asymmetrical config validations as a warning.
The validations are done during the terraform plan and terraform
only provides a way to error out on those validations. Hence, parse
the terraform plan output to print those validations as a warning

Inputs:
--env: Env for which validations are run
--tfplanpath: Path to the terraform plan file
"""

import argparse
import json
import os
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--env', type=str, required=True)
parser.add_argument('--tfplanpath', type=str, required=True)
args = parser.parse_args()

env = args.env
terraformPlanPath = args.tfplanpath

if os.path.exists(terraformPlanPath):
    cmd = "terraform show -json " + terraformPlanPath
    cmd = cmd.split()

    subprocessArgs = {
        'args': cmd,
        'check': False,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }

    tfplan = None
    try:
        result = subprocess.run(**subprocessArgs)
        out = result.stdout
        if out and out != "":
            tfplan = json.loads(out)
    except subprocess.CalledProcessError as e:
        sys.exit(f"Exception when calling subprocess: {e.stdout}")

    if tfplan:
        if "prior_state" in tfplan:
            priorState = tfplan["prior_state"]
            if "values" in priorState and "root_module" in priorState["values"]:
                rootModule = priorState["values"]["root_module"]
                if "child_modules" in rootModule:
                    for childModule in rootModule["child_modules"]:
                        if "resources" in childModule:
                            for resource in childModule["resources"]:
                                name = resource["name"]
                                if name == "get_helm_config_endpoint_current_state" or \
                                        name == "get_legacy_config_endpoint_current_state":
                                    appName = resource["values"]["query"]["app_name"]
                                    validationText = resource["values"]["result"]["validation_check"]
                                    if validationText:
                                        print(f"WARNING: There are below asymmetrical config that needs to be fixed "
                                              f"for app {appName}:\n\n")
                                        print(f"{validationText}\n\n")
