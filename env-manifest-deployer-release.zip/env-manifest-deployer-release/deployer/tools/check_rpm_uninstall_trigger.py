#!/usr/bin/env python3

import sys
import json
import os
import json
import subprocess


input = sys.stdin.read()
input_json = json.loads(input)
app_name = input_json.get("app_name")
module_name = input_json.get("module_name")
app_env = input_json.get("app_env")
app_org = input_json.get("app_org")
app_brand = input_json.get("app_brand")
app_group = input_json.get("app_group")
dry_run_flag = input_json.get("dry_run_flag")

dry_run_flag_to_set = dry_run_flag

if os.path.exists("terraform.tfstate"):
    cmd = "terraform show -json terraform.tfstate"
    cmd = cmd.split()

    subprocessArgs = {
        'args': cmd,
        'check': False,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }

    try:
        result = subprocess.run(**subprocessArgs)
        out = result.stdout
        if out and out != "":
            tfstate = json.loads(out)
            child_modules = tfstate["values"]["root_module"]["child_modules"]
            for child_module in child_modules:
                if child_module.get("address", "") == f"module.vm-services-module[\"{module_name}\"]":
                    if "resources" in child_module:
                        for resource in child_module["resources"]:
                            if "rpm-uninstall" in resource["address"]:
                                triggers = resource["values"]["triggers"]
                                app_name_current_val = triggers.get("app_name", "")
                                app_env_current_val = triggers.get("app_env", "")
                                app_org_current_val = triggers.get("app_org", "")
                                app_brand_current_val = triggers.get("app_brand", "")
                                app_group_current_val = triggers.get("app_group", "")
                                dry_run_flag_current_val = triggers.get("dry_run", dry_run_flag)
                                if (app_name_current_val != app_name) or (app_env_current_val != app_env) or \
                                        (app_org_current_val != app_org) or (app_brand_current_val != app_brand) or \
                                        (app_group_current_val != app_group):
                                    trigger = True
                                    dry_run_flag_to_set = dry_run_flag
                                else:
                                    dry_run_flag_to_set = dry_run_flag_current_val
    except subprocess.CalledProcessError:
        sys.stderr.write(f"Exception when calling subprocess: {subprocess.CalledProcessError.stderr}")
        sys.exit(1)

output = {
    "dry_run_flag": dry_run_flag_to_set,
    "app_name": app_name,
    "app_org": app_org,
    "app_env": app_env,
    "app_brand": app_brand,
    "app_group": app_group
}

print(json.dumps(output))
