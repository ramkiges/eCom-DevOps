#!/usr/bin/env python3

import sys, xmltodict

response_xml_path = sys.argv[1]
response_xml = ""
with open(response_xml_path, "r") as f:
    response_xml = f.read()

new_config_job = sys.argv[2]
new_app_job = sys.argv[3]
new_app_tag = sys.argv[4]

# converting the xml config to a python dict
response_dict = xmltodict.parse(response_xml)

# get the propertiesContent element of interest that consists of the helm packaging branch currently configured
# for the job
propertiesContent = response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info'][
        'propertiesContent']

# populate the values to a dictionary by splitting on "=".
# Example of a propertiesContent
# HELM_PROJECT_CONFIG_JOB=eCommerce-Kubernetes-Bedrock/vertex-lite-helm-config/release
jobPropertiesKVPair = dict()
for propertyContent in propertiesContent.split("\n"):
    splits = propertyContent.split("=")
    jobPropertiesKVPair[splits[0]] = splits[1]

existing_app_job = ""
existing_config_job = ""
if "HELM_PROJECT_APP_JOB" in jobPropertiesKVPair:
    existing_app_job = jobPropertiesKVPair['HELM_PROJECT_APP_JOB']
if "HELM_PROJECT_APP_TAG" in jobPropertiesKVPair:
    existing_app_job = jobPropertiesKVPair['HELM_PROJECT_APP_TAG']
if "HELM_PROJECT_CONFIG_JOB" in jobPropertiesKVPair:
    existing_config_job = jobPropertiesKVPair['HELM_PROJECT_CONFIG_JOB']

new_property = ""
if new_app_job:
    new_property = f"HELM_PROJECT_APP_JOB={new_app_job}"
if new_app_tag:
    new_property = f"HELM_PROJECT_APP_TAG={new_app_tag}"
new_job_properties = f"{new_property}\nHELM_PROJECT_CONFIG_JOB={new_config_job}"
response_dict['flow-definition']['properties']['EnvInjectJobProperty']['info'][
    'propertiesContent'] = new_job_properties

if len(new_config_job) == 0 and len(new_app_job) == 0:
    triggers = response_dict['flow-definition']['properties']['org.jenkinsci.plugins.workflow.job.properties.PipelineTriggersJobProperty']['triggers']
    if triggers:
        if 'upstreamProjects' in triggers['jenkins.triggers.ReverseBuildTrigger']:
            triggers['jenkins.triggers.ReverseBuildTrigger']['upstreamProjects'] = ""
    
new_xml = xmltodict.unparse(response_dict, pretty=True)

print(new_xml)
