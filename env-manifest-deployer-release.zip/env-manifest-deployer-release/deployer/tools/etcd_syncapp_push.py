#!/usr/bin/env python3

"""
Combine all changed services into one file and push it to the remote.
"""

import sys
import ruamel.yaml
import os
from modules import utils
import time

yaml = ruamel.yaml.YAML()

env = sys.argv[1]
commit = sys.argv[2]

os.chdir("etcd-syncappconfig-helm-config")
utils.run(['git', 'remote', '-v'])
diffOut = utils.run(['git', 'diff'])
if diffOut:
    utils.run(['git', 'add', f'config/{env}/values.yaml'])
    commitMsg = f'[Auto-update] etcd-syncapp-config updated for {env} from manifest commit {commit}'
    utils.run(['git', 'commit',  '-m', commitMsg])
    retryLimit = 5
    for i in range(retryLimit):
        try:
            utils.run(['git', 'pull', '--prune'], exitOnError=False)
            utils.run(['git', 'push', 'origin', 'HEAD'], exitOnError=False)
            break
        except Exception as e:
            if i == retryLimit - 1:
                sys.exit(1)
            else:
                time.sleep(2)
                continue
else:
    print('Skipping push as there are no changes in etcd-syncappconfig-helm-config repo to push')
