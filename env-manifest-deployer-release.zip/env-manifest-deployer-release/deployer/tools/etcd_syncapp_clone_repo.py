#!/usr/bin/env python3

"""
Clone etcd-syncappconfig repo if the service is present in the manifest.
"""

import sys
import ruamel.yaml
from modules import utils
import os
import subprocess

yaml = ruamel.yaml.YAML()
yaml.allow_duplicate_keys = True

env = sys.argv[1]

with open(utils.ENV_MANIFEST_PATH.format(env=env), 'r') as stream:
    manifest = yaml.load(stream)

if 'etcd-syncapp-config' in manifest['services']:
    syncapp_config_change_path = f"temp/etcd-syncapp-config-changes/{env}"
    if os.path.isdir(syncapp_config_change_path):
        subprocess.run(['rm', '-rf', syncapp_config_change_path])
    if 'pkg_branch' in manifest['services']['etcd-syncapp-config']['packaging']:
        helm_config_pkg_branch_path = manifest['services']['etcd-syncapp-config']['packaging']['pkg_branch']
        utils.clone_etcd_syncapp_repo(helm_config_pkg_branch_path)
