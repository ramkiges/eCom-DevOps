#!/usr/bin/env python3

"""
TO BE REFACTORED
"""

import yaml
import sys
import requests
from modules import utils
import xmltodict
import re
import argparse
import os


STATIC_DEPLOYER_JENKINS_URL = "https://ecombuild.wsgc.com/jenkins/view/devops-mfe/job"
ETCD_SYNCAPP_REPO = "etcd-syncappconfig-helm-config"

# exception for keys. Default key uri
ETCD_SYNCAPP_SERVICE_KEY_EXCEPTION = {
    "experimentation": "baseUri"
}


def etcd_syncapp_manifest_process():
    requests.packages.urllib3.disable_warnings()
    args = parseArgs()
    env = args.env
    push_changes = args.push_changes

    user = utils.getCredential('jenkins', 'user')
    password = utils.getCredential('jenkins', 'password')

    request_url = f"{STATIC_DEPLOYER_JENKINS_URL}/config-{env}-mfe/config.xml"
    response = requests.get(request_url, verify=False, auth=(user, password))
    response_xml = response.text
    # converting the xml config to a python dict
    response_dict = xmltodict.parse(response_xml)
    param_list = \
    response_dict['project']['properties']['hudson.model.ParametersDefinitionProperty']['parameterDefinitions'][
        'hudson.model.StringParameterDefinition']

    configFound = False
    for param in param_list:
        if param["name"] == "SYNCAPPCONFIG_REPO":
            syncapp_config_repo = param['defaultValue']
            if syncapp_config_repo != "":
                configFound = True
                syncapp_config_splits = syncapp_config_repo.split("/")
                syncapp_config_org = syncapp_config_splits[0]
                syncapp_config_branch = syncapp_config_splits[1]
                syncapp_config_branch_url = f"https://github.wsgc.com/raw/{syncapp_config_org}/{ETCD_SYNCAPP_REPO}/{syncapp_config_branch}"
                syncapp_config_common_values_url = f"{syncapp_config_branch_url}/config/values.yaml"
                syncapp_config_env_values_url = f"{syncapp_config_branch_url}/config/{env}/values.yaml"
                syncapp_config_common_values = get_yaml_content(syncapp_config_common_values_url)
                syncapp_config_env_values = get_yaml_content(syncapp_config_env_values_url)
                values = readCombinedYaml(syncapp_config_common_values, syncapp_config_env_values)
                generate_etcd_syncapp_config(values, syncapp_config_repo, True, push_changes, env)
        if not configFound and param["name"] == "SYNCAPPCONFIG_VERSION":
            syncapp_config_version = param['defaultValue']
            if syncapp_config_version != "":
                configFound = True
                syncapp_config_org = "eCommerce-Kubernetes-Bedrock"
                syncapp_config_release_tag = f"release-{syncapp_config_version}"
                syncapp_config_branch_url = f"https://github.wsgc.com/raw/{syncapp_config_org}/{ETCD_SYNCAPP_REPO}/{syncapp_config_release_tag}"
                syncapp_config_common_values_url = f"{syncapp_config_branch_url}/config/values.yaml"
                syncapp_config_env_values_url = f"{syncapp_config_branch_url}/config/{env}/values.yaml"
                syncapp_config_common_values = get_yaml_content(syncapp_config_common_values_url)
                syncapp_config_env_values = get_yaml_content(syncapp_config_env_values_url)
                values = readCombinedYaml(syncapp_config_common_values, syncapp_config_env_values)
                generate_etcd_syncapp_config(values, syncapp_config_version, False, push_changes, env)


def generate_etcd_syncapp_config(values, syncapp_config_param, is_branch, push_changes, env):
    configValues = {
        "name": "etcd-syncapp-config",
        "type": "helm",
        "org": "ecom",
        "shared": False
    }

    helm_config_packaging = []
    if is_branch:
        packagingObj = {"packaging": {"branch_only_config": {"helm_config_pkg_branch": syncapp_config_param}}}
    else:
        packagingObj = {"packaging": {"helm_config_version_only": {"helm_config_pkg_version": syncapp_config_param}}}

    helm_config_packaging.append(packagingObj)
    configValues["helm_config_packaging"] = helm_config_packaging

    configMap = {}
    for service, serviceObj in values["services"].items():
        if service != "dp" and service != "dpStoreEndpoint":
            key = "uri"
            if service in ETCD_SYNCAPP_SERVICE_KEY_EXCEPTION:
                key = ETCD_SYNCAPP_SERVICE_KEY_EXCEPTION[service]

            url = serviceObj[key]
            extractUrlComponents = re.compile("http(|s)://([a-zA-Z0-9-.]+)/(.*)")
            regexMatch = extractUrlComponents.match(url)
            urlPrefix = ""
            if regexMatch:
                urlComponent = regexMatch.group(2)
                urlSuffix = regexMatch.group(3)
                if "ecommerce-ecom-svc-catalog" in urlComponent:
                    serviceName = "ecom-svc-catalog"
                    if 'rj-' in urlComponent:
                        urlPrefix = "rj-"
                    else:
                        urlPrefix = "WS-"
                elif "pb-catalog-service" in urlComponent:
                    serviceName = "catalog-pb"
                    urlPrefix = "pb-"
                else:
                    if "svc.cluster.local" in urlComponent:
                        extractServiceName = re.compile("([a-zA-Z0-9-]+)\.(.*)")
                        isMatch = extractServiceName.match(urlComponent)
                        if isMatch:
                            serviceName = isMatch.group(1)
                        else:
                            sys.exit(f"Failed tp extract service name from url {url} for service {service}")
                    else:
                        extractServiceName = re.compile("([a-zA-Z0-9]+)-(.*)-(.*\.services.west.nonprod.wsgc.com)")
                        isMatch = extractServiceName.match(urlComponent)
                        if isMatch:
                            serviceName = isMatch.group(2)
                        else:
                            sys.exit(f"Failed tp extract service name from url {url} for service {service}")
            else:
                sys.exit(f"Failed to extract service name from url {url} for service {service}")
            if urlSuffix:
                urlSuffix = f"/{urlSuffix}"
            url = f"{urlPrefix}getUrl(services.{serviceName}){urlSuffix}"
            configMap[service] = {key: url}

    configValues["config"] = configMap

    etcdSyncappServiceMap = {"etcd-syncapp-config": configValues}

    servicesMap = {"services": etcdSyncappServiceMap}
    out = yaml.safe_dump(servicesMap, sort_keys=False)

    if push_changes:
        pushChangesToNewBranch(servicesMap, env)
    else:
        print(out)


def pushChangesToNewBranch(servicesMap, env):
    branch = f'etcd-syncapp-config-{env}'
    utils.run(['rm', '-rf', 'env-manifest'])
    repoUrl = "git@github.wsgc.com:eCommerce-DevOps/env-manifest.git"
    utils.run(['git', 'clone', repoUrl])
    os.chdir('env-manifest')
    repoUrl = "git@github.wsgc.com:eCommerce-Echo/env-manifest.git"
    utils.run(['git', 'remote', 'add', 'echo', repoUrl])
    utils.run(['git', 'checkout', '-b', branch, 'origin/release'])

    with open(f'manifest/{env}/{env}-services-manifest.yaml', 'r') as stream:
        manifest = yaml.safe_load(stream)

    manifest['services']['etcd-syncapp-config'] = servicesMap['services']['etcd-syncapp-config']

    out = yaml.safe_dump(manifest, sort_keys=False)
    print(out)
    with open(f"manifest/{env}/{env}-services-manifest.yaml", 'w') as stream:
        stream.write(yaml.safe_dump(manifest, sort_keys=False))
    utils.run(['git', 'add', f"manifest/{env}/{env}-services-manifest.yaml"])
    commitMsg = f'[ECHO-146] Add etcd-syncapp-config service to env {env}'
    utils.run(['git', 'commit', '-m', commitMsg])
    utils.run(['git', 'push', '-u', 'echo', branch])
    os.chdir('../')
    utils.run(['rm', '-rf', 'env-manifest'])


def applyOverrides(values, overrides):
    """
    Override values in dictionary `values` with the values from `overrides`.
    Recurses into dictionaries, so if `values` is {1: {2: 'a', 3: 'b'}}, and
    `overrides` is {1: {2: 'c'}}, `values` will become {1: {2: 'c', 3: 'b'}}.

    This is like a "deep" version of values.update(theseValues) (which would turn
    values into {1: {2: 'c'}}).

    Modifies the values argument in place; no useful return value.
    """
    for key, overrideValue in overrides.items():
        if key in values:
            if overrideValue is None:
                # The override set a value to null (not the string null, but
                # a bare literal 'null' (without the quotes).
                del values[key]
                continue

            valuesValue = values[key]
            if isinstance(valuesValue, dict) and isinstance(overrideValue, dict):
                # Recurse.
                applyOverrides(valuesValue, overrideValue)
                continue

        values[key] = overrideValue


def readCombinedYaml(syncapp_config_common_values, syncapp_config_env_values):
    """Read the YAML files, letting later files override earlier ones"""
    values = syncapp_config_common_values

    if syncapp_config_env_values:
        applyOverrides(values=values, overrides=syncapp_config_env_values)

    return values


def get_yaml_content(request_raw_url: str):
    github_token = utils.getCredential('github', 'ghe_admin_token')
    headers = {"Authorization": f"token {github_token}"}
    values_text = None
    for x in range(6):
        result = requests.get(request_raw_url, headers=headers, verify=False)
        if result.status_code == 200:
            values_text = result.text
            break

    if values_text:
        content = yaml.safe_load(values_text)
        return content
    else:
        sys.exit(1)


def parseArgs():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env', help="Manifest env")
    parser.add_argument('--push_changes',  action='store_true', default=False)
    return parser.parse_args()


if __name__ == '__main__':
    try:
        etcd_syncapp_manifest_process()
    except KeyboardInterrupt:
        # Don't dump stack, just exit.
        sys.exit(1)
