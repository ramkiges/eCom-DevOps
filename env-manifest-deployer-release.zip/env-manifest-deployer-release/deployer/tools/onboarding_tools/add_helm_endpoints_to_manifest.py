#!/usr/bin/env python3

import sys
from modules import utils
import argparse
import os
import ruamel.yaml

"""
Can be run from anywhere
Args
--env manifest env to which helm endpoints to be added
--push_changes whether to push changes to the branch or just print it. default value - false
"""

service_params = {
    'ecom-svc-catalog':{
        'applicationProperties':
            ['inventory.microservice.url', 'oauth_rest_client.access_token_url/r', 'domain_details_client.domain_publisher_url/s']
    },
    'ecom-svc-order-servicing':{
        'applicationProperties':
            ['catalogservice.serviceUrl', 'orderhistory.profileServiceUrl', 'oauth.baseUri', 'oauth.accessTokenUrl', 'oauth.checkTokenUrl']
    },
    'pricing': {
        'rootXml/environments':
            ['PublisherConceptURI','Single_use_configuration.service_uri'], 
        'pricingProperties': 
            ['vertex.service_uri/s']
    },
    'promo-admin': {
        'rootXml/environments':
            ['PromoUseAdminGatewayUrl','publisherServicesGatewayUrl','rulePublisherWebAppUrl','PromoRuleFeedURI','PromoCode2RuleFeedURI','TestPromoUseAdminGatewayUrl']
    },
    'ecom-svc-customer':{
        'applicationProperties':
            ['svc.claim.service.uri','business.sales.connector.url','c3.service_uri','oauth.checkTokenUrl','oauth.acessTokenUrl','avs.address.validation.url','cos.currentids.service.uri','cof.rewardsummary.service.uri','user.service.url','profile.service.url','profile.verification.service.url','loyalty.service.url']
    },
    'ecom-svc-registry':{
        'applicationProperties':
            ['favorites.service.uri','oauth.baseUri','registry.service.uri','platform.session.service.base.url','session.oauth.base.Uri']
    },
    'ecom-app-order-servicing':{
        'extraEnv':
            ['ORDER_SERVICING_SERVICE_URI']
    },
    'salesforceconnector':{
        'applicationProperties':
            ['oauth.baseUri','oauth.access_token_url','oauth.check_token_url','oauth.health_endpoint']
    },
    'oauth':{
        'applicationProperties':
            ['c3_connect.service_uri','wsgc.migration.profile.URL','wsgc.migration.oauth.accessTokenUri']
    },
    'credit-card-orchestration':{
        'applicationProperties':
            ['wsgc.els.client.url','wsgc.els.oauth.accessTokenURI']
    },
    'profile':{
        'applicationProperties':
            ['c3.service_uri','membership.service.baseUrl','wsgc.cross.brand.registryService.url','wsgc.oauth.accessTokenUri','wsgc.oauth.checkTokenURI','wsgc.registryService.url','wsgc.userService.url']
    },
    'cart-checkout':{
        'oauth':
            ['base.uri'], 
        'env':
            ['pricing.service_uri/r', 'singleuse_promo_service.service_uri/r']
    },
    'favorites':{
        'environmentSettings':
            ['favorites_service_oauth.check_token_url/r']
    },
    'short-token':{
        'applicationProperties':
            ['wsgc.oauth.checkTokenURI','wsgc.oauth.health.endpoint']
    },
    'stored-value-card-orchestration':{
        'applicationProperties':
            ['oauth.url','c3.service_uri'], 
        'cronJob/applicationProperties':
            ['c3.service_uri']
    },
    'membership-service':{
        'applicationProperties':
            ['oauth.endpoint','membership_c3.health_uri','membership_c3.service_uri']
    },
    'oss-publisher':{
        'applicationProperties':
            ['oauth.check_token_url/r']
    },
    'experimentation-service':{
        'applicationProperties':
            ['wsgc.oauth.accessTokenURI','wsgc.oauth.checkTokenURI']
    },
    'experiment-proxy':{
        'applicationProperties':
            ['wsgc.oauth.accessTokenURI','wsgc.oauth.checkTokenURI','experimentation.proxy.experimentation.service.base']
    },
    'reward-certificate-exporter':{
        'applicationProperties':
            ['certificateServiceServer'], 
        'extraEnv':
            ['RCMS_SERVICE_URL']
    },
    'reward-certificate-loader':{
        'applicationProperties':
            ['serviceUrl'], 
        'extraEnv': 
            ['RCMS_SERVICE_URL']
    }
}

yaml = ruamel.yaml.YAML()
yaml.preserve_quotes = True
yaml.allow_duplicate_keys = True
yaml.indent(mapping=2, sequence=4, offset=2)


def main():
    args = parseArgs()
    env = args.env
    push_changes = args.push_changes

    env_manifest_branch = f'ECHO-156-add-helm-endpoints-{env}'
    utils.run(['rm', '-rf', 'env-manifest'])
    repoUrl = "git@github.wsgc.com:eCommerce-DevOps/env-manifest.git"
    utils.run(['git', 'clone', repoUrl])
    os.chdir('env-manifest')
    os.mkdir('helm_repos')
    repoUrl = "git@github.wsgc.com:eCommerce-Echo/env-manifest.git"
    utils.run(['git', 'remote', 'add', 'echo', repoUrl])
    utils.run(['git', 'checkout', '-b', env_manifest_branch, 'origin/release'])

    check_changes = False
    with open(utils.SERVICES_MANIFEST_PATH.format(env), 'r') as stream:
        manifest = yaml.load(stream)
        result_manifest = manifest
        for service in manifest['services']:
            if service in service_params:
                service_type = manifest['services'][service]['type']
                if service_type == "helm" or service_type == "legacy-helm":
                    # sample: eCommerce-Kubernetes-Bedrock/ecom-app-shop-helm-config/release
                    if service_type == "helm":
                        org, repo, branch = manifest['services'][service]['packaging']['pkg_branch'].split('/')
                        config_path = "config"
                    else:
                        org, repo, branch = manifest['services'][service]['packaging']['pkg_branch'].split('/')
                        config_path = "src/main/helm/config"
                    utils.run(['rm', '-rf', f'helm_repos/{repo}'])
                    os.chdir('helm_repos')
                    helm_repo_url = f"git@github.wsgc.com:{org}/{repo}.git"
                    utils.run(['git', 'clone', helm_repo_url])
                    os.chdir(repo)
                    utils.run(['git', 'checkout', branch])
                    out = {}
                    out['configuration'] = {}
                    try:
                        with open(f'{config_path}/{env}/values.yaml', 'r') as stream:
                            values = yaml.load(stream)
                    except:
                        print(f'No config for env {env} service {service}')
                        values = {}

                    try:
                        with open(f'{config_path}/values.yaml', 'r') as stream:
                            common_values = yaml.load(stream)
                        for service_name, properties in service_params[service].items():
                            print(f"service_name: {service_name}")
                            print(f"Properties: {properties}")
                            if '/' in service_name:
                                out['configuration'][service_name.split('/')[0]] = {}
                                out['configuration'][service_name.split('/')[0]][service_name.split('/')[1]] = {}
                            else:
                                out['configuration'][service_name] = {}
                            for item in properties:
                                if '/' in service_name:
                                    try:
                                        out['configuration'][service_name.split('/')[0]][service_name.split('/')[1]][item] = values[service_name.split('/')[0]][service_name.split('/')[1]][item]
                                    except:
                                        out['configuration'][service_name.split('/')[0]][service_name.split('/')[1]][item] = common_values[service_name.split('/')[0]][service_name.split('/')[1]][item]
                                else:
                                    try:
                                        out['configuration'][service_name][item] = values[service_name][item]
                                    except:
                                        out['configuration'][service_name][item] = common_values[service_name][item]
                    except:
                        print(f'No config for env {env} service {service}')
                    if out['configuration'] != {}:
                        result_manifest['services'][service].update(out)
                        check_changes = True
                    os.chdir('../..')

    if check_changes:
        with open(utils.SERVICES_MANIFEST_PATH.format(env=env), 'w') as stream:
            yaml.dump(result_manifest, stream)
        if push_changes:
            utils.run(['git', 'add', utils.SERVICES_MANIFEST_PATH.format(env=env)])
            commitMsg = f'[ECHO-156] Add helm endpoints to env {env}'
            utils.run(['git', 'commit', '-m', commitMsg])
            utils.run(['git', 'push', '-u', 'echo', env_manifest_branch])
            os.chdir('..')
            utils.run(['rm', '-rf', 'env-manifest'])
        else:
            utils.run(['cat', utils.SERVICES_MANIFEST_PATH.format(env=env)])


def parseArgs():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env', help="Manifest env")
    parser.add_argument('--push_changes',  action='store_true', default=False)
    return parser.parse_args()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        # Don't dump stack, just exit.
        sys.exit(1)
