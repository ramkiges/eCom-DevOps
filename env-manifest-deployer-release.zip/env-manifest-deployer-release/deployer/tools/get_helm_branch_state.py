#!/usr/bin/env python3

import json
import sys
from modules import processing_utils, utils

input = sys.stdin.read()
input_json = json.loads(input)

app_name = input_json.get("app_name")
module_name = input_json.get("module_name")
new_config_job = input_json.get("helm_config_pkg_branch")
new_app_job = ""
if input_json.get("app_branch"):
    new_app_job = input_json.get("app_branch")
if input_json.get("app_version"):
    new_app_job = input_json.get("app_version")
app_env = input_json.get("app_env")
app_org = input_json.get("app_org")
protected_env = input_json.get("protected_env")

if app_name == "etcd-syncapp-config":
    output = {}
    output["app_name"] = app_name
    output["app_env"] = app_env
    output["app_org"] = app_org
    if new_config_job != "":
        path = new_config_job.split('/')
        output["helm_branch_exist"] = str(utils.check_jenkins_url(f'https://ecombuild.wsgc.com/jenkins/job/{path[0]}/job/etcd-syncappconfig-helm-config/job/{path[1]}/'))
    else:
        output["helm_branch_exist"] = "False"
else:
    output = processing_utils.get_helm_version(app_name, module_name, new_config_job, new_app_job, app_env, app_org, protected_env)  
    output["helm_config_pkg_branch"] = new_config_job
    output["app_branch"] = input_json.get("app_branch")
    output["app_version"] = input_json.get("app_version")
    output["app_name"] = app_name
    output["app_env"] = app_env
    output["app_org"] = app_org

print(json.dumps(output))
