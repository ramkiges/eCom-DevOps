# env-manifest-deployer
env-manifest-deployer


Requirements
------------

Python modules:

  * xmltodict
  * ansible_runner
  * kubernetes

Kubeconfig location:

  * ~/.kube/svcak8sci/ts-sharedplatform-rck-nonprod