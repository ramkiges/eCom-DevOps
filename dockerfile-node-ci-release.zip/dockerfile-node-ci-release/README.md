# dockerfile-node-ci

A node container for use in CI builds.  

This configures the user in the container as the Jenkins uid/gid and adds our NPM repo configurations

We can decomission this repo https://github.wsgc.com/eCommerce-DevOps/node-18-ci-docker/blob/release/Dockerfile
and https://github.wsgc.com/eCommerce-DevOps/node-14-ci-docker
once we have all Node apps updated with this image in their docker-packaging.yaml file
