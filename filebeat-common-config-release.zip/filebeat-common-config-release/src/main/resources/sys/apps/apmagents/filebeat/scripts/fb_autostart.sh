#!/bin/sh

SERVICE="filebeat";
 
if ps ax | grep -v grep | grep $SERVICE > /dev/null
then
    echo "$SERVICE service running, everything is fine"
else
    echo "Restarting filebeat:  $(date)" >> /tmp/fbstart.log
#    ~/filebeat/scripts/fb_startup.sh &
    /apps/apmagents/filebeat/scripts/fb_startup.sh &
fi
