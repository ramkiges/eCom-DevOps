#!/bin/sh
# with debug
# nohup /apps/apmagents/filbeat/filebeat -e -c /apps/apmagents/filebeat/filebeat.yml -d "publish" > /dev/null 2>&1 &
# no debug - use me in prod
nohup /apps/apmagents/filebeat/bin/filebeat -e -c /apps/apmagents/filebeat/filebeat.yml > /dev/null 2>&1 &
nohup /apps/apmagents/filebeat/bin/filebeat -e -c /apps/apmagents/filebeat/filebeat2.yml > /dev/null 2>&1 &
# nohup ~/filebeat/filebeat -e -c ~/filebeat/filebeat.yml > /dev/null 2>&1 &
# if you want to look at nohup.out  
# nohup /apps/apmagents/filebeat/filebeat -e -c /apps/apmagents/filebeat/filebeat.yml &
# local testing in foreground from homei or test directory
# ~/filebeat/filebeat -e -c ~/filebeat/filebeat.yml
