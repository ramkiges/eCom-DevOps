BOTMENTION = "<@U03EL5K6LKU>"
HELP_REGEX = "(.*)(\s+|^|[^a-zA-Z\d])(help|features|feature)(\s+|$|[^a-zA-Z\d])(.*)"
STATIC_DEPLOYER_REGEX = "(.*)(\s+|^|[^a-zA-Z\d])(update([^a-zA-Z\d]*)static([^a-zA-Z\d]*)deployer)(\s+|$|[^a-zA-Z\d])(.*)"
MENTION_REGEX = "(\s+|^)(" + BOTMENTION + "|)(.*)"

# slack request types
URL_VERIFICATION = "url_verification"
EVENT_CALLBACK = "event_callback"

# slack action types
INTERACTIVE_MESSAGE = "interactive_message"
DIALOG_SUBMISSION = "dialog_submission"
BLOCK_ACTIONS = "block_actions"
VIEW_SUBMISSION = "view_submission"

# slack interactive message types
BUTTON = "button"
SELECT = "select"

# slack external menu select types
BLOCK_SUGGESTION = "block_suggestion"

# slack block actions
EXTERNAL_SELECT = "external_select"
PLAIN_TEXT_INPUT = "plain_text_input"
BLOCK_ACTION_BUTTON = "button"

JENKINS_USER_ID = "svcaecjnk"

