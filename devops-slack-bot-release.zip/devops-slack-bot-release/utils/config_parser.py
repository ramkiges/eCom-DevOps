import configparser
import os

CONFIG_VALUES = dict()

PROPERTY_FILE_PATH = os.environ.get('PROPERTY_FILE_PATH', "property-sample.ini")

config = configparser.ConfigParser()
config.read(PROPERTY_FILE_PATH)

CONFIG_VALUES["SlackToken"] = config["DEFAULT"]["SlackToken"]
CONFIG_VALUES["JenkinsUserPassword"] = config["DEFAULT"]["JenkinsUserPassword"]
