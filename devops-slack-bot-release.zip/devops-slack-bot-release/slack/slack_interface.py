"""
module to interact with slack
"""

import json
import logging

import requests

from slack_sdk import WebClient
from utils import config_parser


class SlackClient:
    def __init__(self):
        self.slack_client = WebClient(token=config_parser.CONFIG_VALUES["SlackToken"])

    def post_message(self, channel, text, attachments, as_user):
        """
        Post a message to a channel
        """
        logging.info(f"Sending message to channel={channel} text={text} attachments={attachments}")
        try:
            self.slack_client.chat_postMessage(
                channel=channel,
                attachments=attachments,
                text=text,
                as_user=as_user
            )
        except Exception as e:
            logging.error("Slack error received %s", e)

    def replace_msg_with_attachments(self, response_url, attachments, text=None):
        """
        Replace the existing message in slack which response_url points to with the new one using text and
        attachments
        """
        reply_to_post = dict()

        if attachments is not None:
            reply_to_post["attachments"] = attachments

        if text is not None:
            reply_to_post["text"] = text

        headers = {
            'Content-Type': 'application/json',
        }
        data = json.dumps(reply_to_post)
        logging.info(f"Sending response to slack, response_url={response_url} data={data}")
        response = requests.post(response_url, data=data, headers=headers)
        logging.info(f"Response from slack, response_url={response_url} response={response.text}")

    def replace_msg_with_blocks(self, response_url, blocks, text=None):
        """
        Replace the existing message in slack which response_url points to with the new one using text and
        blocks
        """
        reply_to_post = dict()

        if blocks is not None:
            reply_to_post["blocks"] = blocks

        if text is not None:
            reply_to_post["text"] = text

        headers = {
            'Content-Type': 'application/json',
        }
        data = json.dumps(reply_to_post)
        logging.info(f"Sending response to slack, response_url={response_url} data={data}")
        response = requests.post(response_url, data=data, headers=headers)
        logging.info(f"Response from slack, response_url={response_url} response={response.text}")
