"""
module to build the payload data for the slack requests in the slack compatible format
"""
import logging


def generate_confirm_block(text, callback_id):
    """
    Generate a Yes/No confirm button attachment block
    callack_id is sent back on the button click to identify the response path
    """
    data = dict()
    data["color"] = "#3AA3E4"
    data["callback_id"] = callback_id
    data["text"] = text
    actions = []
    for action_text in ["Yes", "No"]:
        action = dict()
        action['name'] = action_text
        action['type'] = "button"
        action["text"] = action_text
        action["value"] = action_text
        actions.append(action)

    data["actions"] = actions
    attachments = [data]
    logging.info(f"Confirm block generated {attachments}")
    return attachments


def get_external_select_section_block(block_id, action_id, section_text, placeholder_text, min_query_length):
    """
    Generate a menu select block with the menu items populated on runtime based on user input
    :param block_id: A unique identifier for a block. Used to identify the source of the action on receiving
    the interaction payload (Identifies the block containing the interactive action)
    :param action_id: Used with block_id to uniquely identify the interactive component itself
    :param section_text: text to be displayed alongside the menu select
    :param placeholder_text: placeholder for the menu
    :param min_query_length: minimum characters to type before the menu items are populated
    """
    block = {
        "type": "section",
        "block_id": block_id,
        "text": {
            "type": "mrkdwn",
            "text": section_text
        },
        "accessory": {
            "action_id": action_id,
            "type": "external_select",
            "placeholder": {
                "type": "plain_text",
                "text": placeholder_text
            },
            "min_query_length": min_query_length
        }
    }

    logging.info(f"External select block generated {block}")
    return block


def get_plain_text_block(text, value):
    """
    Plain text block used to compose the select menu options
    :param text: Text to be displayed
    :param value: A unique string passed back when this option is chosen
    """
    block = {
        "text": {
            "type": "plain_text",
            "text": text,
            "emoji": True
        },
        "value": value
    }

    logging.info(f"Plain text block generated {block}")
    return block


def get_mrkdwn_section(block_id, text):
    """
    Display the text with markdown in slack
    :param block_id: unique identifier for the block
    :param text: text to display
    """
    block = {
        "type": "section",
        "block_id": block_id,
        "text": {
            "type": "mrkdwn",
            "text": text
        }
    }

    logging.info(f"Markdown section block generated {block}")
    return block


def get_context_block(block_id, text):
    """
    Display Context block in slack
    :param block_id: unique identifier for the block
    :param text: text to display
    """
    block = {
        "type": "context",
        "block_id": block_id,
        "elements": [
            {
                "type": "mrkdwn",
                "text": text
            }
        ]
    }

    logging.info(f"Context block generated {block}")
    return block


def get_divider():
    """Divider block (line)"""
    block = {
        "type": "divider"
    }

    return block


def get_action_button_element(action_id, text, value):
    """
    Generate button action block
    :param action_id: unique identifier for the action
    :param text: text to display on button
    :param value: value for the button passed back on click
    """
    element = {
        "type": "button",
        "text": {
            "type": "plain_text",
            "text": text,
            "emoji": True
        },
        "value": value,
        "action_id": action_id
    }

    logging.info(f"Action button element {element}")
    return element


def get_actions_block(block_id, elements):
    """
    Generate a block of action list elements
    :param block_id: unique identifier for the block
    :param elements: action elements
    """
    block = {
        "type": "actions",
        "block_id": block_id,
        "elements": elements
    }

    logging.info(f"Actions block generated {block}")
    return block


def get_input_dispatch_action_block(block_id, action_id, placeholder_text, label_text):
    """
    Generate a user input block which submits the input on hitting return key
    :param block_id: unique identifier for the block
    :param action_id:unique identifier for the action
    :param placeholder_text: placeholder text
    :param label_text: label for the input block
    """
    block = {
        "dispatch_action": True,
        "type": "input",
        "block_id": block_id,
        "element": {
            "type": "plain_text_input",
            "action_id": action_id,
            "placeholder": {
                "type": "plain_text",
                "text": placeholder_text
            }
        },
        "label": {
            "type": "plain_text",
            "text": label_text,
            "emoji": True
        }
    }

    logging.info(f"Input block generated {block}")
    return block


def get_attachment(blocks, color):
    """
    Get slack attachment format
    :param blocks: blocks to be displayed in attachment
    :param color: color of the attachment
    """
    attachment = {
        "color": color,
        "blocks": blocks
    }

    logging.info(f"Attachment generated {attachment}")
    return attachment
