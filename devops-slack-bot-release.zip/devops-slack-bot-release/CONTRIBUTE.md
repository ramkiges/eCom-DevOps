Users are welcome to contribute to the devopsbot repository for enhancing an existing capability or adding a new one.

### Prerequisites

Devops bot is built using python. Here's what is needed for local development.
* Python - Python version 3.7+ to be installed
* IDE (optional) - Pycharm is a good IDE for python projects

### Code Structure

* intents - Package for handling all intents. Any new intent goes in here.
  * static_deployer - Package for updating the static deployer job in jenkins. Anything related to the handling of static deployer update goes in here. Similarly create packages for additional intents as new features are onboarded.
* slack - Package for interfacing with slack
  * slack_data_composer - module to build the payload data for the slack requests in the slack compatible format
  * slack_interface - module to interact with slack API
* utils - Package for utilities shared across entire project
* requirements/requirements.txt - External packages needed for the app
* bot.py - This is the entrypoint for the slack app. It runs a flask server which is listening to the endpoints configured in slack app. The intent is identified by the handle_command routine which does the regex match for the intent and calls the corresponding handler for the intent once identified. To add a new intent, add the regex to identify the intent and then call the corresponding handler withing the intents package. 
  * /slack/events - Any command user types in slack channel or direct message is received at this endpoint as a POST request
  * /slack/actions - Any interaction with slack button, static menu, dialog and slack block actions is received at this endpoint as a POST request
  * /slack/options-load - Slack sends POST request to this endpoint for sending external options to menu selection.

### Contribute process
* Create your own team fork of the repository if not already
* Clone your fork and checkout a new work branch from the bedrock release branch
* Perform the code changes. Please refer to the above code structure for better understanding of package structure
* Increment the project.yaml version based on whether it's a major, minor or a bugfix change
* The helm-config repo for the bot is https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/devops-slack-bot-helm-config. Perform any config changes in your own fork branch for the helm-config. 
* The credentials or any other secrets are passed to the application using the helm secrets (secrets.yaml) which places the property-config.ini file inside the container. The sample property-sample.ini is added to the repo. To add any new secret, add it here and also in config_parser.py in utils. The PROPERTY_FILE_PATH env variable tells the app the path to the property file to read.
* Once the code and config changes are pushed and ready for testing, update the static deployer job for the bot https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/ecom/job/devops-slack-bot/job/release/ to deploy from your work branch.
* Once successful, submit the PR for review and merge
* Schedule a demo with the devops team along with its intended users to demo your new feature
* For users, more familiar with scripting, can also contribute to this by having most of their feature handling in a script and then call the script using the python paramiko ssh client.
* Sample code snippet (very basic for using paramiko). There maybe other ways too.
```
import paramiko
client = paramiko.SSHClient()
client.connect(hostname, username, password)
client.exec_command(call_your_script_on_host_with_args)
client.close()
```

### Pointers
* Slack API and events usage guide. We use Events API. https://api.slack.com/reference
* Slack Block kit builder to build and test slack blocks and get the payload json for the block. https://api.slack.com/tools/block-kit-builder
* Building a slack app. https://api.slack.com/start/building