import _thread
import json
import logging.handlers
import re

from flask import Flask, request, make_response, jsonify

from intents import help
from intents.static_deployer import static_deployer, helm_project_deployer
from slack import slack_interface
from utils import constants

app = Flask(__name__)

LOG = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s', level=logging.INFO)


@app.route("/healthcheck", methods=["GET"])
def health_check():
    """
    Checks the health of the application
    """
    return "200"


@app.route("/slack/events", methods=["POST"])
def events():
    """
    Any command user types in slack channel or direct message is received at this endpoint as a POST request which is
    configured in the slack app. Routes request based on the request type.
    :return: HTTP success response back to slack
    """
    with app.app_context():
        req_data = request.get_json()
        req_type = req_data['type']
        if req_type == constants.URL_VERIFICATION:
            return req_data['challenge']
        elif req_type == constants.EVENT_CALLBACK:
            if "bot_id" not in json.dumps(req_data):
                LOG.info("Request received %s", req_data)
                event = req_data['event']
                workspace_name = req_data['team_id']
                event_type = event['type']
                if event_type == "message":
                    subtype = event.get("subtype")
                    if subtype == "message_changed":
                        text = event["message"].get('text')
                    else:
                        text = event.get('text')
                    if text is not None:
                        ch_type = event.get('channel_type')
                        if ch_type == 'im':
                            _thread.start_new_thread(handle_direct_message, (event, workspace_name,))
            else:
                handle_bot_event(req_data)
        return make_response("", 200)


def handle_bot_event(req_data):
    event = req_data['event']


def handle_direct_message(event, workspace_name):
    """
    Handle messages from a direct user channel in its own thread

    :param event: slack event payload
    :param workspace_name: workspace name
    :return: None
    """
    with app.app_context():
        subtype = event.get('subtype')
        if subtype == "message_changed":
            text = event['message'].get('text')
            user = event['message']['user']
        else:
            text = event.get('text')
            user = event['user']
        bot_mention, message = parse_direct_mention(text)

        if message:
            handle_command(message, event['channel'], user, event['channel_type'], workspace_name)


def parse_direct_mention(message_text):
    """
    Finds a direct mention (a mention that is at the beginning) in message text

    :param message_text: message text
    :return: the user id which was mentioned along with the rest of the message
    """
    with app.app_context():
        matches = re.search(constants.MENTION_REGEX, message_text)
        return matches.group(2).strip(), matches.group(3).strip()


def handle_command(command, channel, user, channel_type, workspace_name):
    """
    Route to the command execution handler for the matching intent. If no intent matching display the general message
    :param command: command typed
    :param channel: channel from which command originated
    :param user: slack user id
    :param channel_type: channel type
    :param workspace_name: workspace name
    """
    with app.app_context():
        if re.search(constants.HELP_REGEX, command, re.IGNORECASE):
            help.handle_help_command(channel)
        elif re.search(constants.STATIC_DEPLOYER_REGEX, command, re.IGNORECASE):
            static_deployer.command_handler(channel)
        else:
            text = "Not yet intelligent (I'm still learning!). Explore features by typing \"*help*\""
            attachment = None
            slack_interface.SlackClient().post_message(channel, text, attachment, 'true')
        return make_response("", 200)


@app.route("/slack/actions", methods=["POST"])
def actions():
    """
    Any interaction with slack button, static menu, dialog and slack block actions is received at this endpoint as a
    POST request. This endpoint is configured in slack app.
    Route request based on the interactive request type
    :return: HTTP success response back to slack
    """
    with app.app_context():
        form_json = json.loads(request.form["payload"])
        action_type = form_json["type"]
        LOG.info("Action request received %s", form_json)
        if action_type == constants.INTERACTIVE_MESSAGE:
            msg_type = form_json["actions"][0]["type"]
            if msg_type == constants.BUTTON:
                _thread.start_new_thread(handle_button_select, (form_json,))
            elif msg_type == constants.SELECT:
                _thread.start_new_thread(handle_menu_select, (form_json,))
            return make_response("", 200)
        elif action_type == constants.DIALOG_SUBMISSION:
            _thread.start_new_thread(handle_dialog_submit, (form_json,))
            return make_response("", 200)
        elif action_type == constants.BLOCK_ACTIONS:
            _thread.start_new_thread(handle_block_actions, (form_json,))
            return make_response("", 200)
        elif action_type == constants.VIEW_SUBMISSION:
            return handle_view_submit(form_json)


@app.route("/slack/options-load", methods=["POST"])
def options_load():
    """
    Slack sends POST request to this endpoint for sending external options to menu selection.
    The endpoint is configured in the slack app
    :return: json string containing the external menu options for the correct event type else
    simply HTTP success response back to slack
    """
    with app.app_context():
        form_json = json.loads(request.form["payload"])
        LOG.info("Options load request received %s", form_json)
        if form_json["type"] == constants.BLOCK_SUGGESTION:
            options_json = handle_block_suggestion(form_json)
            return jsonify(options_json)
        else:
            make_response("", 200)


def handle_block_suggestion(form_json):
    """
    Handles the slack call for block suggestion. Any time user types a character(s) in external menu select box,
    slack sends this event to suggest names to the user starting with that character(s)
    :param form_json: block_suggestion payload received from slack as part of this event
    :return: json string containing the suggested options that will be displayed in menu
    """
    with app.app_context():
        block_id = form_json["block_id"]
        action_id = form_json["action_id"]

        options_json = {}
        if block_id == static_deployer.DEPLOYER_ORG_BLOCK_ID and action_id == static_deployer.DEPLOYER_ORG_ACTION_ID:
            options_json = static_deployer.get_org_options(form_json)
        elif block_id == static_deployer.DEPLOYER_APP_JOB_BLOCK_ID and action_id == \
                static_deployer.DEPLOYER_APP_JOB_ACTION_ID:
            options_json = static_deployer.get_app_job_options(form_json)
        elif block_id == static_deployer.DEPLOYER_APP_ENV_BLOCK_ID and action_id == \
                static_deployer.DEPLOYER_APP_ENV_ACTION_ID:
            options_json = static_deployer.get_app_env_options(form_json)
        return options_json


def handle_view_submit(form_json):
    pass


def handle_block_actions(form_json):
    """
    Handles slack block_actions request type by routing to the corresponding feature handler
    :param form_json: block_actions payload received from slack as part of this event
    :return: None
    """
    action = form_json["actions"][0]
    action_type = action["type"]
    action_id = action["action_id"]
    block_id = action["block_id"]

    if action_type == constants.EXTERNAL_SELECT:
        if action_id == static_deployer.DEPLOYER_ORG_ACTION_ID and \
                block_id == static_deployer.DEPLOYER_ORG_BLOCK_ID:
            static_deployer.handle_org_menu_selection(form_json)
        elif action_id == static_deployer.DEPLOYER_APP_JOB_ACTION_ID and \
                block_id == static_deployer.DEPLOYER_APP_JOB_BLOCK_ID:
            static_deployer.handle_app_job_menu_selection(form_json)
        elif action_id == static_deployer.DEPLOYER_APP_ENV_ACTION_ID and \
                block_id == static_deployer.DEPLOYER_APP_ENV_BLOCK_ID:
            static_deployer.handle_app_env_menu_selection(form_json)
    elif action_type == constants.PLAIN_TEXT_INPUT:
        if action_id == static_deployer.DEPLOYER_BRANCH_INPUT_ACTION_ID and \
                block_id == static_deployer.DEPLOYER_BRANCH_INPUT_BLOCK_ID:
            static_deployer.handle_helm_packaging_branch_input(form_json)
    elif action_type == constants.BLOCK_ACTION_BUTTON:
        if block_id == helm_project_deployer.DEPLOYER_APP_DEPLOY_CONFIRM_BLOCK_ID:
            helm_project_deployer.handle_app_deploy_confirm(form_json)


def handle_dialog_submit(form_json):
    pass


def handle_menu_select(form_json):
    pass


def handle_button_select(form_json):
    """
    Handles slack button select request type by routing to the corresponding feature handler
    :param form_json: button select json form received from slack as part of this request
    :return: HTTP success response
    """
    with app.app_context():
        selection = form_json["actions"][0]["name"]

        if selection == "Yes":
            handle_yes_confirmation(form_json, selection)
        elif selection == "No":
            handle_no_confirmation(form_json, selection)
        return make_response("", 200)


def handle_yes_confirmation(form_json, selection):
    """
    Handles "yes" button selection event from the user and routes to the appropriate handler based on the feature
    it was selected for
    :param form_json: json form received from slack for this event
    :param selection: name of the action selected from the json form
    :return: None
    """
    with app.app_context():
        callback_id = form_json["callback_id"]
        if callback_id == static_deployer.REQUEST_CONFIRM_CALLBACK_ID:
            static_deployer.handle_yes_confirmation(form_json, callback_id, selection)


def handle_no_confirmation(form_json, selection):
    """
    Handles "No" button selection event from the user
    :param form_json: json form received from slack for this event
    :param selection: name of the action selected from the json form
    :return:
    """
    with app.app_context():
        text = "`No` selected \n OK, will stop here"
        slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"], text, None)


if __name__ == "__main__":
    app.run()
