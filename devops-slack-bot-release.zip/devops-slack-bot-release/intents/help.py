from slack import slack_interface, slack_data_composer


def handle_help_command(channel):
	"""
	handler for the help command. Post the help message block to slack
	"""

	feature_text = "1. Update configurations for static deployers for your app and env and trigger a deploy " \
					"post update. \n*Command to invoke:* `update static deployer`\n" \
					"<https://confluence.wsgc.com/display/TAH/Static+Deployers|Learn more about Static Deployers>"

	blocks = [
		slack_data_composer.get_mrkdwn_section("welcome_block_id",
											   "Welcome to DevOpsBot! Learn about my features below."),
		slack_data_composer.get_divider(),
		slack_data_composer.get_mrkdwn_section("feature_block_id",
											   feature_text)
	]

	attachments = [slack_data_composer.get_attachment(blocks, "#3AA3E4")]
	slack_interface.SlackClient().post_message(channel, None, attachments, 'true')
