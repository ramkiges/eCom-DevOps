"""
module for updating the legacy helm packaging deployer job
"""

import json
import time

import requests

from slack import slack_interface, slack_data_composer
from utils import constants, config_parser


def get_existing_props(jobPropertiesKVPair):
    """
    Construct the existing job properties for legacy helm project job and return
    """
    return f"HELM_PACKAGING_BRANCH: `{jobPropertiesKVPair['K8S_PACKAGE_JOB']}`"


def get_helper_block():
    """Generate helper block for the user to enter the input in the particular format"""
    helper_text = "Please enter in the above text box the new helm packaging branch to use in the below format for " \
                  "legacy K8s package:\n`<GitOrg>/<GitRepo>/<GitBranch>`\nExample for K8s Packaging:\n" \
                  "`eCommerce-Whitney/assortment-export-pb-k8s-package/perf`"
    return slack_data_composer.get_context_block("K8S_PACKAGE_JOB", helper_text)


def get_new_job_properties(new_helm_packaging_branch):
    """Construct new job properties to update to the jenkins job"""
    new_job_properties = f"K8S_PACKAGE_JOB={new_helm_packaging_branch}"
    return new_job_properties


def send_deployer_job_update_msg(form_json, new_helm_packaging_branch, base_url):
    """
    Post the jenkins job success update message back to the user in slack and wait for the jenkins build to be started
    and then post again with the jenkins job url.
    :param form_json: interaction payload received from slack
    :param new_helm_packaging_branch: New helm packaging branch updated
    :param base_url: jenkins base url
    """

    # Post the success message to the user in slack
    output_success_attachments = [form_json["message"]["attachments"][0]]
    output_text = f"Static deployer job successfully updated with\nHELM_PACKAGING_BRANCH: " \
                  f"`{new_helm_packaging_branch}`\nA new deployment job is triggered:\n" \
                  f"Please wait a moment to grab the job url"
    output_helm_config_success_blocks = [
        slack_data_composer.get_mrkdwn_section("deployer_helm_packaging_branch_output",
                                               output_text)
    ]
    output_success_attachments.append(slack_data_composer.get_attachment(output_helm_config_success_blocks, "#3AA3E4"))
    slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"], output_success_attachments)

    # Get the jenkins job url which was triggered. Wait and try again if the build is not started yet
    count = 0
    while True:
        lastbuildurl = f"{base_url}/lastBuild/api/json"
        lastbuildurl_response = requests.get(lastbuildurl, verify=False,
                                             auth=(constants.JENKINS_USER_ID,
                                                   config_parser.CONFIG_VALUES["JenkinsUserPassword"]))
        lastbuildurl_response_json = json.loads(lastbuildurl_response.text)
        if lastbuildurl_response_json["building"]:
            build_url = lastbuildurl_response_json["url"]
            output_text = f"Static deployer job successfully updated with\nHELM_PACKAGING_BRANCH: " \
                          f"`{new_helm_packaging_branch}`\nA new deployment job is triggered:\n{build_url}"
            output_helm_config_success_block = slack_data_composer.get_mrkdwn_section(
                "deployer_helm_packaging_branch_output",
                output_text)
            output_helm_config_success_blocks[-1] = output_helm_config_success_block
            helm_config_branch_attachment = slack_data_composer.get_attachment(output_helm_config_success_blocks,
                                                                               "#3AA3E4")
            output_success_attachments[-1] = helm_config_branch_attachment
            slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"],
                                                                       output_success_attachments)
            break
        time.sleep(10)
        count += 1
        if count == 10:
            break
