"""
module for updating the new helm packaging deployer job
"""

from slack import slack_data_composer, slack_interface

DEPLOYER_APP_DEPLOY_CONFIRM_BLOCK_ID = "deployer_app_deploy_confirm_block_id"


def ask_for_confirmation_for_app_deploy_update(form_json, new_helm_packaging_branch):
    """
    For helm packaging, ask whether the application deploy branch needs to be updated or the app deploy tag or
    there is no change in the app deploy branch by posting buttons in slack for those.
    :param form_json: interaction payload received from slack
    :param new_helm_packaging_branch: the new packaging branch already inputed
    """
    output_attachments = [form_json["message"]["attachments"][0]]
    blocks = form_json["message"]["attachments"][1]["blocks"][0:2]
    blocks += [
        slack_data_composer.get_mrkdwn_section(f"deployer_helm_packaging_branch_block_id:{new_helm_packaging_branch}",
                                               f"New HELM_PACKAGING_BRANCH selected: `{new_helm_packaging_branch}`"),
        slack_data_composer.get_divider()
    ]
    output_attachments.append(slack_data_composer.get_attachment(blocks, "#3AA3E4"))

    action_block_elements = [
        slack_data_composer.get_action_button_element("APP_DEPLOY_BRANCH", "APP_DEPLOY_BRANCH", "APP_DEPLOY_BRANCH"),
        slack_data_composer.get_action_button_element("APP_DEPLOY_TAG", "APP_DEPLOY_TAG", "APP_DEPLOY_TAG"),
        slack_data_composer.get_action_button_element("NO_CHANGE", "NO_CHANGE", "NO_CHANGE")
    ]
    helper_text = "Please confirm if you would like to configure either the *APP_DEPLOY_BRANCH* or *APP_DEPLOY_TAG* " \
                  "or leave as it is.\n*APP_DEPLOY_TAG* represents the application release version to be deployed.\n" \
                  "*APP_DEPLOY_BRANCH* represents the application version to be deployed from a specified app branch."
    app_deploy_blocks = [
        slack_data_composer.get_context_block("deployer_app_deploy_block_id",
                                              helper_text),
        slack_data_composer.get_actions_block(DEPLOYER_APP_DEPLOY_CONFIRM_BLOCK_ID, action_block_elements)
    ]
    output_attachments.append(slack_data_composer.get_attachment(app_deploy_blocks, "#3AA3E4"))
    slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"], output_attachments)


def handle_app_deploy_confirm(form_json):
    """
    Action event from slack based on the user selection to update the app deploy branch or app deploy tag or no change
    :param form_json: interaction payload received from slack
    """
    action_id = form_json["actions"][0]["action_id"]
    if action_id == "APP_DEPLOY_BRANCH":
        handle_app_deploy_branch(form_json)
    elif action_id == "APP_DEPLOY_TAG":
        handle_app_deploy_tag(form_json)
    elif action_id == "NO_CHANGE":
        pass


def handle_app_deploy_tag(form_json):
    """
    Handler to update the app deploy tag. Asks for the user input for the new tag to use.
    :param form_json: interaction payload received from slack
    """
    output_attachments = form_json["message"]["attachments"][0:2]

    helper_text = "Please enter in the above text box the app release version tag to use for deployment.\n" \
                  "Example:\n`1.2.4`\n\nNotes:\n- If left empty, the APP_DEPLOY_TAG if configured in the existing " \
                  "job properties will be removed."
    job_app_properties_blocks = [
        slack_data_composer.get_input_dispatch_action_block("deployer_helm_app_tag_packaging_branch_input_block_id",
                                                            "deployer_helm_app_tag_packaging_branch_input_action_id",
                                                            "Enter the app release version tag to be deployed",
                                                            "APP_DEPLOY_TAG"),
        slack_data_composer.get_context_block("deployer_helm_app_tag_packaging_branch_helper_block_id",
                                              helper_text)
    ]

    output_attachments.append(slack_data_composer.get_attachment(job_app_properties_blocks, "#3AA3E4"))
    slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"], output_attachments)


def handle_app_deploy_branch(form_json):
    """
    Handler to update the app deploy branch. Asks for the user input for the new app branch to use.
    :param form_json: interaction payload received from slack
    """
    output_attachments = form_json["message"]["attachments"][0:2]

    helper_text = "Please enter in the above text box the app branch to use for deployment in the below format:\n" \
                  "`<GitOrg>/<GitRepo>/<GitBranch>`\nExample:\n`Commerce-Bedrock/ecom-app-shop/release`\n\nNotes:\n- " \
                  "If left empty, the APP_DEPLOY_BRANCH if configured in the existing job properties will be removed."

    job_app_properties_blocks = [
        slack_data_composer.get_input_dispatch_action_block("deployer_helm_app_packaging_branch_input_block_id",
                                                            "deployer_helm_app_packaging_branch_input_action_id",
                                                            "Enter the app branch to use for the deployment",
                                                            "APP_DEPLOY_BRANCH"),
        slack_data_composer.get_context_block("deployer_helm_app_packaging_branch_helper_block_id",
                                              helper_text)
    ]

    output_attachments.append(slack_data_composer.get_attachment(job_app_properties_blocks, "#3AA3E4"))
    slack_interface.SlackClient().replace_msg_with_attachments(form_json["response_url"], output_attachments)


def get_helper_block():
    """Generate helper block for the user to enter the input in the particular format"""
    helper_text = "Please enter in the above text box the new helm packaging branch to use in the below format for " \
                  "HelmProject packaging:\n`<GitOrg>/<GitRepo>/<GitBranch>`\nExample for HelmProject Packaging:\n" \
                  "`eCommerce-Kubernetes-Bedrock/ecom-app-shop-helm-config/release`"
    return slack_data_composer.get_context_block("HELM_PROJECT_CONFIG_JOB", helper_text)


def get_existing_props(jobPropertiesKVPair):
    """
    Construct the existing job properties for helm project job each on a new line and return
    """
    existing_props = f"HELM_PACKAGING_BRANCH: `{jobPropertiesKVPair['HELM_PROJECT_CONFIG_JOB']}`"
    if "HELM_PROJECT_APP_JOB" in jobPropertiesKVPair:
        existing_props += f"\nAPP_DEPLOY_BRANCH: `{jobPropertiesKVPair['HELM_PROJECT_APP_JOB']}`"
    if "HELM_PROJECT_APP_TAG" in jobPropertiesKVPair:
        existing_props += f"\nAPP_DEPLOY_TAG: `{jobPropertiesKVPair['HELM_PROJECT_APP_TAG']}`"

    return existing_props
