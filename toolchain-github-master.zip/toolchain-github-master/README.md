# toolchain-github

repository for github management 

This repo will help us manage github organizations and repos using its ReSTful interfaces.
Some of the things we should be able to do:
* ReSTfully create a GHE repo within for a given user or organization
* convert a subversion module to its own GHE repository

Useful docs:

* [Migrate Subversion Module to GitHub Enterprise](../../wiki/Migrate-Subversion-Module-to-GitHub-Enterprise)


TODOS:
* consider adding the GitHub Plugin to Jenkins, what value will this provide?
* add GitHub/Jenkins integration for providing a complete CI Project with webhook in github project triggering jenkins job.
  * see: https://gist.github.com/stuart-warren/7786892
  * get config.xml for a folder like so:
```
   https://wsgc-devops-dev/jenkins/job/test-folder1/config.xml
   like:  curl -XPOST 'http://jenkins/createItem?name=FolderName&mode=com.cloudbees.hudson.plugins.folder.Folder&from=&json=%7B%22name%22%3A%22FolderName%22%2C%22mode%22%3A%22com.cloudbees.hudson.plugins.folder.Folder%22%2C%22from%22%3A%22%22%2C%22Submit%22%3A%22OK%22%7D&Submit=OK' --user user.name:YourAPIToken -H "Content-Type:application/x-www-form-urlencoded"
```

rerun modules including:
   * github: employs github apis for managing repositories and workflow operations
   * wsgc-git-util: helper util such as converting svn modules to git repos

