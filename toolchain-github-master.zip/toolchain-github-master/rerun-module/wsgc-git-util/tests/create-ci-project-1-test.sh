#!/usr/bin/env roundup
#
#/ usage:  rerun stubbs:test -m wsgc-git-util -p create-ci-project [--answers <>]
#

# Helpers
# -------
[[ -f ./functions.sh ]] && . ./functions.sh

# The Plan
# --------
describe "create-ci-project"

# ------------------------------
# Replace this test. 
it_fails_without_a_real_test() {
    exit 1
}
# ------------------------------

