# DDL Scripts to define tables and indexes
