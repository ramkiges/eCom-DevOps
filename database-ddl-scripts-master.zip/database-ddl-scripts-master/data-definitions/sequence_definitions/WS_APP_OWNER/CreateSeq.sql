-- @category_id_seq.sql
@cmx_savecart_seq.sql
@emc_option_seq.sql
@newreg_create_seq.sql
-- @toad_seq.sql
@tool_log_seq.sql
@vnd_reviewer_seq.sql
@ww_account_action_seq.sql
@ww_email_sequence.sql
@ww_feedback_sequence.sql
@ww_inventory_locations_seq.sql
@ww_profile_sequence.sql
@ww_reg_status_seq.sql
@ww_rgdtltmp_sequence.sql
@ww_seqid_sequence.sql
@ww_swatch_sequence.sql