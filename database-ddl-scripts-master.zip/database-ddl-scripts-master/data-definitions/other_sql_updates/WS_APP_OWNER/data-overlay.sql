WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET DEFINE OFF;

--This is for a Simple PIP without Attributes to be used for the End to End Tests
begin
    insert into ww_inventory_state (sku, entry_time, duration, expiration_time, availability, confidence, back_order_date, concept_code, market_code, regional_availability, fulfillment_availability, ship_mode, guaranteed_delivery, is_reservation_choice_avail, ship_sub_mode, vas_type, vas_category, vas_categories)
        values ('4248196', '22-OCT-21', 86400, '24-OCT-21', 'fulfillment_availability', 'AsIs', null, 'MG', 'USA', null, '[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]', null, null, 'N', null, 'NONE', 'STANDARD', '[]');
exception
    when dup_val_on_index then
        update ww_inventory_state set availability='fulfillment_availability' where concept_code='MG' and sku='4248196';
        update ww_inventory_state set fulfillment_availability='[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]' where concept_code='MG' and sku='4248196';
end;

--This is for CMO-Consolidation End to End Tests
begin
    insert into ww_inventory_state (sku, entry_time, duration, expiration_time, availability, confidence, back_order_date, concept_code, market_code, regional_availability, fulfillment_availability, ship_mode, guaranteed_delivery, is_reservation_choice_avail, ship_sub_mode, vas_type, vas_category, vas_categories)
        values ('5283119', '22-OCT-21', 86400, '24-OCT-21', 'fulfillment_availability', 'AsIs', null, 'PK', 'USA', null, '[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]', null, null, 'N', null, 'NONE', 'STANDARD', '[]');
exception
    when dup_val_on_index then
        update ww_inventory_state set availability='fulfillment_availability' where concept_code='PK' and sku='5283119';
        update ww_inventory_state set fulfillment_availability='[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]' where concept_code='PK' and sku='5283119';
end;

--This is for Allstate warranty End to End Tests
begin
    INSERT INTO WW_ITEMS (CONCEPT_CODE,ITEM_ID,ITEM_TYPE_CODE,PARENT_CONCEPT_CODE,PARENT_ITEM_ID,ITEM_NAME,ITEM_SHORT_NAME,ITEM_MEDIUM_NAME,IS_SHOPPABLE,IS_PERISHABLE,IS_DIRECT_SHIP,IS_CONVEYABLE,IS_IN_HOME,HAS_GIFT_WRAP_AVAILABLE,COLLECTION_CODE,TAX_CATEGORY_CODE,DEPT_CODE,CLASS_CODE,SUBCLASS_CODE,ASSOCIATE_DISCOUNT_CODE,IS_SPECIAL_ORDER,PROMOTION_CONSTRAINT,IS_MARKETPLACE,MARKET_CODE,IS_BARCODE_REQUIRED,WARRANTY_TYPE_CODE) 
        VALUES ('WE','3998024','REG','WE','694145','Trace ChandelierChandelierMetal30 InchesAntique Brass','Trace30InBrass','TraceChndlr30InBrass','Y','N','N','N','N','N','WE839L','V:145|L:1','805','9','2','001','N',null,'N','USA','N','Lighting-802');
exception
    when dup_val_on_index then
        UPDATE WW_ITEMS SET WARRANTY_TYPE_CODE='Lighting_802' WHERE CONCEPT_CODE='WE' AND MARKET_CODE='USA' AND ITEM_ID='3998024';
end;

begin
    INSERT INTO WW_ITEMS (CONCEPT_CODE,ITEM_ID,ITEM_TYPE_CODE,PARENT_CONCEPT_CODE,PARENT_ITEM_ID,ITEM_NAME,ITEM_SHORT_NAME,ITEM_MEDIUM_NAME,IS_SHOPPABLE,IS_PERISHABLE,IS_DIRECT_SHIP,IS_CONVEYABLE,IS_IN_HOME,HAS_GIFT_WRAP_AVAILABLE,COLLECTION_CODE,TAX_CATEGORY_CODE,DEPT_CODE,CLASS_CODE,SUBCLASS_CODE,ASSOCIATE_DISCOUNT_CODE,IS_SPECIAL_ORDER,PROMOTION_CONSTRAINT,IS_MARKETPLACE,MARKET_CODE,IS_BARCODE_REQUIRED,WARRANTY_TYPE_CODE) 
        VALUES ('WE','2888214','PACK',null,null,'SAPIRA MATTRESS KING w/ Free Pillow','Spra Mtrs Kg w Plw','Sapira Mttrs Kng w Free Plw','Y','N','Y','N','N','N','WE462H','V:147|L:1','802','5','2','010','N','MAP ExcludePrice','Y','USA','N','Mattress - Cal King Size-802-5');

exception
    when dup_val_on_index then
        UPDATE WW_ITEMS SET WARRANTY_TYPE_CODE='Mattress - Cal King Size-802-5' WHERE CONCEPT_CODE='WE' AND MARKET_CODE='USA' AND ITEM_ID='2888214';
end;

begin
    INSERT INTO WW_ITEMS (CONCEPT_CODE,ITEM_ID,ITEM_TYPE_CODE,PARENT_CONCEPT_CODE,PARENT_ITEM_ID,ITEM_NAME,ITEM_SHORT_NAME,ITEM_MEDIUM_NAME,IS_SHOPPABLE,IS_PERISHABLE,IS_DIRECT_SHIP,IS_CONVEYABLE,IS_IN_HOME,HAS_GIFT_WRAP_AVAILABLE,COLLECTION_CODE,TAX_CATEGORY_CODE,DEPT_CODE,CLASS_CODE,SUBCLASS_CODE,ASSOCIATE_DISCOUNT_CODE,IS_SPECIAL_ORDER,PROMOTION_CONSTRAINT,IS_MARKETPLACE,MARKET_CODE,IS_BARCODE_REQUIRED,WARRANTY_TYPE_CODE) 
        VALUES ('WE','109050','REG','WE','1449285','Dot Diamond Performance Shag Rug5X8 FeetAlabaster','DtDmPrSh5x8Alab','DotDimndPrformShag5x8Alabastr','Y','N','N','N','N','N','WE413Q','V:161|L:1','809','15','4','001','N',null,'N','USA','N','Rugs-809');

exception
    when dup_val_on_index then
        UPDATE WW_ITEMS SET WARRANTY_TYPE_CODE='Rugs-809' WHERE CONCEPT_CODE='WE' AND MARKET_CODE='USA' AND ITEM_ID='109050';
end;
