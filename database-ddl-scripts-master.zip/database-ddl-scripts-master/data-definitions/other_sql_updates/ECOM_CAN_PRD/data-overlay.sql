WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET DEFINE OFF;

begin
    insert into ww_inventory_state (sku, entry_time, duration, expiration_time, availability, confidence, back_order_date, concept_code, market_code, regional_availability, fulfillment_availability, ship_mode, guaranteed_delivery, is_reservation_choice_avail, ship_sub_mode, vas_type, vas_category, vas_categories)
        values ('4248196', '22-OCT-21', 86400, '24-OCT-21', 'fulfillment_availability', 'AsIs', null, 'MG', 'CAN', null, '[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]', null, null, 'N', null, 'NONE', 'STANDARD', '[]');
exception
    when dup_val_on_index then
        update ww_inventory_state set availability='fulfillment_availability' where concept_code='MG' and sku='4248196';
        update ww_inventory_state set fulfillment_availability='[{"fulfillmentLocation":"003_CMO 028_CMO 030_CMO 034_CMO BIL_CMO BMA_CMO CHI_CMO CLT_CMO CMH_CMO COI_CMO CRB_CMO DEN_CMO DMI_CMO DTX_CMO ELP_CMO FLL_CMO GRP_CMO HAW_CMO HNC_CMO HOU_CMO HPR_CMO HSA_CMO IFI_CMO IND_CMO KAN_CMO KAU_CMO KON_CMO LAK_CMO LAS_CMO LGR_CMO LIT_CMO MAU_CMO MLZ_CMO MNX_CMO MOB_CMO MWK_CMO NGA_CMO OAH_CMO OBM_CMO PHX_CMO PIT_CMO POR_CMO ROC_CMO SAT_CMO SBA_CMO SEA_CMO SFO_CMO SLC_CMO SMD_CMO XXX1_CMO XXX3_CMO","inventoryLocation":"OB2DTC","transitDays":0,"availability":"ON_HAND","availabilityDate":{"year":2021,"month":10,"day":9},"confidence":"HIGH","reservationChoiceAvailable":false}]' where concept_code='MG' and sku='3741295';
end;
