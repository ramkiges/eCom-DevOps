CREATE TABLE RGDTLP_CAN_BAK_1202
(
  KEYRRN  NUMBER(9)                             NOT NULL,
  DTLRNO  NUMBER(9)                             NOT NULL,
  DTLSKU  NUMBER(7)                             NOT NULL,
  DTLDQT  NUMBER(3)                             NOT NULL,
  DTLQTP  NUMBER(3)                             NOT NULL,
  DTASID  NUMBER(9)                             NOT NULL,
  DTMGID  NUMBER(9)                             NOT NULL,
  DTSGID  NUMBER(9)                             NOT NULL,
  DTMGSQ  NUMBER(5)                             NOT NULL,
  DTSGSQ  NUMBER(5)                             NOT NULL,
  DTLKSQ  NUMBER(5)                             NOT NULL,
  DTLPRC  NUMBER(9,2)                           NOT NULL,
  DTLIVR  CHAR(1 BYTE)                          NOT NULL,
  DTLSSK  NUMBER(6)                             NOT NULL
)
TABLESPACE ECOMMDATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;
