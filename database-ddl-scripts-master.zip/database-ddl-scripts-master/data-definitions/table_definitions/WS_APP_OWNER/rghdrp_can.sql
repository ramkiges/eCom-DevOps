CREATE TABLE RGHDRP_CAN
(
  HDRRNO  NUMBER(9)                             NOT NULL,
  HDCON   NUMBER(2)                             NOT NULL,
  HDRTYP  NUMBER(2)                             NOT NULL,
  HDROSR  NUMBER(4)                             NOT NULL,
  HDRRDT  NUMBER(9)                             NOT NULL,
  HDRRBY  VARCHAR2(14 BYTE)                     NOT NULL,
  HDREDT  NUMBER(9)                             NOT NULL,
  HDRETM  NUMBER(7)                             NOT NULL,
  HDUPDT  NUMBER(9)                             NOT NULL,
  HDUPTM  NUMBER(7)                             NOT NULL,
  HDRWDT  NUMBER(9)                             NOT NULL,
  HDRBLN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRBFN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRBA1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRBA2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRBCT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRBST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDBZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDBDPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDBEPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDRGLN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRGFN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRGA1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRGA2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRGCT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRGST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDGZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDGDPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDGEPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDRPSN  VARCHAR2(30 BYTE)                     NOT NULL,
  HDRPS1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRPS2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRPCT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRPST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDPZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDRASN  VARCHAR2(30 BYTE)                     NOT NULL,
  HDRAS1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRAS2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRACT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRAST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDAZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDRCN1  VARCHAR2(30 BYTE)                     NOT NULL,
  HDC1PH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDRCN2  VARCHAR2(30 BYTE)                     NOT NULL,
  HDC2PH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDRSLF  CHAR(1 BYTE)                          NOT NULL,
  HDRNOF  CHAR(1 BYTE)                          NOT NULL,
  HDRRSS  CHAR(1 BYTE)                          NOT NULL,
  HDRUSR  VARCHAR2(10 BYTE)                     NOT NULL,
  HDRPWD  VARCHAR2(10 BYTE)                     NOT NULL,
  HDBEML  VARCHAR2(70 BYTE)                     NOT NULL,
  HDRSEC  CHAR(1 BYTE)                          NOT NULL,
  HDRVAL  VARCHAR2(10 BYTE)                     NOT NULL,
  HDRSBD  NUMBER(8)                             NOT NULL,
  HDRSAD  NUMBER(8)                             NOT NULL,
  HDGEML  VARCHAR2(70 BYTE)                     NOT NULL,
  HDREMS  CHAR(1 BYTE)                          NOT NULL,
  HDRHLN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRHFN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRHA1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRHA2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRHCT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRHST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDHZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDHDPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDHEPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDHEML  VARCHAR2(70 BYTE)                     NOT NULL,
  HDRMLN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRMFN  VARCHAR2(15 BYTE)                     NOT NULL,
  HDRMA1  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRMA2  VARCHAR2(20 BYTE)                     NOT NULL,
  HDRMCT  VARCHAR2(13 BYTE)                     NOT NULL,
  HDRMST  VARCHAR2(2 BYTE)                      NOT NULL,
  HDMZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  HDMDPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDMEPH  VARCHAR2(16 BYTE)                     NOT NULL,
  HDMEML  VARCHAR2(70 BYTE)                     NOT NULL,
  HDRINT  VARCHAR2(70 BYTE)                     NOT NULL
)
TABLESPACE REGISTRY
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE INDEX IDX_RGHDRP_CAN_HDCON ON RGHDRP_CAN
(HDCON)
LOGGING
TABLESPACE REGISTRY
NOPARALLEL;


CREATE UNIQUE INDEX PK_RGHDRP_CAN_HDRRNO ON RGHDRP_CAN
(HDRRNO)
LOGGING
TABLESPACE REGISTRY
NOPARALLEL;


ALTER TABLE RGHDRP_CAN ADD (
  CONSTRAINT PK_RGHDRP_CAN_HDRRNO
  PRIMARY KEY
  (HDRRNO)
  USING INDEX PK_RGHDRP_CAN_HDRRNO
  ENABLE VALIDATE);


GRANT DELETE, INSERT, SELECT, UPDATE ON RGHDRP_CAN TO ECOMM_USER;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO MG_USER2018;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO PB_USER2018;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO PK_USER2018;

GRANT SELECT ON RGHDRP_CAN TO PRODSUPPORTREADONLY;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO PT_USER2018;

GRANT SELECT ON RGHDRP_CAN TO SELECT_WSAPPOWNER_TABLES;

GRANT SELECT ON RGHDRP_CAN TO STOREUSERROLE;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO WE_USER2018;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO WS_USER;

GRANT DELETE, INSERT, UPDATE ON RGHDRP_CAN TO WS_USER2018;
