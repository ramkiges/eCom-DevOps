CREATE TABLE NEWREGITEM_66
(
  KEYRRN            NUMBER(9)                   NOT NULL,
  DMPRNO            NUMBER(9)                   NOT NULL,
  DMPSKU            NUMBER(7)                   NOT NULL,
  DMPDQT            NUMBER(3)                   NOT NULL,
  DMPQTP            NUMBER(3)                   NOT NULL,
  DMASID            NUMBER(9)                   NOT NULL,
  DMMGID            NUMBER(9)                   NOT NULL,
  DMSGID            NUMBER(9)                   NOT NULL,
  DMMGSQ            NUMBER(5)                   NOT NULL,
  DMSGSQ            NUMBER(5)                   NOT NULL,
  DMPKSQ            NUMBER(5)                   NOT NULL,
  DMPPRC            NUMBER(9,2)                 NOT NULL,
  DMPIVR            VARCHAR2(1 BYTE)            NOT NULL,
  DMPSSK            NUMBER(6)                   NOT NULL,
  TIMESTAMP         DATE,
  LOCATION          VARCHAR2(30 BYTE),
  TIMESTAMP_DMPDQT  DATE,
  LOCATION_DMPDQT   VARCHAR2(30 BYTE),
  TSTAMP            TIMESTAMP(6) WITH TIME ZONE
)
TABLESPACE USERS
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX NEWREGITEM_66_PK ON NEWREGITEM_66
(KEYRRN)
LOGGING
TABLESPACE USERS
NOPARALLEL;
