CREATE TABLE NEWREG
(
  HTMRNO     NUMBER(9)                          NOT NULL,
  HTCON      NUMBER(2)                          NOT NULL,
  HTMTYP     NUMBER(2)                          NOT NULL,
  HTMOSR     NUMBER(4)                          NOT NULL,
  HTMRDT     NUMBER(9)                          NOT NULL,
  HTMRBY     VARCHAR2(14 BYTE)                  NOT NULL,
  HTMEDT     NUMBER(9)                          NOT NULL,
  HTMETM     NUMBER(7)                          NOT NULL,
  HTUPDT     NUMBER(9)                          NOT NULL,
  HTUPTM     NUMBER(7)                          NOT NULL,
  HTMWDT     NUMBER(9)                          NOT NULL,
  HTMBLN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMBFN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMBA1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMBA2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMBCT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMBST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTBZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTBDPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTBEPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMGLN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMGFN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMGA1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMGA2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMGCT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMGST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTGZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTGDPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTGEPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMPSN     VARCHAR2(30 BYTE)                  NOT NULL,
  HTMPS1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMPS2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMPCT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMPST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTPZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTMASN     VARCHAR2(30 BYTE)                  NOT NULL,
  HTMAS1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMAS2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMACT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMAST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTAZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTMCN1     VARCHAR2(30 BYTE)                  NOT NULL,
  HTC1PH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMCN2     VARCHAR2(30 BYTE)                  NOT NULL,
  HTC2PH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMSLF     VARCHAR2(1 BYTE)                   NOT NULL,
  HTMNOF     VARCHAR2(1 BYTE)                   NOT NULL,
  HTMRSS     VARCHAR2(1 BYTE)                   NOT NULL,
  HTMUSR     VARCHAR2(10 BYTE)                  NOT NULL,
  HTMPWD     VARCHAR2(10 BYTE)                  NOT NULL,
  HTBEML     VARCHAR2(70 BYTE)                  NOT NULL,
  HTMSEC     VARCHAR2(1 BYTE)                   NOT NULL,
  HTMVAL     VARCHAR2(10 BYTE)                  NOT NULL,
  HTMSBD     NUMBER(8)                          NOT NULL,
  HTMSAD     NUMBER(8)                          NOT NULL,
  HTGEML     VARCHAR2(70 BYTE)                  NOT NULL,
  HTMEMS     VARCHAR2(1 BYTE)                   NOT NULL,
  HTMHLN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMHFN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMHA1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMHA2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMHCT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMHST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTHZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTHDPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTHEPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTHEML     VARCHAR2(70 BYTE)                  NOT NULL,
  HTMMLN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMMFN     VARCHAR2(15 BYTE)                  NOT NULL,
  HTMMA1     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMMA2     VARCHAR2(20 BYTE)                  NOT NULL,
  HTMMCT     VARCHAR2(13 BYTE)                  NOT NULL,
  HTMMST     VARCHAR2(2 BYTE)                   NOT NULL,
  HTMZIP     VARCHAR2(9 BYTE)                   NOT NULL,
  HTMDPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMEPH     VARCHAR2(16 BYTE)                  NOT NULL,
  HTMEML     VARCHAR2(70 BYTE)                  NOT NULL,
  HTMINT     VARCHAR2(70 BYTE)                  NOT NULL,
  HTMFD1     VARCHAR2(77 BYTE)                  NOT NULL,
  HTMFD2     VARCHAR2(77 BYTE)                  NOT NULL,
  HTMFD3     VARCHAR2(77 BYTE)                  NOT NULL,
  HTMFD4     VARCHAR2(77 BYTE)                  NOT NULL,
  HTMFD5     VARCHAR2(77 BYTE)                  NOT NULL,
  NUMITEMS   NUMBER(9),
  TIMESTAMP  DATE,
  LOCATION   VARCHAR2(30 BYTE),
  TSTAMP     TIMESTAMP(6) WITH TIME ZONE
)
TABLESPACE REGISTRY
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
CACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX NEWREG_PK ON NEWREG
(HTMRNO)
LOGGING
TABLESPACE REGISTRY
NOPARALLEL;


ALTER TABLE NEWREG ADD (
  CONSTRAINT NEWREG_PK
  PRIMARY KEY
  (HTMRNO)
  USING INDEX NEWREG_PK
  ENABLE VALIDATE);


GRANT SELECT ON NEWREG TO DSTEPHENS;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO ECOMM_USER;

GRANT SELECT ON NEWREG TO EDEVELOPER;

GRANT SELECT ON NEWREG TO E_WS_APP_SELECT;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO MG_USER2018;

GRANT SELECT ON NEWREG TO MSMITH;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO PB_USER2018;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO PK_USER2018;

GRANT SELECT ON NEWREG TO PRODSUPPORTREADONLY;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO PT_USER2018;

GRANT SELECT ON NEWREG TO SELECT_WSAPPOWNER_TABLES;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO WEBADMIN_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO WE_USER2018;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO WS_USER;

GRANT DELETE, INSERT, SELECT, UPDATE ON NEWREG TO WS_USER2018;
