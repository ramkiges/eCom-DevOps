CREATE TABLE MYTEMP
(
  KEYRRN  NUMBER(10)                            NOT NULL,
  TRNRNO  NUMBER(9)                             NOT NULL,
  TRNBYN  VARCHAR2(25 BYTE)                     NOT NULL,
  TRNBA1  VARCHAR2(20 BYTE)                     NOT NULL,
  TRNBA2  VARCHAR2(20 BYTE)                     NOT NULL,
  TRNBCT  VARCHAR2(13 BYTE)                     NOT NULL,
  TRNBST  VARCHAR2(2 BYTE)                      NOT NULL,
  TRBZIP  VARCHAR2(9 BYTE)                      NOT NULL,
  TRB1PH  VARCHAR2(16 BYTE)                     NOT NULL,
  TRB2PH  VARCHAR2(16 BYTE)                     NOT NULL,
  TRASID  NUMBER(9)                             NOT NULL,
  TRMGID  NUMBER(9)                             NOT NULL,
  TRMGSQ  NUMBER(5)                             NOT NULL,
  TRSGID  NUMBER(9)                             NOT NULL,
  TRSGSQ  NUMBER(5)                             NOT NULL,
  TRLKSQ  NUMBER(5)                             NOT NULL,
  TRNSKU  NUMBER(7)                             NOT NULL,
  TRNPRC  NUMBER(7,2)                           NOT NULL,
  TRNPSR  NUMBER(4)                             NOT NULL,
  TRNDAT  NUMBER(9)                             NOT NULL,
  TRNTIM  NUMBER(7)                             NOT NULL,
  TRNQTY  NUMBER(3)                             NOT NULL,
  TRTYPE  CHAR(1 BYTE)                          NOT NULL,
  TRNSWF  CHAR(1 BYTE)                          NOT NULL
)
TABLESPACE ECOMMDATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE INDEX PK_MYTEMP ON MYTEMP
(KEYRRN)
LOGGING
TABLESPACE ECOMMDATA
NOPARALLEL;
