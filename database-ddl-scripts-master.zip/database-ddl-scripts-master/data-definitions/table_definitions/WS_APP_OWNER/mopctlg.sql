CREATE TABLE MOPCTLG
(
  COMPNY  VARCHAR2(1 BYTE)                      NOT NULL,
  CATCOD  NUMBER(2)                             NOT NULL,
  CONCPT  NUMBER(2)                             NOT NULL,
  CATDES  VARCHAR2(25 BYTE)                     NOT NULL,
  STKSLS  NUMBER(13,2)                          NOT NULL,
  BYDFLG  CHAR(1 BYTE)                          NOT NULL,
  BYSFLG  CHAR(1 BYTE)                          NOT NULL,
  XCPFLG  CHAR(1 BYTE)                          NOT NULL,
  SL6FLG  CHAR(1 BYTE)                          NOT NULL,
  SPACAD  CHAR(1 BYTE)                          NOT NULL,
  STORSN  CHAR(1 BYTE)                          NOT NULL,
  SHIPME  CHAR(1 BYTE)                          NOT NULL,
  CATTYP  CHAR(1 BYTE)                          NOT NULL,
  CIRC    NUMBER(9)                             NOT NULL,
  DTEREL  NUMBER(6)                             NOT NULL,
  DTEORD  NUMBER(6)                             NOT NULL,
  ORTDT   NUMBER(7)                             NOT NULL,
  EXPORD  NUMBER(7)                             NOT NULL,
  TOTLWK  NUMBER(2)                             NOT NULL,
  WKSLFT  NUMBER(2)                             NOT NULL,
  SLSTD   NUMBER(9,2)                           NOT NULL,
  EXPSLS  NUMBER(9)                             NOT NULL,
  COST1   NUMBER(5,2)                           NOT NULL,
  COST2   NUMBER(5,2)                           NOT NULL,
  ORDLIN  NUMBER(3)                             NOT NULL,
  CATORD  NUMBER(7)                             NOT NULL,
  CATSLS  NUMBER(9)                             NOT NULL,
  NET     NUMBER(2)                             NOT NULL,
  ORDKEY  NUMBER(3)                             NOT NULL,
  COST3   NUMBER(3,2)                           NOT NULL,
  PRJCOD  CHAR(1 BYTE)                          NOT NULL,
  DATEXP  NUMBER(6)                             NOT NULL,
  FILL30  VARCHAR2(30 BYTE)                     NOT NULL,
  FILL20  VARCHAR2(20 BYTE)                     NOT NULL,
  AVGORD  NUMBER(5,2)                           NOT NULL,
  FILL02  VARCHAR2(2 BYTE)                      NOT NULL,
  DATEFF  NUMBER(6)                             NOT NULL,
  EFFABS  NUMBER(5)                             NOT NULL,
  EXPABS  NUMBER(5)                             NOT NULL,
  SHRUL   NUMBER(3)                             NOT NULL
)
TABLESPACE ECOMMDATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
CACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX PK_MOPCTLG_CONCPT_CATCOD ON MOPCTLG
(CONCPT, CATCOD)
LOGGING
TABLESPACE ECOMMDATA
NOPARALLEL;


ALTER TABLE MOPCTLG ADD (
  CONSTRAINT PK_MOPCTLG_CONCPT_CATCOD
  PRIMARY KEY
  (CONCPT, CATCOD)
  USING INDEX PK_MOPCTLG_CONCPT_CATCOD
  ENABLE VALIDATE);


GRANT SELECT ON MOPCTLG TO BASE_PRIVS;

GRANT SELECT ON MOPCTLG TO DSTEPHENS;

GRANT DELETE, INSERT, SELECT, UPDATE ON MOPCTLG TO ECOMM_USER;

GRANT SELECT ON MOPCTLG TO EDEVELOPER;

GRANT SELECT ON MOPCTLG TO E_WS_APP_SELECT;

GRANT SELECT ON MOPCTLG TO MSMITH;

GRANT SELECT ON MOPCTLG TO PRODSUPPORTREADONLY;

GRANT SELECT ON MOPCTLG TO SELECT_WSAPPOWNER_TABLES;

GRANT SELECT ON MOPCTLG TO STOREUSERROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON MOPCTLG TO WEBADMIN_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON MOPCTLG TO WSWEB_USER_ROLE;
