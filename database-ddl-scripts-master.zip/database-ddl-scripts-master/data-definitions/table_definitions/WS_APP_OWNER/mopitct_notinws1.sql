CREATE TABLE MOPITCT_NOTINWS1
(
  ICSKU   NUMBER(7)                             NOT NULL,
  ICCAT   NUMBER(2)                             NOT NULL,
  ICPRCE  NUMBER(7,2)                           NOT NULL,
  ICEXPR  NUMBER(6)                             NOT NULL,
  ICEFFP  NUMBER(6)                             NOT NULL
)
TABLESPACE USERS
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;
