CREATE TABLE IPRICE_CAN
(
  RPNBR   NUMBER(7)                             NOT NULL,
  RPSKU#  NUMBER(6)                             NOT NULL,
  RPCHKD  NUMBER(1)                             NOT NULL,
  RPPRCD  CHAR(1 BYTE)                          NOT NULL,
  RPZONE  NUMBER(3)                             NOT NULL,
  RPSTSP  VARCHAR2(2 BYTE)                      NOT NULL,
  RPSRET  NUMBER(9,2)                           NOT NULL,
  RPSREC  NUMBER(1)                             NOT NULL,
  RPSRED  NUMBER(6)                             NOT NULL,
  RPCRET  NUMBER(9,2)                           NOT NULL,
  RPCREC  NUMBER(1)                             NOT NULL,
  RPCRED  NUMBER(6)                             NOT NULL,
  RPCPLU  NUMBER(9,2)                           NOT NULL,
  RPCPEC  NUMBER(1)                             NOT NULL,
  RPCPED  NUMBER(6)                             NOT NULL,
  RPTRET  NUMBER(9,2)                           NOT NULL,
  RPTEFC  NUMBER(1)                             NOT NULL,
  RPTEFD  NUMBER(6)                             NOT NULL,
  RPTETC  NUMBER(1)                             NOT NULL,
  RPTETD  NUMBER(6)                             NOT NULL,
  RPPRP1  NUMBER(9,2)                           NOT NULL,
  RPPRC1  NUMBER(1)                             NOT NULL,
  RPPRD1  NUMBER(6)                             NOT NULL,
  RPPRP2  NUMBER(9,2)                           NOT NULL,
  RPPRC2  NUMBER(1)                             NOT NULL,
  RPPRD2  NUMBER(6)                             NOT NULL,
  RPPRP3  NUMBER(9,2)                           NOT NULL,
  RPPRC3  NUMBER(1)                             NOT NULL,
  RPPRD3  NUMBER(6)                             NOT NULL,
  RPPEND  CHAR(1 BYTE)                          NOT NULL,
  RPNRP1  NUMBER(9,2)                           NOT NULL,
  RPNFC1  NUMBER(1)                             NOT NULL,
  RPNFD1  NUMBER(6)                             NOT NULL,
  RPNTC1  NUMBER(1)                             NOT NULL,
  RPNTD1  NUMBER(6)                             NOT NULL,
  RPNRP2  NUMBER(9,2)                           NOT NULL,
  RPNFC2  NUMBER(1)                             NOT NULL,
  RPNFD2  NUMBER(6)                             NOT NULL,
  RPNTC2  NUMBER(1)                             NOT NULL,
  RPNTD2  NUMBER(6)                             NOT NULL
)
TABLESPACE ECOMMDATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX PK_IPRICE_CAN_RPNBR ON IPRICE_CAN
(RPNBR)
LOGGING
TABLESPACE ECOMMDATA
NOPARALLEL;


ALTER TABLE IPRICE_CAN ADD (
  CONSTRAINT PK_IPRICE_CAN_RPNBR
  PRIMARY KEY
  (RPNBR)
  USING INDEX PK_IPRICE_CAN_RPNBR
  ENABLE VALIDATE);


GRANT DELETE, INSERT, SELECT, UPDATE ON IPRICE_CAN TO ECOMM_USER;

GRANT SELECT ON IPRICE_CAN TO PRODSUPPORTREADONLY;

GRANT SELECT ON IPRICE_CAN TO SELECT_WSAPPOWNER_TABLES;

GRANT SELECT ON IPRICE_CAN TO STOREUSERROLE;
