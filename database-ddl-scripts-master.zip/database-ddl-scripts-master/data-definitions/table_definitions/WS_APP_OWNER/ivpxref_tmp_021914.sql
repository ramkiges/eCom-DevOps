CREATE TABLE IVPXREF_TMP_021914
(
  IXOCAT  NUMBER(2)                             NOT NULL,
  IXOSKU  NUMBER(7)                             NOT NULL,
  IXNCAT  NUMBER(2)                             NOT NULL,
  IXNSKU  NUMBER(7)                             NOT NULL,
  IXMIS1  VARCHAR2(1 BYTE)                      NOT NULL,
  IXMIS2  VARCHAR2(1 BYTE)                      NOT NULL,
  IXMIS3  VARCHAR2(1 BYTE)                      NOT NULL,
  IXMIS4  VARCHAR2(1 BYTE)                      NOT NULL,
  IXSCAT  NUMBER(9)                             NOT NULL,
  IXCYR   NUMBER(4)                             NOT NULL,
  IXCTYP  NUMBER(2)                             NOT NULL,
  IXCCON  NUMBER(2)                             NOT NULL
)
TABLESPACE ECOMMDATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;
