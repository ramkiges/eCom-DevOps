#!/bin/bash
###################################################################################################
#Description: Shell script to tag and push docker image
#Author: Sandeep Chitte
#Date of creation: 13-09-2018
#Arguements : registry name/Path & imagename with version
#Usage: ./build_push.sh <Full path of registry> <imagename:version>
###################################################################################################
#Exit on error
set -e

##This script accepts two arguments.Arg1 is path of the registry,Arg2 is the complete image name with version.These are saved in two variables registry and imageid respectively
registry="$1"
imageid="$2"

##This line displays the contents of the arguments
echo "registry path is $registry : image used is $imageid"

##The below block tags and pushes the image to the required registry
docker tag $imageid $registry/$imageid
docker push $registry/$imageid
