#!/bin/bash

# TODO: Seriously? Improve this build script. It sucks!

docker build -t wsgc/centos7:base -f docker/base/Dockerfile .

docker build -t wsgc/wct:latest -f docker/wct/Dockerfile docker/wct

docker build -t wsgc/node:10-maven -f docker/node/10/Dockerfile .

# This is the base image built upon by eCommerce-Kubernetes-Bedrock/deployer
docker build -t container-registry01.nonprod.wsgc.com/ecom/deployer:base -f docker/helm-deployer/Dockerfile .

docker build -t wsgc/etcd-tools:base -f docker/etcd-tools/Dockerfile .

docker build -t wsgc/wsi-alpine:base -f docker/wsi-alpine/Dockerfile .

docker build -t container-registry01.nonprod.wsgc.com/edap/trillium:16.1.0-wsi -f docker/trillium/trillium/Dockerfile .

docker build -t container-registry01.nonprod.wsgc.com/edap/trillium-nginx:1.20-wsi -f docker/trillium/nginx/Dockerfile .

docker build -t container-registry01.nonprod.wsgc.com/edap/hazelcast-enterprise:4.2.4-wsi -f docker/hazelcast/hazelcast-enterprise/Dockerfile .

docker build -t container-registry01.nonprod.wsgc.com/edap/hazelcast-management-center:5.0.4-wsi -f docker/hazelcast/hazelcast-management-center/Dockerfile .
