eComDevOps Docker Images
=======================

A collection of base images for all eCommerceDevOps containarized apps.

# Pre requisites

 - Ansible is installed
 - Docker is installed
 - Python2 includes the lxml package
   - `python2 -m pip install lxml` if not


# Building

 - `./download` will download a local cache of rpms to save time
 - `./generate_secrets` will create the `sensitive` directory and contents
 - `./build.sh` will create the docker images
