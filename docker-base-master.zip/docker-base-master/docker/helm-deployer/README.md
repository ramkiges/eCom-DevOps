Helm deployer base image

Build and Push Image:
`docker build . -t container-registry01.nonprod.wsgc.com/ecom/deployer:base -f docker/helm-deployer/Dockerfile`
`docker push container-registry01.nonprod.wsgc.com/ecom/deployer:base`
