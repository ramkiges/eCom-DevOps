Headless WCT Container
=======
This repo was created to test WCT running in headless mode.

# Getting Started

Build the container:

```
docker build -t wsgc/wct:latest -f docker/wct/Dockerfile docker/wct
```

Go to your application root directory.

First delete your local `node_modules`. We want to install the dependencies inside the container:

```
rm -rf node_modules/
```

Start a fresh container using the docker image, mounting your current folder to `/usr/src`:

Run the container:

```
docker run -it --rm -v "$PWD:/usr/src" -e "NPM_TOKEN=your_npm_auth_token" wsgc/wct:latest bash
```

Inside the container follow the regular node workflow:

Install

```
SKIP_WCT_SAUCE_POSTINSTALL_DOWNLOAD=true NOSELENIUM=true npm install
```

Link the selenium-standalone folder from our global node_modules to each module that you have a selenium-standalone dependency:

```
ln -sf /usr/local/lib/node_modules/selenium-standalone/.selenium node_modules/selenium-standalone/.selenium
```

Run the tests :)

```
xvfb-run ./node_modules/.bin/wct --configFile wct-ci.conf.json
```

