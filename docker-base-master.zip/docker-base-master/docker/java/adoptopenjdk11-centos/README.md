Java 11 image

Build and Push Image:
Note: Both `11-wsi` and `jre-11.0.9.1_1-centos-wsi` are same. Use the simpler tag `11-wsi` instead of the long name. Once we have updated that in all
apps, we can remove the tag `jre-11.0.9.1_1-centos-wsi`

`docker build . -t container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:11-wsi -f docker/java/adoptopenjdk11-centos/Dockerfile`
`docker tag container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:11-wsi container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11.0.9.1_1-centos-wsi`
`docker push container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:11-wsi`
`docker push container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11.0.9.1_1-centos-wsi`
