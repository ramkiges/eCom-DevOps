Java 8 image

Build and Push Image:
`docker build . -t container-registry01.nonprod.wsgc.com/ecom/jre:8 -f docker/java/jre8/Dockerfile`
`docker push container-registry01.nonprod.wsgc.com/ecom/jre:8`
