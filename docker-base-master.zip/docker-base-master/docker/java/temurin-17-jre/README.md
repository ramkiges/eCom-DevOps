Java 17 image

Build and Push Image:
eclipse-temurin:17.0.1_12-jre-centos7

'docker push container-registry01.nonprod.wsgc.com/ecom/eclipse-temurin:17.0.1_12-jre-centos7'
