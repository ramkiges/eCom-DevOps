Java 11 image

Build and Push Image: adoptopenjdk:jdk-11.0.9.1_1-centos-official

'docker push container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jdk-11.0.9.1_1-centos-official'
