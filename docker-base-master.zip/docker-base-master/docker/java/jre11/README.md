JRE 11 image

Build and Push Image:
Note: Both `jre-11-wsi` and `jre-11.0.20.1_1-wsi` are same. Use the simpler tag `jre-11-wsi` instead of the long name. Once we have updated that in all apps, we can remove the other two java 11 dockerfiles and the remaining tags.

`docker build . -t container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11-wsi -f docker/java/jre11/Dockerfile --platform=linux/amd64`
`docker tag container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11-wsi container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11.0.20.1_1-wsi`
`docker push container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11-wsi`
`docker push container-registry01.nonprod.wsgc.com/ecom/adoptopenjdk:jre-11.0.20.1_1-wsi`
