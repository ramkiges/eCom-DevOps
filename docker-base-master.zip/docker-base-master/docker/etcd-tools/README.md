ETCD-tools base image

Build and Push Image:
`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/wsgc/etcd-tools:base -f docker/etcd-tools/Dockerfile`
`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/wsgc/etcd-tools:base`
