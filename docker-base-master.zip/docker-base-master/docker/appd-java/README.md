A small container which includes the AppD agent, plus some customizations to the controller info.  Any change to the 
container, will require a new tag, we cannot re-use the tag with how we pull the image down. 

`docker build . -t container-registry01.nonprod.wsgc.com/ecom/appd-java:4.5.14.3`

`docker push container-registry01.nonprod.wsgc.com/ecom/appd-java:4.5.14.3`
