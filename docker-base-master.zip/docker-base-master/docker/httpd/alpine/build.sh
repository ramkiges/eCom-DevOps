#!/bin/sh

docker build -t container-registry01.nonprod.wsgc.com/ecom/httpd:2.4-alpine-wsi .
