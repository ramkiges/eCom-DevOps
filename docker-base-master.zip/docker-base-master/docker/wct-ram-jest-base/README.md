Container for building web component repositories
=======
This repo was created to test web components with Jest, and move all web component builds into RAM for speed.

## Build the container
Note: we use `--no-cache` to prevent the build from re-using
possibly-stale layers of OS and NPM packages from earlier builds on
your machine.
```
docker build --no-cache -t snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest-node18:latest -f docker/wct-ram-jest-base/node18/Dockerfile .
```

## Test the container

Go to your application root directory.

Start a fresh container using the docker image, mounting your current folder to `/npm/src`:

Run the container (we need --priveleged in order to mount the RAMFS):

```
docker run -it --privileged --rm -v "$PWD:/npm/src" -e "NPM_TOKEN=your_npm_auth_token" snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest-node18:latest bash
```

Inside the container follow the ci workflow steps:

Step 1 - init - mount the RAM FS and copy the source code there

```
ci-1-init.sh
```

Step 1b - swiffer - run swiffer to lint the package structure

```
ci-1b-swiffer.sh
```

Step 2 - lint - check for linting issues before building

```
ci-2-lint.sh
```

Step 3 - install - npm install and lerna bootstrap

```
ci-3-install.sh
```

Step 4 - build - perform the build step on each component

```
ci-4-build.sh
```

Step 5 - test - run the headless tests

```
ci-5-test.sh
```

## Push the container
Note: Every time an image is generated (even from the same commit hash), it may be different due to 
changes in upstream dependencies downloaded during `docker build`.  Add the current date to the tag,
which will allow us to go back to an earlier image generated from same commit hash.
```
docker tag snapshotrepo.wsgc.com/ecommerce-docker-repo/snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest-node18:latest snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest:[YYYY-MM-DD]-[COMMITHASH (first 8 chars)]
docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest:latest
docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest:[YYYY-MM-DD]-[COMMITHASH (first 8 chars)]
```
Example for the tag:
```
:2020-12-07-164935f1
```

## Running Python Unit Tests

`cd docker/wct-ram/npm_publish/git/` run `python -m unittest test_commit_parser`
