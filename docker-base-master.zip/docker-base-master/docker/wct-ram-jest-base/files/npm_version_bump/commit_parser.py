""" A class for publishing new versions of NPM packages """
import re

PATCH = 0
MINOR = 1
MAJOR = 2

class CommitParser:
    """ A refactor of npm-publish to facilitate unit tests """

    def __init__(self, commit_lines):
        self.commitLines = commit_lines

    # take the output of 'git log v1.1.0..HEAD' and return the highest severity found.
    # Fail and exit with error code 1 if there are no commits in the range
    # Fail and exit with error code 1 if any commit in the range does not include a severity
    # Assumptions:
    #  - script is running in the root directory of the repo
    #  - the current directory is a valid git repo, and has a valid upstream named 'origin'
    #  - another script has run the tests, and all the artifacts from an npm install are here still
    #  - nodejs/npm are installed
    #  - lerna is installed at ./node_modules/.bin/lerna (it is only on PATH for NPM commands)
    #  - python 2 is installed
    #  - gitpyhton is installed ```pip install gitpython```
    #  - semver is installed ```pip install semver```
    #  - git is currently on the proper branch
    #  - you are using lerna to publish components
    #  - you must have at least one commit since the last semver tag (vX.Y.Z)
    #  - each commit must have a severity tag [PATCH|MINOR|MAJOR]
    #  - git tag history must agree with lerna.json on the current version
    def parse_change_severity(self):
        commits = []
        commit = {}
        bumps = []
        # iterate lines and save
        for nextLine in self.commitLines:
            if nextLine == '' or nextLine == '\n':
                # ignore empty lines
                pass
            elif bool(re.match('commit', nextLine, re.IGNORECASE)):
                # commit xxxx
                if len(commit) != 0:  # new commit, so re-initialize
                    # As we are now ignoring merge commits, it's possible that the commit object here does not have
                    # the actual message and only contain author, email and date info which is of no use, so only
                    # consider the commits with has an actual message.
                    if 'message' in commit:
                        commits.append(commit)
                    commit = {}
                commit = {'hash': re.match('commit (.*)', nextLine, re.IGNORECASE).group(1)}
            elif bool(re.match('merge:', nextLine, re.IGNORECASE)):
                # Merge: xxxx xxxx
                pass
            elif bool(re.search('merge branch|merge commit', nextLine, re.IGNORECASE)):
                # Merge Commit ... (ignore this commit created by jenkins locally if PR is out of
                # date from the target branch
                # Merge Branch ... (ignore this commit created when dev use the update button in the PR
                # update their out of date branch with target branch
                pass
            elif bool(re.match('author:', nextLine, re.IGNORECASE)):
                # Author: xxxx <xxxx@xxxx.com>
                m = re.compile('Author: (.*) <(.*)>').match(nextLine)
                commit['author'] = m.group(1)
                commit['email'] = m.group(2)
            elif bool(re.match('date:', nextLine, re.IGNORECASE)):
                # Date: xxx
                pass
            elif bool(re.match('    ', nextLine, re.IGNORECASE)):
                # (4 empty spaces)
                if commit.get('message') is None:
                    commit['message'] = nextLine.strip()
                else:
                    commit['message'] = commit['message'] + nextLine.strip()
            else:
                print('ERROR: Unexpected Line: ' + nextLine)

        # need to append the last commit from the parsing
        if 'message' in commit:
            commits.append(commit)

        any_release_commit = False
        cmt = {}
        for cmt in commits:
            severity_found = False
            if self.is_release_commit(cmt):
                # ignore the commit, it is an auto-publish FUTURE:Fix lerna to allow a better commit message
                any_release_commit = True
                continue
            if bool(re.search('\[PATCH\]', cmt['message'], re.IGNORECASE)):
                bumps.append(PATCH)
                severity_found = True
            if bool(re.search('\[MINOR\]', cmt['message'], re.IGNORECASE)):
                bumps.append(MINOR)
                severity_found = True
            if bool(re.search('\[MAJOR\]', cmt['message'], re.IGNORECASE)):
                bumps.append(MAJOR)
                severity_found = True
            if not severity_found:
                # In the case of a missing severity, and due to an inconvenient 
                # bug in GHE losing the severity on PR edit, we are defaulting
                # to a MINOR severity for this commit, rather than failing completely.
                # In the case this is a PATCH, all is well.
                # In the case this is a MAJOR, manual intervention will be needed
                # after the fact.
                bumps.append(MINOR)
                severity_found = True
                # fail if we have commits but are missing a severity change marker
                print("No Severity Found, looking for [MAJOR], [MINOR], or [PATCH] in commit messages")
                print("Using MINOR for missing commit severity")
                print(cmt['hash'])
                print(cmt['message'])

                # bail out no commits since latest tag - no need to publish
        if len(commits) == 0:
            print("Skipping publish, found no commits")
            exit(0)

        if len(bumps) == 0 and any_release_commit:
            print("The commit message has a mention of [RELEASE] vX.Y.Z. " 
                  "Exiting without auto release as it is considered as a release commit. "
                  "If it's suppose to create a new release, please amend the commit by "
                  "removing the mention of string [RELEASE] vX.Y.Z and add a severity to it.")
            exit(1)

        severity = max(bumps)

        if severity == PATCH:
            return 'patch'
        elif severity == MINOR:
            return 'minor'
        else:
            return 'major'

    # check if given commit object is a release commit
    # Now: check for commit message of vX.Y.Z
    def is_release_commit(self, commit):
        return bool(re.search('(\[RELEASE\]\s?)v((0|(?:[1-9]\d*))\.(0|(?:[1-9]\d*))\.(0|([1-9]\d*)))', commit['message']))
