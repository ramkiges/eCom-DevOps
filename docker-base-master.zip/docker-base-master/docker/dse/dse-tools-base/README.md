A base image which installs external packages necessary to run DataStax Enterprise tools (such as `cqlsh` and `dsbulk`).  The expectation is that the project `Dockerfile` only installs pip packages and uses any `apt` and vendor packages provided by this container.  Doing this allows us to build the application container in CI without access to the internet.

Build and Push Image:

Push to `snapshotrepo.wsgc.com`
`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/dse-tools-base:latest -f docker/dse/dse-tools-base/Dockerfile`
`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/dse-tools-base:latest`

Also, it needs to be pushed to `container-registry01.nonprod.wsgc.com`
`docker tag snapshotrepo.wsgc.com/ecommerce-docker-repo/dse-tools-base:latest container-registry01.nonprod.wsgc.com/ecom/dse-tools-base:latest`
`docker push container-registry01.nonprod.wsgc.com/ecom/dse-tools-base:latest`
