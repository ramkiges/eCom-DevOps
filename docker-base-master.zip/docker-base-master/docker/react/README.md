Container for React based projects
=======
This repo was created to build and test React based projects.

## Build the container

```
docker build -t snapshotrepo.wsgc.com/ecommerce-docker-repo/react-pipeline:current -f docker/react/Dockerfile docker/react
```

## Test the container

Go to your application root directory.

Start a fresh container using the docker image, mounting your current folder to `/npm/src`:

Run the container:

```
docker run -it --user=node  --rm -v "$PWD:/npm/src" -e "NPM_TOKEN=your_npm_auth_token" snapshotrepo.wsgc.com/ecommerce-docker-repo/react-pipeline:current bash
```

Inside the container follow the CI workflow steps:

Step 1 - Swiffer - run swiffer to lint the package structure

```
cd /npm/src;
. /home/node/.profile && swiffer .
```

Step 2 - lint - check for linting issues before building

```
cd /npm/src;
npm link @js-ecom-build/eslint-config-base eslint-plugin-jest;
npm run lint-ci;
```

Step 3 - install - npm install

```
cd /npm/src;
npm install
```

Step 4 - build - perform the build step on each component

```
cd /npm/src;
npm run build-ci
```

Step 5 - test - run the headless tests

```
cd /npm/src;
npm run test-ci
```

Step 8 - SonarQube Analysis

Since SonarQube is on a separate image, stop `react-pipeline:current` image and start `sonar-scanner:4.2.0.1873` image.

```
docker run -it --user=jenkins --rm -v "$PWD:/npm/src" snapshotrepo.wsgc.com/ecommerce-docker-repo/sonar-scanner:4.2.0.1873 /bin/sh
```

Now run SonarQube analysis:

```
REPORT_PATHS=$(find . -name 'lcov.info' -type f -path '*/coverage/jest/*' -printf %p,)
SOURCES=$(find . -maxdepth 2 -type d -name 'src' -printf %p,)
PROJECT_NAME=<PACKAGE_NAME>
PROJECT_DESCRIPTION=<PROJECT_DESC>
PROJECT_KEY=projectKey
BRANCH_NAME=<ORG_NAME>/<BRANCH_NAME>
PROJECT_VERSION=<APP_VERSION>

sonar-scanner \
-Dsonar.javascript.lcov.reportPaths="${REPORT_PATHS}" \
-Dsonar.sources="${SOURCES}" \
-Dsonar.projectName="${PROJECT_NAME}" \
-Dsonar.projectDescription="${PROJECT_DESCRIPTION}" \
-Dsonar.projectKey="${PROJECT_KEY}" \
-Dsonar.branch.name="${BRANCH_NAME}" \
-Dsonar.projectVersion="${PROJECT_VERSION}" \
-Dsonar.exclusions='src/index.js,src/serviceWorker.js' \
-Dsonar.cfamily.build-wrapper-output.bypass=true \
-Dsonar.working.directory="${jenkins.env.WORKSPACE}/sonar" \
-Dsonar.analysis.mode=publish \
-Dsonar.coverage.exlusions='src/index.js,src/serviceWorker.js' \
-Dsonar.test.inclusions='**/src/**/*.spec.js,**/src/**/*.spec.jsx,**/src/**/*.test.js,**/src/**/*.test.jsx'
```
