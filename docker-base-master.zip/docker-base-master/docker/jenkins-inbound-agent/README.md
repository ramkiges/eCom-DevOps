Jenkins inbound agent image

Build and Push Image:
`docker build . -t container-registry01.nonprod.wsgc.com/ecom/jenkins-inbound-agent:3131-wsi --platform=linux/amd64`
`docker push container-registry01.nonprod.wsgc.com/ecom/jenkins-inbound-agent:3131-wsi`
