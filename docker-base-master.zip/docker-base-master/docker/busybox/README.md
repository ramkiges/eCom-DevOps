A busybox base image which is used by the 'appd-java' and to spin up 'init container' for 'k8s-pricing service'
Adding curl to busybox to support the init container requirements for k8s-pricing service

`docker push container-registry01.nonprod.wsgc.com/ecom/wsi-busybox:1.1.0`
