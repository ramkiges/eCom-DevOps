#!/bin/sh

docker build -t container-registry01.nonprod.wsgc.com/ecom/wsi-busybox:1.1.0 .
