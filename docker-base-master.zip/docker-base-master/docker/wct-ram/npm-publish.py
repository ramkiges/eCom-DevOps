#!/usr/bin/env python2

import git
import json
import sys
import re
import os
import os.path as osp
from subprocess import call
import StringIO
import semver
from npm_publish.git.commit_parser import CommitParser

finalVersionBump = None
data = json.load(open('lerna.json'))

# ask lerna for its version
lernaLatestVersion = str(data["version"])

cwd = os.getcwd()
repo = git.Repo.init(cwd)

# semver sort of versions
tags = []
for tag in repo.tags:
    # check for 'vX.Y.Z' format of valid semver tags and only use those
    # allow for new [RELEASE] tagged items
    if bool(re.match('^(\[RELEASE\]\s?)?v[0-9]+\.[0-9]+\.[0-9]+$', str(tag))):
        tags.append(str(tag)[1:])
    else:
        print "Ignoring tag: " + tag.name
tags = sorted(tags, cmp=semver.compare)  # sort all the tags in semver order

# the last tag sorted by semver
gitLatestVersion = str(tags[-1])

if lernaLatestVersion == gitLatestVersion:
    # we are at an expected state
    log = repo.git.log('tags/v' + gitLatestVersion + '..HEAD')
    buf = StringIO.StringIO(log)
    # commits = repo.iter_commits(None, 'tags/v' + gitLatestVersion)
    commit_parser = CommitParser(buf.readlines())
    finalVersionBump = commit_parser.parse_change_severity()
    print "publishing a " + finalVersionBump + " version"
    # lerna should exit 0 on success, 1 on failure
    exit(call(["node_modules/.bin/lerna", "publish", "-m [RELEASE] %s", "--exact", "--ignore-scripts", "--force-publish=*", "--yes", "--cd-version=" + finalVersionBump]))
else:
    print "ERROR: Last lerna version " + lernaLatestVersion + " does not agree with git version " + gitLatestVersion
    exit(1)
    
# we never did anything, we should fail to let our upstream know about it
print "ERROR: No work was done, exiting"
exit(1)
