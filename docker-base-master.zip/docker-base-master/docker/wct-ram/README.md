Headless WCT Container
=======
This repo was created to test WCT running in headless mode, and move all web component builds into RAM for speed.

# Getting Started

Build the container:

```
docker build -t wsgc/wct-ram:latest -f docker/wct-ram/Dockerfile docker/wct-ram
```

Go to your application root directory.

Start a fresh container using the docker image, mounting your current folder to `/npm/src`:

Run the container (we need --priveleged in order to mount the RAMFS):

```
docker run -it --privileged --rm -v "$PWD:/npm/src" -e "NPM_TOKEN=your_npm_auth_token" wsgc/wct-ram:latest bash
```

Inside the container follow the ci workflow steps:

Step 1 - init - mount the RAM FS and copy the source code there

```
ci-1-init.sh
```

Step 2 - lint - check for linting issues before building

```
ci-2-lint.sh
```

Step 3 - install - npm install and lerna bootstrap

```
ci-3-install.sh
```

Step 4 - build - perform the build step on each component

```
ci-4-build.sh
```

Step 5 - test - run the headless tests

```
ci-5-test.sh
```


### Running Python Unit Tests

`cd docker/wct-ram/npm_publish/git/` run `python -m unittest test_commit_parser`
