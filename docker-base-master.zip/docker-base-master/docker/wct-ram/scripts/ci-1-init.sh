#!/bin/bash

#mount a RAM based FS to copy the code to, makes npm install massively faster
#because I/O is now RAM based instead of storage based
mount -t tmpfs -o exec,size=2048m tmpfs /npm/app

#mount had to be done as root, but we want everything else running as 'node'
sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

echo "copying code to RAM!"
rm -rf /npm/app/*
time cp -r . /npm/app/

cd /npm/app

EOF
