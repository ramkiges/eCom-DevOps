#!/bin/bash

sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

cd /npm/app

echo "lerna bootstrap and npm install"
time lerna bootstrap
mkdir -p node_modules/selenium-standalone
ln -sf /npm/lib/node_modules/selenium-standalone/.selenium node_modules/selenium-standalone/.selenium

echo "npm link"
time npm link lerna eslint webpack webpack-cli @web-component-utility/eslint-config-ecom @web-component-utility/web-component-config jest babel-jest

EOF
