#!/usr/bin/env bash

sudo -H -u node bash << EOF
export SONAR_SCANNER_OPTS="-Djavax.net.ssl.trustStore=/usr/local/cacerts"
umask 002

cd /npm/src

sonar-scanner -Dsonar.projectName='$1' -Dsonar.projectDescription='$2' -Dsonar.projectKey='$3' -Dsonar.branch.name='$4' -Dsonar.projectVersion='$5'
EOF
