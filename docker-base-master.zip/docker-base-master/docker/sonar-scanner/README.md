Build and Push

```
   docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/sonar-scanner:4.3.0.2102
   docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/sonar-scanner:4.3.0.2102
```

Usage

```
    docker run -v ${PWD}:/sonar snapshotrepo.wsgc.com/ecommerce-docker-repo/sonar-scanner:4.3.0.2102 sonar-scanner {additional params here}
```
    
You'll need to mount the thing to scan into `/sonar` in the above example, it mounts the current directory

You'll also likely need some additional runtime parameters to be passed into the scanner, for example `-Dsonar.projectKey={unique project id} -Dsonar.exclusions=**/*.class,**/*.java`
