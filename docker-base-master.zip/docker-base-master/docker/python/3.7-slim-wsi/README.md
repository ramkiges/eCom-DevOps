A small addition to the official python 3.7 container to use our pypi repo instead of the public repo.  This allows the use of our internal repo.

`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.7-slim-wsi`

`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.7-slim-wsi`
