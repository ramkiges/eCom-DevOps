Python 3.9-slim, WSI-root-trusting, PIP-configured base image.

Build from root of repo:
```
docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.9-slim-wsi -f docker/python/3.9-slim-wsi/Dockerfile

docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.7-slim-wsi
```
