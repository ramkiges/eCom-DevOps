Flask Python 3.7, WSI-root-trusting, PIP-configured base image.

```
DOCKER_BUILDKIT=0 docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/python-flask:3.7-wsi -f docker/python/flask-3.7-wsi/Dockerfile
```
