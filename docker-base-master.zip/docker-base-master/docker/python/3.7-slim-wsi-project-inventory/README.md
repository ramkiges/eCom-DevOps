A small addition to the WSI python 3.7 container to add some specific packages needed by the Project Inventory project for CI use only.

`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.7-slim-wsi-project-inventory`

`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/python:3.7-slim-wsi-project-inventory`
