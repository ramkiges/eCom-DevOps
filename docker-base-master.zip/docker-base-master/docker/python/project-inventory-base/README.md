A base image which installs external packages into the base image.  The expectation is that the project `Dockerfile` only installs pip packages and uses any `apt` packages provided by this container.  Doing this allows us to build the application container in CI without access to the internet.


`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/project-inventory-base`

`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/project-inventory-base`
