Tomcat 8 Image for Kubernetes used by the tomcat 8 docker file and the DP K8s packages.
The base image `8.0.26.10-DP` for this dockerfile comes from `https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/k8s-tomcat-base/tree/release-8.x`
 
Build and Push Image:
`docker build . -t container-registry01.nonprod.wsgc.com/ecom/tomcat:8.0.26-DP.2 -f docker/k8s-tomcat-dp/Dockerfile`
`docker push container-registry01.nonprod.wsgc.com/ecom/tomcat:8.0.26-DP.2`

**NOTE:**
The base image mentioned above (`8.0.26.10-DP`), is the base image referenced in the `Dockerfile` found in this directory.
It is *not* the same as the the output file intended to be created by building with the "Build and Push Image" instructions.
Despite the extraordinarily confusing similarity of the names, these are two very different images.  Please do not mix them up.
(Repairs to this process are forthcoming.)
