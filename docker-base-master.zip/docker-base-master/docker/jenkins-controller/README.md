Jenkins controller image

Build and Push Image:
`docker build . -t container-registry01.nonprod.wsgc.com/ecom/jenkins-controller:2.401.4-wsi --platform=linux/amd64`
`docker push container-registry01.nonprod.wsgc.com/ecom/jenkins-controller:2.401.4-wsi`
