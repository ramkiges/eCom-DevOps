Trillium app image

Build and Push Image:
`docker build -t container-registry01.nonprod.wsgc.com/edap/trillium:<version> -f docker/trillium/trillium/Dockerfile .`
`docker push container-registry01.nonprod.wsgc.com/edap/trillium:<version>`

Current version published: `16.1.0-wsi`
