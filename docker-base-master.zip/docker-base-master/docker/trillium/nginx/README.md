Trillium nginx image

Build and Push Image:
`docker build -t container-registry01.nonprod.wsgc.com/edap/trillium-nginx:<version> -f docker/trillium/nginx/Dockerfile .`
`docker push container-registry01.nonprod.wsgc.com/edap/trillium-nginx:<version>`

Current version published: `1.20-wsi`
