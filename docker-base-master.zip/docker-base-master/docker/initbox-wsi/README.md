This image was created with the intention to be used only as an init
container image, replacing busybox:1.0 (which has a version of curl
that does not support tls1.2). This image is currently in use in the
gizmos-app-k8s-package as an init container, and contains curl version
7.64 (which supports tlsv1.2) to allow downloading hinoki data
from Artifactory.

v1.1:
* add gpg, for use with spring-boot-chart's GPG key loading facility.
* Update Alpine 3.9 -> 3.13.5
