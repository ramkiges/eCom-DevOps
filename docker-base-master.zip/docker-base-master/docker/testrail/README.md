# dockerfile-testrail
Docker File for TestRail
This repo was created to update the entrypoint script excluding the chown commands performed in the deafult script as well as ovveriding the default Apache port 80 to 8080 to deploy on kubernetes environment.

Build the Image
docker build --no-cache --pull -t container-registry01.nonprod.wsgc.com/ecom/testrail:7.0.2.1016-wsi .

Push the Image
docker push container-registry01.nonprod.wsgc.com/ecom/testrail:7.0.2.1016-wsi 
