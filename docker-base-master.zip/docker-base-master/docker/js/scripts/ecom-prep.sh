#!/bin/bash

# This script allows ecom devs to use the container locally as if they were in CI.
# It combines all stages into a single script that can be run from the command line like:
#  docker run -it --privileged --rm -v "$PWD:/npm/src" snapshotrepo.wsgc.com/ecommerce-docker-repo/wct-ram-jest:latest /usr/local/bin/ecom-test.sh

ci-1-init.sh && ci-1b-swiffer.sh && ci-2-install.sh && ci-3-lint.sh && ci-4-build.sh && ci-5-test.sh
