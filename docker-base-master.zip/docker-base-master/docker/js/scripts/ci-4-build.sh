#!/bin/bash

sudo -H -u node bash << EOF
set -x
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

cd /npm/app

time npm run build-ci

EOF
