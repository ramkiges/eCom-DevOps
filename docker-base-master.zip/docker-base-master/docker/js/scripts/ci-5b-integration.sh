#!/bin/bash
ENV_VARS=$1

#here we are starting the docker service because `/etc/docker/` was not created by the Docker CE package during install
service docker start
sleep 5
echo '{"insecure-registries": ["https://snapshotrepo.wsgc.com"]}' >/etc/docker/daemon.json

service docker restart

sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
if [[ ! -z "$ENV_VARS" ]]; then
    eval "export $ENV_VARS"
fi
umask 002

cd /npm/app

echo "npm run test-integration-ci"
time npm run test-integration-ci
EOF
