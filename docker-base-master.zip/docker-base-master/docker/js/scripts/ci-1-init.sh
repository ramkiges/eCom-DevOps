#!/bin/bash

echo "starting ci-1-init.sh"

# mount a RAM based FS to copy the code to, makes npm install massively faster
# because I/O is now RAM based instead of storage based
# only mount if the mount does not exist (makes this script re-entrant for dev workflow)
[ ! -d "/npm/app" ] && mount -t tmpfs -o exec,size=2048m tmpfs /npm/app || echo "last exit code $?"

echo "after tmpfs mount"

# mount had to be done as root, but we want everything else running as 'node'
sudo -H -u node bash << EOF
umask 002

echo "copying code to RAM!"
rm -rf /npm/app/*
time cp -r . /npm/app/ && echo "disk space: " && du -sm .

cd /npm/app

EOF
