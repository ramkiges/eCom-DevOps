#!/bin/bash

# This script allows ecom devs to use the container locally as if they were in CI.
# For a fast turnaround, we rsync the source code from the host, and then run the unit tests. 

sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

echo "syncing code to RAM"
time rsync -av --delete --exclude node_modules /npm/src/ /npm/app

cd /npm/app

echo "npm run test-ci"
time npm run test-ci "$@"

EOF
