#!/bin/bash
ENV_VARS=$1

sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
if [[ ! -z "$ENV_VARS" ]]; then
    eval "export $ENV_VARS"
fi
umask 002

cd /npm/app

echo "npm run test-component-ci"
time npm run test-component-ci
EOF
