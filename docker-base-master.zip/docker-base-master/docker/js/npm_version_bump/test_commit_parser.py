""" Unit tests for npm publish class """
import unittest
from commit_parser import CommitParser


class CommitParserTestCase(unittest.TestCase):
    """ Unit tests for the npm publish class """

    def test_parse_change_severity_tah_1063_minor(self):
        """ this test reproduces TAH-1063 so that we can confirm it's fixed """
        f = open("tah_1063_minor_git_log.txt")
        commit_lines = f.readlines()
        f.close()
        commit_parser = CommitParser(commit_lines)
        severity = commit_parser.parse_change_severity()
        self.assertEqual(severity, "minor")


    def test_parse_change_severity_tah_1063_patch(self):
        """ This tests that commits with only patches are captured correctly """
        f = open("tah_1063_patch_git_log.txt")
        commit_lines = f.readlines()
        f.close()
        commit_parser = CommitParser(commit_lines)
        severity = commit_parser.parse_change_severity()
        self.assertEqual(severity, "patch")


    def test_parse_change_severity_tah_1063_major(self):
        """ This tests that commits with multiple levels are captured correctly """
        f = open("tah_1063_major_git_log.txt")
        commit_lines = f.readlines()
        f.close()
        commit_parser = CommitParser(commit_lines)
        severity = commit_parser.parse_change_severity()
        self.assertEqual(severity, "major")
