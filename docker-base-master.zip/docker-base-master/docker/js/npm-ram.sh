#!/bin/bash

mount -t tmpfs -o exec,size=2048m tmpfs /app
sudo -u node /usr/local/bin/ci.sh
