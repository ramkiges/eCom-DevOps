#!/bin/bash

sudo -H -u node bash << EOF
set -x
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

cd /npm/app

time npm link jest @js-ecom-build/eslint-config-base @js-ecom-build/prettier-config-base eslint-config-prettier eslint-plugin-prettier eslint-plugin-jest eslint-plugin-no-only-tests eslint-plugin-vue

time npm run lint-ci
EOF
