#!/bin/bash

sudo -H -u node bash << EOF
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

cd /npm/app

echo "swiffer"
time swiffer .
EOF
