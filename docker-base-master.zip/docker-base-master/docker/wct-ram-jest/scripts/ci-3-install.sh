#!/bin/bash

sudo -H -u node bash << EOF
set -x
export PATH=/npm/bin:/npm/app/node_modules/.bin:$PATH
umask 002

cd /npm/app

time lerna bootstrap

time npm link lerna eslint jest @babel/runtime @js-ecom-build/babel-preset-ecom @js-ecom-build/ecom-scripts @js-ecom-build/jest-preset-ecom @js-ecom-build/jest-environment-web-components @web-component-utility/web-component-config babel-jest babel-loader css-loader node-sass postcss postcss-loader puppeteer regenerator-runtime sass-loader webpack webpack-cli jest-sonar-reporter vue-jest vue-template-compiler

EOF
