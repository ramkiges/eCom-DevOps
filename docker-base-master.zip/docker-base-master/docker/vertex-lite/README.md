Packaging for the Vertex Lite application.

`docker build . -t container-registry01.nonprod.wsgc.com/ecom/vertex-lite:1.0.0`

`docker push container-registry01.nonprod.wsgc.com/ecom/vertex-lite:1.0.0`
