#!/bin/bash
responseTimeThreshold=0.05
totalNumberOfRequestFiles=$(ls request*xml | wc -l)
responseTime=0
exit=false
maxNumberOfRequests=50
url="$1/pricing/initial"

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 https://pricing-qa1-rk1v.wsgc.com"
    echo "Usage: $0 https://localhost:8080"
    exit 1
fi

# CURLing initialOrderPricingRequests
# Script terminates either when it reaches max number of requests or
# when the average response time is less than the threshold response time
while true; do
    totalTime=0
    # 15 Initial Order Pricing Requests
    for i in {1..15}; do
        responseTime=$(curl -k -o /dev/null -s -w %{time_total}\\n -X POST $url -H 'Accept: application/xml' -H 'Content-Type: application/xml' -d "@request$i.xml")
        count=$((count + 1))
        totalNumberOfRequests=$((totalNumberOfRequests + 1))
        totalTime=$(echo $totalTime + $responseTime | bc)
        echo "Request#$count RespnseTime:$responseTime"

        # exit when it reaches max number of requests
        if [ $count -eq $maxNumberOfRequests -o $count -gt $maxNumberOfRequests ]; then
            exit=true
            break
        fi
    done

    totalTime=$(echo "scale=2; $totalTime / $totalNumberOfRequestFiles" | bc)
    echo "Average ${totalTime}"
    echo "Threshold ${responseTimeThreshold}"

    if (($(echo "$totalTime < $responseTimeThreshold" | bc))) || [ "$exit" = true ]; then
        break;
    fi
done
