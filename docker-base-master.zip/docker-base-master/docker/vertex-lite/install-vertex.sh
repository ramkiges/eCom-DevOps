#!/bin/sh

# application name
APP=vertex-lite

# various variables
INSTALL_JAR=vertex-o-series-pos-install-9.0.0.0.327.jar
PATCH_JAR=vertex-o-series-pos-patch-9.0.11.2.6.jar 
INSTALL_CFG=/etc/wsgc/vertex-lite/config/application.properties
INSTALL_DIR=/apps/$APP
CACHE_WARMUP=$INSTALL_DIR/cache-warmup

# run the installer
# the installer creates the tomcat directory structure within the installation directory
java -jar $INSTALL_JAR -f $INSTALL_CFG
if [ $? -ne 0 ]
then
	echo "Something went wrong while running the installer..."
	exit 1
fi

# copy these so we can have a record of what we installed
cp $PATCH_JAR $INSTALL_JAR $INSTALL_DIR

# copy the patch jar
cp $PATCH_JAR $INSTALL_DIR/patch

find $INSTALL_DIR -name "*.sh" -exec chmod 755 {} \;

# install our custom server.xml & logging properties
cp config/server.xml $INSTALL_DIR/tomcat/conf
cp config/logging.properties $INSTALL_DIR/tomcat/conf
cp /etc/wsgc/vertex-lite/log4j2.xml $INSTALL_DIR/tomcat/lib/log4j2.xml
cp /etc/wsgc/vertex-lite/log4j.properties $INSTALL_DIR/tomcat/lib/log4j.properties

# copy cache warmup scripts and xml files
mkdir -p $CACHE_WARMUP
cp cache-warmup/* $CACHE_WARMUP

# install patch
echo "Installing patch"
cd $INSTALL_DIR/patch
java -jar $PATCH_JAR

echo "Setting WSI-specific parameters in vertex.cfg"
cat /etc/wsgc/vertex-lite/config/additional-vertex-cfg.properties >> $INSTALL_DIR/config/vertex.cfg

# copy the latest tax extract zip already placed by init container at that path
cp /mnt/data-extract-dir/*.zip $INSTALL_DIR/data/taxdata/

# run the cache-warmup scripts in background after letting the tomcat start
sleep 90 && cd $CACHE_WARMUP && ./initialPricingRequest.sh https://$(hostname --fqdn) 2>&1 &
$INSTALL_DIR/tomcat/bin/catalina.sh run
