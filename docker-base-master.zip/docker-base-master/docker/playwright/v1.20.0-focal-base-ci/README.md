# playwright-v1.20.0-focal-base-ci
A playwright container for use in CI builds.  

This configures the user in the container as the Jenkins uid/gid and adds our NPM repo configurations
The node version is configurable via and build arg.

The base image for this Dockerfile is Playwright official image which has playwright version 1.20 and Ubuntu 20.04.
```
mcr.microsoft.com/playwright:v1.20.0-focal
```

## Node 12

Build and run locally for testing

    docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node12-base-ci --build-arg NODE_VERSION=12.14
        
    docker run -it -v ${PWD}:/app -w /app --rm snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node12-base-ci bash

Push image to private docker repo
```
docker login snapshotrepo.wsgc.com

user: wsgc-docker-user
pwd: 

docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node12-base-ci
```

## Node 14

Build and run locally for testing

    docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node14-base-ci --build-arg NODE_VERSION=14.19
        
    docker run -it -v ${PWD}:/app -w /app --rm snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node14-base-ci bash

Push image to private docker repo
```
docker login snapshotrepo.wsgc.com 

user: wsgc-docker-user
pwd: 

docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node14-base-ci
```

## Node 16

Build and run locally for testing

    docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node16-base-ci --build-arg NODE_VERSION=16.14
        
    docker run -it -v ${PWD}:/app -w /app --rm snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node16-base-ci bash

Push image to private docker repo
```
docker login snapshotrepo.wsgc.com

user: wsgc-docker-user
pwd: 

docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node16-base-ci
```

## Node 18

Build and run locally for testing

    docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node18-base-ci --build-arg NODE_VERSION=18.14
        
    docker run -it -v ${PWD}:/app -w /app --rm snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node18-base-ci bash

Push image to private docker repo
```
docker login snapshotrepo.wsgc.com

user: wsgc-docker-user
pwd: 

docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/playwright:v1.20.0-focal-node18-base-ci
```
