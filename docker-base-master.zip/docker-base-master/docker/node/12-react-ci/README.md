A docker container which adds some required dependencies needed for running React CD pipelines in CI

    docker build . -t container-registry01.nonprod.wsgc.com/ecom/node:12.14-ci
    docker push container-registry01.nonprod.wsgc.com/ecom/node:12.14-ci
