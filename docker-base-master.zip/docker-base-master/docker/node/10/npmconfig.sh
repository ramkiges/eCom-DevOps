#!/bin/bash

if [[ "$BUILD_BRANCH" =~ "release" && "$GIT_URL" =~ "Bedrock" ]] 
then
    npm set registry https://npmrepo.wsgc.com/repository/wsgc-npm/ -g
    npm set sass_binary_site=https://npmrepo.wsgc.com/repository/wsgc-raw-local/ -g
else
    npm set registry https://npmrepo-dev.wsgc.com/repository/wsgc-npm/ -g
    npm set sass_binary_site=https://npmrepo-dev.wsgc.com/repository/wsgc-raw-local/ -g
fi
