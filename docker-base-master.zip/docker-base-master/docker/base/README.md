Centos base image

Build and Push Image:
`docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/wsgc/centos7:base -f docker/base/Dockerfile`
`docker push snapshotrepo.wsgc.com/ecommerce-docker-repo/centos7:base`
