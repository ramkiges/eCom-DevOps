<%
def myList = ["kilimanjaro", "KILIMANJARO", "lohtse", "LHOTSIE", "marcy", "MARCY", "eqa", "EQA", "denali", "DENALI", "manaloa", "MANALOA",  "meru", "MERU", "makalu", "MAKALU", "whitney", "WHITNEY", "matterhorn", "MATTERHORN", "enterprise", "ENTERPRISE", "annapurna", "ANNAPURNA", "hood", "HOOD"];
def buildEnv = build.envVars.BUILD_URL
def emailText = ''

changeSet = build.changeSet
def items = changeSet.getItems()

    if(items != null)
      {
        for (item in myList) {

             def result = items[0].msg.matches("(.*)${item}(.*)")
               if (result)
              {
		emailText = affinityEmail(item)
		println emailText
		break
              }
          }
      }
     else
      {
	 for (item in myList) {

             def result = buildEnv.matches("(.*)${item}(.*)")
               if (result)
              {
                emailText = affinityEmail(item)
                println emailText
                break
              }
          }
      }

def affinityEmail(value){
	def email = ""

	switch (value){

	case ["kilimanjaro"]:
	email = "eComKilimanjaro@WSGC.com"
	break

	case ["KILIMANJARO"]:
	email = "ecomKilimanjaro@wsgc.com"
	break

	case ["manaloa"]:
	email = "eComMaunaLoa@WSGC.com"
	break

	case ["MANALOA"]:
	email = "ecommaunaloa@wsgc.com"
	break

	case ["denali"]:
	email = "eComdenali@WSGC.com"
	break

	case ["DENALI"]:
	email = "eComdenali@wsgc.com"
	break

	case ["meru"]:
	email = "eCommmeru@WSGC.com"
	break

	case ["MERU"]:
	email = "eCommeru@wsgc.com"
	break

	case ["makalu"]:
	email = "eComMakalu@WSGC.com"
	break

	case ["MAKALU"]:
	email = "ecomMakalu@wsgc.com"
	break

	case ["whitney"]:
	email = "eComWhitney@WSGC.com"
	break

	case ["WHITNEY"]:
	email = "eComWhitney@wsgc.com"
	break

	case ["matterhorn"]:
	email = "eComMatterhorn@WSGC.com"
	break

	case ["MATTERHORN"]:
	email = "eComMatterhorn@wsgc.com"
	break

	case ["k2"]:
	email = "eComK2@WSGC.com"
	break

	case ["K2"]:
	email = "eComK2@wsgc.com"
	break

	case ["shasta"]:
	email = "eComShasta@WSGC.com"
	break

	case ["SHASTA"]:
	email = "eComShasta@wsgc.com"
	break

	case ["annapurna"]:
	email = "eComAnnapurna@WSGC.com"
	break

	case ["ANNAPURNA"]:
	email = "eComAnnapurna@wsgc.com"
	break

	case ["marcy"]:
	email = "eComMarcy2@WSGC.com"
	break

	case ["MARCY"]:
	email = "eComMarcy@wsgc.com"
	break

	case ["lhotsie"]:
	email = "ecomlhotse@wsgc.com"
	break

	case ["LHOTSIE"]:
	email = "eComlhotsie@wsgc.com"
	break

	case ["hood"]:
	email = "ecomhood@wsgc.com"
	break

	case ["HOOD"]:
	email = "ecomhood@wsgc.com"
	break

}
}
%>
