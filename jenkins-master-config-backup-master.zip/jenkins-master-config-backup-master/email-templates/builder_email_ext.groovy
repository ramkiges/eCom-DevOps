<STYLE>
BODY, TABLE, TD, TH, P {
  font-family:Verdana,Helvetica,sans serif;
  font-size:11px;
  color:black;
}
h1 { color:black; }
h2 { color:black; }
h3 { color:black; }
TD.bg1 { color:white; background-color:#0000C0; font-size:120% }
TD.bg2 { color:white; background-color:#4040FF; font-size:110% }
TD.bg3 { color:white; background-color:#8080FF; }
TD.test_passed { color:blue; }
TD.test_failed { color:red; }
TD.console { font-family:Courier New; }
</STYLE>
<BODY>
<%
   def depoyersText = ""
   buildEnv = build.envVars.BUILD_URL
   def myList = ["kilimanjaro", "lohtse", "marcy", "eqa", "denali", "manaloa", "meru", "makalu", "whitney", "matterhorn", "enterprise", "annapurna"];

	for (item in myList) {

             def result = buildEnv.matches("(.*)${item}(.*)")
             deployersText = deployers(item)
               if (result)
               {
                  deployersText
		  break
               }
        }
%>
<TABLE>
  <TR><TD align="right"><IMG SRC="${rooturl}static/e59dfe28/images/32x32/<%= build.result.toString() == 'SUCCESS' ? "blue.gif" : build.result.toString() == 'FAILURE' ? 'red.gif' : 'yellow.gif' %>" />
  </TD><TD valign="center"><B style="font-size: 200%;">BUILD ${build.result}</B></TD></TR>
  <TR><TD>URL</TD><TD><A href="${rooturl}${build.url}">${rooturl}${build.url}</A></TD></TR>
  <TR><TD>Project:</TD><TD>${project.name}</TD></TR>
  <TR><TD>Date:</TD><TD>${it.timestampString}</TD></TR>
  <TR><TD>Duration:</TD><TD>${build.durationString}</TD></TR>
  <TR><TD>Deployers:</TD><TD>${deployersText}</TD></TR>
  <TR><TD>Cause:</TD><TD><% build.causes.each() { cause -> %> ${cause.shortDescription} <%  } %></TD></TR>
</TABLE>
<BR/>
<% def deployers(value){

      def URL = ''
      def URL2 = ''
      def URL3 = ''

	switch (value) {
            case ["manaloa"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa1-deployers" target="_blank"> Trigger QA1 Deployers </a>'
                break
            case ["denali"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa2-deployers" target="_blank"> Trigger QA2 Deployers </a>'
                break
            case ["meru"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa3-deployers"> Trigger QA3 Deployers </a>'
                break
            case ["makalu"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa4-deployers" target="_blank"> Trigger QA4 Deployers </a>'
                break
            case ["whitney"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa5-deployers" target="_blank"> Trigger QA5 Deployers </a>'
                break
            case ["kilimanjaro"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa6-deployers" target="_blank"> Trigger QA6 Deployers </a>'
                break
            case ["matterhorn"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa7-deployers" target="_blank"> Trigger QA7 Deployers </a>'
                URL2 = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa8-deployers" target="_blank"> Trigger QA8 Deployers </a>'
                URL3 = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa11-deployers" target="_blank"> Trigger QA11 Deployers </a>'
                break
            case ["makalu"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa9-deployers" target="_blank"> Trigger QA9 Deployers </a>'
                break
            case ["enterprise"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa10-deployers" target="_blank"> Trigger QA10 Deployers </a>'
                break
            case ["k2"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa12-deployers" target="_blank"> Trigger QA12 Deployers </a>'
                break
             case ["shasta"]:
                URL = '<a href="https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa13-deployers" target="_blank"> Trigger QA13 Deployers </a>'
                break
            case ["annapurna"]:
                URL = '<a href "https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa14-deployers" target="_blank"> Trigger QA14 Deployers </a>'
                break
            case ["eqa"]:
                URL = '<a href "https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa15-deployers" target="_blank"> Trigger QA15 Deployers </a>'
                break
            case ["marcy"]:
                URL = '<a href "https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa16-deployers" target="_blank"> Trigger QA16 Deployers </a>'
                break
            case ["lhotsie"]:
                URL = '<a href "https://ecombuild.wsgc.com/jenkins/job/trigger-all-qa17-deployers" target="_blank"> Trigger QA17 Deployers'
                break
            default:
                URL = ''
        }

	if(URL != '')
	      messageContent = URL;
           if(URL2 != '')
	      messageContent += "\n" + URL2;
 	   if(URL3 != '')
	      messageContent += "\n" + URL3;

	   deployersText  = (messageContent);

}
%>

<!-- CHANGE SET -->
<% def changeSet = build.changeSet
if(changeSet != null) {
	def hadChanges = false %>
	<TABLE width="100%">
    <TR><TD class="bg1" colspan="2"><B>CHANGES</B></TD></TR>
<% 	changeSet.each() { cs ->
		hadChanges = true %>
      <TR>
        <TD colspan="2" class="bg2">&nbsp;&nbsp;Revision <B><%= cs.metaClass.hasProperty('commitId') ? cs.commitId : cs.metaClass.hasProperty('revision') ? cs.revision :
        cs.metaClass.hasProperty('changeNumber') ? cs.changeNumber : "" %></B> by
          <B><%= cs.author %>: </B>
          <B>(${cs.msgAnnotated})</B>
         </TD>
      </TR>
<%		cs.affectedFiles.each() { p -> %>
        <TR>
          <TD width="10%">&nbsp;&nbsp;${p.editType.name}</TD>
          <TD>${p.path}</TD>
        </TR>
<%		}
	}

	if(!hadChanges) { %>
        <TR><TD colspan="2">No Changes</TD></TR>
<%	} %>
  </TABLE>
<BR/>
<% } %>

<!-- ARTIFACTS -->
<% def artifacts = build.artifacts
if(artifacts != null && artifacts.size() > 0) { %>
  <TABLE width="100%">
    <TR><TD class="bg1"><B>BUILD ARTIFACTS</B></TD></TR>
    <TR>
      <TD>
<% 		artifacts.each() { f -> %>
      	  <li>
      	    <a href="${rooturl}${build.url}artifact/${f}">${f}</a>
      	  </li>
<%		} %>
      </TD>
    </TR>
  </TABLE>
<BR/>
<% } %>

<!-- MAVEN ARTIFACTS -->
<%
try {
  def mbuilds = build.moduleBuilds
  if(mbuilds != null) { %>
  <TABLE width="100%">
      <TR><TD class="bg1"><B>BUILD ARTIFACTS</B></TD></TR>
<%
    try {
        mbuilds.each() { m -> %>
        <TR><TD class="bg2"><B>${m.key.displayName}</B></TD></TR>
<%		m.value.each() { mvnbld ->
			def artifactz = mvnbld.artifacts
			if(artifactz != null && artifactz.size() > 0) { %>
      <TR>
        <TD>
<%				artifactz.each() { f -> %>
      	    <li>
      	      <a href="${rooturl}${mvnbld.url}artifact/${f}">${f}</a>
      	    </li>
<%				} %>
      	</TD>
      </TR>
<%			}
		}
       }
    } catch(e) {
	// we don't do anything
    }  %>
  </TABLE>
<BR/>
<% }

}catch(e) {
	// we don't do anything
}
%>

<!-- JUnit TEMPLATE -->

<% def junitResultList = it.JUnitTestResult
try {
 def cucumberTestResultAction = it.getAction("org.jenkinsci.plugins.cucumber.jsontestsupport.CucumberTestResultAction")
 junitResultList.add(cucumberTestResultAction.getResult())
} catch(e) {
        //cucumberTestResultAction not exist in this build
}
if (junitResultList.size() > 0) { %>
 <TABLE width="100%">
 <TR><TD class="bg1" colspan="2"><B>${junitResultList.first().displayName}</B></TD></TR>
 <% junitResultList.each{
  junitResult -> %>
     <% junitResult.getChildren().each { packageResult -> %>
        <TR><TD class="bg2" colspan="2"> Name: ${packageResult.getName()} Failed: ${packageResult.getFailCount()} test(s), Passed: ${packageResult.getPassCount()} test(s), Skipped: ${packageResult.getSkipCount()} test(s), Total: ${packageResult.getPassCount()+packageResult.getFailCount()+packageResult.getSkipCount()} test(s)</TD></TR>
        <% packageResult.getFailedTests().each{ failed_test -> %>
          <TR bgcolor="white"><TD class="test_failed" colspan="2"><B><li>Failed: ${failed_test.getFullName()} </li></B></TD></TR>
        <% }
      }
 } %>
 </TABLE>
 <BR/>
<%
} %>

<!-- CONSOLE OUTPUT -->
<% if(build.result==hudson.model.Result.FAILURE) { %>
<TABLE width="100%" cellpadding="0" cellspacing="0">
<TR><TD class="bg1"><B>CONSOLE OUTPUT</B></TD></TR>
<% 	build.getLog(100).each() { line -> %>
	<TR><TD class="console">${org.apache.commons.lang.StringEscapeUtils.escapeHtml(line)}</TD></TR>
<% 	} %>
</TABLE>
<BR/>
<% } %>

</BODY>
