<%
def myList = ["kilimanjaro", "lohtse", "marcy", "eqa", "denali", "manaloa", "meru", "makalu", "whitney", "matterhorn", "enterprose", "annapurna", "k2"];
def buildEnv = build.envVars.BUILD_URL
def emailText = ''
        for (item in myList) {

             def result = buildEnv.matches("(.*)${item}(.*)")
               if (result)
               {
		emailText = affinityEmail(item)
		println emailText
		break
               }
        }


def affinityEmail(value){
	def email = ""

	switch (value){

	case ["kilimanjaro"]:
	email = "eComKilimanjaro@WSGC.com"
	break

	case ["manaloa"]:
	email = "eComMaunaLoa@WSGC.com"
	break

	case ["denali"]:
	email = "eComdenali@WSGC.com"
	break

	case ["meru"]:
	email = "eCommmeru@WSGC.com"
	break


	case ["makalu"]:
	email = "eComMakalu@WSGC.com"
	break

	case ["whitney"]:
	email = "eComWhitney@WSGC.com"
	break

	case ["matterhorn"]:
	email = "eComMatterhorn@WSGC.com"
	break

	case ["k2"]:
	email = "eComK2@WSGC.com"
	break

	case ["shasta"]:
	email = "eComShasta@WSGC.com"
	break

	case ["annapurna"]:
	email = "eComAnnapurna@WSGC.com"
	break

	case ["marcy"]:
	email = "eComMarcy2@WSGC.com"
	break

	case ["lhotsie"]:
	email = "ecomlhotse@wsgc.com"
	break
}
}
%>
