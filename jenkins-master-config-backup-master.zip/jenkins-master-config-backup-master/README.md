# jenkins-master-config-backup
Automated periodic backups of the Jenkins configs on the master Jenkins box
