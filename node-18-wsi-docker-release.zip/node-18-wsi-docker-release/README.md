# node-18-wsi-docker
A base image for deploying Node projects using Node 18

## Building

This must be built outside Jenkins, with, e.g.:
```shell
docker build --no-cache --pull -t container-registry01.nonprod.wsgc.com/ecom/node-18-wsi:my-tag .
```
and manually pushed.
