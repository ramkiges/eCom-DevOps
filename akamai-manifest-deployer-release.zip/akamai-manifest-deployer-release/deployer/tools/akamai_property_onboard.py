#!/usr/bin/env python3
"""
Script for parisng akamai configs ( Microservice_shop.json and recommendations_service.json ).
Script exports two akamai properties via docker akamai image ( prod and qa ).
PROD values are used as common values and will be stored in a common allenv manifest.
QA akamai config files are parsed, and path values are compared with common values.

The script creates a new microservice and recommendations-service configs with a new structure ( one rule for one env ) and 
saves them to the provided akamai-manifest-deployer directory in with accordance the accepted structure for the deployer.
The script generates manifests for all envs that were found in the microservice or recommendations-service configs and exports manifests to provided `akamai_manifest_path`.

Script stores all gathered env-specific information in a temporary `intermediate_hostname_info` dictionary.
You can export that dictionary to a json file for better understanding and check what is inside by adding 
the following code snippet to the different steps of if `__name__ == "__main__":` part:

    utils.export_json(json_filepath = 'microservice_intermediate_hostname_info.json',
                      body = microservice_intermediate_hostname_info,
                      indent = 2)

    utils.export_json(json_filepath = 'recommend_intermediate_hostname_info.json',
                      body = recommend_intermediate_hostname_info,
                      indent = 2)

For checking common PROD values you can use:

    utils.export_json(json_filepath = 'common_microservice_matches.json',
                      body = [common_microservice_matches, common_microservice_not_match],
                      indent = 2)

In addition, the microservice filename will be renamed from `microservice_original_config_name` to `microservice_desired_config_name`.  
The "include" section in `main.json` will be updated.

Example run:
python3 deployer/tools/akamai_property_onboard.py \
    --akamai_edgerc_path ***/.edgerc \
    --brand_name mg \
    --akamai_manifest_path ***/akamai-manifest/manifest \
    --akamai_manifest_deployer_path ***/akamai-manifest-deployer/deployer
"""
import argparse
import utils                          # Shared functions without binding to the current context
import populate_single_brand_allenv   # Populate data from newly created manifests 
import akamai_utils                   # Shared functions for processing data to/from akamai configs and manifests
import shutil
import os
import sys
import hcl2
import json
            

def rename_akamai_property_snippet(snippets_path: str, original_config_possible_names: list, desired_snippet_name: str):
    snippets_file_list = []
    snippets_file_list = os.listdir(snippets_path)
    found_snippets = []
    for original_config_name in original_config_possible_names:
        if f'{original_config_name}.json' in snippets_file_list:
            found_snippets.append(original_config_name)

    if len(found_snippets) == 0:
        print(f'ERROR: None of {original_config_possible_names} were found in {snippets_path}')
        sys.exit(1)
    elif len(found_snippets) > 1:
        "Combine snippets and rename if more than one snippet is found"
        for snippets_num, snippet_name in enumerate(found_snippets):
            if snippets_num == 0:
                snippet_body = utils.import_json(json_filepath = f'{snippets_path}/{snippet_name}.json')
            else:
                snippet_body_add = utils.import_json(json_filepath = f'{snippets_path}/{snippet_name}.json')
                snippet_body["children"] = snippet_body["children"] + snippet_body_add["children"]
        snippet_body["name"] = desired_snippet_name
        utils.export_json(json_filepath=f'{snippets_path}/{desired_snippet_name}.json', 
                          body = snippet_body, 
                          indent = 2)
    elif len(found_snippets) == 1:
        "Rename snippet"
        snippet_body = utils.import_json(json_filepath = f'{snippets_path}/{found_snippets[0]}.json')
        snippet_body["name"] = desired_snippet_name
        utils.export_json(json_filepath=f'{snippets_path}/{desired_snippet_name}.json', 
                          body = snippet_body, 
                          indent = 2)
    "Rename snippet link in main.json"
    main_body = utils.import_json(json_filepath = f'{snippets_path}/main.json')
    for rule_key, rule_value in main_body["rules"].items():
        if rule_key == "children":
            for found_snippet in found_snippets:
                if f"#include:{found_snippet}.json" in rule_value:
                    rule_value.remove(f"#include:{found_snippet}.json")
            rule_value.append(f"#include:{desired_snippet_name}.json")
    utils.export_json(json_filepath=f'{snippets_path}/main.json', 
                      body = main_body, 
                      indent = 2)
    "Remove needless snippets"
    for snippet_name in found_snippets:
        if snippet_name != desired_snippet_name:
            os.remove(f'{snippets_path}/{snippet_name}.json')


def main(akamai_edgerc_path: str, brand_name: str, akamai_manifest_path: str, akamai_manifest_deployer_path: str):

    microservice_manifest_filename = "microservice.json"
    microservice_common_manifest_filename = "microservice.json"
    microservice_intermediate_hostname_info = {}

    recommend_manifest_filename = "recommend-service.json"
    recommend_common_manifest_filename = "recommend-service.json"
    recommend_intermediate_hostname_info = {}


    """
    Get property names for QA and USA/CAN PROD.
    Check if USA and CAN markets are present for the requested brand.
    """
    nonprod_property_name = ""
    prod_usa_property_name = ""
    prod_can_property_name = ""

    prod_usa_property_exists = False
    prod_can_property_exists = False

    nonprod_property_name = akamai_utils.get_proprety_name_from_mapping(market_name="USA", 
                                                                        brand_name=brand_name,
                                                                        env_type = "QA")
    prod_usa_property_name = akamai_utils.get_proprety_name_from_mapping(market_name="USA", 
                                                                        brand_name=brand_name,
                                                                        env_type = "PROD")
    prod_can_property_name = akamai_utils.get_proprety_name_from_mapping(market_name="CAN", 
                                                                        brand_name=brand_name,
                                                                        env_type = "PROD")

    if prod_usa_property_name:
          prod_usa_property_exists = True
    if prod_can_property_name:
          prod_can_property_exists = True


    """
    Exports properties (QA and USA/CAN PROD) from akamai API.
    """
    docker_export_dir = ".docker_tmp_"

    nonprod_microservice_config_path = ""
    nonprod_recommend_config_path = ""

    prod_usa_microservice_config_path = ""
    prod_usa_recommend_config_path = ""

    prod_can_microservice_config_path = ""
    prod_can_recommend_config_path = ""

    microservice_config_name = 'Microservice_shop'
    recommend_config_name = 'recommendations_service'

    nonprod_microservice_config_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets/{microservice_config_name}.json'
    nonprod_recommend_config_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets/{recommend_config_name}.json'

    if prod_usa_property_exists:
        prod_usa_microservice_config_path = f'{docker_export_dir}/{prod_usa_property_name}/property-snippets/{microservice_config_name}.json'
        prod_usa_recommend_config_path = f'{docker_export_dir}/{prod_usa_property_name}/property-snippets/{recommend_config_name}.json'

    if prod_can_property_exists:
        prod_can_microservice_config_path = f'{docker_export_dir}/{prod_can_property_name}/property-snippets/{microservice_config_name}.json'
        prod_can_recommend_config_path = f'{docker_export_dir}/{prod_can_property_name}/property-snippets/{recommend_config_name}.json'

    akamai_utils.dump_akamai_property(akamai_property_name = nonprod_property_name,
                                      akamai_edgerc_path = akamai_edgerc_path,
                                      export_path = docker_export_dir)

    if prod_usa_property_exists:
        akamai_utils.dump_akamai_property(akamai_property_name = prod_usa_property_name,
                                          akamai_edgerc_path = akamai_edgerc_path,
                                          export_path = docker_export_dir)
    if prod_can_property_exists:
        akamai_utils.dump_akamai_property(akamai_property_name = prod_can_property_name,
                                          akamai_edgerc_path = akamai_edgerc_path,
                                          export_path = docker_export_dir)

    """
    Rename akamai configs.
    """
    microservice_config_possible_names = [
        'Microservice_shop',
        'Microservice__shop__',
        'Microservice_Frontend',
        'Microservice_GMTP_CAN___shop__'
    ]

    recommend_config_possible_names = [
        'recommendation_service',
        'recommendations_service',
        'Recommendations_service',
        'recommendation_services'
    ]

    rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets', 
                                  original_config_possible_names=microservice_config_possible_names, 
                                  desired_snippet_name=microservice_config_name)
    rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets', 
                                  original_config_possible_names=recommend_config_possible_names, 
                                  desired_snippet_name=recommend_config_name)
    if prod_usa_property_exists:
        rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{prod_usa_property_name}/property-snippets', 
                                      original_config_possible_names=microservice_config_possible_names, 
                                      desired_snippet_name=microservice_config_name)
        rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{prod_usa_property_name}/property-snippets', 
                                      original_config_possible_names=recommend_config_possible_names, 
                                      desired_snippet_name=recommend_config_name)

    if prod_can_property_exists:
        rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{prod_can_property_name}/property-snippets', 
                                      original_config_possible_names=microservice_config_possible_names, 
                                      desired_snippet_name=microservice_config_name)
        rename_akamai_property_snippet(snippets_path = f'{docker_export_dir}/{prod_can_property_name}/property-snippets', 
                                      original_config_possible_names=recommend_config_possible_names, 
                                      desired_snippet_name=recommend_config_name)     


    """
    Import akamai configs.
    """
    nonprod_microservice_config_body = {}
    nonprod_recommend_config_body = {}

    prod_usa_microservice_config_body = None
    prod_usa_recommend_config_body = None

    prod_can_microservice_config_body = None
    prod_can_recommend_config_body = None

    nonprod_microservice_config_body = utils.import_json(json_filepath = nonprod_microservice_config_path)
    nonprod_recommend_config_body = utils.import_json(json_filepath = nonprod_recommend_config_path)

    if prod_usa_property_exists:
        prod_usa_microservice_config_body = utils.import_json(json_filepath = prod_usa_microservice_config_path)
        prod_usa_recommend_config_body = utils.import_json(json_filepath = prod_usa_recommend_config_path)

    if prod_can_property_exists:
        prod_can_microservice_config_body = utils.import_json(json_filepath = prod_can_microservice_config_path)
        prod_can_recommend_config_body = utils.import_json(json_filepath = prod_can_recommend_config_path)


    """
    Copy terraform files and property-snippets to deployer.
    """
    nonprod_exported_path = f'{docker_export_dir}/{nonprod_property_name}/'
    nonprod_exported_files = utils.get_nested_files(nonprod_exported_path)

    utils.init_directory_path(directory_path = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/property-snippets')

    for file_path in nonprod_exported_files:
        if ("property-snippets" in file_path):
            """
            Gets filename from path:
            `.docker_tmp_/qa.markandgraham.com_pm/property-snippets/enable_OPTIONS.json` ---> `enable_OPTIONS.json`
            """
            filename = file_path.split('/')[-1]
            shutil.copy2(file_path, f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/property-snippets/{filename}')
        elif (".tf" in file_path):
            """
            Gets filename from path:
            `.docker_tmp_/qa.westelm.com_pm/variables.tf` ---> `variables.tf`
            """
            filename = os.path.basename(file_path)
            if filename == 'property.tf':
                tf_imported = {}

                with open(file_path, 'r') as file:
                    tf_imported = hcl2.load(file)
                with open(f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/{filename}.json', 'w') as file:
                    file.write(json.dumps(tf_imported, indent=2))
            else:
                shutil.copy2(file_path, f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/{filename}')       


    """
    Update terraform files.
    """
    tf_custom_varibales_file = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/custom-varibales.tf'
    ft_note_variable = '''variable "note" {\n  type    = string\n  default = ""\n}'''
    ft_request_limit_variable = '''variable "request_limit" {\n  type    = number\n  default = "1"\n}'''

    tf_override_file = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/override.tf'
    ft_override_provider_akamai = '''provider "akamai" {\n  request_limit = "${var.request_limit}"\n}'''
    nonprod_property_name_tf_style = nonprod_property_name.replace('.', '-')
    ft_override_resource_activation = '''resource "akamai_property_activation" ''' + f'"{nonprod_property_name_tf_style}"' + ''' {\n  note          = "${var.note}"\n}'''

    with open(f'{tf_custom_varibales_file}', 'w') as file:
        file.write(f'{ft_note_variable}\n\n{ft_request_limit_variable}')

    with open(f'{tf_override_file}', 'w') as file:
        file.write(f'{ft_override_provider_akamai}\n\n{ft_override_resource_activation}')

    """
    Create origin unique files for Microservice_shop and recommendations_service.
    """
    unique_microservice_origins = {}
    unique_recommend_origins = {}
    origin_behaviors_path = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/origin-behaviors'

    unique_microservice_origins = akamai_utils.get_unique_origins(nonprod_microservice_config_body)
    unique_recommend_origins = akamai_utils.get_unique_origins(nonprod_recommend_config_body)
    akamai_utils.export_unique_origins(nonprod_microservice_config_body, unique_microservice_origins, origin_behaviors_path)
    akamai_utils.export_unique_origins(nonprod_recommend_config_body, unique_recommend_origins, origin_behaviors_path)

    """Detect full brand name"""
    brand_full_name = ""
    brand_full_name = akamai_utils.get_brand_full_name(brand_short_name = brand_name)
    if brand_full_name == None:
        print()
        print(f'''ERROR: Can't find the full brand name for `{brand_name}`, please check `akamai_utils.get_brand_full_name` function''')
        sys.exit(1)


    """
    Collects common values from PROD USA/CAN "Microservice_shop" and "recommendations_service". 
    Export common microservice/recommend allenv manifests.
    """

    prod_microservice_rule_name = "Host PROD"

    if prod_usa_property_exists:
        common_usa_values_map = {}
        common_usa_values_map = akamai_utils.collect_and_export_common_values(prod_microservice_rule_name = prod_microservice_rule_name, 
                                                                              prod_microservice_config_body = prod_usa_microservice_config_body,
                                                                              prod_recommend_config_body = prod_usa_recommend_config_body,
                                                                              manifest_directory_path = f'{akamai_manifest_path}/USA/{brand_name}/common',
                                                                              microservice_common_manifest_filename = microservice_common_manifest_filename,
                                                                              recommend_common_manifest_filename = recommend_common_manifest_filename)
    if prod_can_property_exists:
        common_can_values_map = {}
        common_can_values_map = akamai_utils.collect_and_export_common_values(prod_microservice_rule_name = prod_microservice_rule_name, 
                                                                              prod_microservice_config_body = prod_can_microservice_config_body,
                                                                              prod_recommend_config_body = prod_can_recommend_config_body,
                                                                              manifest_directory_path = f'{akamai_manifest_path}/CAN/{brand_name}/common',
                                                                              microservice_common_manifest_filename = microservice_common_manifest_filename,
                                                                              recommend_common_manifest_filename = recommend_common_manifest_filename)    


    """
    Gather hostname-related information and store it in the temporary dictionary.
    """
    
    akamai_utils.akamai_config_collect_hostname_information(akamai_config_body = nonprod_microservice_config_body,
                                                            akamai_config_type = "microservice",
                                                            brand_full_name = brand_full_name,
                                                            intermediate_hostname_info = microservice_intermediate_hostname_info)
    akamai_utils.akamai_config_collect_hostname_information(akamai_config_body = nonprod_recommend_config_body,
                                                            brand_full_name = brand_full_name,
                                                            akamai_config_type = "recommend",
                                                            intermediate_hostname_info = recommend_intermediate_hostname_info)


    """
    Updates microservice match_values/not_match_values based on PROD common values in `intermediate_hostname_info`.
    Populates exclude_common_match_values/exclude_common_not_match_values in intermediate_hostname_info.
    """
    for hostname_info in microservice_intermediate_hostname_info.values():
        if prod_usa_property_exists and hostname_info["market_name"] == "USA":

            hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["match_values"], 
                common_usa_values_map["microservice_matches"]
            )

            hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["not_match_values"], 
                common_usa_values_map["microservice_not_match"]
            ) 

        if prod_can_property_exists and hostname_info["market_name"] == "CAN":

            hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["match_values"], 
                common_can_values_map["microservice_matches"]
            )

            hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["not_match_values"], 
                common_can_values_map["microservice_not_match"]
            ) 


    """
    Updates recommend match_values/not_match_values based on PROD common values in `intermediate_hostname_info`.
    Populates exclude_common_match_values/exclude_common_not_match_values in intermediate_hostname_info.
    """
    for hostname_info in recommend_intermediate_hostname_info.values():
        if prod_usa_property_exists and hostname_info["market_name"] == "USA":
            
            hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["match_values"], 
                common_usa_values_map["recommend_matches"]
            )

            hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["not_match_values"], 
                common_usa_values_map["recommend_not_match"]
            ) 

        if prod_can_property_exists and hostname_info["market_name"] == "CAN":
            
            hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["match_values"], 
                common_can_values_map["recommend_matches"]
            )     

            hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                hostname_info["not_match_values"], 
                common_can_values_map["recommend_not_match"]
            ) 

    """
    Split rules from the original akamai config to "one rule = one hostname" view.
    """
    print()
    print('Display converted rules:')
    print("========================")

    nonprod_updated_microservice_config_body = {}
    nonprod_updated_recommend_config_body = {}

    nonprod_updated_microservice_config_body = akamai_utils.akamai_config_split_rules_to_one_rule_one_env(akamai_config_body = nonprod_microservice_config_body, 
                                                                                                          akamai_config_type = "microservice")
    nonprod_updated_recommend_config_body = akamai_utils.akamai_config_split_rules_to_one_rule_one_env(akamai_config_body = nonprod_recommend_config_body, 
                                                                                                        akamai_config_type = "recommend")


    """
    Generate microservice manifests for each env name.
    """
    for hostname_info in microservice_intermediate_hostname_info.values():
        env_common_dir_name = ""
        market_name = ""
        market_name = hostname_info["market_name"]
        env_name = hostname_info["env"]
        if "qa" in env_name:
            env_common_dir_name = "qa"
        elif "uat" in env_name:
            env_common_dir_name = "uat"
        elif "regression" in env_name:
            env_common_dir_name = "regression"
        elif "integration" in env_name:
            env_common_dir_name = "integration"
        else:
            env_common_dir_name = env_name
        env_manifest = akamai_utils.generate_env_manifest(hostname_info = hostname_info, 
                                            include_filename = microservice_common_manifest_filename)
        utils.init_directory_path(directory_path = f'{akamai_manifest_path}/{market_name}/{brand_name}/{env_common_dir_name}/{env_name}')
        utils.export_json(json_filepath = f'{akamai_manifest_path}/{market_name}/{brand_name}/{env_common_dir_name}/{env_name}/{microservice_manifest_filename}',
                            body = env_manifest,
                            indent = 2)

    """
    Generate recommend manifests for each env name.
    """                  
    for hostname_info in recommend_intermediate_hostname_info.values():
        patch_structure = ""
        env_name = hostname_info["env"]
        market_name = ""
        market_name = hostname_info["market_name"]
        if env_name == "qa":
            patch_structure = "qa/common"
        elif env_name == "uat":
            patch_structure = "uat/common"
        elif env_name == "regression":
            patch_structure = "regression/regression"
        elif "qa" in env_name:
            patch_structure = f'qa/{env_name}'
        env_manifest = akamai_utils.generate_env_manifest(hostname_info = hostname_info,
                                            include_filename = recommend_common_manifest_filename)
        utils.init_directory_path(directory_path = f'{akamai_manifest_path}/{market_name}/{brand_name}/{patch_structure}')
        utils.export_json(json_filepath = f'{akamai_manifest_path}/{market_name}/{brand_name}/{patch_structure}/{recommend_manifest_filename}',
                            body = env_manifest,
                            indent = 2)


    """
    Check parsed and updated microservice and recommend configs for duplicated rules.
    Export parsed and updated microservice and recommend configs.
    """
    nonprod_microservice_rule_duplicates = bool
    nonprod_recommend_rule_duplicates = bool

    nonprod_microservice_rule_duplicates = akamai_utils.akamai_config_check_rules_duplication(akamai_config_body = nonprod_updated_microservice_config_body)
    nonprod_recommend_rule_duplicates = akamai_utils.akamai_config_check_rules_duplication(akamai_config_body = nonprod_updated_recommend_config_body)

    if nonprod_microservice_rule_duplicates:
        print()
        print('ERROR: The parsed and updated Microservice_shop config has duplicated rules')
        raise(ValueError)
    
    if nonprod_recommend_rule_duplicates:
        print()
        print('ERROR: The parsed and updated recommendations_service config has duplicated rules')
        raise(ValueError)
    
    utils.export_json(json_filepath = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/property-snippets/{microservice_config_name}.json',
                      body = nonprod_updated_microservice_config_body,
                      indent = 2)
    utils.export_json(json_filepath = f'{akamai_manifest_deployer_path}/ALL-MARKET/{brand_name}/property-snippets/{recommend_config_name}.json',
                      body = nonprod_updated_recommend_config_body,
                      indent = 2)


    """
    Populate data from manifests
    """
    if prod_usa_property_exists:
        print()
        print("Populate all USA manifests")
        print("==========================")
        populate_single_brand_allenv.main(market_name="USA", 
                                          brand_name=brand_name, 
                                          manifest_path=akamai_manifest_path)

    if prod_can_property_exists:
        print()
        print("Populate all CAN manifests")
        print("==========================")
        populate_single_brand_allenv.main(market_name="CAN", 
                                          brand_name=brand_name, 
                                          manifest_path=akamai_manifest_path)


    """
    Display summary
    """
    print()
    print('Display summary')
    print("===============")
    print()
    print('Microservice_shop:')
    print(f'Original config rules: {str(len(nonprod_microservice_config_body["children"]))}')
    print(f'Manifests created: {str(len(microservice_intermediate_hostname_info))}') 
    print(f'Updated config rules: {str(len(nonprod_updated_microservice_config_body["children"]))}')
    print()
    print('recommendations_service:')
    print(f'Original config rules: {str(len(nonprod_recommend_config_body["children"]))}')
    print(f'Manifests created: {str(len(recommend_intermediate_hostname_info))}') 
    print(f'Updated config rules: {str(len(nonprod_updated_recommend_config_body["children"]))}')


if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--akamai_edgerc_path', type=str, required=True)
    parser.add_argument('--brand_name', type=str, required=True)
    parser.add_argument('--akamai_manifest_path', type=str, required=True)
    parser.add_argument('--akamai_manifest_deployer_path', type=str, required=True)
    args = parser.parse_args()

    main(akamai_edgerc_path=args.akamai_edgerc_path,
         brand_name=args.brand_name,
         akamai_manifest_path=args.akamai_manifest_path,
         akamai_manifest_deployer_path=args.akamai_manifest_deployer_path)
