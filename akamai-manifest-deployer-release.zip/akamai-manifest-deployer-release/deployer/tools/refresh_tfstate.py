import json
import os
import time
import sys
import subprocess

import utils
import argparse
import constants

parser = argparse.ArgumentParser()
parser.add_argument('--markets', type=str, required=True)
parser.add_argument('--brand_name', type=str, required=True)
parser.add_argument('--akamai_property_network', type=str, required=False)

args = parser.parse_args()

markets = args.markets
brand_short_name = args.brand_name
if args.akamai_property_network == 'staging':
    akamai_property_network = 'staging'
else:
    akamai_property_network = 'production'

marketList = markets.split(',')
anyMarketName = marketList[0]
nonprod_property_name = constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING[brand_short_name.lower()][anyMarketName.upper()]['QA']
property_resource_address = None
property_id = None

if os.path.exists("terraform.tfstate"):
    cmd = "terraform show -json terraform.tfstate"
    result_text = utils.run(cmd)
    if result_text:
        tfstate = json.loads(result_text)
        akamai_resources = tfstate["values"]["root_module"]["resources"]
        for akamai_resource in akamai_resources:
            if akamai_resource['type'] == "akamai_property":
                if "values" in akamai_resource:
                    resource_values = akamai_resource['values']
                    if "name" in resource_values and resource_values["name"] == nonprod_property_name:
                        property_resource_address = akamai_resource['address']
                        property_id = resource_values["id"]

    if property_resource_address:
        cmd = f"terraform state rm {property_resource_address}"
        result_text = utils.run(cmd)
        if result_text:
            print(result_text)
            retries = 3
            #  Importing prod/stage active version of property to terraform state
            if akamai_property_network == 'staging':
                cmd = f"terraform import -no-color {property_resource_address} {property_id},STAGE"
            else:
                cmd = f"terraform import -no-color {property_resource_address} {property_id},PROD"
            while retries != 0:
                try:
                    result_text = subprocess.run(cmd.split(), check=True, encoding='UTF-8', capture_output=True)
                    print(f"Output from importing the active prod version of property: {result_text.stdout}")
                    break
                except subprocess.CalledProcessError as e:
                    time.sleep(5)
                    retries -= 1
                    if retries == 0:
                        sys.exit(f"Exception when calling subprocess: {e.stdout}")

            #  Verifying that resource is not present in state
            utils.run(f"terraform state show {property_resource_address}")
        else:
            print(f"Could not remove property resource {property_resource_address} from tf state")
    else:
        print(f"Could not find resource in tf state for {nonprod_property_name}")
else:
    print("No terraform state exists to refresh")
