import argparse
import glob
import json
import os
import sys
from jsonschema import validate

'''
Module checks schema in all files in directory
example: schema_checker.py --manifest_list='manifest/USA/mg-test/bpv/bpv/microservice.json --market_name USA --brand_name mg-test'
'''
parser = argparse.ArgumentParser()
parser.add_argument('--market_name', type=str, required=True)
parser.add_argument('--brand_name', type=str, required=True)
parser.add_argument('--manifest_list', type=str, required=False)
args = parser.parse_args()
manifests = args.manifest_list.split()
market_name = args.market_name
brand_name = args.brand_name

if len(manifests) == 0:
    for filename in glob.iglob(f'../manifest/{market_name}/{brand_name}/**', recursive=True):
        if os.path.isfile(filename):
            manifests.append(filename.replace("../",""))
schema = {
 "type": "object",
 "properties":
    {
        "include":{"type": "array"},
        "name":{"type": "string"},
        "criteria": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string",
                    "pattern": "^(path|hostname)$"},
                    "options": {
                        "type": "object",
                         "items": {
                            "matchCaseSensitive": {"type": "bool"},
                            "matchOperator": {"type": "string",
                            "pattern": "^(MATCHES_ONE_OF|DOES_NOT_MATCH_ONE_OF|IS_ONE_OF)$"},
                            "values": {"type": "object"}
                         },
                    }
                },
                "required":["name", "options"]
            }
        },
        "behaviors": {
            "type": "array",
            "items": {
                "type": "object",
                "oneOf" : [
                {
                    "properties": {
                    "name": {"type": "string",
                    "pattern": "^(origin)$"},
                    "options": {
                        "type": "object",
                         "items": {
                            "hostname": {"type": "string"}
                         },
		            "required":["hostname"],
                    }
                },
                "required":["name", "options"]},
                {
                    "properties": {
                    "name": {"type": "string",
                    "pattern": "^(rewriteUrl)$"},
                    "options": {
                        "type": "object",
                    }
                },
                "required":["name", "options"]}
                ]
            }
        }
    }
}

for filename in manifests:
    if 'Jenkinsfile' not in filename:
        path=f"../{filename}"   
        if os.path.exists(path):
            with open(path, "r") as read_file:
                try:            
                    json_content = json.load(read_file)
                except:
                    print(f"Invalid json in {filename}")
                    sys.exit(1)
                validate(instance=json_content, schema=schema)
                print(f"Correct schema in {filename}")
