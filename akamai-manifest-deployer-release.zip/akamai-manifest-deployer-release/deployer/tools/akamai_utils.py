"""
Common functions for processing data to/from akamai configs and manifests.
"""

import utils
import copy
import os
import subprocess
import constants
from deepmerge import always_merger


def get_unique_origins(akamai_config: dict):
    """
    This function searches unique origin behaviors in the akamai config. 
    Returns a dictionary with unique origin behaviors.

    Dictionary example:
    {
      "uat.origin-svc.collectandgather.com": {
        "filename": "uat.origin-svc.collectandgather.com.json",
        "certificate": {
          "notAfter": 1619697600000,
          "serialNumber": 1.8821412562303063e+37
        },
        "origin_body": { *** origin behavior body *** }
      "qa.origin-svc.collectandgather.com": {
        "filename": "qa.origin-svc.collectandgather.com.json",
        "certificate": {
          "notAfter": 1619697600000,
          "serialNumber": 1.8821412562303063e+37
        },
        "origin_body": { *** origin behavior body *** }
    }

    The function returns the unique origin with the newest certificate declared in "customCertificates".
    """
    result = {}

    def origin_entry_change(result: dict, 
                          hostname: str, 
                          certificate_valid_not_after: int, 
                          certificate_serial_number: str,
                          certificate_validity: bool,
                          origin_body: dict,
                          init_entry: bool):
        if init_entry:
            result[hostname] = {}
            result[hostname]["filename"] = f'{hostname}.json'
            result[hostname]["certificate"] = {}
        result[hostname]["certificate"]["notAfter"] = certificate_valid_not_after
        result[hostname]["certificate"]["serialNumber"] = certificate_serial_number
        result[hostname]["certificate"]["validity"] = certificate_validity
        result[hostname]["origin_body"] = origin_body

    for rule in akamai_config["children"]:
        if check_rule_convention(rule):
            if "behaviors" in rule["children"][0]:
                for behavior in rule["children"][0]["behaviors"]:
                    if behavior["name"] == "origin":
                        hostname = ""
                        empty_custom_certificates = False
                        certificate_valid_not_after = ""
                        certificate_serial_number = ""
                        origin_behavior_certificate_validity = False

                        hostname = behavior["options"]["hostname"]

                        if behavior["options"].get("customCertificates"):
                            if behavior["options"]["customCertificates"] == []:
                                empty_custom_certificates = True
                        else:
                            empty_custom_certificates = True
                        
                        if (empty_custom_certificates == True) and (hostname not in result):
                            origin_entry_change(result = result, 
                                            hostname = hostname, 
                                            certificate_valid_not_after = 0,
                                            certificate_serial_number = "",
                                            certificate_validity = False,
                                            origin_body = behavior,
                                            init_entry = True)            
                        elif empty_custom_certificates == False:
                            certificate_valid_not_after = behavior["options"]["customCertificates"][0]["notAfter"]
                            certificate_serial_number = behavior["options"]["customCertificates"][0]["serialNumber"]

                            origin_behavior_certificate_validity = get_origin_validity(origin_behavior=behavior)

                            if (origin_behavior_certificate_validity == False) and (hostname not in result):
                                origin_entry_change(result = result, 
                                                    hostname = hostname, 
                                                    certificate_valid_not_after = certificate_valid_not_after,
                                                    certificate_serial_number = certificate_serial_number,
                                                    certificate_validity = False,
                                                    origin_body = behavior,
                                                    init_entry = True)
                            elif (origin_behavior_certificate_validity == True) and (hostname not in result):
                                origin_entry_change(result = result, 
                                                    hostname = hostname, 
                                                    certificate_valid_not_after = certificate_valid_not_after,
                                                    certificate_serial_number = certificate_serial_number,
                                                    certificate_validity = True,
                                                    origin_body = behavior,
                                                    init_entry = True)
                            elif (origin_behavior_certificate_validity == True) and (hostname in result):
                                if result[hostname]["certificate"]["validity"] == False:
                                    origin_entry_change(result = result,
                                                        hostname = hostname,
                                                        certificate_valid_not_after = certificate_valid_not_after,
                                                        certificate_serial_number = certificate_serial_number,
                                                        certificate_validity = True,
                                                        origin_body = behavior,
                                                        init_entry = False)
                                elif result[hostname]["certificate"]["validity"] == True:                     
                                    if certificate_valid_not_after > result[hostname]["certificate"]["notAfter"]:
                                        origin_entry_change(result = result,
                                                            hostname = hostname,
                                                            certificate_valid_not_after = certificate_valid_not_after,
                                                            certificate_serial_number = certificate_serial_number,
                                                            certificate_validity = True,
                                                            origin_body = behavior,
                                                            init_entry = False)
                                    elif certificate_valid_not_after == result[hostname]["certificate"]["notAfter"]:
                                        if type(certificate_serial_number) == str and type(result[hostname]["certificate"]["serialNumber"]) == float:
                                            origin_entry_change(result = result,
                                                                hostname = hostname,
                                                                certificate_valid_not_after = certificate_valid_not_after,
                                                                certificate_serial_number = certificate_serial_number,
                                                                certificate_validity = True,
                                                                origin_body = behavior,
                                                                init_entry = False)
    return result


def get_origin_validity(origin_behavior: dict) -> bool:
    """
    Validity check for origin behavior. 
    Checks that origin hostname is present in custom certificates  ( subjectCN and subject Alternative Names ).
    Returns boolean.
    """
    result = False
    origin_hostname = ""
    custom_certificate_names = []
    origin_hostname = origin_behavior["options"]["hostname"]
    for custom_certificate in origin_behavior["options"]["customCertificates"]:
        custom_certificate_names.append(custom_certificate["subjectCN"])
        custom_certificate_names += custom_certificate["subjectAlternativeNames"]
    if origin_hostname in custom_certificate_names:
        result = True
    return result


def export_unique_origins(config_body, unique_origins_dict: dict, output_path: str):
    """
    Works with result dictionary from get_unique_origins() function. 
    Saves each dictionary element as a separate file.
    If the origin file was updated, updates it in each rule containing origin with the same hostname.
    """
    utils.init_directory_path(directory_path=output_path)
    for hostname, value in unique_origins_dict.items():
        unique_origin_before = {}
        unique_origin_after = {}
        try:
            unique_origin_before = utils.import_json(json_filepath=f'{output_path}/{value["filename"]}')
        except(FileNotFoundError):
            pass

        unique_origin_after = value["origin_body"]
        if unique_origin_before != unique_origin_after:
            if unique_origin_before:
                print(f'\nThe origin behavior file was updated: {value["filename"]}')
                for rule in config_body["children"]:
                    if "behaviors" in rule["children"][0]:
                        for behavior_num, behavior in enumerate(rule["children"][0]["behaviors"]):
                            if (behavior["name"] == "origin") and (behavior["options"]["hostname"] == hostname):
                                rule["children"][0]["behaviors"][behavior_num] = unique_origin_after
                                print(f'replacing it in {rule["name"]} ...')
            else:
                print(f'\nThe origin behavior file has been created: {value["filename"]}')
            
            utils.export_json(json_filepath=f'{output_path}/{value["filename"]}', body=value["origin_body"], indent=2)


def reconstruct_origin_file(origin_behaviors_path: str, origin_hostname: str) -> bool:
    """
    This function is used when we want to populate the origin hostname, but there is no such hostname.json file.
    The function takes the desired hostname and tries to find it among alternative subjects inside existing origin behavior json files.
    Once found, the new origin behavior file will be created based on the found origin behavior and certificate. 
    """
    result = bool
    existing_origin_files = ""
    found_proper_origin_behavior = {}
    found_proper_custom_certificate = {}
    break_origin_filepath_loop = False
    existing_origin_files = utils.get_nested_files(directory = origin_behaviors_path)
    for origin_filepath in existing_origin_files:
        origin_body = {}
        origin_body = utils.import_json(json_filepath=origin_filepath)
        for custom_certificate_body in origin_body["options"]["customCertificates"]:
            if origin_hostname in custom_certificate_body["subjectAlternativeNames"]:
                found_proper_custom_certificate = custom_certificate_body.copy()
                found_proper_origin_behavior = origin_body.copy()
                print(f'The "{origin_hostname}" hostname was found in "{origin_filepath}" certificate.')
                break_origin_filepath_loop = True
                break
        if break_origin_filepath_loop:
            break

    if found_proper_custom_certificate and found_proper_origin_behavior:
        found_proper_origin_behavior["options"]["customCertificates"] = []
        found_proper_origin_behavior["options"]["customCertificates"].append(found_proper_custom_certificate)
        found_proper_origin_behavior["options"]["hostname"] = origin_hostname
        utils.export_json(json_filepath = f'{origin_behaviors_path}/{origin_hostname}.json',
                          body = found_proper_origin_behavior)
        print()
        print(f'The origin filename is reconstructed and saved as: \n\t{origin_behaviors_path}/{origin_hostname}.json')
        result = True
    else:
        print()
        print(f'ERROR: The origin hostname "{origin_hostname}" was not found among existing origin behavior cartificates.')
        result = False
    return result

def get_brand_full_name(brand_short_name: str) -> str:
    """Accepts brand short name, returns brand full name"""
    result = None
    if "mg" in brand_short_name:
        result = "markandgraham"
    if brand_short_name == "we":
        result = "westelm"
    if brand_short_name == "ws":
        result = "williams-sonoma"
    if brand_short_name == "rj":
        result = "rejuvenation"
    if brand_short_name == "pb":
        result = "potterybarn"
    if brand_short_name == "pk":
        result = "potterybarnkids"
    if brand_short_name == "pt":
        result = "pbteen"
    if brand_short_name == "gr":
        result = "greenrow"
    return result


def get_prod_microservice_rule_paths(root_children: list, rule_name_pattern: str, match_operator: str) -> list:
    """
    As the prod microservice config has its structure,
    it requires a separate function for getting path values.
    Returns path values stored in the requested rule name and match Operator.
    """
    result = []
    for children_item in root_children:
        if children_item["name"] == rule_name_pattern:
            for criteria in children_item["criteria"]:
                if (criteria["options"]["matchOperator"] == match_operator) and (criteria["name"] == 'path'):
                    result = criteria["options"]["values"]
                    break
    return result


def get_prod_recommend_rule_values(rule: dict, match_operator: str) -> list:
    """
    As the prod recommendations config has its structure,
    it requires a separate function for getting path values.
    Returns path values stored in the requested rule name and match Operator.
    """
    result = []
    for criteria in rule["children"][0]["criteria"]:
        if criteria["name"] == "path" and criteria["options"]["matchOperator"] == match_operator:
            result = criteria["options"]["values"]
            break
    return result


def get_env_name_from_hostname(hostname: str) -> str:
    """
    Example1:
    hostname: "www.qa.*"
    result: "qa1"

    Example2:
    hostname: "www.uat6.markandgraham.com"
    result: "uat6"

    Example3:
    hostname: "*www.qa*"
    result: "qa"
    """
    result = []
    if hostname == "www.qa.*":
        result = "qa1"
    elif hostname == "*www.qa*":
        result = "qa"
    elif hostname == "www.perf*":
        result = "perf"
    elif hostname == "*www.uat*":
        result = "uat"
    elif hostname == "*www.qa2*" or hostname == "www.qa2*":
        result = "qa2"
    elif hostname == "*www.qa3*":
        result = "qa3"
    elif "www" in hostname:
        result = hostname.split('.')[1]
    else: 
        result = hostname.split('.')[0]
    return result


def get_rule_hostnames(rule: dict) -> list:
    """
    Returns the list of hostnames from the rule criteria.
    Example:
    {
      "name": "hostname",
      "options": {
        "matchOperator": "IS_ONE_OF",
        "values": [
          "www.uat3.markandgraham.com",
          "www.bpv.markandgraham.com",
          "www.uat6.markandgraham.com"
        ]
      }
    }
    result = ["www.uat3.markandgraham.com", "www.bpv.markandgraham.com", "www.uat6.markandgraham.com"]
    """
    result = []
    for criteria in rule["criteria"]:
        if criteria["name"] == "hostname":
            for hostname in criteria["options"]["values"]:
                result.append(hostname)
    return result


def get_manifest_hostname_values(manifest_body: dict):
    "Returns hostname values from the manifest."
    result = []
    for criteria in manifest_body["criteria"]:
        if criteria["name"] == "hostname":
            result = criteria["options"]["values"]
    return result


def get_rule_path_values(rule: dict, match_operator: str) -> list:
    """
    Args:
      rule: A complete akamai config rule.
      match_operator: Path criteria match operator, `MATCHES_ONE_OF` or `DOES_NOT_MATCH_ONE_OF`.

    Returns:
      The list of paths from the non-prod rule structure.
    """
    result = []
    if "children" in rule:
        for criteria in rule["children"][0]["criteria"]:
            if (criteria["name"] == "path") and (criteria["options"]["matchOperator"] == match_operator):
                result = criteria["options"]["values"]
    return result


def get_manifest_path_values(manifest_body: dict, match_operator: str, values_pointer: str) -> list:
    """
    Returns values from manifest path criteria based on match operator and values pointer name.
    Example:
    manifest_body = imported manifest structure
    match_operator = "MATCHES_ONE_OF"
    values_pointer = "exclude_common_values"
    ---
    result = [
        "/pages/xbrand-rows/",
        "/products/*/minipip.html",
        "/products/*/pip-print.html",
        "/products/*/quicklook.html"     
    ]
    """
    result = []
    for criteria in manifest_body["criteria"]:
        if criteria["options"]["matchOperator"] == match_operator:
            if values_pointer in criteria["options"]:
                result = criteria["options"][values_pointer]
    return result


def get_manifest_behaviors(manifest_body: dict, behavior_name: str) -> dict:
    result = {}
    if "behaviors" in manifest_body:
        for behavior in manifest_body["behaviors"]:
            if behavior["name"] == behavior_name:
                result = behavior
    return result


def get_known_rule_behaviors(rule: dict):
    """
    For origin rule behavior - returns hostname only.
    For rewriteUrl rule - returns the behavior as is with full behavior structure.
    All other behaviors are ignored.
    """
    result = {}
    if "behaviors" in rule["children"][0]:
        for behavior in rule["children"][0]["behaviors"]:
            if behavior["name"] == "rewriteUrl":
                result["rewriteUrl"] = behavior
            if behavior["name"] == "origin":
                result["origin"] = behavior["options"]["hostname"]
    return result


def get_rule_behavior(rule: dict, behavior_name: str):
    """
    Get behavior from the akamai config rule.

    Args:
        rule: A complete akamai config rule.
        behavior_name: The desired behavior name that we are looking for.

    Returns:
        If the behavior was found, the full behavior dictionary will be returned.
        If the behavior wasn't found, the empty dictionary will be returned.
    """
    result = {}
    if "behaviors" in rule["children"][0]:
        for behavior in rule["children"][0]["behaviors"]:
            if behavior["name"] == behavior_name:
                result = behavior
                break
    return result


def get_rule_name(rule: dict) -> str:
    result = ""
    result = rule["children"][0]["name"]
    return result


def get_market_name_from_rule(rule: dict) -> str:
    """
    Determines which market the rule belongs to.
    Returns the market name.
    """
    result = "USA"
    rule_hostname_list = []
    if ("GMTP" in rule["name"]) or ("CA-" in rule["name"]) or ("Host CA" in rule["name"]) or ("CAN" in rule["name"]):
        result = "CAN"
    else:
        rule_hostname_list = get_rule_hostnames(rule = rule)
        for hostname in rule_hostname_list:
            if ".ca" in hostname:
                result = "CAN"
    return result


def construct_hostname_info(hostname: str, 
                            match_values: list, 
                            not_match_values: list,
                            market_name: str,
                            brand_full_name: str, 
                            behaviors: dict,
                            rule_name: str,
                            original_rule_name: str,
                            akamai_config_name: str):
    """
    Creates entry for temporary intermediate_hostname_info dictionary.
    Exclude entries will be populated at later steps.

    Example microservice:
    {
      'www.qa.*':
        'hostname': 'www.qa1.markandgraham.com',
        'env': 'qa1',
        'market_name': 'USA',
        'rule_name': '/shop/* /.delivery/* /.aecv1/* /.static/* /m/shop/*',
        'original_rule_name': "Host QA",
        'match_values': ["/favorites/*",  "/m/favorites/*"],
        'exclude_common_match_values': [],
        'not_match_values': ["/.static/*"],
        'exclude_common_not_match_values': [],
        'behaviors': {}
    }

    Example 2:
    {
      '"*www.uat*"':
        'hostname': '"*www.uat*"',
        'env': 'uat',
        'market_name': 'USA',
        'rule_name': '/svc/*',
        'original_rule_name': "Host UAT",
        'match_values': ["/svc/*"],
        'exclude_common_match_values': [],
        'not_match_values': ["/svc/hash-lookup/*"],
        'exclude_common_not_match_values': [],
        'behaviors': {}
    }
    """
    env_name = None
    full_hostname = None
    env_name = get_env_name_from_hostname(hostname = hostname)
    body_match_values = copy.deepcopy(match_values)
    body_not_match_values = copy.deepcopy(not_match_values)
    if akamai_config_name == "microservice":
        if "*" in hostname:
            full_hostname = f'www.{env_name}.{brand_full_name}.com'
        else:
            full_hostname = hostname
    elif akamai_config_name == "recommend":
        full_hostname = hostname
    body = {
      hostname: {
        'hostname': full_hostname,
        'env': env_name,
        'market_name': market_name,
        'rule_name': rule_name,
        'original_rule_name': original_rule_name,
        'match_values': body_match_values,
        'exclude_common_match_values': [],
        'not_match_values': body_not_match_values,
        'exclude_common_not_match_values': [],
        'behaviors': behaviors
      }
    }
    return body


def update_intermediate_hostname_info(intermediate_hostname_info: dict, hostname_info: dict, hostname: str):
    """
    Updates temporary intermediate_hostname_info dictionary where the changeable information for env is stored. 
    """
    if hostname in intermediate_hostname_info:
        """
        If `hostname` is already present in `intermediate_hostname_info`, we have the same env name in different rules in the original config.
        Only updates the values for existing `hostname` in `intermediate_hostname_info`.
        ---
        Example input `intermediate_hostname_info` and `hostname_info`:
        ---
        intermediate_hostname_info:
          qa1:
            match_values: ["/favorites/*",  "/m/favorites/*"]
            not_match_values: []
        ---
        hostname_info:
          qa1:
            match_values: ["/shop/*", "/.aecv1/*"]
            not_match_values: ["/.static/*"]
        ---
        Updated `intermediate_hostname_info`:
        ---
        intermediate_hostname_info:
          qa1:
            match_values: ["/favorites/*",  "/m/favorites/*", "/shop/*", "/.aecv1/*"]
            not_match_values: ["/.static/*"]
        """
        tmp_match_list = []
        tmp_does_not_match_list = []
        tmp_match_list = intermediate_hostname_info[hostname]['match_values'] + hostname_info[hostname]['match_values']
        tmp_does_not_match_list = intermediate_hostname_info[hostname]['not_match_values'] + hostname_info[hostname]['not_match_values']
        intermediate_hostname_info[hostname]['match_values'] = utils.remove_list_duplicates(input_list=tmp_match_list,sort=True)
        intermediate_hostname_info[hostname]['not_match_values'] = utils.remove_list_duplicates(input_list=tmp_does_not_match_list,sort=True)
    else:
        """
        If we don't have 'hostname' in `intermediate_hostname_info`, we meet it the first time. 
        The structure from `hostname_info` will be added to intermediate_hostname_info.
        """
        intermediate_hostname_info[hostname] = hostname_info[hostname]
        intermediate_hostname_info[hostname]['match_values'].sort()
        intermediate_hostname_info[hostname]['not_match_values'].sort()


def merge_path_values_with_common(in_values: list, common_values: list):
    """
    The function takes a route list and compares it with the route list from the common manifest. 
    The goal is to determine which routes should be placed in the `values` list in the manifest and 
    which routes should be placed in the `exclude_common_values` list. 
    The function returns a sorted list of manifest `values` and `exclude_common_values`, without duplicates.

    Example input:
        in_values = ['a', 'b', 'c']
        common_values = ['c', 'd', 'e']
    ---
    Description:
        'c'         : will be removed from `out_values` since it is already present in `common_values`.
        'a' and 'b' : will remain in `out_values` as they are unique individual routes.
        'd' and 'e' : will be added to `out_exclude_common_values` as they are present in `common_values` but not in `in_values`.
    ---
    Result:
        out_values = ['a', 'b']
        out_exclude_common_values = ['d', 'e']
    """
    out_values = sorted(list(set(in_values) - set(common_values)))
    out_exclude_common_values = sorted(list(set(common_values) - set(in_values)))
    return out_values, out_exclude_common_values


def update_rule_to_dedicated_env(rule: dict, env_name: str) -> dict:
    """
    Splits rules in the original microservice config to "one rule = one env" structure. 
    """
    result = {}
    market_name = ""
    market_name = get_market_name_from_rule(rule = rule)
    result = copy.deepcopy(rule)
    if market_name == "CAN":
        result["name"] = f'Host CAN-{env_name}'
    else:
        result["name"] = f'Host {env_name}'
    
    return result


def generate_rule_name(market_name: str, env_name: str, type_name: str = "", env_group: str = "") -> str:
    """
    The function for generating rule names in accordance with accepted naming conventions.  
    `type_name` - manifest or config type, it could be `microservice` or `recommend`.
    """
    def raise_error(market_name: str):
        print()
        print(f'ERROR: Could not detect the rule name based on provided market name [{market_name}].')
        raise(ValueError)
    
    def generate_core_name(market_name: str, core_name: str):
        rule_name = ""
        if market_name == "USA":
            rule_name = f'Host {core_name}'
        elif market_name == "CAN":
            rule_name = f'Host CAN-{core_name}'
        else:
            raise_error(market_name=market_name)
        return rule_name
      
    result = ""
    if type_name and env_group:
        if (type_name == "recommend") and (env_name == "common"):
            result = generate_core_name(market_name = market_name, 
                                        core_name = env_group)
        elif (type_name == "recommend") and (env_name != "common"):
            result = generate_core_name(market_name = market_name, 
                                        core_name = env_name)
        elif (type_name == "microservice"):
            result = generate_core_name(market_name = market_name, 
                                        core_name = env_name)                  
    else:
        result = generate_core_name(market_name = market_name, 
                                    core_name = env_name)  
    return result


def generate_common_manifest(common_matches: list, common_not_match: list) -> dict:
    """
    Returns a structure for common manifest.
    """
    result = {}
    result = {
        'criteria': [
            {
                "name": "path",
                "options": {
                    'matchCaseSensitive': False,
                    'matchOperator': "MATCHES_ONE_OF",
                    'values': common_matches
                }
            },
            {
                "name": "path",
                "options": {
                    'matchCaseSensitive': False,
                    'matchOperator': "DOES_NOT_MATCH_ONE_OF",
                    'values': common_not_match
                }
            },
        ]
    }
    return result


def generate_env_manifest(hostname_info: dict, include_filename: str, includeCommon=True) -> dict:
    """
    Returns a structure for env manifest.
    """
    result = {}
    includeManifest = {
        'include': [
            f'../../common/{include_filename}'
        ]
    }

    if includeCommon:
        result = includeManifest.copy()

    remManifest = {
      'name': hostname_info["rule_name"],
      'criteria': [
          {
              'name': 'hostname',
              'options': {
                  'matchOperator': "IS_ONE_OF",
                  'values': [ hostname_info["hostname"]  ]
              }
          },
          {
              'name': 'path',
              'options': {
                  'matchCaseSensitive': False,
                  'matchOperator': 'MATCHES_ONE_OF',
                  'values': hostname_info["match_values"],
                  'exclude_common_values': hostname_info["exclude_common_match_values"]
              }
          },
          {
              'name': 'path',
              'options': {
                  'matchCaseSensitive': False,
                  'matchOperator': 'DOES_NOT_MATCH_ONE_OF',
                  'values': hostname_info["not_match_values"],
                  'exclude_common_values': hostname_info["exclude_common_not_match_values"]
              }
          }
      ],
      'behaviors': [
          {
              'name': 'origin',
              'options': {
                 'hostname': hostname_info['behaviors']['origin']
              }

          }
      ]
    }

    result.update(remManifest)
    if "rewriteUrl" in hostname_info['behaviors']:
        result["behaviors"].append(hostname_info['behaviors']['rewriteUrl'])
    return result


def get_proprety_name_from_mapping(market_name: str, brand_name: str, env_type: str) -> str:
    """
    Returns akamai property name for requested market/brand/env.
    Mapping example:
    {
      "mg": {
        "USA": {
          "PROD": "prod.markandgraham.com_pm",
          "QA": "qa.markandgraham.com_pm"
        }
      },
      "pb": {
        "USA": {
          "PROD": "prod.potterybarn.com_pm",
          "QA": "qa.potterybarn.com_pm"
        },
        "CA": {
          "PROD": "prod.potterybarn.ca_pm",
          "QA": "qa.potterybarn.com_pm"
        }
      }
    }
    """
    result = ""
    if brand_name not in constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING:
        pass
    else:
        if market_name not in constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING[brand_name]:
            pass
        else:
            result = constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING[brand_name][market_name][env_type]
    return result


def dump_akamai_property(akamai_property_name: str, 
                         akamai_edgerc_path: str,
                         akamai_docker_image: str = constants.AKAMAI_DOCKER_IMAGE,
                         akamai_cli_export_command: str = 'export-property',
                         export_path: str = '.docker_tmp_',
                         akamai_property_version: str = 'LATEST'):
    """
    Simple parameterized function for dumping akamai property.
    """
    utils.init_directory_path(directory_path=f'{export_path}/{akamai_property_name}')
    current_pwd = os.getcwd()
    with open(f'{export_path}/{akamai_property_name}/output.log', 'a') as docker_output:
        subprocess.call(f'''docker run --rm -v {current_pwd}/{export_path}/{akamai_property_name}:/root -w /root -v {akamai_edgerc_path}:/root/.edgerc {akamai_docker_image} /bin/bash -c "akamai terraform --section readwrite {akamai_cli_export_command} --version {akamai_property_version} {akamai_property_name} && chown -R $(id -u) ./" ''', 
                        shell=True, 
                        stdout=docker_output, 
                        stderr=docker_output)


def collect_and_export_common_values(prod_microservice_rule_name: str, 
                                     prod_microservice_config_body: dict, 
                                     prod_recommend_config_body: dict,
                                     manifest_directory_path: str,
                                     microservice_common_manifest_filename: str,
                                     recommend_common_manifest_filename: str) -> dict:
    """
    Creates and returns a map of common values lists for a particular market.
    Generates common manifests.
    Exports common manifests.
    """
    common_microservice_manifest = {}
    common_recommend_manifest = {}

    common_values_map = {
        'microservice_matches': [],
        'microservice_not_match': [],
        'recommend_matches': [],
        'recommend_not_match': []
    }
    
    common_values_map["microservice_matches"] =  get_prod_microservice_rule_paths(root_children = prod_microservice_config_body["children"],
                                                                                  rule_name_pattern = prod_microservice_rule_name,
                                                                                  match_operator = "MATCHES_ONE_OF")
    common_values_map["microservice_not_match"] =  get_prod_microservice_rule_paths(root_children = prod_microservice_config_body["children"],
                                                                                    rule_name_pattern = prod_microservice_rule_name,
                                                                                    match_operator = "DOES_NOT_MATCH_ONE_OF")
    common_values_map["recommend_matches"] = get_prod_recommend_rule_values(rule = prod_recommend_config_body,
                                                                            match_operator = "MATCHES_ONE_OF")
    common_values_map["recommend_not_match"] = get_prod_recommend_rule_values(rule = prod_recommend_config_body,
                                                                              match_operator = "DOES_NOT_MATCH_ONE_OF")
    
    for common_list in common_values_map:
        common_values_map[common_list].sort()

    common_microservice_manifest = generate_common_manifest(common_matches = common_values_map["microservice_matches"],
                                                            common_not_match = common_values_map["microservice_not_match"])
    common_recommend_manifest =  generate_common_manifest(common_matches = common_values_map["recommend_matches"],
                                                          common_not_match = common_values_map["recommend_not_match"])

    utils.init_directory_path(directory_path = manifest_directory_path)
    utils.export_json(json_filepath = f'{manifest_directory_path}/{microservice_common_manifest_filename}',
                      body = common_microservice_manifest,
                      indent = 2)
    utils.export_json(json_filepath = f'{manifest_directory_path}/{recommend_common_manifest_filename}',
                      body = common_recommend_manifest,
                      indent = 2)
    return common_values_map


def akamai_config_collect_hostname_information(akamai_config_body: dict,
                                              akamai_config_type: str,
                                              brand_full_name: str, 
                                              intermediate_hostname_info: dict) -> list:
    """
    Iterates through the akamai config and collects information regarding a particular hostname. 
    That information accumulates in the intermediate_hostname_info dictionary. 
    """
    for rule in akamai_config_body["children"]:
        hostname_info = None
        rule_match_values = []
        rule_not_match_values = []
        rule_hostname_list = []
        rule_behaviors = []
        rule_name = ""
        market_name = ""
        rule_hostname_list = get_rule_hostnames(rule = rule)
        rule_match_values = get_rule_path_values(rule = rule,
                                                match_operator = "MATCHES_ONE_OF")
        rule_not_match_values = get_rule_path_values(rule = rule,
                                                    match_operator = "DOES_NOT_MATCH_ONE_OF")
        rule_behaviors = get_known_rule_behaviors(rule = rule)
        rule_name = get_rule_name(rule = rule)
        market_name = get_market_name_from_rule(rule = rule)
        for hostname in rule_hostname_list:
            hostname_info = construct_hostname_info(hostname = hostname,
                                                    match_values = rule_match_values,
                                                    not_match_values = rule_not_match_values,
                                                    market_name = market_name,
                                                    brand_full_name = brand_full_name,
                                                    behaviors = rule_behaviors,
                                                    rule_name = rule_name,
                                                    original_rule_name = rule["name"],
                                                    akamai_config_name = akamai_config_type)
            update_intermediate_hostname_info(intermediate_hostname_info = intermediate_hostname_info,
                                              hostname_info = hostname_info,
                                              hostname = hostname)


def akamai_config_get_rule_list(akamai_config_body: dict) -> list:
    result = []
    for rule in akamai_config_body['children']:
        result.append(rule['name'])
    return result



def akamai_config_check_rules_duplication(akamai_config_body: dict) -> bool:
    """
    Returns True if the akamai config has duplicated rule names.
    """
    result = False
    rule_list = []
    rule_duplicate_list = []

    for rule in akamai_config_body['children']:
        rule_list.append(rule['name'])

    rule_duplicate_list = utils.get_list_duplicates(input_list = rule_list)
    if rule_duplicate_list:
        result = True

    return result


def akamai_config_split_rules_to_one_rule_one_env(akamai_config_body: dict, akamai_config_type: str) -> dict:
    """
    The function splits rules from the original akamai config to "one rule = one hostname" view.
    Returns the dictionary with unique rules.

    Example original rule:
        {
          "name": "Host UAT3",
          "children": [...],
          "criteria": [
            {
              "name": "hostname",
              "options": {
                "values": [
                  "www.uat3.markandgraham.com",
                  "www.bpv.markandgraham.com",
                  "www.uat6.markandgraham.com"
                ]
              }
            }
          ]
        }

    Example result with splitted rules:
        {
          "name": "Host uat3",
          "children": [...],
          "criteria": [
            {
              "name": "hostname",
              "options": {
                "values": [
                  "www.uat3.markandgraham.com",
                  "www.bpv.markandgraham.com",
                  "www.uat6.markandgraham.com"
                ]
              }
            }
          ]
        },
        {
          "name": "Host bpv",
          "children": [...],
          "criteria": [
            {
              "name": "hostname",
              "options": {
                "values": [
                  "www.uat3.markandgraham.com",
                  "www.bpv.markandgraham.com",
                  "www.uat6.markandgraham.com"
                ]
              }
            }
          ]
        },
        {
          "name": "Host uat6",
          "children": [...],
          "criteria": [
            {
              "name": "hostname",
              "options": {
                "values": [
                  "www.uat3.markandgraham.com",
                  "www.bpv.markandgraham.com",
                  "www.uat6.markandgraham.com"
                ]
              }
            }
          ]
        }
    
    The hostnames are left because the hostname values will be overwritten at the first population script run.
    The main idea here is to take one rule, read how many hostnames are present in the rule, and create as many 
    new rules as we got hostnames from the parent rule.
    """
    result = {}
    akamai_intermediate_config_body = {}
    result = akamai_config_body.copy()
    result["children"] = []
    low_priority_rule_names = [
        'Host All Nonprod',
        'Host all nonprod',
        'All-nonprod',
        'Host All-NonProd',
        'Host all-Nonprod'
    ] 

    for rule in akamai_config_body["children"]:
        rule_hostname_list = []
        rule_market_name = ""
        rule_hostname_list = get_rule_hostnames(rule = rule)
        rule_market_name = get_market_name_from_rule(rule = rule)
        for hostname in rule_hostname_list:
            env_name = ""
            new_rule_name = ""
            env_name = get_env_name_from_hostname(hostname = hostname)
            new_rule_name = generate_rule_name(market_name = rule_market_name, 
                                                env_name = env_name)
            print()
            print(f'[{akamai_config_type}] rule: "{rule["name"]}", hostname: "{hostname}" ---> market: "{rule_market_name}", env_name: "{env_name}" ---> new rule name: "{new_rule_name}"')
            if akamai_intermediate_config_body.get(new_rule_name):
                if rule["name"] in low_priority_rule_names:
                    print(f'Rule "{new_rule_name}" is already present in the resulting akamai config, however, the "{rule["name"]}" rule has low priority and will be skipped to avoid duplication inside the rule.')
                else:
                    akamai_intermediate_config_body[new_rule_name] = rule.copy()
                    print(f'Rule "{new_rule_name}" is already present in the resulting akamai config.')
                    print(f'The newly found "{rule["name"]}" rule has normal priority and the rule data will overwrite the existing one to avoid duplication inside the rule.')
                akamai_intermediate_config_body[new_rule_name]["name"] = new_rule_name
            else:
                akamai_intermediate_config_body[new_rule_name] = {}
                akamai_intermediate_config_body[new_rule_name] = rule.copy()
                akamai_intermediate_config_body[new_rule_name]["name"] = new_rule_name
    akamai_intermediate_config_body = dict(sorted(akamai_intermediate_config_body.items()))
    for rule_body in akamai_intermediate_config_body.values():
        result["children"].append(rule_body)
    return result


def print_change_log(changes_info: str, values_before, values_after):
    """
    The function could be used for printing the before and after changes for various types of values.
    Example 1:
        print_change_log(config_name = config_body["name"],
                          rule_name = f'''"{'Host qa2'}"''',
                          additional_info = f'- match operator "DOES_NOT_MATCH_ONE_OF"',
                          values_before = [ 'test-A', 'test-B' ],
                          values_after = [ 'test-A', 'test-C' ])
    Output1:
        Microservice_shop - rule "{'Host qa2'}" - match operator "DOES_NOT_MATCH_ONE_OF" - values are updated:
        + ['test-C']
        - ['test-B']

    The optional `additional_info` variable can describe more accurately where the change is ( behavior , or path and match operator ).

    By passing `values_before` as `None` and `values_after` as a string we can display some general information about changes. 
    Example2: 
        print_change_log(config_name = config_body["name"],
                          rule_name = f'''"{'Host qa1'}"''',
                          additional_info = f'- "{behavior["name"]}" behavior hostname',
                          values_before = None,
                          values_after = "No changes in the origin hostname, but there are changes in the origin behavior. It's possible the certificate was updated.")    
    Output2:
        Microservice_shop - rule "{'Host qa1'}" - "origin" behavior hostname - value is updated:
        No changes in the origin hostname, but there are changes in the origin behavior. It's possible the certificate was updated.
    
    """
    if values_before != values_after:
        if isinstance(values_before, list) and isinstance(values_after, list):
            values_to_add = list(set(values_after) - set(values_before))
            values_to_remove = list(set(values_before) - set(values_after))
            print()
            print(changes_info)
            if values_to_add:
                print(f'+ {values_to_add}')
            if values_to_remove:
                print(f'- {values_to_remove}')
        elif isinstance(values_before, str) and isinstance(values_after, str):
            print()
            print(changes_info)
            values_to_add = values_after
            values_to_remove = values_before
            if values_to_add:
                print(f'+ {values_to_add}')
            if values_to_remove:
                print(f'- {values_to_remove}')
        elif (values_before is None) and isinstance(values_after, str):
            print()
            print(changes_info)
            print(f'{values_after}')
        elif isinstance(values_before, str) and (values_after is None):
            print()
            print(changes_info)
            print(f'{values_before}')


def check_rule_convention(rule: dict):
    if 'host ' not in rule['name'].lower():
        return False
    if not get_rule_hostnames(rule):
        return False
    if (not get_rule_path_values(rule, 'MATCHES_ONE_OF')) and (not get_rule_path_values(rule, 'DOES_NOT_MATCH_ONE_OF')):
        return False
    return True


def check_manifest_route_duplicates(manifest_body: dict, manifest_type: str = ''):
    duplicates_present = False
    match_operators = ['MATCHES_ONE_OF', 'DOES_NOT_MATCH_ONE_OF']
    operator_route_pointers = ['values', 'exclude_common_values']

    for operator in match_operators:
        for route_pointer in operator_route_pointers:
            routes = []
            duplicate_routes = []
            routes = get_manifest_path_values(manifest_body, operator, route_pointer)
            duplicate_routes = utils.get_list_duplicates(routes)
            if duplicate_routes:
                duplicates_present = True
                print(f'\nThere are duplicates in the {manifest_type} manifest `{operator}/{route_pointer}` routes:\n{duplicate_routes}')
    return duplicates_present