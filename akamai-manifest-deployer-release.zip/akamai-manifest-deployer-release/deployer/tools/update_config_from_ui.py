import json
import os
import re
import subprocess
import sys
import utils
import akamai_utils
import shutil
import argparse
import constants
import copy
import hcl2

"""
Example run:

  python3 deployer/tools/update_config_from_ui.py \
    --akamai_edgerc_path /Users/ostarostin/.edgerc \
    --markets USA \
    --brand_name mg-test \
    --akamai_manifest_path ***/akamai-manifest/manifest \
    --akamai_manifest_deployer_path ***/akamai-manifest-deployer/deployer \
    --routes_changes True
"""

def prepare_and_print_manifests_change_log(manifest_body_before: dict, manifest_body_after: dict, manifest_location: str):
    changed_values_map = {
        'before': {
            'hostname': [],
            'behaviors': {
                'origin': {},
                'rewrite_url': {}
            },
            'routes': {
                'match': {
                    'values': [],
                    'exclude_common_values': []
                },
                'not_match': {
                    'values': [],
                    'exclude_common_values': []        
                }
            }
        },
        'after': {
            'hostname': [],
            'behaviors': {
                'origin': {},
                'rewrite_url': {}
            },
            'routes': {
                'match': {
                    'values': [],
                    'exclude_common_values': []
                },
                'not_match': {
                    'values': [],
                    'exclude_common_values': []        
                }
            }
        }
    }
    """
    Dispaly hostname changes
    """
    changed_values_map['before']['hostname'] = akamai_utils.get_manifest_hostname_values(manifest_body = manifest_body_before)
    changed_values_map['after']['hostname'] = akamai_utils.get_manifest_hostname_values(manifest_body = manifest_body_after)
    if changed_values_map['before']['hostname'] != changed_values_map['after']['hostname']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Action: hostname updated;',
                                      values_before = changed_values_map['before']['hostname'], 
                                      values_after = changed_values_map['after']['hostname'])
    """
    Dispaly paths (routes) changes
    """
    changed_values_map['before']['routes']['match']['values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_before,
                                                                                                      match_operator = 'MATCHES_ONE_OF',
                                                                                                      values_pointer = 'values')
    changed_values_map['after']['routes']['match']['values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_after,
                                                                                                      match_operator = 'MATCHES_ONE_OF',
                                                                                                      values_pointer = 'values')
    changed_values_map['before']['routes']['match']['exclude_common_values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_before,
                                                                                                                    match_operator = 'MATCHES_ONE_OF',
                                                                                                                    values_pointer = 'exclude_common_values')
    changed_values_map['after']['routes']['match']['exclude_common_values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_after,
                                                                                                                    match_operator = 'MATCHES_ONE_OF',
                                                                                                                    values_pointer = 'exclude_common_values')      
    changed_values_map['before']['routes']['not_match']['values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_before,
                                                                                                          match_operator = 'DOES_NOT_MATCH_ONE_OF',
                                                                                                          values_pointer = 'values')
    changed_values_map['after']['routes']['not_match']['values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_after,
                                                                                                        match_operator = 'DOES_NOT_MATCH_ONE_OF',
                                                                                                        values_pointer = 'values')     
    changed_values_map['before']['routes']['not_match']['exclude_common_values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_before,
                                                                                                                        match_operator = 'DOES_NOT_MATCH_ONE_OF',
                                                                                                                        values_pointer = 'exclude_common_values')
    changed_values_map['after']['routes']['not_match']['exclude_common_values'] = akamai_utils.get_manifest_path_values(manifest_body = manifest_body_after,
                                                                                                                        match_operator = 'DOES_NOT_MATCH_ONE_OF',
                                                                                                                        values_pointer = 'exclude_common_values')     
    if changed_values_map['before']['routes']['match']['values'] != changed_values_map['after']['routes']['match']['values']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Path actions: values updated, Match operator: "MATCHES_ONE_OF";',
                                      values_before = changed_values_map['before']['routes']['match']['values'], 
                                      values_after = changed_values_map['after']['routes']['match']['values'])
    if changed_values_map['before']['routes']['match']['exclude_common_values'] != changed_values_map['after']['routes']['match']['exclude_common_values']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Path actions: exclude common values updated, Match operator: "MATCHES_ONE_OF";',
                                      values_before = changed_values_map['before']['routes']['match']['exclude_common_values'], 
                                      values_after = changed_values_map['after']['routes']['match']['exclude_common_values'])
    if changed_values_map['before']['routes']['not_match']['values'] != changed_values_map['after']['routes']['not_match']['values']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Path actions: values updated, Match operator: "DOES_NOT_MATCH_ONE_OF";',
                                      values_before = changed_values_map['before']['routes']['not_match']['values'], 
                                      values_after = changed_values_map['after']['routes']['not_match']['values'])
    if changed_values_map['before']['routes']['not_match']['exclude_common_values'] != changed_values_map['after']['routes']['not_match']['exclude_common_values']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Path actions: exclude common values updated, Match operator: "DOES_NOT_MATCH_ONE_OF";',
                                      values_before = changed_values_map['before']['routes']['not_match']['exclude_common_values'], 
                                      values_after = changed_values_map['after']['routes']['not_match']['exclude_common_values'])
    """
    Dispaly origin behaviors changes
    """
    changed_values_map['before']['behaviors']['origin'] = akamai_utils.get_manifest_behaviors(manifest_body = manifest_body_before, 
                                                                                            behavior_name = 'origin')
    changed_values_map['after']['behaviors']['origin'] = akamai_utils.get_manifest_behaviors(manifest_body = manifest_body_after, 
                                                                                            behavior_name = 'origin')
    if changed_values_map['before']['behaviors']['origin'] != changed_values_map['after']['behaviors']['origin']:
        akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Behavior name: "origin", Action: "hostname" value updated;',
                                      values_before = changed_values_map['before']['behaviors']['origin']['options']['hostname'], 
                                      values_after = changed_values_map['after']['behaviors']['origin']['options']['hostname'])      
    """
    Dispaly rewriteUrl behaviors changes
    """     
    changed_values_map['before']['behaviors']['rewrite_url'] = akamai_utils.get_manifest_behaviors(manifest_body = manifest_body_before, 
                                                                                                  behavior_name = 'rewriteUrl')
    changed_values_map['after']['behaviors']['rewrite_url'] = akamai_utils.get_manifest_behaviors(manifest_body = manifest_body_after, 
                                                                                                  behavior_name = 'rewriteUrl')
    if changed_values_map['before']['behaviors']['rewrite_url'] != changed_values_map['after']['behaviors']['rewrite_url']:
        if changed_values_map['before']['behaviors']['rewrite_url'] == {}:
            akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Behavior name: "rewriteUrl", Action: added;',
                                          values_before = None, 
                                          values_after = changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
        elif changed_values_map['after']['behaviors']['rewrite_url'] == {}:
            akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Behavior name: "rewriteUrl", Action: removed;',
                                          values_before = None, 
                                          values_after = changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
        else:
            if changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'] != changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend']:
                akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Behavior name: "rewriteUrl", Action: "targetPathPrepend" value updated;',
                                              values_before = changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'], 
                                              values_after = changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
            else:
                akamai_utils.print_change_log(changes_info = f'Manifest: "{manifest_location}", Action: "rewriteUrl" behavior updated;',
                                              values_before = None, 
                                              values_after = "Non `targetPathPrepend` value was updated") 


def prepare_and_print_akamai_config_change_log(akamai_config_before: dict, akamai_config_after: dict, akamai_config_name: str):
    rule_list_before = []
    rule_list_after = []

    rule_dict_before = {}
    rule_dict_after = {}

    rule_list_before = akamai_utils.akamai_config_get_rule_list(akamai_config_body = akamai_config_before)
    rule_list_after = akamai_utils.akamai_config_get_rule_list(akamai_config_body = akamai_config_after)

    if rule_list_before == rule_list_after:
        pass
    else:
        rules_added_list = []
        rules_removed_list = []

        rules_added_list, rules_removed_list = utils.compare_before_after_lists(before_list = rule_list_before, after_list = rule_list_after)

        for rule in rules_added_list:
            print()
            print(f'Akamai config: "{akamai_config_name}", The rule "{rule}" was added')
            rule_list_after.remove(rule)

        for rule in rules_removed_list:
            print()
            print(f'Akamai config: "{akamai_config_name}", The rule "{rule}" was removed')
            rule_list_before.remove(rule)

    for rule in akamai_config_before['children']:
        rule_dict_before[rule["name"]] = rule

    for rule in akamai_config_after['children']:
        rule_dict_after[rule["name"]] = rule

    for rule_name in rule_list_after:
        changed_values_map = {}
        changed_values_map = {
            'before': {
                'hostname': [],
                'behaviors': {
                    'origin': {},
                    'rewrite_url': {}
                },
                'routes': {
                    'match': {
                        'values': [],
                        'exclude_common_values': []
                    },
                    'not_match': {
                        'values': [],
                        'exclude_common_values': []        
                    }
                }
            },
            'after': {
                'hostname': [],
                'behaviors': {
                    'origin': {},
                    'rewrite_url': {}
                },
                'routes': {
                    'match': {
                        'values': [],
                        'exclude_common_values': []
                    },
                    'not_match': {
                        'values': [],
                        'exclude_common_values': []        
                    }
                }
            }
        }

        if rule_dict_before[rule_name] != rule_dict_after[rule_name]:
            """
            Compare akamai config rule `criterias` ( hostname )
            """
            if rule_dict_before[rule_name]['criteria'] != rule_dict_after[rule_name]['criteria']:
                changed_values_map['before']['hostname'] = akamai_utils.get_manifest_hostname_values(manifest_body = rule_dict_before[rule_name])
                changed_values_map['after']['hostname'] = akamai_utils.get_manifest_hostname_values(manifest_body = rule_dict_after[rule_name])
                if changed_values_map['before']['hostname'] != changed_values_map['after']['hostname']:
                    akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Action: hostname updated;',
                                                  values_before = changed_values_map['before']['hostname'], 
                                                  values_after = changed_values_map['after']['hostname'])
            if rule_dict_before[rule_name]['children'] != rule_dict_after[rule_name]['children']:
                """
                Compare akamai config rule `children` behaviors
                """
                if rule_dict_before[rule_name]['children'][0]['behaviors'] != rule_dict_after[rule_name]['children'][0]['behaviors']:

                    changed_values_map['before']['behaviors']['origin'] = akamai_utils.get_rule_behavior(rule = rule_dict_before[rule_name],
                                                                                                         behavior_name = 'origin')
                    changed_values_map['after']['behaviors']['origin'] = akamai_utils.get_rule_behavior(rule = rule_dict_after[rule_name],
                                                                                                        behavior_name = 'origin')
                    changed_values_map['before']['behaviors']['rewrite_url'] = akamai_utils.get_rule_behavior(rule = rule_dict_before[rule_name],
                                                                                                              behavior_name = 'rewriteUrl')
                    changed_values_map['after']['behaviors']['rewrite_url'] =  akamai_utils.get_rule_behavior(rule = rule_dict_after[rule_name],
                                                                                                              behavior_name = 'rewriteUrl')
                    if changed_values_map['before']['behaviors'] != changed_values_map['after']['behaviors']:
                        if changed_values_map['before']['behaviors']['rewrite_url'] != changed_values_map['after']['behaviors']['rewrite_url']:
                            if changed_values_map['before']['behaviors']['rewrite_url'] == {}:
                                akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Behavior name: "rewriteUrl", Action: added;',
                                                              values_before = None, 
                                                              values_after = changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
                            elif changed_values_map['after']['behaviors']['rewrite_url'] == {}:
                                akamai_utils.print_change_log(changes_info = f'Manifest: "{akamai_config_name}", Rule name: "{rule_name}", Behavior name: "rewriteUrl", Action: removed;',
                                                              values_before = None, 
                                                              values_after = changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
                            else:
                                if changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'] != changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend']:
                                    akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Behavior name: "rewriteUrl", Action: "targetPathPrepend" value updated;',
                                                                  values_before = changed_values_map['before']['behaviors']['rewrite_url']['options']['targetPathPrepend'],
                                                                  values_after = changed_values_map['after']['behaviors']['rewrite_url']['options']['targetPathPrepend'])
                                else:
                                    akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Action: "rewriteUrl" behavior updated;',
                                                                  values_before = None, 
                                                                  values_after = "Non `targetPathPrepend` value was updated")
                        if changed_values_map['before']['behaviors']['origin'] != changed_values_map['after']['behaviors']['origin']:
                            if changed_values_map['before']['behaviors']['origin']['options']['hostname'] != changed_values_map['after']['behaviors']['origin']['options']['hostname']:
                                akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Behavior name: "origin", Action: "hostname" value updated;',
                                                              values_before = changed_values_map['before']['behaviors']['origin']['options']['hostname'],
                                                              values_after = changed_values_map['after']['behaviors']['origin']['options']['hostname'])
                            else:
                                akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Behavior name: "origin", Action: "hostname" value updated;',
                                                              values_before = None, 
                                                              values_after = "Non `hostname` value was updated")                               
                    else:
                        print()
                        print(f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Action: non-manifested behaviors were updated;')
                """
                Compare akamai config rule `children` criteria paths
                """
                if rule_dict_before[rule_name]['children'][0]['criteria'] != rule_dict_after[rule_name]['children'][0]['criteria']:
                    changed_values_map['before']['routes']['match']['values'] = akamai_utils.get_rule_path_values(rule = rule_dict_before[rule_name], 
                                                                                                                  match_operator = 'MATCHES_ONE_OF')
                    changed_values_map['after']['routes']['match']['values'] =  akamai_utils.get_rule_path_values(rule = rule_dict_after[rule_name],
                                                                                                                  match_operator = 'MATCHES_ONE_OF')
                    changed_values_map['before']['routes']['not_match']['values'] = akamai_utils.get_rule_path_values(rule = rule_dict_before[rule_name],
                                                                                                                      match_operator = 'DOES_NOT_MATCH_ONE_OF')
                    changed_values_map['after']['routes']['not_match']['values'] =  akamai_utils.get_rule_path_values(rule = rule_dict_after[rule_name],
                                                                                                                      match_operator = 'DOES_NOT_MATCH_ONE_OF')   
                    if changed_values_map['before']['routes']['match']['values'] != changed_values_map['after']['routes']['match']['values']:
                        akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Path actions: values updated, Match operator: "MATCHES_ONE_OF";',
                                                      values_before = changed_values_map['before']['routes']['match']['values'], 
                                                      values_after = changed_values_map['after']['routes']['match']['values'])                     
                    if changed_values_map['before']['routes']['not_match']['values'] != changed_values_map['after']['routes']['not_match']['values']:
                        akamai_utils.print_change_log(changes_info = f'Akamai config: "{akamai_config_name}", Rule name: "{rule_name}", Path actions: values updated, Match operator: "DOES_NOT_MATCH_ONE_OF";',
                                                      values_before = changed_values_map['before']['routes']['not_match']['values'], 
                                                      values_after = changed_values_map['after']['routes']['not_match']['values'])

parser = argparse.ArgumentParser()
parser.add_argument('--akamai_edgerc_path', type=str, required=True)
parser.add_argument('--markets', type=str, required=True)
parser.add_argument('--brand_name', type=str, required=True)
parser.add_argument('--akamai_manifest_path', type=str, required=True)
parser.add_argument('--akamai_manifest_deployer_path', type=str, required=True)
parser.add_argument('--akamai_property_network', type=str, required=False)
parser.add_argument('--routes_changes', type=str, required=True)
parser.add_argument('--origin_changes', type=str, required=False)
parser.add_argument('--tf_changes', type=str, required=False)
parser.add_argument('--snippets_changes', type=str, required=False)
args = parser.parse_args()

akamai_edgerc_path = args.akamai_edgerc_path
markets = args.markets
brand_short_name = args.brand_name
akamai_manifest_path = args.akamai_manifest_path
akamai_manifest_deployer_path = args.akamai_manifest_deployer_path
routes_changes = args.routes_changes in ['True', 'true']

if args.akamai_property_network not in ['production', 'staging']:
    sys.exit(f'\nError: The [akamai_property_network] variable can only be set to `production` or `staging`.')
else:
    akamai_property_network = args.akamai_property_network

if not args.origin_changes:
    origin_changes = True
else:
    origin_changes = args.origin_changes in ['True', 'true']

if not args.tf_changes:
    tf_changes = True
else:
    tf_changes = args.tf_changes in ['True', 'true']

if not args.snippets_changes:
    snippets_changes = True
else:
    snippets_changes = args.snippets_changes in ['True', 'true']

print(f"\nAkamai property network: {akamai_property_network}")
print(f"Update routes: {routes_changes}")
print(f"Update origins: {origin_changes}")
print(f"Update terraform files: {tf_changes}")
print(f"Update Akamai property-snippets: {snippets_changes}")

marketList = markets.split(',')
anyMarketName = marketList[0]
nonprod_property_name = constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING[brand_short_name.lower()][anyMarketName.upper()]['QA']

microservice_original_config_name = constants.MICROSERVICE_RULE_FILE_NAME
microservice_desired_config_name = constants.MICROSERVICE_RULE_FILE_NAME
microservice_manifest_filename = "microservice.json"
microservice_common_manifest_filename = "microservice.json"

recommend_config_name = constants.RECOMMEND_SERVICE_RULE_FILE_NAME
recommend_manifest_filename = "recommend-service.json"
recommend_common_manifest_filename = "recommend-service.json"
main_config_name = "main.json"

# Export qa prod/stage property from akamai API
docker_export_dir = ".docker_tmp_"
akamai_cli_export_command = 'export-property'
exported_microservice_config_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets/{microservice_original_config_name}'
exported_recommend_config_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets/{recommend_config_name}'
exported_main_config_path = f'{docker_export_dir}/{nonprod_property_name}/property-snippets/{main_config_name}'
production_version = None
staging_version = None
latest_version = None
if os.path.exists("terraform.tfstate"):
    cmd = "terraform show -json terraform.tfstate"
    cmd = cmd.split()
    subprocessArgs = {
        'args': cmd,
        'check': False,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }
    try:
        result = subprocess.run(**subprocessArgs)
        result_text = result.stdout
        if result_text:
            tfstate = json.loads(result_text)
            akamai_resources = tfstate["values"]["root_module"]["resources"]
            for akamai_resource in akamai_resources:
                if akamai_resource['type'] == "akamai_property":
                    if "values" in akamai_resource:
                        resource_values = akamai_resource['values']
                        if "name" in resource_values and resource_values["name"] == nonprod_property_name:
                            if "production_version" in resource_values:
                                production_version = resource_values["production_version"]
                            if "staging_version" in resource_values:
                                staging_version = resource_values["staging_version"]
                            if "latest_version" in resource_values:
                                latest_version = resource_values["latest_version"]
    except subprocess.CalledProcessError:
        sys.exit(f"Exception when calling subprocess: {subprocess.CalledProcessError.stderr}")

print(f"\nProduction active version: {production_version}")
print(f"Staging active version: {staging_version}")
print(f"Latest version: {latest_version}")

if production_version and akamai_property_network == 'production':
    akamai_utils.dump_akamai_property(nonprod_property_name, akamai_edgerc_path, akamai_property_version = production_version)
elif staging_version and akamai_property_network == 'staging':
    akamai_utils.dump_akamai_property(nonprod_property_name, akamai_edgerc_path, akamai_property_version = staging_version)
else:
    sys.exit(f"Exiting the sync/drift resolution as could not fetch the current {akamai_property_network} active version for property {nonprod_property_name}")

exported_microservice_config_body = utils.import_json(json_filepath = exported_microservice_config_path)
exported_recommend_config_body = utils.import_json(json_filepath = exported_recommend_config_path)
exported_main_config_body = utils.import_json(json_filepath = exported_main_config_path)

if origin_changes:
    # Create origin unique files for Microservice_shop and recommendations_service
    origin_behaviors_path = 'origin-behaviors'
    unique_microservice_origins = akamai_utils.get_unique_origins(akamai_config=exported_microservice_config_body)
    unique_recommend_origins = akamai_utils.get_unique_origins(akamai_config=exported_recommend_config_body)
    akamai_utils.export_unique_origins(exported_microservice_config_body, unique_origins_dict=unique_microservice_origins, output_path=origin_behaviors_path)
    akamai_utils.export_unique_origins(exported_recommend_config_body, unique_origins_dict=unique_recommend_origins, output_path=origin_behaviors_path)

if routes_changes == True:
    # Perform this section only in case of changed routes/behaviors in detected drift
    for market_name in marketList:  # Iterate over all markets
        microservice_intermediate_hostname_info = {}
        recommend_intermediate_hostname_info = {}
        common_microservice_matches = None
        common_microservice_not_match = None
        common_recommend_matches = None
        common_recommend_not_match = None
        isCommonMicroServiceExists = False
        isCommonRecommendServiceExists = False

        common_microservice_path = f'{akamai_manifest_path}/{market_name}/{brand_short_name}/common/microservice.json'
        if os.path.exists(common_microservice_path):
            common_microservice = utils.import_json(common_microservice_path)
            isCommonMicroServiceExists = True
            common_microservice_matches = akamai_utils.get_manifest_path_values(common_microservice, 'MATCHES_ONE_OF', 'values')
            common_microservice_not_match = akamai_utils.get_manifest_path_values(common_microservice, 'DOES_NOT_MATCH_ONE_OF', 'values')

        common_recommend_path = f'{akamai_manifest_path}/{market_name}/{brand_short_name}/common/recommend-service.json'
        if os.path.exists(common_recommend_path):
            common_recommend = utils.import_json(common_recommend_path)
            isCommonRecommendServiceExists = True
            common_recommend_matches = akamai_utils.get_manifest_path_values(common_recommend, 'MATCHES_ONE_OF', 'values')
            common_recommend_not_match = akamai_utils.get_manifest_path_values(common_recommend, 'DOES_NOT_MATCH_ONE_OF', 'values')

        brand_full_name = akamai_utils.get_brand_full_name(brand_short_name = brand_short_name)

        # Collect microservice values MATCHES_ONE_OF/DOES_NOT_MATCH_ONE_OF specified for each env to the temporary dictionary
        original_microservice_rules = []
        for rule in exported_microservice_config_body["children"]:
            if akamai_utils.check_rule_convention(rule):
                hostname_info = None
                original_microservice_rules.append(rule["name"])
                rule_hostname_list = akamai_utils.get_rule_hostnames(rule = rule)
                rule_match_values = akamai_utils.get_rule_path_values(rule = rule, match_operator = "MATCHES_ONE_OF")
                rule_not_match_values = akamai_utils.get_rule_path_values(rule = rule, match_operator = "DOES_NOT_MATCH_ONE_OF")
                rule_behaviors = akamai_utils.get_known_rule_behaviors(rule = rule)
                rule_name = akamai_utils.get_rule_name(rule = rule)
                market_name_from_rule = akamai_utils.get_market_name_from_rule(rule=rule)
                if market_name_from_rule != market_name:
                    continue

                for hostname in rule_hostname_list:
                    hostname_info = akamai_utils.construct_hostname_info(hostname = hostname,
                                                        match_values = rule_match_values,
                                                        not_match_values = rule_not_match_values,
                                                        market_name=market_name,
                                                        brand_full_name = brand_full_name,
                                                        behaviors = rule_behaviors,
                                                        rule_name = rule_name,
                                                        original_rule_name=rule["name"],
                                                        akamai_config_name = "microservice")
                
                    akamai_utils.update_intermediate_hostname_info(intermediate_hostname_info = microservice_intermediate_hostname_info,
                                                    hostname_info = hostname_info,
                                                    hostname = hostname)

        # Collect recommend values MATCHES_ONE_OF/DOES_NOT_MATCH_ONE_OF specified for each env to the temporary dictionary
        original_recommend_rules = []
        for rule in exported_recommend_config_body["children"]:
            if akamai_utils.check_rule_convention(rule):
                hostname_info = None
                original_recommend_rules.append(rule["name"])
                rule_hostname_list = akamai_utils.get_rule_hostnames(rule = rule)
                rule_match_values = akamai_utils.get_rule_path_values(rule = rule, match_operator = "MATCHES_ONE_OF")
                rule_not_match_values = akamai_utils.get_rule_path_values(rule = rule, match_operator = "DOES_NOT_MATCH_ONE_OF")
                rule_behaviors = akamai_utils.get_known_rule_behaviors(rule = rule)
                rule_name = akamai_utils.get_rule_name(rule = rule)
                market_name_from_rule = akamai_utils.get_market_name_from_rule(rule=rule)
                if market_name_from_rule != market_name:
                    continue

                for hostname in rule_hostname_list:
                    hostname_info = akamai_utils.construct_hostname_info(hostname = hostname,
                                                        match_values = rule_match_values,
                                                        not_match_values = rule_not_match_values,
                                                        market_name=market_name,
                                                        brand_full_name = brand_full_name,
                                                        behaviors = rule_behaviors,
                                                        rule_name = rule_name,
                                                        original_rule_name=rule["name"],
                                                        akamai_config_name = "recommend")
                    akamai_utils.update_intermediate_hostname_info(intermediate_hostname_info = recommend_intermediate_hostname_info,
                                                    hostname_info = hostname_info,
                                                    hostname = hostname)
            
        """
        Updates microservice/recommend match_values/not_match_values based on PROD common values in `intermediate_hostname_info`
        Populates exclude_common_match_values/exclude_common_not_match_values in intermediate_hostname_info

        Sample entry in intermediate_hostname_info:
        {
        'www.qa.*':
            'hostname': 'www.qa1.markandgraham.com',
            'env': 'qa1',
            'rule_name': '/shop/* /.delivery/* /.aecv1/* /.static/* /m/shop/*',
            'match_values': ["/favorites/*",  "/m/favorites/*"],
            'exclude_common_match_values': [],
            'not_match_values': ["/.static/*"],
            'exclude_common_not_match_values': [],
            'behaviors': {}
        }
        """
        if isCommonMicroServiceExists:
            for hostname, hostname_info in microservice_intermediate_hostname_info.items():
                if common_microservice_matches:
                    hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                        hostname_info["match_values"], 
                        common_microservice_matches
                    )

                if common_microservice_not_match:
                    hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                        hostname_info["not_match_values"], 
                        common_microservice_not_match
                    )

        if isCommonRecommendServiceExists:
            for hostname, hostname_info in recommend_intermediate_hostname_info.items():
                if common_recommend_matches:
                    hostname_info["match_values"], hostname_info["exclude_common_match_values"] = akamai_utils.merge_path_values_with_common(
                        hostname_info["match_values"], 
                        common_recommend_matches
                    )

                if common_recommend_not_match:
                    hostname_info["not_match_values"], hostname_info["exclude_common_not_match_values"] = akamai_utils.merge_path_values_with_common(
                        hostname_info["not_match_values"], 
                        common_recommend_not_match
                    )

        all_manifest_files = utils.get_nested_files(f'{akamai_manifest_path}/{market_name}/{brand_short_name}')
        microservice_env_names_in_manifest = {}
        recommend_env_names_in_manifest = {}
        for file in all_manifest_files:
            if 'microservice.json' in file and ('common' not in file):
                env_name = file.split('/')[-2]
                microservice_env_names_in_manifest[env_name] = file
            if 'recommend-service.json' in file and ('common' not in file):
                env_name = file.split('/')[-2]
                recommend_env_names_in_manifest[env_name] = file

        # Generate microservice manifests for each env name
        for hostname, hostname_info in microservice_intermediate_hostname_info.items():
            env_common_dir_name = ""
            env_name = hostname_info["env"]
            if "qa" in env_name:
                env_common_dir_name = "qa"
            elif "uat" in env_name:
                env_common_dir_name = "uat"
            elif "regression" in env_name:
                env_common_dir_name = "regression"
            elif "int" in env_name:
                env_common_dir_name = "integration"
            else:
                env_common_dir_name = env_name

            env_manifest = akamai_utils.generate_env_manifest(hostname_info = hostname_info, include_filename = microservice_common_manifest_filename, includeCommon = isCommonMicroServiceExists)
            utils.init_directory_path(directory_path = f'{akamai_manifest_path}/{market_name}/{brand_short_name}/{env_common_dir_name}/{env_name}')

            # Print logs
            manifest_body_before = {}
            manifest_body_after = {}
            try:
                manifest_body_before = utils.import_json(json_filepath = f'{akamai_manifest_path}/{market_name}/{brand_short_name}/{env_common_dir_name}/{env_name}/{microservice_manifest_filename}')
                manifest_body_after = env_manifest.copy()
                prepare_and_print_manifests_change_log(manifest_body_before = manifest_body_before,
                                                      manifest_body_after = manifest_body_after,
                                                      manifest_location = f'{market_name}/{brand_short_name}/{env_common_dir_name}/{env_name}/{microservice_manifest_filename}')  
            except(FileNotFoundError):
                print()
                print(f'Manifest created: {market_name}/{brand_short_name}/{env_common_dir_name}/{env_name}/{microservice_manifest_filename}')

            # Export manifest
            utils.export_json(json_filepath=f'{akamai_manifest_path}/{market_name}/{brand_short_name}/'
                                            f'{env_common_dir_name}/{env_name}/{microservice_manifest_filename}',
                              body=env_manifest, indent=2)
            if env_name in microservice_env_names_in_manifest:
                # env_name is visited so delete it from the list
                del microservice_env_names_in_manifest[env_name]

        # env which are deleted from Microservice_shop file, hence remove from manifest as well
        for env, file in microservice_env_names_in_manifest.items():
            print(f'Manifest removed: env {env} file {file}')
            os.remove(file)
            directory_path = os.path.dirname(file)
            if len(os.listdir(directory_path)) == 0:
                os.rmdir(directory_path)

        # Generate recommend manifests for each env name.
        for hostname, hostname_info in recommend_intermediate_hostname_info.items():
            patch_structure = ""
            env_name = hostname_info["env"]
            if env_name == "qa":
                patch_structure = "qa/common"
            elif env_name == "uat":
                patch_structure = "uat/common"
            elif env_name == "regression":
                patch_structure = "regression/regression"
            elif "qa" in env_name and env_name != "qa":
                patch_structure = f'qa/{env_name}'
            elif "uat" in env_name and env_name != "uat":
                patch_structure = f'uat/{env_name}'

            env_manifest = akamai_utils.generate_env_manifest(hostname_info = hostname_info,
                                                              include_filename = recommend_common_manifest_filename,
                                                              includeCommon = isCommonRecommendServiceExists)
            utils.init_directory_path(directory_path=f'{akamai_manifest_path}/{market_name}/{brand_short_name}/{patch_structure}')

            # Print logs
            manifest_body_before = {}
            manifest_body_after = {}
            try:
                manifest_body_before = utils.import_json(json_filepath = f'{akamai_manifest_path}/{market_name}/{brand_short_name}/{patch_structure}/{recommend_manifest_filename}')
                manifest_body_after = env_manifest.copy()
                prepare_and_print_manifests_change_log(manifest_body_before = manifest_body_before,
                                                      manifest_body_after = manifest_body_after,
                                                      manifest_location = f'{market_name}/{brand_short_name}/{patch_structure}/{recommend_manifest_filename}')  
            except(FileNotFoundError):
                print()
                print(f'Manifest created: {market_name}/{brand_short_name}/{patch_structure}/{recommend_manifest_filename}')

            # Export manifest
            utils.export_json(json_filepath=f'{akamai_manifest_path}/{market_name}/{brand_short_name}/'
                                            f'{patch_structure}/{recommend_manifest_filename}',
                              body=env_manifest, indent=2)
            if env_name in recommend_env_names_in_manifest:
                # env_name is visited so delete it from the list
                del recommend_env_names_in_manifest[env_name]

        # env which are deleted from recommend service file, hence remove from manifest as well
        for env, file in recommend_env_names_in_manifest.items():
            print(f'Manifest removed: env {env} file {file}')
            os.remove(file)
            directory_path = os.path.dirname(file)
            if len(os.listdir(directory_path)) == 0:
                os.rmdir(directory_path)

if origin_changes or snippets_changes:
    microservice_config_body_before = utils.import_json(json_filepath=f'property-snippets/{microservice_desired_config_name}')
    microservice_config_body_after = copy.deepcopy(exported_microservice_config_body)
    if microservice_config_body_before != microservice_config_body_after:
        # Print change logs microservice config
        prepare_and_print_akamai_config_change_log(akamai_config_before = microservice_config_body_before, akamai_config_after = microservice_config_body_after, akamai_config_name = 'microservice')
        # Export parsed and updated microservice config
        utils.init_directory_path(directory_path = f'property-snippets')
        utils.export_json(json_filepath = f'property-snippets/{microservice_desired_config_name}', body = exported_microservice_config_body, indent = 2)

    recommend_config_body_before = utils.import_json(json_filepath=f'property-snippets/{recommend_config_name}')
    recommend_config_body_after = copy.deepcopy(exported_recommend_config_body)
    if recommend_config_body_before != recommend_config_body_after:
        # Export parsed and updated recommend config
        utils.init_directory_path(directory_path = f'property-snippets')
        utils.export_json(json_filepath = f'property-snippets/{recommend_config_name}', body = exported_recommend_config_body, indent = 2)



# Gather information about exported property files 
exported_snippets_files = []
exported_tf_files = []
exported_property_path = f'{docker_export_dir}/{nonprod_property_name}/'
exported_property_files = utils.get_nested_files(exported_property_path)

for file_path in exported_property_files:
    if "property-snippets" in file_path:
        exported_snippets_files.append(file_path)
    elif ".tf" in file_path:
        exported_tf_files.append(file_path)

# Update property-snippets
if snippets_changes:
    main_include = []
    for snippet in exported_snippets_files:
        if (recommend_config_name in snippet) or (microservice_original_config_name in snippet) or (microservice_desired_config_name in snippet):
            pass
        else:
            snippet_filename = os.path.basename(snippet)
            dest_snippet_path = f'property-snippets/{snippet_filename}'
            if snippet_filename == main_config_name and os.path.exists(dest_snippet_path):
                dest_main_config_json = utils.import_json(dest_snippet_path)
                comments = dest_main_config_json.get("comments", "")
                src_main_config_json = utils.import_json(snippet)
                src_main_config_json["comments"] = comments
                if 'children' in src_main_config_json['rules']:
                    for include_entry in src_main_config_json['rules']['children']:
                        main_include.append(include_entry.replace('#include:', ''))
                src_main_config_json["ruleFormat"] = constants.AKAMAI_RULE_FORMAT_VERSION
                utils.export_json(snippet, src_main_config_json)
            if not os.path.exists(dest_snippet_path):
                print(f'\nAkamai property snippet: {snippet_filename}, Action: added')
                print(f'+ {dest_snippet_path}')
            shutil.copy2(snippet, dest_snippet_path)

    # Find and remove unused .json files
    property_snippet_removal = []
    snippets_dir = f'property-snippets'
    for snippet_path in utils.get_nested_files(snippets_dir):
        snippet_filename = os.path.basename(snippet_path)
        if snippet_filename != main_config_name and snippet_filename not in main_include:
            print(f'\nAkamai property snippet: {snippet_filename}, Action: removed')
            print(f'- {snippet_path}')
            os.remove(snippet_path)

# Update terraform files
if tf_changes:
    for tf in exported_tf_files:
        property_filename = os.path.basename(tf)

        if property_filename == 'property.tf':
            property_names = []
            property_name = ""
            property_tf_exported = {}

            with open(tf, 'r') as file:
                property_tf_exported = hcl2.load(file)

            for count, resource in enumerate(property_tf_exported['resource']):
                if 'akamai_property' in resource:
                    akamai_property_resource_position = count
                    for name in resource['akamai_property']:
                        property_names.append(name)
                elif 'akamai_property_activation' in resource:
                    activation_resource_position = count

            if len(property_names) > 1:
                sys.exit(f'\nFound property_names: {property_names}\nError: Multiple instances of the `akamai_property` resource have been found in `property.tf`. We were expecting only one.')
            else:
                property_name = property_names[0]

            # set the rule format
            property_tf_exported['resource'][akamai_property_resource_position]['akamai_property'][property_name]['rule_format'] = constants.AKAMAI_RULE_FORMAT_VERSION

            # remove `note` from the `akamai_property_activation` as it is already present in `override.tf`
            if 'note' in property_tf_exported['resource'][activation_resource_position]['akamai_property_activation'][property_name]:
                del(property_tf_exported['resource'][activation_resource_position]['akamai_property_activation'][property_name]['note'])

            # compare exported and existing `property.tf`, print changes, update existing
            property_tf_body = utils.import_json(f'{property_filename}.json')

            if property_tf_body != property_tf_exported:
                print(f'\n{property_filename}.json has been updated.')

                hostnames_before = []
                hostnames_after = []
                for cname_entry in property_tf_body['resource'][akamai_property_resource_position]['akamai_property'][property_name]['hostnames']:
                    hostnames_before.append(cname_entry['cname_from'])
                for cname_entry in property_tf_exported['resource'][akamai_property_resource_position]['akamai_property'][property_name]['hostnames']:
                    hostnames_after.append(cname_entry['cname_from'])
                hostnames_added, hostnames_removed = utils.compare_before_after_lists(hostnames_before, hostnames_after)

                if hostnames_added:
                    print(f'\nAkamai property hostnames, Action: added')
                    print(f'+ {hostnames_added}')
                if hostnames_removed:
                    print(f'\nAkamai property hostnames, Action: removed')
                    print(f'- {hostnames_removed}')

            utils.export_json(f'{property_filename}.json', property_tf_exported)

        else:
            shutil.copy2(tf, f'{property_filename}')
