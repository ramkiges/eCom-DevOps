import sys
import argparse
import requests
from akamai.edgegrid import EdgeGridAuth, EdgeRc
from urllib.parse import urljoin

from utils import import_json

"""
Example run:
  python3 check_property_activation_status.py \
    --akamai_edgerc_path ~/.edgerc \
    --brand_name mg-test \
    --akamai_property_network production \
    --checked_status_activation PENDING
"""

parser = argparse.ArgumentParser()
parser.add_argument('--akamai_edgerc_path', type=str, required=True)
parser.add_argument('--brand_name', type=str, required=True)
parser.add_argument('--akamai_property_network', type=str, required=True)
parser.add_argument('--checked_status_activation', type=str, required=True)
args = parser.parse_args()

if args.akamai_property_network == 'staging':
    akamai_property_network = 'STAGING'
else:
    akamai_property_network = 'PRODUCTION'

akamai_edgerc_path = args.akamai_edgerc_path
brand_short_name = args.brand_name
status_activation = args.checked_status_activation

if not akamai_edgerc_path.endswith('.edgerc'):
    sys.exit("Invalid akamai_edgerc_path. Please provide a valid .edgerc file.")

valid_networks = ['production', 'staging']
if args.akamai_property_network and args.akamai_property_network.lower() not in valid_networks:
    sys.exit("Invalid akamai_property_network. Valid options are 'production' or 'staging'.")

valid_status_activations = ['PENDING', 'ACTIVE']
if status_activation.upper() not in valid_status_activations:
    sys.exit("Invalid checked_status_activation. Valid options are 'PENDING' or 'ACTIVE'.")

edgerc = EdgeRc(akamai_edgerc_path)
section = 'readwrite'
baseurl = 'https://%s' % edgerc.get(section, 'host')

session = requests.Session()
session.auth = EdgeGridAuth.from_edgerc(edgerc, section)

path_to_main_json = f"../deployer/ALL-MARKET/{brand_short_name}/property-snippets/main.json"
main_data = import_json(path_to_main_json)
propertyId = main_data["propertyId"]
contractId = main_data["contractId"]
groupId = main_data["groupId"]
path = f"/papi/v1/properties/{propertyId}/activations"
headers = {
    "Accept": "application/json",
    "PAPI-Use-Prefixes": "true"
}
querystring = {
    "contractId": contractId,
    "groupId": groupId
}

try:
    result = session.get(urljoin(baseurl, path), headers=headers, params=querystring)
    result.raise_for_status()  # Raise an exception for non-2xx status codes
except requests.exceptions.RequestException as e:
    sys.exit(f"Error occurred while retrieving activation status: {str(e)}")

if result.status_code == 200:
    activations = result.json().get('activations', {}).get('items', [])

    filtered_activations = [
        activation for activation in activations
        if activation.get('network') == akamai_property_network and activation.get('status') == status_activation.upper()
    ]

    if len(filtered_activations) > 0:
        print(f"There are {status_activation} status activations for the {akamai_property_network} network.")
    else:
        print(f"No {status_activation} status activations for the {akamai_property_network} network.")
else:
    sys.exit(f"Error occurred while retrieving activation status.")
