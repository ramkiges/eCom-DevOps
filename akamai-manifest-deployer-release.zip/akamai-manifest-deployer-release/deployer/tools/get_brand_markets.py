#!/usr/bin/env python3

import constants
import argparse


parser = argparse.ArgumentParser()
parser.add_argument('--brand', type=str, required=True)
args = parser.parse_args()
brand = args.brand

markets = ""

if brand in constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING:
    brandObj = constants.AKAMAI_MARKET_BRAND_PROPERTY_MAPPING[brand]
    marketList = list(brandObj.keys())
    markets = ','.join(marketList)

print(markets)
