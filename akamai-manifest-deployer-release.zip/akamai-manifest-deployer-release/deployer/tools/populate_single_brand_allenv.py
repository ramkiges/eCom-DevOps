#!/usr/bin/env python3
"""
Script for populating data for all environments specified market/brand from akama-manifest repository.
Forms data that could be passed to `populate_single_brand.py`.

(Optional) Comment string could be optionally passed and populated to main.json as a `comments` entry (--main_comments). 
Result: String will be present on LUNA UI Version History page.

python3 deployer/tools/populate_single_brand_allenv.py \
    --market_name USA \
    --brand_name mg-test \
    --manifest_path ~/path/to/akamai-manifest/manifest
"""

import argparse
import shutil
import utils
import populate_single_brand
import os

def main(market_name: str, brand_name: str, manifest_path: str, main_comments: str = "", fail_on_error: bool = True):
    """
    Copy all manifests
    """
    manifests_target_dir = "manifest"
    proceed_copy_process = True
    manifest_list = []

    if os.path.abspath(manifest_path) == os.path.abspath(manifests_target_dir):
        """
        If `manifest_path` == `manifests_target_dir`, it means that the manifest directory is already at the desired location 
        so there is no need to initiate the copy process.
        """
        proceed_copy_process = False

    if proceed_copy_process:
        shutil.copytree(manifest_path, manifests_target_dir)

    manifest_list = utils.get_nested_files(directory = f'{manifests_target_dir}/{market_name}/{brand_name}')
    populate_single_brand.main([], manifest_list, market_name, brand_name, main_comments, fail_on_error)

    if proceed_copy_process:
        shutil.rmtree(manifests_target_dir)
  
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--market_name', type=str, required=True)
    parser.add_argument('--brand_name', type=str, required=True)
    parser.add_argument('--manifest_path', type=str, required=True)
    parser.add_argument('--main_comments', type=str, required=False)
    parser.add_argument('--fail_on_error', action=argparse.BooleanOptionalAction, default=True, required=False)
    args = parser.parse_args()

    market_name = args.market_name
    brand_name = args.brand_name
    manifest_path = args.manifest_path
    if args.main_comments != None:
        main_comments = args.main_comments
    else:
        main_comments = ""
    fail_on_error = args.fail_on_error

    main(market_name, brand_name, manifest_path, main_comments, fail_on_error)
