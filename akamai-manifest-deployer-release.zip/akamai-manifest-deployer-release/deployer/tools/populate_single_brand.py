#!/usr/bin/env python3
"""
Script for populating manifests values into `Microservice_shop.json` and `recommendations_service.json` configs.
Script mandatory requires an argument with the manifest list, 
represented as file paths separated by space. 
The file path should follow the structure:

  manifest/{MARKET}/{BRAND}/.../...

Additionally and optionally script can accept arguments for market and brand.
The market/brand pair will be auto-detected if we pass only the file list without market and brand names. 
The script fails if more than one market/brand pair is auto-detected.

If we pass the market/brand manually, but the file list has more than one market/brand pair, 
all paths that are not regarding the passed market/brand will be ignored. 
The accordance message will be displayed.

The optional market/brand arguments are present for compatibility with outside 
scripts that can call the `main` function from the current script.
Such outside scripts can handle presorting multi-market/brand paths, or create 
the manifest list based on akamai-manifest repository files for specified market/brand. 

Example without market/brand:
python3 deployer/tools/populate_single_brand.py \
    --manifest_list manifest/USA/mg-test/qa/qa1/microservice.json \
                    manifest/USA/mg-test/qa/qa14/microservice.json \
                    manifest/USA/mg-test/perf/perf/microservice.json \
                    manifest/USA/mg-test/regression/regression/microservice.json \
                    manifest/USA/mg-test/regression/regression2/microservice.json

Example with market/brand:
python3 deployer/tools/populate_single_brand.py \
    --manifest_list manifest/USA/mg-test/qa/common/recommend-service.json \
                    manifest/USA/mg-test/regression/regression/recommend-service.json \
                    manifest/USA/mg-test/uat/common/recommend-service.json \
                    manifest/USA/mg-test/common/microservice.json \
                    manifest/USA/mg-test/common/recommend-service.json \
    --market_name USA \
    --brand_name mg-test

(Optional) Comment string could be optionally passed and populated to main.json as a `comments` entry (--main_comments). 
Result: String will be present on LUNA UI Version History page.

During the execution, all gathered information from manifests, configs, and so on is stored in temporary dictionaries and lists.
For debugging purposes, you can add the following code snippets to the main function to check the temporary essences:

    utils.export_json(json_filepath = "common_microservice_values.json",
                      body = common_microservice_values,
                      indent = 2)

    utils.export_json(json_filepath = "common_recommend_values.json",
                      body = common_recommend_values,
                      indent = 2)

    utils.export_json(json_filepath = "aggregated_microservice_manifests.json",
                      body = aggregated_microservice_manifests,
                      indent = 2)

    utils.export_json(json_filepath = "aggregated_recommend_manifests.json",
                      body = aggregated_recommend_manifests,
                      indent = 2)

    utils.export_json(json_filepath = "manifests_summary.json",
                      body = manifests_summary,
                      indent = 2)        

"""

import argparse
import os
import utils
import akamai_utils
import sys
import re
import constants
import akamai_utils
from deepmerge import always_merger
import copy


def get_market_brand_names(manifest_path_list: list):
    """
    manifest/USA/mg-test/perf/perf/microservice.json
    manifest/USA/mg-test/common/microservice.json
    manifest/USA/mg-test/qa/common/recommend-service.json

    --->

    market_list = ['USA']
    brand_list = ['mg-test']
    """
    market_list = []
    brand_list = []
    for manifest_path in manifest_path_list:
        market_list.append(manifest_path.split('/')[1])
        brand_list.append(manifest_path.split('/')[2])
    market_list = utils.remove_list_duplicates(input_list = market_list, sort = False)
    brand_list = utils.remove_list_duplicates(input_list = brand_list, sort = False)
    return market_list, brand_list


def check_path_for_market_brand_affiliation(market_name: str, brand_name: str, manifest_path_list: list) -> list:
    """
    Returns the list of paths that are not matched to passed market and brand.
    Example:
    manifest_path_list = [
      'manifest/USA/mg/perf/perf/microservice.json',
      'manifest/USA/mg-test/regression/regression/microservice.json',
      'manifest/USA/mg-test/regression/regression2/microservice.json'
      ]
    market_name = "USA"
    brand_name  = "mg-test"
    ---
    result = ['manifest/USA/mg/perf/perf/microservice.json']
    """
    result = []
    for manifest_path in manifest_path_list:
        manifest_path_market_name = manifest_path.split('/')[1]
        manifest_path_brand_name = manifest_path.split('/')[2]
        if (market_name != manifest_path_market_name) or (brand_name != manifest_path_brand_name):
            result.append(manifest_path)
    return result


def parse_manifest_path(manifest_path: str):
    """
    manifest_path:
      'manifest/USA/mg-test/qa/qa1/microservice.json'

    env_group: 'qa'
    env_name: 'qa1'
    manifest_type: 'microservice'
    """
    env_group = ""
    env_name = ""
    manifest_type = ""
    manifest_filename = ""

    env_group = manifest_path.split('/')[3]
    env_name = manifest_path.split('/')[4]
    try:
        manifest_filename = manifest_path.split('/')[5]
    except IndexError:
        pass
    if "microservice.json" == manifest_filename:
        manifest_type = "microservice"
    elif "recommend-service.json" == manifest_filename:
        manifest_type = "recommend"
    return env_group, env_name, manifest_type


def resolve_manifest_include_path(include_entry: list, manifest_path: str) -> list:
    """
    Converts the "include" path from the manifest to the path accessible for python scripts from the Jenkins agent entry point.
    
    Args:
        include_entry: `include` from the manifest ( example: `['../../common/microservice.json']` )
        manifest_path: the path to the manifest that contains the provided `include_entry`

    Returns:
        result: the actual path to the manifest from the include_entry. ( example: `['manifest/USA/mg-test/common/microservice.json']` )
    """
    result = []
    manifest_dir = ""
    include_absolute_path = ""
    manifest_dir = os.path.dirname(manifest_path)
    for entry in include_entry:
        include_absolute_path = os.path.abspath(f'{manifest_dir}/{entry}')
        include_absolute_path = re.sub(r'.*manifest/', 'manifest/', include_absolute_path)
        result.append(include_absolute_path)
    return result


def get_manifest_behavior(manifest_body: dict, behavior_name: str) -> dict:
    """
    Returns values from manifest behaviors based on behavior name.
    Example:
    manifest_body = imported manifest structure
    behavior_name = "rewriteUrl"
    ---
    result = {
        "name": "rewriteUrl",
        "options": {
            "behavior": "PREPEND",
            "keepQueryString": true,
            "targetPathPrepend": "/{{builtin.AK_DOMAIN}}/"
        }
    }
    """
    result = {}
    for behavior in manifest_body["behaviors"]:
        if behavior["name"] == behavior_name:
            result = behavior
            break
    return result


def merge_path_values(manifest_body: dict, match_operator: str, common_manifest_body: dict) -> list:
    """
    Before populating path values from manifest to akamai config, we should know what exactly common 
    values we want to add based on exclude_common_values.

    Returns path values that will be added to akamai config.
    Example:
    common_values = [
          "/AAA/",
          "/BBB/",
          "/CCC/",
          "/DDD/",
          "/EEE/"
          ]
    manifest_values = [
          "/FFF/",
          "/GGG/"
          ]
    manifest_exclude_common_values = [
          "/AAA/",
          "/BBB/"
          ]
    ---
    result = [
          "/CCC/",
          "/DDD/",
          "/EEE/",
          "/FFF/",
          "/GGG/"
          ]

    Returns:
        manifest_values_result: Values that will be added to akamai config.
        duplicate_values: Duplicated values that are present in both the individual manifest and the common manifest.
        non_relevant_exclude_values: Individual manifest exclude values that are not present in the common manifest.
    """
    manifest_values = []
    manifest_exclude_common_values = []
    manifest_values_result = []
    common_values = []

    manifest_values = akamai_utils.get_manifest_path_values(manifest_body = manifest_body,
                                                            match_operator = match_operator,
                                                            values_pointer = "values")
    manifest_exclude_common_values = akamai_utils.get_manifest_path_values(manifest_body = manifest_body,
                                                                          match_operator = match_operator,
                                                                          values_pointer = "exclude_common_values")
    common_values = akamai_utils.get_manifest_path_values(manifest_body = common_manifest_body,
                                                          match_operator = match_operator,
                                                          values_pointer = "values")
    duplicate_values = set(manifest_values) & set(common_values)
    non_relevant_exclude_values = set(manifest_exclude_common_values) - set(common_values)
    """Subtraction `manifest_exclude_common_values` list from `common_values` is needed to get result manifest match values"""
    manifest_values_result = manifest_values + [item for item in common_values if item not in manifest_exclude_common_values]
    manifest_values_result = utils.remove_list_duplicates(input_list = manifest_values_result, sort = True)
    return manifest_values_result, duplicate_values, non_relevant_exclude_values


def update_manifest_path_values(manifest_body: dict, match_operator: str, values: list):
    """
    The function simply overwrites manifests path values based on match operator.
    Example:
    manifest_values (Before) = [
          "/FFF/",
          "/GGG/"
          ]
    values = [
          "/AAA/",
          "/BBB/"
    ]
    ---
    manifest_values (After) = [
          "/AAA/",
          "/BBB/"
          ] 
    """
    for criteria in manifest_body["criteria"]:
        if (criteria["options"]["matchOperator"] == match_operator) and (criteria["name"] == "path"):
            criteria["options"]["values"] = values


def populate_path_values(rule_name: str, match_operator: str, manifest_values: list, config_body: dict):
    "Populates path values from manifest to akamai config, based on rule name and match operator name."
    for rule in config_body["children"]:
        if rule["name"] == rule_name:
            for criteria in rule["children"][0]["criteria"]:
                if (criteria["options"]["matchOperator"] == match_operator) and (criteria["name"] == "path"):
                    akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Match operator: "{match_operator}";',
                                                values_before = criteria["options"]["values"],
                                                values_after = manifest_values)
                    criteria["options"]["values"] = manifest_values
                    criteria["options"]["values"].sort()


def populate_hostname(rule_name: str, hostname_values: list, config_body: dict):
    "Populates hostname from manifest to akamai config, based on rule name."
    for rule in config_body["children"]:
        if rule["name"] == rule_name:
            for rule_criteria_num, rule_criteria_item in enumerate(rule["criteria"]):
                if rule_criteria_item["name"] == "hostname":
                    akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Action: hostname updated;',
                                                  values_before = rule_criteria_item["options"]["values"],
                                                  values_after = hostname_values)
                    rule["criteria"][rule_criteria_num]["options"]["values"] = hostname_values


def populate_behavior(rule_name: str, behavior_name: str, behavior_body: dict, config_body: dict):
    """
    Populates behavior from manifest to akamai config, based on rule name and behavior name.
    Supports:
        - Adding `rewriteUrl` behavior
        - Updating `rewriteUrl/origin` behaviors
        - Removing `rewriteUrl` behavior
    To remove the `rewriteUrl` behavior, the `behavior_body` should be passed as an empty dictionary.
    """
    for rule in config_body["children"]:
        if rule["name"] == rule_name:
            if "behaviors" in rule["children"][0]:
                behavior_present = False
                behavior_present_num = int
                behavior_present_body = {}
                for behavior_num, behavior in enumerate(rule["children"][0]["behaviors"]):
                    # Before adding, updating, or removing rule behavior, it is a good idea to first check if it already exists in the rule.
                    if behavior["name"] == behavior_name:
                        behavior_present = True
                        behavior_present_num = behavior_num
                        behavior_present_body = behavior
                        break
                if behavior_present_body != behavior_body:
                    if behavior_present and behavior_body:
                        # If the behavior is present in the rule and the incoming behavior is not empty, proceed with updating the existing behavior.
                        rule["children"][0]["behaviors"][behavior_present_num] = behavior_body
                        if behavior["name"] == "rewriteUrl":
                            akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Behavior name: "{behavior_body["name"]}", Action: "Updated";',
                                                          values_before = str(behavior_present_body["options"]),
                                                          values_after = str(behavior_body["options"]))
                        elif behavior["name"] == "origin":  
                            if behavior["options"]["hostname"] == behavior_body["options"]["hostname"]:
                                akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Behavior name: "{behavior_body["name"]}";',
                                                              values_before = None,
                                                              values_after = "No changes in the origin hostname, but there are changes in the origin behavior. It's possible the certificate was updated.")
                            else:
                                akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Behavior name: "{behavior_body["name"]}", Action: "hostname" value updated;',
                                                              values_before = behavior["options"]["hostname"],
                                                              values_after = behavior_body["options"]["hostname"])               
                    elif not behavior_present and behavior_body:
                        # If the behavior is not present in the rule and the incoming behavior is not empty, proceed with adding new behavior.
                        rule["children"][0]["behaviors"].append(behavior_body)
                        if behavior_body["name"] == "rewriteUrl":
                            akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Behavior name: "{behavior_body["name"]}", Action: "Added"',
                                                          values_before = None,
                                                          values_after = str(behavior_body['options']))
                    elif behavior_present and not behavior_body:
                        # If the behavior is present in the rule and the incoming behavior is empty, proceed with deleting the existing rule behavior.
                        if behavior_name == "origin":
                            sys.exit(f'\nAkamai config: "{config_body["name"]}", Rule: "{rule["name"]}"\nERROR: Deletion of the "origin" behavior is prohibited')
                        elif behavior_name == "rewriteUrl":
                            akamai_utils.print_change_log(changes_info = f'Akamai config: "{config_body["name"]}", Rule: "{rule["name"]}", Behavior name: "{behavior_present_body["name"]}", Action: "Deleted"',
                                                          values_before = str(behavior_present_body["options"]),
                                                          values_after = None)
                            del rule["children"][0]["behaviors"][behavior_present_num]


def init_config_path_criteria(rule_name: str, match_operator: str, config_body: dict):
    """
    Gathers information about path match operator names in a specified rule. 
    If no such path criteria with the requested match operator name the empty one will be created.
    Used for creating DOES_NOT_MATCH_ONE_OF path criteria.
    """
    rule_match_operators = []
    path_criteria_body = {
        'name': 'path',
        'options': {
            'matchCaseSensitive': False,
            'matchOperator': match_operator,
            'normalize': False,
            'values': []
        }
    }
    for rule in config_body["children"]:
        if rule["name"] == rule_name:
            for criteria in rule["children"][0]["criteria"]:
                if "matchOperator" in criteria["options"]:
                    rule_match_operators.append(criteria["options"]["matchOperator"])
            if match_operator not in rule_match_operators:
                rule["children"][0]["criteria"].append(path_criteria_body)


def remove_config_path_criteria(rule_name: str, match_operator: str, config_body: dict):
    """
    Gathers information about path match operator names in a specified rule. 
    If there is a criteria with the requested match operator name it will be removed.
    Used for removing DOES_NOT_MATCH_ONE_OF path criteria.
    """
    for rule in config_body["children"]:
        if rule["name"] == rule_name:
            for criteria_num, criteria in enumerate(rule["children"][0]["criteria"]):
                if "matchOperator" in criteria["options"]:
                    if criteria["options"]["matchOperator"] == match_operator:
                        rule["children"][0]["criteria"].pop(criteria_num)


def populate_manifest_values(aggregated_manifests: dict, akamai_config_body: dict, market_name: str, brand_name: str):
    origin_behaviors_path = f'deployer/ALL-MARKET/{brand_name}/origin-behaviors'
    for manifest_body in aggregated_manifests.values():
        manifest_match_values = []
        manifest_not_match_values = []
        manifest_hostname = []
        manifest_rewrite_behavior = {}
        manifest_origin_behavior = {}
        manifest_origin_hostname = ""
        origin_behavior = {}

        manifest_match_values = akamai_utils.get_manifest_path_values(manifest_body = manifest_body,
                                                                      match_operator = "MATCHES_ONE_OF",
                                                                      values_pointer = "values")
        manifest_not_match_values = akamai_utils.get_manifest_path_values(manifest_body = manifest_body,
                                                                          match_operator = "DOES_NOT_MATCH_ONE_OF",
                                                                          values_pointer = "values")
        populate_path_values(rule_name = manifest_body["target_rule_name"], 
                            match_operator = "MATCHES_ONE_OF", 
                            manifest_values = manifest_match_values,
                            config_body = akamai_config_body)
        if manifest_not_match_values:
            # Create DOES_NOT_MATCH_ONE_OF only if we have DOES_NOT_MATCH_ONE_OF in manifest.
            init_config_path_criteria(rule_name = manifest_body["target_rule_name"], 
                                      match_operator = "DOES_NOT_MATCH_ONE_OF", 
                                      config_body = akamai_config_body)
            populate_path_values(rule_name = manifest_body["target_rule_name"], 
                                match_operator = "DOES_NOT_MATCH_ONE_OF", 
                                manifest_values = manifest_not_match_values,
                                config_body = akamai_config_body)
        else:
            # Remove DOES_NOT_MATCH_ONE_OF criteria from config.
            remove_config_path_criteria(rule_name = manifest_body["target_rule_name"], 
                                        match_operator = "DOES_NOT_MATCH_ONE_OF", 
                                        config_body = akamai_config_body)
            
        manifest_hostname = akamai_utils.get_manifest_hostname_values(manifest_body = manifest_body)
        populate_hostname(rule_name = manifest_body["target_rule_name"],
                          hostname_values = manifest_hostname,
                          config_body = akamai_config_body)
        
        # Populate rewrite behavior
        manifest_rewrite_behavior = get_manifest_behavior(manifest_body = manifest_body, behavior_name = "rewriteUrl")
        populate_behavior(rule_name = manifest_body["target_rule_name"], 
                          behavior_name = "rewriteUrl",
                          behavior_body = manifest_rewrite_behavior,
                          config_body = akamai_config_body)

        # Populate origin behavior
        manifest_origin_behavior = get_manifest_behavior(manifest_body = manifest_body, behavior_name = "origin")
        if manifest_origin_behavior != {}:
            manifest_origin_hostname = manifest_origin_behavior["options"]["hostname"]
            try:
                origin_behavior = utils.import_json(f'{origin_behaviors_path}/{manifest_origin_hostname}.json')
            except FileNotFoundError:
                origin_reconstruct_result = bool
                print(f"""
                The origin file "{manifest_origin_hostname}.json" was not detected on the path:
                \t{origin_behaviors_path}/{manifest_origin_hostname}.json\n
                Trying to find "{manifest_origin_hostname}" in existing origin behaviors.""")
                origin_reconstruct_result =  akamai_utils.reconstruct_origin_file(origin_behaviors_path=origin_behaviors_path, origin_hostname=manifest_origin_hostname)
                if origin_reconstruct_result:
                    print("We can proceed.")
                    origin_behavior = utils.import_json(f'{origin_behaviors_path}/{manifest_origin_hostname}.json')
                else:
                    sys.exit(1)
        populate_behavior(rule_name = manifest_body["target_rule_name"],
                          behavior_name = "origin",
                          behavior_body = origin_behavior,
                          config_body = akamai_config_body)

def out_duplicates(duplicate_values, type, fail_on_error: bool = True):
    print(f"\nThere are duplications between {type} manifests and common routes for envs.\nRemove the duplicate routes from the individual env manifest for build to succeed.")
    for env, info in duplicate_values.items():
        print(env)
        for k, v in info.items():
            print(f'  {k}: {v}')
    sys.exit(1) if fail_on_error else None

def out_non_relevant_exclude_values(non_relevant_exclude_values, type, fail_on_error: bool = True):
    print(f"\nThere are `exclude` routes in the {type} manifests that are not present among the common routes.\nRemove `exclude` routes from the individual env manifest for build to succeed.")
    for env, info in non_relevant_exclude_values.items():
        print(env)
        for k, v in info.items():
            print(f'  {k}: {v}')
    sys.exit(1) if fail_on_error else None


def combine_individual_and_common_values(aggregated_manifests: dict, manifest_type: str, common_values: dict, fail_on_error: bool = True):
    """
    Compares individual and common manifest values (routes).
    Performs value (route) checks, and identifies duplicate or non-relevant exclude values.
    Combines individual and common values if there are no errors.
    Updates values in `aggregated_manifests`.
    Updates `common_values` dictionary.

    Args:
        aggregated_manifests: A dictionary with all available aggregated manifests.
        manifest_type: `microservice` or `recommend`
        common_values: A dictionary that stores imported common manifests of a specific type.

    """
    duplicate_values = {}
    non_relevant_exclude_values = {}

    for env_name, manifest_body in aggregated_manifests.items():
        manifest_match_values = []
        manifest_not_match_values = []
        if "include" in manifest_body:
            if manifest_body["include"] != []:
                updated_include_entry = []
                updated_include_entry = resolve_manifest_include_path(manifest_body["include"], manifest_body["manifest_path"])
                manifest_body["include"] = updated_include_entry
                if manifest_body["include"][0] not in common_values:
                    common_values[manifest_body["include"][0]] = utils.import_json(manifest_body["include"][0])

                manifest_match_values, duplicate_values_match, non_relevant_exclude_match_values = merge_path_values(manifest_body, "MATCHES_ONE_OF", common_values[manifest_body["include"][0]])
                manifest_not_match_values, duplicate_values_not_match, non_relevant_exclude_not_match_values = merge_path_values(manifest_body, "DOES_NOT_MATCH_ONE_OF", common_values[manifest_body["include"][0]])

                update_manifest_path_values(manifest_body, "MATCHES_ONE_OF", manifest_match_values)
                update_manifest_path_values(manifest_body, "DOES_NOT_MATCH_ONE_OF", manifest_not_match_values)

                if duplicate_values_match or duplicate_values_not_match:
                    duplicate_values[env_name] = {}
                    if duplicate_values_match:
                        duplicate_values[env_name]["MATCHES_ONE_OF"] = duplicate_values_match
                    if duplicate_values_not_match:
                        duplicate_values[env_name]["DOES_NOT_MATCH_ONE_OF"] = duplicate_values_not_match

                if non_relevant_exclude_match_values or non_relevant_exclude_not_match_values:
                    non_relevant_exclude_values[env_name] = {}
                    if non_relevant_exclude_match_values:
                        non_relevant_exclude_values[env_name]["MATCHES_ONE_OF"] = non_relevant_exclude_match_values
                    if non_relevant_exclude_not_match_values:
                        non_relevant_exclude_values[env_name]["DOES_NOT_MATCH_ONE_OF"] = non_relevant_exclude_not_match_values

    if duplicate_values:
        out_duplicates(duplicate_values, manifest_type, fail_on_error)
    if non_relevant_exclude_values:
        out_non_relevant_exclude_values(non_relevant_exclude_values, manifest_type, fail_on_error)



def main(removed_list, manifest_list: list, market_name: str, brand_name: str, main_comments: str = "", fail_on_error: bool = True) -> None:
    manifests_summary = []
    common_microservice_values = {}
    common_recommend_values = {}

    microservice_config_name = constants.MICROSERVICE_RULE_FILE_NAME
    microservice_config_path = f'deployer/ALL-MARKET/{brand_name}/property-snippets/{microservice_config_name}'
    microservice_body = utils.import_json(json_filepath = microservice_config_path)

    recommend_config_name = constants.RECOMMEND_SERVICE_RULE_FILE_NAME
    recommend_config_path = f'deployer/ALL-MARKET/{brand_name}/property-snippets/{recommend_config_name}'
    recommend_body = utils.import_json(json_filepath = recommend_config_path)

    def remove_rule(rule_name, config_body, config_path):
        isFound = False
        num = None
        for num, rule in enumerate(config_body["children"]):
            if rule["name"] == rule_name:
                isFound = True
                break
        if isFound:
            del config_body["children"][num]
        utils.export_json(json_filepath = config_path, body = config_body, indent = 2)

    """
    Check path affilion to provided market and brand.
    """
    not_affiliated_paths = []
    not_affiliated_paths = check_path_for_market_brand_affiliation(market_name = market_name, brand_name = brand_name, manifest_path_list = manifest_list)
    if not_affiliated_paths:
        print()
        print(f'The following file paths are not affiliated to provided')
        print(f'market: {market_name}')
        print(f'brand: {brand_name}')
        print(f'and will be excluded from the procedure:')
        for manifest_path in not_affiliated_paths:
            print(manifest_path)
        """Subtraction `not_affiliated_paths` list from `manifest_list`"""
        manifest_list = [item for item in manifest_list if item not in not_affiliated_paths]

        print()
        print("The following file paths will be processed:")
        for manifest_path in manifest_list:
            print(manifest_path)


    """
    Work with common manifests if present.
    This block handles common manifests and checks if any changes have been made to them. 
    If there are changes to the paths in the common manifests, those changes will be applied to all environment rules that use the  common manifest as an include entry.
    The block searches for the presence of common manifests in the list of changed files. 
    If a common manifest is found, the function will check all corresponding manifests for the market/brand pair.
    If the common manifest is found as an include in the environment manifest, the path of the environment manifest will be added to the population process.
    """
    common_manifest_path_pattern = f'{market_name}/{brand_name}/common'
    manifest_set = {}
    common_manifest_list = []
    manifest_list_common_affected = []

    for manifest_path in manifest_list:
        if common_manifest_path_pattern in manifest_path:
            common_manifest_list.append(manifest_path)

    if common_manifest_list:
        manifest_set = set(manifest_list) - set(common_manifest_list)
        manifest_list = list(manifest_set)
        current_brand_manifest_list = []

        print()
        print('Shared manifests were found among the modified files:')
        for common_manifest in common_manifest_list:
            print(common_manifest)
            # check for duplicated routes in the common manifest
            common_manifest_body = utils.import_json(common_manifest)
            if akamai_utils.check_manifest_route_duplicates(common_manifest_body, f'{market_name} {brand_name} common'):
                sys.exit(1) if fail_on_error else None


        current_brand_manifest_list = utils.get_nested_files(directory=f'manifest/{market_name}/{brand_name}/')

        for manifest_path in current_brand_manifest_list:
            manifest_body = {}
            manifest_body = utils.import_json(json_filepath=manifest_path)

            if "include" in manifest_body:             
                full_include_entry_list = resolve_manifest_include_path(include_entry = manifest_body["include"],
                                                                  manifest_path = manifest_path)
                for full_include_entry in full_include_entry_list:
                    if full_include_entry in common_manifest_list:
                        manifest_list_common_affected.append(manifest_path)
        print()
        print('The following manifests are using common manifest as `include`, so they will be added to the current population process:')
        for manifest_path in manifest_list_common_affected:
            print(manifest_path)

        manifest_list = manifest_list + manifest_list_common_affected
        manifest_list = utils.remove_list_duplicates(input_list = manifest_list, sort = True)


    """
    Import all env manifests into one single aggregated_manifests list.
    Add rule templates for added manifests.
    """
    aggregated_microservice_manifests = {}
    aggregated_recommend_manifests = {}
    for manifest_path in manifest_list:
        manifest_body = {}
        rule_template = {}
        env_group = ""
        env_name = ""
        manifest_type = ""
        env_group, env_name, manifest_type = parse_manifest_path(manifest_path = manifest_path)
        manifests_summary.append({
          "manifest_path": manifest_path,
          "env_group": env_group,
          "env_name": env_name,
          "manifest_type": manifest_type
          })
        
        body = copy.deepcopy(microservice_body)
        if manifest_type == "recommend":
            body = copy.deepcopy(recommend_body)

        target_rule_name = akamai_utils.generate_rule_name(market_name = market_name, env_name = env_name, type_name = manifest_type, env_group = env_group)
        if os.path.exists(manifest_path):
            manifest_body = utils.import_json(json_filepath = manifest_path)
            manifest_body["manifest_path"] = manifest_path
            manifest_body["manifest_type"] = manifest_type
            manifest_body["target_rule_name"] = target_rule_name
            rule_present = False
            for rule in body["children"]:
                if rule_template == {}:
                    rule_template = copy.deepcopy(rule)

                if rule["name"] == target_rule_name:
                    rule_present = True
                    break

            if not rule_present:
                rule_template["children"][0]["name"] = manifest_body["name"]
                rule_template["name"] = manifest_body["target_rule_name"]
                body["children"].append(rule_template)

            if manifest_type == "recommend":
                aggregated_recommend_manifests[env_group] = manifest_body
                recommend_body = copy.deepcopy(body)
            else:
                aggregated_microservice_manifests[env_name] = manifest_body
                microservice_body = copy.deepcopy(body)


    # Remove rules which manifests were deleted or renamed
    if removed_list:
        for path in removed_list:
            env_group, env_name, manifest_type = parse_manifest_path(manifest_path = path)
            target_rule_name = akamai_utils.generate_rule_name(market_name = market_name, env_name = env_name, type_name = manifest_type, env_group = env_group)
            if manifest_type == 'microservice':
                remove_rule(target_rule_name, microservice_body, microservice_config_path)
            else:
                remove_rule(target_rule_name, recommend_body, recommend_config_path)
    
    # Update individual manifest routes to the state ready to be added to the Akamai config.
    if aggregated_microservice_manifests:
        combine_individual_and_common_values(aggregated_microservice_manifests, 'microservice', common_microservice_values, fail_on_error)
    if aggregated_recommend_manifests:
        combine_individual_and_common_values(aggregated_recommend_manifests, 'recommendation', common_recommend_values, fail_on_error)

    """
    Populate values from manifests
    """
    if aggregated_microservice_manifests:
        populate_manifest_values(akamai_config_body = microservice_body, 
                                aggregated_manifests = aggregated_microservice_manifests,
                                market_name = market_name,
                                brand_name = brand_name)
        """Export updated Microservice_shop.json"""
        utils.export_json(json_filepath = microservice_config_path,
                          body = microservice_body,
                          indent = 2)
        
    if aggregated_recommend_manifests:
        populate_manifest_values(akamai_config_body = recommend_body, 
                                aggregated_manifests = aggregated_recommend_manifests,
                                market_name = market_name,
                                brand_name = brand_name)
        """Export updated recommendations_service.json"""
        utils.export_json(json_filepath = recommend_config_path,
                          body = recommend_body,
                          indent = 2)

    # Add/Change comments in main.json
    main_config_name = "main.json"
    main_config_path = f'deployer/ALL-MARKET/{brand_name}/property-snippets/{main_config_name}'
    main_config_body = {}
    main_config_body = utils.import_json(json_filepath = main_config_path)

    # Only update if main_comments is not empty
    if main_comments != "":
        main_config_body["comments"] = main_comments
    utils.export_json(json_filepath = main_config_path,
                      body = main_config_body,
                      indent = 2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--market_name', type=str, required=False)
    parser.add_argument('--brand_name', type=str, required=False)
    parser.add_argument('--main_comments', type=str, required=False)
    parser.add_argument('--manifest_list', nargs='+', type=str, required=True)
    parser.add_argument('--removed_list', nargs='*', type=str, required=False)
    args = parser.parse_args()

    market_name = args.market_name
    brand_name = args.brand_name
    manifest_list = args.manifest_list
    if args.main_comments != None:
        main_comments = args.main_comments
    else:
        main_comments = ""
    removed_list = args.removed_list
    if args.removed_list:
        removed_list = args.removed_list
    else:
        removed_list = []


    """
    If no info about market/brand were provided, we should detect it first based in the list of paths that were provided.
    """
    if (market_name == None) or (brand_name == None):
        market_name_detected = []
        brand_name_detected = []
        market_name_detected, brand_name_detected = get_market_brand_names(manifest_path_list = manifest_list)
        if len(market_name_detected) > 1:
            sys.exit('''More than one market name was detected in the manifest_list, can't proceed.''')
        else:
            market_name = market_name_detected[0]
        if len(brand_name_detected) > 1:
            sys.exit('''More than one brand name was detected in the manifest_list, can't proceed.''')
        else:
            brand_name = brand_name_detected[0]

    main(removed_list, manifest_list = manifest_list,
        market_name = market_name,
        brand_name = brand_name,
        main_comments = main_comments)
