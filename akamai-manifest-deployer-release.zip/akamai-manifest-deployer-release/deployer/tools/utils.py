import json
import os
import subprocess
import sys


def import_json(json_filepath: str):
    """
    Common function for importing json data.
    Accepts path to json file.
    Outputs json body as a result.
    """
    result = None
    with open(json_filepath, "r") as infile:
        result = json.load(infile)
    return result


def export_json(json_filepath: str, body, indent: int = 2):
    """
    Common function for exporting json data.
    Example:
    my_dict = {'name': 'hostname'}
    utils.export_json(json_filepath = 'my_dict.json',
                    body = my_dict,
                    indent = 2)
    """
    json_object = None
    json_object = json.dumps(body, indent=indent)
    with open(json_filepath, "w") as outfile:
        outfile.write(json_object)


def get_list_duplicates(input_list: list) -> list:
    """
    Checks if the duplicates are present in input list, returns a list of duplicates.
    Example:
    input_list = ['A', 'B', 'C', 'A']
    duplicate_list = ['A']
    """
    unique_list = []
    duplicate_list = []
    for item in input_list:
        if item in unique_list:
            duplicate_list.append(item)
        else:
            unique_list.append(item)
    return duplicate_list


def remove_list_duplicates(input_list: list, sort: bool = False) -> list:
    """
    Returns input list without duplicated values, the output list could be sorted if required.
    Example:
    my_list = ['C', 'A', 'B', 'A']
    my_result = utils.remove_list_duplicates(input_list=my_list,sort=True)
    print(my_result)

    ['A', 'B', 'C']
    """
    result = list(set(input_list))
    if sort == True:
        result.sort()
    return result


def get_nested_files(directory: str) -> list:
    """
    This function takes in a directory path as an argument and returns a 
    list of all nested files within that directory.
    This function could be useful for searching for specific files within a nested 
    directory structure, or for simply getting a list of all files within a directory for further processing.
    """
    result = []
    for root, _, files in os.walk(directory):
        for file in files:
            result.append(os.path.join(root, file))
    return result


def init_directory_path(directory_path: str):
    """This function creates a directory at the specified path, if it does not already exist."""
    directory_exists = False
    directory_exists = os.path.exists(directory_path)
    if directory_exists == False:
        path = os.path.join(directory_path)
        os.makedirs(path)


def run(cmd, print_cmd: bool = True):
    """Print cmd and run it."""

    # Allow the user to pass a whitespace-separated string instead of a list, for cases where you
    # know the input doesn't have quoting issues (e.g., run('ls /')).
    if isinstance(cmd, str):
        cmd = cmd.strip().split()

    if print_cmd:
        # Print the command as a series of strings, with quotes if an arg
        # contains a space.  This looks more natural than the raw list.
        print(' '.join((f"'{x}'" if ' ' in x else x) for x in cmd))

    subprocessArgs = {
        'args': cmd,
        'check': True,
        'encoding': 'UTF-8',
        'universal_newlines': True,
        'capture_output': True
    }

    try:
        result = subprocess.run(**subprocessArgs)
    except subprocess.CalledProcessError as err:
        err_msg = "Exception when calling subprocess: "
        if hasattr(err, 'stderr'):
            err_msg += str(err.stderr)
        else:
            err_msg += str(err.stdout)
        sys.exit(err_msg)

    return result.stdout


def compare_before_after_lists(before_list: list, after_list: list):
    """
    Compare `before` and `after` lists and return the items that were added and removed.

    Args:
        before_list: A list representing the original state.
        after_list: A list representing the updated state.

    Returns:
        A tuple of two lists, where the first list contains the items that were
        added to the `after` list, and the second list contains the items that
        were removed from the `before` list.
    """
    items_added = list(set(after_list) - set(before_list))
    items_removed = list(set(before_list) - set(after_list))
    return items_added, items_removed


def compare_before_after_dicts(before_dict, after_dict):
    """
    Returns `items_changed`, items that are in `before` and `after`
    Returns `items_removed`, items are present only in `before`
    Returns `items_added`, items are present only in `after`
    """
    items_changed = []
    items_removed = []
    items_added = []

    def compare_a_b(a_item, b_item, a_unique, ab_changed):
        for i in a_item:
            if i in b_item:
                if a_item[i] != b_item[i]:
                    ab_changed.append(i)
            else:
                a_unique.append(i)
        return ab_changed, a_unique

    items_changed, items_removed = compare_a_b(before_dict, after_dict, items_removed, items_changed)
    items_changed, items_added = compare_a_b(before_dict, after_dict, items_added, items_changed)
    items_changed = list(set(items_changed))
    return items_changed, items_removed, items_added

