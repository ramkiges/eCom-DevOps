AKAMAI_MARKET_BRAND_PROPERTY_MAPPING = {
  "mg-test": {
    "USA": {
      "PROD": "prod.markandgraham.com_pm",
      "QA": "qa.markandgraham.com_pm_clone_devops"
    }
  },
  "mg": {
    "USA": {
      "PROD": "prod.markandgraham.com_pm",
      "QA": "qa.markandgraham.com_pm"
    },
    "CAN": {
      "PROD": "prod.markandgraham.com_pm",
      "QA": "qa.markandgraham.com_pm"
    }
  },
  "pb": {
    "USA": {
      "PROD": "prod.potterybarn.com_pm",
      "QA": "qa.potterybarn.com_pm"
    },
    "CAN": {
      "PROD": "prod.potterybarn.ca_pm",
      "QA": "qa.potterybarn.com_pm"
    }
  },
  "pk": {
    "USA": {
      "PROD": "prod.potterybarnkids.com_pm",
      "QA": "qa.potterybarnkids.com_pm"
    },
    "CAN": {
      "PROD": "prod.potterybarnkids.ca_pm",
      "QA": "qa.potterybarnkids.com_pm"
    }
  },
  "pt": {
    "USA": {
      "PROD": "prod.pbteen.com_pm",
      "QA": "qa.pbteen.com_pm"
    },
    "CAN": {
      "PROD": "prod.pbteen.ca_pm",
      "QA": "qa.pbteen.com_pm"
    }
  },
  "we": {
    "USA": {
      "PROD": "prod.westelm.com_pm",
      "QA": "qa.westelm.com_pm"
    },
    "CAN": {
      "PROD": "prod.westelm.ca_pm",
      "QA": "qa.westelm.com_pm"
    }
  },
  "ws": {
    "USA": {
      "PROD": "prod.williams-sonoma.com_pm",
      "QA": "qa.williams-sonoma.com_pm"
    },
    "CAN": {
      "PROD": "prod.williams-sonoma.ca_pm",
      "QA": "qa.williams-sonoma.com_pm"
    }
  },
  "rj": {
    "USA": {
      "PROD": "prod.rejuvenation.com_pm",
      "QA": "qa.rejuvenation.com_pm"
    },
    "CAN": {
      "QA": "qa.rejuvenation.com_pm"
    }
  },
  "gr": {
    "USA": {
      "PROD": "prod.greenrow.com_pm",
      "QA": "qa.greenrow.wsgc.com_pm"
    },
    "CAN": {
      "QA": "qa.greenrow.wsgc.com_pm"
    }
  }
}

AKAMAI_DOCKER_IMAGE = 'container-registry01.nonprod.wsgc.com/ecom/akamai/shell:v2.8.1'
ALL_MARKET = 'ALL-MARKET'
MICROSERVICE_RULE_FILE_NAME = 'Microservice_shop.json'
RECOMMEND_SERVICE_RULE_FILE_NAME = 'recommendations_service.json'
AKAMAI_RULE_FORMAT_VERSION = 'v2023-05-30'
