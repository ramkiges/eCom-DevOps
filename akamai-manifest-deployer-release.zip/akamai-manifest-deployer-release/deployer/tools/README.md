## Akamai Manifest Deployer Tools

The Akamai manifest deployer tools are a collection of scripts located in the `deployer/tools` folder. These tools provide functionality related to deploying and managing manifests on the Akamai network.

Here is a brief overview of the available tools and their functionalities:

- ### check_property_activation_status.py

The script checks the activation status of an Akamai property using the Akamai API. It retrieves the activation status of the specified property and determines if there are any pending activations. 

#### Example

```shell
python3 check_property_activation_status.py \
    --akamai_edgerc_path ~/.edgerc \
    --brand_name mg-test \
    --akamai_property_network production
```

If there are pending activations for the specified property and network, the script will output a message indicating their presence. Otherwise, it will exit with a success code.

For any errors that occur during the activation status retrieval, an appropriate error message will be displayed.

#### Requirements

- Python 3.x
- module edgegrid-python

