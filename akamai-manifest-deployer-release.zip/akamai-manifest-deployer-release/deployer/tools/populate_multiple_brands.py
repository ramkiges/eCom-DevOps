#!/usr/bin/env python3

"""
Script for populating data from the manifest list that contains paths with multiple market/brand pairs. 
Do sorting for all passed manifests paths and split it into the form that could be passed to `populate_single_brand.py`:

    MARKET - BRAND - manifest_list
    USA - mg-test - manifest_list
    USA - mg - manifest_list

During the execution, all gathered information from manifests, configs, and so on is stored in temporary dictionaries.
For debugging purposes, you can add the following code snippets to the main function to check the temporary essences:

    utils.export_json(json_filepath = "market_brand_pairs.json",
                      body = market_brand_pairs,
                      indent = 2)
    utils.export_json(json_filepath = "market_brand_map.json",
                      body = market_brand_map,
                      indent = 2)

Example run:
python3 deployer/tools/populate_multiple_brands.py \ 
    --manifest_list manifest/USA/mg-test/qa/qa1/microservice.json \
                    manifest/USA/mg-test/qa/qa14/microservice.json \
                    manifest/USA/mg/perf/perf/microservice.json \
                    manifest/USA/mg/regression/regression/microservice.json \
                    manifest/USA/ws/regression/regression2/microservice.json \
                    manifest/USA/ws/staging/staging/microservice.json \
                    manifest/CA/ws/uat/uat3/microservice.json \
                    manifest/CA/ws/uat/uat6/microservice.json

(Optional) Comment string could be optionally passed and populated to main.json as a `comments` entry (--main_comments). 
Result: String will be present on LUNA UI Version History page.
"""
import argparse
import populate_single_brand

def get_market_brand_name_pairs(manifest_list: list) -> list:
    """
    Returns all found market/brand pairs from the paths provided.
    Example:
    manifest_list = [
      'manifest/USA/mg-test/qa/qa1/microservice.json',
      'manifest/USA/mg/qa/qa14/microservice.json',
      'manifest/CA/mg-test/perf/perf/microservice.json'
      ]
    ---
    result = {
      'USA': [ 'mg-test', 'mg' ],
      'CA': [ 'mg-test' ]
    }
    """
    market_brand_pairs = {}
    for manifest_path in manifest_list:
        market_name = manifest_path.split('/')[1]
        brand_name = manifest_path.split('/')[2]
        if market_name not in market_brand_pairs:
            market_brand_pairs[market_name] = []
            market_brand_pairs[market_name].append(brand_name)
        else:
            if brand_name not in market_brand_pairs[market_name]:
               market_brand_pairs[market_name].append(brand_name)
    return market_brand_pairs


def get_filepath_by_market_brand(manifest_list: list, market_name: str, brand_name: str) -> list:
    """
    Returns all found paths that have specified the requested market/brand pair.
    Example:
    manifest_list = [
      'manifest/USA/mg-test/qa/qa1/microservice.json',
      'manifest/USA/mg/qa/qa14/microservice.json',
      'manifest/CA/mg-test/perf/perf/microservice.json'
      ]
    market_name = "USA"
    brand_name = "mg-test"
    ---
    result = [ 'manifest/USA/mg-test/qa/qa1/microservice.json' ]
    """
    result = []
    for manifest_path in manifest_list:
        if f'manifest/{market_name}/{brand_name}/' in manifest_path:
            result.append(manifest_path)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest_list', nargs='+', type=str, required=True)
    parser.add_argument('--main_comments', type=str, required=False)
    args = parser.parse_args()

    manifest_list = args.manifest_list
    if args.main_comments != None:
        main_comments = args.main_comments
    else:
        main_comments = ""
    market_brand_pairs = []
    market_brand_map = {}

    market_brand_pairs = get_market_brand_name_pairs(manifest_list=manifest_list)

    for market_name, market_brands in market_brand_pairs.items():
        for brand_name in market_brands:
            filtered_filepath_list = []
            filtered_filepath_list = get_filepath_by_market_brand(manifest_list=manifest_list, 
                                                                  market_name=market_name, 
                                                                  brand_name=brand_name)
            if market_name not in market_brand_map:
                market_brand_map[market_name] = {}
                market_brand_map[market_name][brand_name] = filtered_filepath_list
            else:
                if brand_name not in market_name:
                    market_brand_map[market_name][brand_name] = filtered_filepath_list

    for market_name, market_brands in market_brand_map.items():
        for brand_name, manifest_list in market_brands.items():
            populate_single_brand.main(manifest_list = manifest_list,
                                      market_name = market_name,
                                      brand_name = brand_name,
                                      main_comments = main_comments)







