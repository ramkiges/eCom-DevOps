import json
import sys
import os
import subprocess

from utils import compare_before_after_dicts, run

"""
Detects changes made outside of the manifest to routes and behaviours of the hosts
get relative path to plan file as an argument

Example run:
    python3 ../../tools/plan_parse.py staging-plan-output
"""


def get_plan_before_after(plan):
    """
    Parses plan and returns before and after as separate dictionaries for future analysis. 
    """

    before = {
        'akamai_property': None,
        'akamai_property_activation': None,
        'akamai_edge_hostname': None
    }

    after = {
        'akamai_property': None,
        'akamai_property_activation': None,
        'akamai_edge_hostname': None
    }

    if 'resource_drift' in plan:
        """
        Check if 'before' and 'after' fields exist in plan
        and get according akamai config before changes and
        akamai config after made in the UI changes 
        """
        for resource in plan['resource_drift']:
            if resource['type'] == 'akamai_property':
                if 'before' in resource["change"]:
                    before['akamai_property'] = json.loads(resource["change"]["before"]["rules"])['rules']
                else:
                    print("No rules exist in terraform state")
                    sys.exit(0)
                if 'after' in resource["change"]:
                    after['akamai_property'] = json.loads(resource["change"]["after"]["rules"])['rules']
                else:
                    print("No rules exist in akamai config")
                    sys.exit(0)
    else:
        """
        Perform this part to get short output
        for the planned changes in terraform
        """
        for obj in plan["resource_changes"]:
            if ("no-op" not in obj["change"]["actions"]) and ("create" not in obj["change"]["actions"]):
                if obj['type'] == 'akamai_property':
                    if obj["change"]["before"] and ("rules" in obj["change"]["after"]):
                        before['akamai_property'] = json.loads(obj["change"]["before"]["rules"])['rules']
                    if obj["change"]["after"] and ("rules" in obj["change"]["after"]):
                        after['akamai_property'] = json.loads(obj["change"]["after"]["rules"])['rules']
                if obj['type'] == 'akamai_property_activation':
                    if obj["change"]["before"]:
                        before['akamai_property_activation'] = obj["change"]["before"]
                    if obj["change"]["after"]:
                        after['akamai_property_activation'] = obj["change"]["after"]
                if obj['type'] == 'akamai_edge_hostname':
                    if obj["change"]["before"]:
                        before['akamai_edge_hostname'] = obj["change"]["before"]
                    if obj["change"]["after"]:
                        after['akamai_edge_hostname'] = obj["change"]["after"]
    return before, after


def detect_major_changes(root_child, before_changes, all_rules, added_rules):
    """
    Major changes == manifest related changes, are located only in `Microservice_shop` and `recommendations_service`.
    Works exclusively with 'Microservice_shop' or 'recommendations_service' object and its created dict as arguments
    and compare state for each child object between actual one and the one from the dict
    """
    change_detected = ""
    for shop_child in root_child['children']:
        if 'children' in shop_child:
            if len(shop_child['children']) == 1:
                all_rules.append(shop_child['name'])
                if shop_child['name'] in before_changes:
                    if shop_child['children'][0] != before_changes[shop_child['name']]:
                        if shop_child['children'][0]['behaviors'] != before_changes[shop_child['name']]['behaviors']:
                            after_rewrite = None
                            after_origin = None
                            before_rewrite = None
                            before_origin = None
                            for item in shop_child['children'][0]['behaviors']:
                                if item['name'] == 'rewriteUrl':
                                    after_rewrite = item
                                if item['name'] == 'origin':
                                    after_origin = item['options']['hostname']

                            for compare_item in before_changes[shop_child['name']]['behaviors']:
                                if compare_item['name'] == 'rewriteUrl':
                                    before_rewrite = compare_item
                                if compare_item['name'] == 'origin':
                                    before_origin = compare_item['options']['hostname']

                            if (after_rewrite and before_rewrite) and (after_rewrite != before_rewrite):
                                change_detected += f"\n{shop_child['name']} changed behavior 'rewriteUrl':\n-before-\n{before_rewrite}\n-after-\n{after_rewrite}\n"
                            elif after_rewrite and not before_rewrite:
                                change_detected += f"\n{shop_child['name']} behavior 'rewriteUrl' added:\n{after_rewrite}\n"
                            elif before_rewrite and not after_rewrite:
                                change_detected += f"\n{shop_child['name']} behavior 'rewriteUrl' deleted:\n{before_rewrite}\n"

                            if (after_origin and before_origin) and (after_origin != before_origin):
                                change_detected += f"\n{shop_child['name']} changed behavior 'origin':\nhostname = {before_origin} -> {after_origin}\n"
                            elif after_origin and not before_origin:
                                change_detected += f"\n{shop_child['name']} behavior 'origin' added:\nhostname = {after_origin}\n"
                            elif before_origin and not after_origin:
                                change_detected += f"\n{shop_child['name']} behavior 'origin' deleted:\nhostname = {before_origin}\n"

                        if shop_child['children'][0]['criteria'] != before_changes[shop_child['name']]['criteria']:
                            after_not_match = None
                            before_not_match = None
                            for item in shop_child['children'][0]['criteria']:
                                if item['options']['matchOperator'] == 'MATCHES_ONE_OF':
                                    after_match = set(item['options']['values'])
                                if item['options']['matchOperator'] == 'DOES_NOT_MATCH_ONE_OF':
                                    after_not_match = set(item['options']['values'])

                            for compare_item in before_changes[shop_child['name']]['criteria']:
                                if compare_item['options']['matchOperator'] == 'MATCHES_ONE_OF':
                                    before_match = set(compare_item['options']['values'])
                                if compare_item['options']['matchOperator'] == 'DOES_NOT_MATCH_ONE_OF':
                                    before_not_match = set(compare_item['options']['values'])

                            if after_not_match and not before_not_match:
                                change_detected += f"\n{shop_child['name']} added 'DOES_NOT_MATCH_ONE_OF' routes:\n{after_not_match}\n"
                            elif before_not_match and not after_not_match:
                                change_detected += f"\n{shop_child['name']} deleted 'DOES_NOT_MATCH_ONE_OF' routes:\n{before_not_match}\n"
                            elif (after_not_match and before_not_match) and (after_not_match != before_not_match):
                                added = after_not_match - before_not_match
                                deleted = before_not_match - after_not_match 
                                if added:
                                    change_detected += f"\n{shop_child['name']} added 'DOES_NOT_MATCH_ONE_OF' routes:\n{added}\n"
                                if deleted:
                                    change_detected += f"\n{shop_child['name']} deleted 'DOES_NOT_MATCH_ONE_OF' routes:\n{deleted}\n"

                            added = after_match - before_match
                            deleted = before_match - after_match
                            if added:
                                change_detected += f"\n{shop_child['name']} added 'MATCHES_ONE_OF' routes:\n{added}\n"
                            if deleted:
                                change_detected += f"\n{shop_child['name']} deleted 'MATCHES_ONE_OF' routes:\n{deleted}\n"
                else:
                    added_rules.append(shop_child['name'])    
            else:
                sys.exit(f"The number of child rules for {shop_child['name']} should be 1 ({root_child['name']})")
        else:
            sys.exit(f"No child object for for {shop_child['name']} ({root_child['name']})")
    return change_detected


def detect_property_activation_changes(before, after):
    property_activation_ignore = ['contact', 'note', 'version']
    property_activation_critical = ['network']
    property_activation_changes, _, _ = compare_before_after_dicts(before, after)
    minor_changes = False   # changes that affect the `akamai-manifest` repository update, but not `akamai-manifest-deployer`

    for change in property_activation_changes:
        if change in property_activation_critical:
            sys.exit(
                f"ERROR: Critical changes have been detected within the `akamai_property_activation`.\n"
                f"{change}: {before[change]} --> {after[change]} ")
        elif change in property_activation_ignore:
            pass
        else:
            minor_changes = True
    return minor_changes


def detect_property_changes(before, after):
    property_root_changes = []
    property_root_add = []
    property_root_remove = []
    changes_msg = ''
    minor_changes = False   # changes that affect the `akamai-manifest` repository update, but not `akamai-manifest-deployer`
    major_changes = False   # changes that affect the `akamai-manifest` and `akamai-manifest-deployer` repository update

    property_root_changes, property_root_remove, property_root_add = compare_before_after_dicts(before, after)

    if property_root_add or property_root_remove:
        minor_changes = True

    if property_root_changes:
        if 'children' in property_root_changes:
            changes_msg = detect_property_children_changes(before['children'], after['children'])
            if changes_msg:
                major_changes = True
            else:
                minor_changes = True
        else:
            minor_changes = True
    return changes_msg, major_changes, minor_changes


def detect_property_children_changes(before, after):
    """
    Create dict of environment names and their state after changes
    for 'Microservice_shop' and 'recommendations service' child objects

    Sample "before" field from plan (same for "after"):
    "before": {
        "contact": null,
        "contract": "ctr_1-2ZMIM5",
        "contract_id": "ctr_1-2ZMIM5",
        "cp_code": null,
        "group": "grp_197887",
        "group_id": "grp_197887",
        ...
        "rule_format": "v2023-05-30",
        "rule_warnings": [],
        "rules": "{\"rules\":{\"advancedOverride\":\"\\u003c!-- Ensure this code is not executed by Image Manager --\\u003e\\n\\u003cmatch:request.method 
        value=\\\"AKAMAI_FETCH\\\" result=\\\"false\\\"\\u003e\\n\\t\\u003cmatch:request.header name=\\\"User-Agent\\\" result=\\\"false\\\" 
        value=\\\"*AkamaiImageServer*\\\" value-wildcard=\\\"on\\\" value-case=\\\"off\\\"\\u003e\\n\\t\\t\\u003cmatch:request.header name=\\\"X-IM-ImageManagerRequired\\\" 
        value=\\\"true\\\" result=\\\"false\\\" value-case=\\\"off\\\"\\u003e\\n\\n\\t\\t\\t\\u003c!-- Origin Health Detect Settings --\\u003e\\n\\t\\t\\t\\u003cforward:cache-parent.non-tail-connect-
            ...
        {\"description\":\"Edgescape Data\",\"hidden\":false,\"name\":\"PMUSER_INCOMING_GEODATA\",\"sensitive\":false,\"value\":\"Null\"},
        {\"description\":\"Country Code\",\"hidden\":false,\"name\":\"PMUSER_COUNTRY_CODE\",\"sensitive\":false},{\"description\":\"Region Code\",\"hidden\":false,\"name\":\"PMUSER_REGION_CODE\",\"sensitive\":false},
        {\"description\":\"Zip Code\",\"hidden\":false,\"name\":\"PMUSER_ZIP_CODE\",\"sensitive\":false},{\"description\":\"Latitude\",\"hidden\":false,\"name\":\"PMUSER_LAT\",\"sensitive\":false},
        {\"description\":\"Longitude\",\"hidden\":false,\"name\":\"PMUSER_LONG\",\"sensitive\":false},{\"description\":\"Extracts Origin header value\",\"hidden\":false,\"name\":\"PMUSER_ACAO\",\"sensitive\":false,\"value\":\"null\"},
        {\"hidden\":false,\"name\":\"PMUSER_EW_DEBUG_KEY\",\"sensitive\":true,\"value\":\"baf38e8e1e63f9239ab7aa011297a69ce19231a6d4fa982e3835c335b0ff5483\"}]}}",
        "staging_version": 0,
        "variables": null
    }
    """
    microservice_name = "Microservice_shop"
    recommendations_name = "recommendations_service"
    major_rule_groups = [microservice_name, recommendations_name]

    before_changes_shop = {}
    before_changes_recommendations = {}

    for root_child in before:
        if root_child['name'] in major_rule_groups:
            if 'children' in root_child:
                for shop_child in root_child['children']:
                    if 'children' in shop_child:
                        if len(shop_child['children']) == 1:
                            if root_child['name'] == microservice_name:
                                before_changes_shop[shop_child['name']] = shop_child['children'][0]
                            elif root_child['name'] == recommendations_name:
                                before_changes_recommendations[shop_child['name']] = shop_child['children'][0]
                        else:
                            sys.exit(f"The number of child rules for {shop_child['name']} should be 1 ({root_child['name']})")
                    else:
                        sys.exit(f"No child object for for {shop_child['name']} ({root_child['name']})")
            else:
                sys.exit(f"No child object for {root_child['name']}")      

    added_rules_shop = []
    added_rules_recommendations = []
    all_rules_shop = []
    all_rules_recommendations = []
    changes_msg = ''
    shop_change_detected = ''
    recommend_change_detected = ''

    for root_child in after:
        if root_child['name'] in major_rule_groups:
            if 'children' in root_child:
                if root_child['name'] == microservice_name:
                    shop_change_detected = detect_major_changes(root_child, before_changes_shop, all_rules_shop, added_rules_shop)
                elif root_child['name'] == recommendations_name:
                    recommend_change_detected = detect_major_changes(root_child, before_changes_recommendations, all_rules_recommendations, added_rules_recommendations)
            else:
                sys.exit(f"No child object for {root_child['name']}")

    if shop_change_detected != "":
        changes_msg += f"Changes for {microservice_name}:\n{shop_change_detected}\n"
    if recommend_change_detected != "":
        changes_msg += f"Changes for {recommendations_name}:\n{recommend_change_detected}\n"

    if added_rules_shop:
        changes_msg += f"New rules added for hosts in {microservice_name}:\n{added_rules_shop}"
    if added_rules_recommendations:
        changes_msg += f"New rules added for hosts in {recommendations_name}:\n{added_rules_recommendations}"

    deleted_rules_shop = set(before_changes_shop.keys()) - set(all_rules_shop)
    deleted_rules_recommendations = set(before_changes_recommendations.keys()) - set(all_rules_recommendations)
    if deleted_rules_shop:
        changes_msg += f"Rules deleted for hosts in {microservice_name}:\n{deleted_rules_shop}"
    if deleted_rules_recommendations:
        changes_msg += f"Rules deleted for hosts in {recommendations_name}:\n{deleted_rules_recommendations}"

    return changes_msg


if __name__ == "__main__":

    plan_filename = sys.argv[1]

    terraform_show_cmd = f"terraform show -no-color -json {plan_filename}"
    plan = json.loads(run(terraform_show_cmd, print_cmd=False))

    """
    The `result` dictionary is what the script will return in overall.
    `changes` : contains a string that describes changes that we are able to parse and display as a simple output. 
    `major_changes` : tells us that changes connected to the `manifests` are present, that potentially could point that drift is present.
    `minor_changes` : changes that are not connected to manifest and should not be recognized as a drift.
    """
    result = {
        'changes': '',
        'major_changes': False,
        'minor_changes': False,
    }

    activation_minor_changes = False
    property_major_changes = False      # changes that affect the `akamai-manifest` and `akamai-manifest-deployer` repository update
    property_minor_changes = False      # changes that affect the `akamai-manifest` repository update, but not `akamai-manifest-deployer`
    property_changes_msg = ''

    before, after = get_plan_before_after(plan)

    if before['akamai_property_activation'] and after['akamai_property_activation']:
        activation_minor_changes = detect_property_activation_changes(before['akamai_property_activation'], after['akamai_property_activation'])
    elif (before['akamai_property_activation'] and not after['akamai_property_activation']) or (not before['akamai_property_activation'] and after['akamai_property_activation']):
        result['minor_changes'] = True

    if before['akamai_property'] and after['akamai_property']:
        property_changes_msg, property_major_changes, property_minor_changes = detect_property_changes(before['akamai_property'], after['akamai_property'])
    elif (before['akamai_property'] and not after['akamai_property']) or (not before['akamai_property'] and after['akamai_property']):
        result['major_changes'] = True

    if before['akamai_edge_hostname'] or after['akamai_edge_hostname']:
        result['minor_changes'] = True

    if property_changes_msg:
        result['changes'] = property_changes_msg

    if property_major_changes:
        result['major_changes'] = True

    if activation_minor_changes or property_minor_changes:
        result['minor_changes'] = True


    print(json.dumps(result))
