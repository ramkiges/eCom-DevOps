# To Execute this script, run: powershell -ExecutionPolicy ByPass -File C:\Users\svcsqauser\scripts\PurgeEvergreenTemp.ps1
# Evergreen creates several folders to hold 

$path = 'C:\bvt_workspace\workspace'

# We will clean files older than this amount of days
$old = 3
$sleep = 7200
	
while (1) {

	$now = Get-Date
	# Path to the folder we will execute the cleanup
	
	# Collects folder size for reporting
	$beforeCleanup = (Get-ChildItem $path | Measure-Object -property length -sum)

	# Recursive Deletes folders/object that match our date criteria
	Get-ChildItem $path -Recurse |
	Where-Object {-not $_.PSIsContainer -and $now.Subtract($_.CreationTime).Days -gt $old } |
	Remove-Item

	# Use `-WhatIf` to check what files would be deleted without deleting.
	#Remove-Item -WhatIf

	$afterCleanup = (Get-ChildItem $path | Measure-Object -property length -sum)

	$reclaimedSpace = $beforeCleanup.sum - $afterCleanup.sum

	"Before: {0:N2}" -f ($reclaimedSpace.sum / 1MB)
	"After: {0:N2}" -f ($afterCleanup.sum / 1MB)
	"Total reclaimed space:" + "{0:N2}" -f ($reclaimedSpace / 1MB) + " MB"

	# chill for a while before we start again
	"And now we wait... " + $sleep + " seconds"
	Start-Sleep -s $sleep
}
