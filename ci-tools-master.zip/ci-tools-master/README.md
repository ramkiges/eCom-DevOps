CI Tools
========
Generally useful scripts available in the CI environment.

As a Maven project, will build `wsgc-devops-toolchain-ci-tools`, for
use by the Jenkins master and slaves.

### Sanity Checks
Provides a group of checks to test if a maven project
is in conformity with WSI standards.

To run sanity-checks tests execute:

```bash
    cd sanity-checks
    make test
```