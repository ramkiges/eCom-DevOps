#!/bin/bash

# This script main purpose is to push the same release version of Sacramento to Ashburn registry

set +x
url="${JOB_URL}/lastSuccessfulBuild/consoleText"
# Fetch the k8s package git url from the jenkins console output.
giturl=$(curl -k -s "$url" | grep -w 'Checking out' | awk -F" " '{print $4}' | tr -d "'" | awk -F"#" '{print $1}')

echo "$giturl"
SCRATCH=$(mktemp -d -t tmp.XXXX)
git clone --depth 1 "$giturl" "$SCRATCH"

# Capture the registry,project and orgname from pomfile.
sacRegistry=$(grep -Po '<docker\.registry>\K[^<]*' "$SCRATCH/pom.xml")
projectname=$(grep -Po '<helm\.project\.name>\K[^<]*' "$SCRATCH/pom.xml")
orgname=$(grep -Po '<docker\.base>\K[^<]*' "$SCRATCH/pom.xml" | awk -F"/" '{print $2}')
repository="$sacRegistry"/"$orgname"/"$projectname"
echo "$sacRegistry"
echo "$projectname"
echo "$orgname"
echo "$repository"

rm -rf "$SCRATCH"

sacRepository="container-registry02.wsgc.com/$orgname/$projectname"

if [[ $repository != $sacRepository ]]; then
    echo "Repository is not correct please update the k8's pom to container-registry02.wsgc.com"
    exit 1
fi

version=$(curl -k -s "$url" | grep -w 'Final release tag name will be' | awk -F"-" '{print $NF}')
imageID=$(docker images | grep "$version" | grep -w "$repository" | awk -F" " '{print $3}' | head -1)
echo "$version"
echo "$imageID"

if [[ -z $imageID ]]; then
    echo "Could not get imageID value"
    exit 1
fi

republish_to_registry() {
    registry=$1
    echo "Republishing to registry $registry"

    # Obtaining ciuser username and password from mvnrelease-scripts
    password=$(grep -wA 2 "$registry" /var/lib/jenkins/mvnrelease-scripts/lib/mvnrelease.mvntemplate | grep -Po '<password>\K[^<]*')
    username=$(grep -wA 2 "$registry" /var/lib/jenkins/mvnrelease-scripts/lib/mvnrelease.mvntemplate | grep -Po '<username>\K[^<]*')

    docker login -u "$username" -p "$password" https://"$registry"

    docker tag "$imageID" "$registry/$orgname/$projectname:$version"
    docker push "$registry/$orgname/$projectname:$version"
}
republish_to_registry "container-registry03.wsgc.com"
