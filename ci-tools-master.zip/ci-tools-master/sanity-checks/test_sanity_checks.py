import os
import unittest
import shutil
from sanity_checks import get_property_value, validate_version, \
    find_property, find_plugin, pom_root, generate_effective_pom, EffectivePom, find_jdk_source_version, \
    run_pomhelper


class TestPomHelper(unittest.TestCase):

    def copy(self, pom_file):
        """pomhelper doesn't support custom pom names. We need to copy
        fixture files to tmp directory with pom.xml as file name so we can test different
        behaviors"""
        path = os.path.join(self.fixture_path, pom_file)
        shutil.copy(path, '/tmp/pom.xml')

    def setUp(self):
        self.current_path = os.path.dirname(os.path.abspath(__file__))
        self.fixture_path = os.path.join(self.current_path, "fixture")

    def tearDown(self):
        os.remove('/tmp/pom.xml')

    def test_run_pomhelper(self):
        self.copy('jdk_pom.xml')
        got = run_pomhelper('/tmp/pom.xml')
        self.assertTrue(got)

    def test_run_pomhelper_failure(self):
        self.copy('no_version_pom.xml')
        got = run_pomhelper('/tmp/pom.xml')
        self.assertFalse(got)

    def test_run_pomhelper_warnings(self):
        self.copy('duplicate_dependency_pom.xml')
        got = run_pomhelper('/tmp/pom.xml')
        self.assertFalse(got)


class TestEffetivePom(unittest.TestCase):


    def setUp(self):
        self.current_path = os.path.dirname(os.path.abspath(__file__))
        self.fixture_path = os.path.join(self.current_path, "fixture")

    def tearDown(self):
        pass


    def test_generate_effective_pom(self):
        """Instantiates an effective, check if root is not None and
        check if the temporary file was deleted"""

        name = os.path.join(self.fixture_path, 'normal_pom.xml')
        with EffectivePom(path=name) as pom:
            temporary = pom.file_name
            self.assertNotEqual(pom.root, None)

        self.assertFalse(os.path.exists(temporary))


class TestXMLParsing(unittest.TestCase):

    def setUp(self):
        self.current_path = os.path.dirname(os.path.abspath(__file__))
        self.fixture_path = os.path.join(self.current_path, "fixture")

    def test_get_root_element(self):
        path = os.path.join(self.fixture_path, "normal_pom.xml")

        root = pom_root(path)

        self.assertEqual('{http://maven.apache.org/POM/4.0.0}project', root.tag)

    def test_get_root_element_invalid_schema(self):

        path = os.path.join(self.fixture_path, "normal_pom.xml")

        root = pom_root(path)

        self.assertEqual('{http://maven.apache.org/POM/4.0.0}project', root.tag)


    def test_get_version_from_regular_pom(self):
        """Given a normal pom it should return the version"""

        path = os.path.join(self.fixture_path, "normal_pom.xml")

        expected = "2.7-SNAPSHOT"

        root = pom_root(path)

        got = get_property_value("version", root=root)

        self.assertEqual(expected, got)


    def test_get_version_from_no_version_pom(self):
        """Given a pom without the version it should return None"""

        path = os.path.join(self.fixture_path, "no_version_pom.xml")

        expected = None

        root = pom_root(path)
        got = get_property_value("version", root=root)

        self.assertEqual(expected, got)

    def test_repository_tag_exists_in_effectivepom(self):
        """Effective pom has a repositories element. Should test
        if method find_property returns an instance of xml Element"""
        path = os.path.join(self.fixture_path, "effective_pom.xml")
        root = pom_root(path)

        got = find_property("repositories", root=root)

        self.assertNotEqual(got, None)

    def test_source_jdk_version(self):
        path = os.path.join(self.fixture_path, "jdk_pom.xml")
        root = pom_root(path)
        version = find_jdk_source_version(root)

        self.assertEqual(version, '1.8')

        path = os.path.join(self.fixture_path, "no_version_pom.xml")
        root = pom_root(path)
        version = find_jdk_source_version(root)
        # Should return None because the file doesn't contain
        # the compile plugin
        self.assertEqual(version, None)

        path = os.path.join(self.fixture_path, "jdk_no_config.xml")
        root = pom_root(path)
        version = find_jdk_source_version(root)
        # Should return None because the file doesn't contain
        # the compile plugin
        self.assertEqual(version, None)


class TestJDK(unittest.TestCase):

    def setUp(self):
        self.current_path = os.path.dirname(os.path.abspath(__file__))
        self.fixture_path = os.path.join(self.current_path, "fixture")

    def test_jdk(self):
        path = os.path.join(self.fixture_path, "jdk_pom.xml")

        root = pom_root(path)

        find_plugin('build', root=root)
        prop = find_property('build', root=root)

        plugins = prop.find('{http://maven.apache.org/POM/4.0.0}plugins')

        for plugin in plugins:
            artifactId = plugin.find('{http://maven.apache.org/POM/4.0.0}artifactId')
            print(artifactId.text)

    def test_find_plugin(self):
        path = os.path.join(self.fixture_path, "jdk_pom.xml")
        root = pom_root(path)

        element = find_plugin('maven-compiler-plugin', root=root)

        self.assertNotEqual(element, None)


class TestVersion(unittest.TestCase):

    def test_validate_version(self):
        """Test suite for version validation"""

        suite = [
            {
                'explanation': 'Correct pattern!',
                'version': '2.6-SNAPSHOT',
                'expected': True,
            },
            {
                'explanation': 'Should not contain 0.0.*-SNAPSHOT',
                'version': '0.0.3-SNAPSHOT',
                'expected': False,
            },
            {
                'explanation': 'Cannot be a release version. Should end with -SNAPSHOT.',
                'version': '0.0.3-SNAPSHOT',
                'expected': False,
            },
            {
                'explanation': 'Cannot contain only -SNAPSHOT.',
                'version': '-SNAPSHOT',
                'expected': False,
            },
            {
                'explanation': 'version tag doesn\'t exist',
                'version': None,
                'expected': False,
            }
        ]

        for case in suite:
            got = validate_version(case['version'])
            self.assertEqual(case['expected'], got, msg=case['explanation'])
