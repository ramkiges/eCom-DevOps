#!/usr/bin/env python3
"""
    This script runs several checks to confirm that a repository
    is in compliance with WSI pom.xml standards.

    It will execute by default in current working directory, but
    you can override the behavior passing a directory as the first
    argument:

        ./sanity_checks.py repository_path [--verbose|-v] [--jdk-version|-j]

    This script validates that the pom specifies the same JDK version as reported
    by the command `java -version` in the user's path.

    To use a different version than reported by `java -version`:

        ./sanity_checks.py --jdk-version 1.7

"""

import os
import tempfile
import subprocess
import re
import argparse
from xml.etree import ElementTree as et

# Maven namespace
NAMESPACE = "{http://maven.apache.org/POM/4.0.0}%s"
# Global array to hold methods decorated with sanity_check
SANITY_CHECKS = []


def sanity_check(description, only_top=False):
    """Decorator to add some useful logging to sanity checks.
    Sanity checks should include a description about what is being
    checked.
    :param only_top: Sanity checks that should be executed only at the
    :param description: Describes the objective of a sanity check
    top level pom
    """

    def sanity_decorator(func):
        """Decorator for sanity checks.
        Used to determinate the success/failure
        of a check and print a log message."""

        def func_wrapper(*args, **kwargs):
            """Wraps sanity_check functions adding required decorator
            logic"""
            checking_top_level = kwargs['checking_top_level']

            # There are some sanity checks that should be only executed
            # at the top level pom. These checks are annotated with
            # top_level=True. If we're running the checks against
            # a maven module we don't want to call the sanity check
            # just return True.
            if only_top and not checking_top_level:
                return None

            ok = func(*args)
            if not ok:
                return False, "ERROR - {0}".format(description)
            return True, "PASS - {0}".format(description)

        # Register a sanity_check in our global array
        SANITY_CHECKS.append(func_wrapper)
        return func_wrapper

    return sanity_decorator


def generate_effective_pom(effective_pom_path='pom.xml'):
    """Generates the effective-pom and return the xml root element and the temporary
    file name"""
    cmd = "mvn -f {} help:effective-pom -Doutput={} --non-recursive"

    # Generate random file name
    temp_file = tempfile.NamedTemporaryFile(dir='/tmp', suffix='.xml', delete=False)

    # Execute maven command
    returncode, stdout, stderr = run_command(cmd.format(effective_pom_path, temp_file.name))
    
    # maven failed if return code is different than 0
    if returncode != 0:
        # We should fail here
        print("Stderr:{}".format(stderr))
        print("Stdout:{}".format(stdout))
        return temp_file.name, None

    # parse xml
    return temp_file.name, pom_root(temp_file.name)


class EffectivePom(object):
    """A context manager that represents maven effective pom"""

    def __init__(self, path='pom.xml'):
        # We're setting a path here so we can send the fixture path
        # when testing.
        self.path = path
        self.file_name = ""
        self.root = None

    def __enter__(self):
        self.file_name, self.root = generate_effective_pom(self.path)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Removes the temporary effective pom"""
        os.remove(self.file_name)


def run_command(cmd):
    """Run commands using Popen constructor.
    Return a tuple with returncode, stdout and stderr"""
    child = subprocess.Popen(cmd.split(' '), stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    stdout, stderr = child.communicate()
    return child.returncode, stdout, stderr


def run_pomhelper(path):
    """Run pomhelper propartifacts against a pom file.
    Return True if the execution succeeds"""
    cmd = "pomhelper {} --propartifacts".format(path)
    returncode, _, stderr = run_command(cmd)

    if stderr != b'':
        print(stderr.decode('utf-8'))
        return False

    return returncode == 0


def java_version():
    """
    Returns the Java version configured in the environment in the format
    used in our pom files ("1.7", "1.8", "9", "11", "13", etc.).

    E.g:
        $ java -version
        java version "1.8.0_121"

        Returns "1.8"

        $ java -version
        openjdk version "11.0.9.1" 2020-11-04

        Returns "11"
    """
    try:
        child = subprocess.Popen(['java', '-version'], stderr=subprocess.PIPE)
        _, stderr = child.communicate()

        regex = re.match(r'(?:java|openjdk) version "((\d+)\.\d+)', stderr.decode('utf-8'))

        if regex is not None:
            majorMinorStr = regex.group(1)
            majorStr = regex.group(2)

            return majorStr if int(majorStr) > 1 else majorMinorStr

    # In case Java isn't found simply return None
    except OSError:
        pass
    return None


def pom_root(pom_path):
    """Returns the root element of pom.xml.
    Throws IOError if file isn't readable"""
    tree = et.ElementTree()
    tree.parse(pom_path)
    return tree.getroot()


def validate_version(version):
    """
    Version should not begin 0.0.*.
    Version should end with -SNAPSHOT

    :return bool
    """
    if version is None:
        print("ERROR - Project version cannot be empty")
        return False

    snapshot_suffix = "-SNAPSHOT"

    if not version.endswith(snapshot_suffix):
        print("ERROR - Version '{}' should end in '{}'".format(version, snapshot_suffix))
        return False

    if version == snapshot_suffix:
        print("Error - Version '{}' contains no real version!".format(version))
        return False

    if version.startswith("0.0."):
        print("ERROR - Nonstandard Version '{}'. "
              "New projects typically use version 0.1-SNAPSHOT".format(version))
        return False

    return True


def find_plugin(plugin_name, root):
    """Return the XML Element of a plugin.
    Example. To find this plugin:
    <plugin>
      <groupId>com.googlecode.maven-download-plugin</groupId>
      <artifactId>download-maven-plugin</artifactId>
      <version>1.2.1</version>
    </plugin>
    # Send the root element
    >>> find_plugin('download-maven-plugin', root)
    """

    try:
        prop = find_property('build', root=root)
        plugins_namespace = NAMESPACE % 'plugins'

        plugins = prop.find(plugins_namespace)

        for plugin in plugins:
            artifact_id = plugin.find(NAMESPACE % 'artifactId').text
            if artifact_id == plugin_name:
                return plugin

    # Ask for forgiveness not for permission
    except AttributeError:
        # Could not find `build`
        return None
    except TypeError:
        # Could not find `plugins`
        return None


def find_jdk_source_version(root):
    """Return the value of <source></source> inside maven-compiler-plugin"""
    try:
        compiler = find_plugin('maven-compiler-plugin', root)
        config = compiler.find(NAMESPACE % 'configuration')
        return config.find(NAMESPACE % 'source').text
    # If plugin not found or configuration section or source tag
    except AttributeError as e:
        print("Couldn't find source JDK: {}".format(e))
        return None


def find_property(property_name, root):
    """Return an instance of xml.etree.ElementTree.Element """
    property_namespace = NAMESPACE % property_name
    return root.find(property_namespace)


def get_property_value(property_name, root):
    """ Return the value of given property inside the pom.xml <project></project>
        This method throws IOError if pom_path isn't readable.

        E.g: <version>2.1</version>

        >>> get_property_value('version', root)
        >>> 2.1
    """
    property_namespace = NAMESPACE % property_name
    searched_property = root.find(property_namespace)

    if searched_property is not None:
        return searched_property.text

    # Return None if versions wasn't found
    return None


class SanityChecks(object):
    """Defines all sanity checks that needs to be performed
    This class should only define high level methods. Complexity should be handled
    by outside functions

    __call__ method runs all registered sanity checks. A sanity check should follow the above
    convention:
        - Method should be annotated with @sanity_check
    """

    def __init__(self, pom_path, verbose=False, user_provided_jdk=None):
        self.pom_path = pom_path
        self.root = None
        self.verbose = verbose
        self.user_provided_jdk = user_provided_jdk

    def __call__(self, *args, **kwargs):
        """Executes all sanity checks"""
        for check in SANITY_CHECKS:
            data = check(self, **kwargs)
            # If we skip the test we will get None
            # otherwise a tuple (bool, string)
            # with the check result and a descriptive message
            if data is not None:
                ok, message = data
                if not ok:
                    # If we fail we should print the message even if we're
                    # not running in verbose mode
                    print(message)
                    exit(1)
                if self.verbose:
                    print(message)

    def __enter__(self):
        """Parse pom and instantiates the root element"""
        print("Running Sanity Checks for {}".format(self.pom_path))
        try:
            self.root = pom_root(self.pom_path)
        except IOError:
            print("Cannot read pom.xml")
            exit(1)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
        # if exc_type is None and self.verbose:
        #     print("All sanity checks passed!")

    @property
    def jdk_version(self):
        """Tries to collect JDK Version from environment
        If None something is wrong with the environment """
        return self.user_provided_jdk if self.user_provided_jdk else java_version()

    @sanity_check("Ensure that <repository> isn't declared in top level pom")
    def sanity_repositories_exists(self):
        """Tests whether pom had declared the repositories """
        repositories_element = find_property('repositories', root=self.root)
        return repositories_element is None

    @sanity_check("Ensure pom version is compliant with WSI standards", only_top=True)
    def sanity_pom_version(self):
        """ Test if pom version is compliant with WSI standards"""
        version = get_property_value('version', root=self.root)
        return validate_version(version)

    @sanity_check("Ensure the environment JDK version is the same as declared in effective-pom",
                  only_top=True)
    def sanity_jdk_same_version(self):
        """Test if env JDK is the same as declared in effective-pom"""
        with EffectivePom(self.pom_path) as pom:
            # Collects the JDK version from the effective pom
            effective_pom_version = find_jdk_source_version(pom.root)

            if self.jdk_version != effective_pom_version:
                print("Effective pom JDK:{} != Environment JDK:{}".format(effective_pom_version,
                                                                          self.jdk_version))
                return False
            return True

    @sanity_check("Ensure pomhelper checks succeed", only_top=True)
    def sanity_pom_helper(self):
        """Since pomhelper runs checks against all modules we don't need to run this
        in all pom.xml files. Only on the top level pom"""
        return run_pomhelper(self.pom_path)


def find_pom_files(path):
    """Walk given path and return a list of existent pom files"""
    projects = []
    exclude = ['.git']
    for root, dirs, files in os.walk(path, topdown=True):
        # Remove excluded folders first
        dirs[:] = [d for d in dirs if d not in exclude]
        for name in files:
            if name == 'pom.xml':
                # We run different checks at the top level pom
                # that's why we need to mark a project as 'top level'
                top_level = root == path
                projects.append({'dir': root, 'top_level': top_level})

    return projects


def parse_arguments():
    """Return an instance of ArgumentParser with parsed arguments"""
    parser = argparse.ArgumentParser(usage=__doc__, prog='sanity_checks')
    parser.add_argument('repository_path', help="Path to a maven project",
                        nargs='?', default=os.getcwd(), type=str)
    parser.add_argument('--jdk-version', '-j', dest='jdk_version', choices=['1.8', '1.7', '1.6'],
                        help="Run sanity checks assuming given JDK as the environment JDK")
    parser.add_argument('--verbose', '-v', help="Display information about each check",
                        default=False, action='store_true')
    return parser.parse_args()


def main():
    if 'JAVA_TOOL_OPTIONS' in os.environ:
        # When the environment variable JAVA_TOOL_OPTIONS is set, Java emits a message to stderr on
        # every invocation explaining that the variable is set and what its value is.  Unset the
        # variable, suppressing this noise, in order to simplify our parsing of command output.  (We
        # don't need unusual arguments passed to Java for our purposes.)
        del os.environ['JAVA_TOOL_OPTIONS']

    parser = parse_arguments()

    projects = find_pom_files(parser.repository_path)

    for project in projects:
        path = os.path.join(project['dir'], 'pom.xml')
        with SanityChecks(path, verbose=parser.verbose, user_provided_jdk=parser.jdk_version) as checks:
            checks(checking_top_level=project['top_level'])

    # If I reach this print we can assume that all checks passed!
    print("All sanity checks passed!")


if __name__ == '__main__':
    main()
