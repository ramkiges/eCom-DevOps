#!/usr/bin/env python3

import requests
import xml.etree.ElementTree as ET
import argparse
import datetime
import subprocess
import os

requests.packages.urllib3.disable_warnings()
api_key = '3QJOSPM3znJJusvoq8nQki1cpJAOvfap'
rundeck_server = 'https://rundeck.wsgc.com/rundeck/'

""""
The script when executed by the  Jenkins job 'remove-old-rundeck-jobs' which collect all Rundeck executions older than 
two years.. 

We also delete the jobs in the list and write out the deleted jobs into a text file that can be viewed in the Jenkins
job output for later retrieval if needed.

We also provide a mechanism logging option which can be used by passing the '--log' parameter which is the default 
behavior on the Jenkins job.  
"""


def main():
    parse_arguments()


def parse_arguments():
    create_git_tag()
    parser = argparse.ArgumentParser()
    parser.add_argument('-log', '--log', action='store_true')
    args = parser.parse_args()
    if args.log:
        now = datetime.datetime.now()
        projects = get_project_names(list_projects())
        for project in projects:
            delete_log_file_content('details_log')
            job_ids = get_job_ids(list_jobs_for_projects(project))
            for job_id in job_ids:
                if check_exclusions(job_id):
                    continue
                else:
                    result = get_execution_date(get_job_executions(job_id))
                    y1 = now.year
                    y2 = (now.year - 1)
                    if str(result).find(str(y1) + '-') == -1 and str(result).find(str(y2) + '-') == -1 and result is not None:
                        print(str(job_id) + ' ' + str(result))
                        log_job_details('details_log', job_id + ' ' + str(result) + '\n')
        print('Log output completed')

    else:
        now = datetime.datetime.now()
        print('Deleting jobs')
        projects = get_project_names(list_projects())

        for project in projects:
            print('parsing project:\t' + project)
            job_ids = get_job_ids(list_jobs_for_projects(project))
            for job_id in job_ids:
                if check_exclusions(job_id):
                    continue
                else:
                    result = get_execution_date(get_job_executions(job_id))
                    y1 = now.year
                    y2 = (now.year - 1)
                    if str(result).find(str(y1) + '-') == -1 and str(result).find(str(y2) + '-') == -1 and result is not None:
                        print(str(job_id) + ' ' + str(result))
                        delete_job(job_id)
                        log_deleted_jobs(job_id)

        print('Deletion completed')


def list_projects():
    url = rundeck_server + 'api/1/projects'
    headers = {'Content-Type': 'application/json','X-RunDeck-Auth-Token': api_key}
    r = requests.get(url, headers=headers, verify=False)
    return r.text.encode('utf-8')


def get_project_names(projectsinfo_xml):
    project_names = []
    root = ET.fromstring(projectsinfo_xml)
    for projects in root:
        for name in projects.findall('project'):
            project_names.append(name.find('name').text)
    return project_names   


def list_jobs_for_projects(project_mame):
    url = rundeck_server + 'api/1/jobs'
    payload = {'project':  project_mame}
    headers = {'Content-Type': 'application/json', 'X-RunDeck-Auth-Token': api_key}
    r = requests.get(url, params=payload, headers=headers, verify=False)
    return r.text.encode('utf-8')


def get_job_ids(jobsinfo_xml):

    job_ids = []
    root = ET.fromstring(jobsinfo_xml)	

    for jobs in root:
        for job in jobs:
            job_ids.append(job.attrib['id'])
    return job_ids


def get_job_executions(job_id):
    url = rundeck_server + 'api/9/job/'+job_id+'/executions'
    headers = {'Content-Type': 'application/json','X-RunDeck-Auth-Token': api_key}
    r = requests.get(url, headers=headers, verify=False)
    return r.text.encode('utf-8')


def get_execution_date(executionsinfo_xml):
    exec_id_dates = {}
    count = 0
    root = ET.fromstring(executionsinfo_xml)

    for executions in root:

        for execution in executions.findall('execution'):
            execution_id = execution.get('id')

            for date in execution.findall('date-ended'):
                execution_date = date.get('unixtime')
                execution_user = execution.find('user').text
                t = datetime.datetime.fromtimestamp(float(execution_date) / 1000.)
                fmt = "%Y-%m-%d %H:%M:%S"
                execution_date_time = t.strftime(fmt)

            if count == 0:
                exec_id_dates[execution_id] = execution_date_time
                return exec_id_dates, execution_user


def check_exclusions(job_id):
    with open('exclusions', 'r') as f:
        text = f.readlines()
        for line in text:
            if job_id in line:
                return True
        return False


def log_job_details(filename, content):
    with open(filename, "a+") as my_file:
        my_file.write(content)


def log_deleted_jobs(job_id):
    with open('deleted_jobs', "a+") as my_file:
        my_file.write(job_id + "\n")


def delete_job(job_id):
    url = rundeck_server + 'api/9/job/'+job_id+''
    headers = {'Content-Type': 'application/json', 'X-RunDeck-Auth-Token': api_key}
    r = requests.delete(url, headers=headers, verify=False)
    return r.text.encode('utf-8')


def delete_log_file_content(fname):
    with open(fname, "w+"):
        pass


def git(*args):
    return subprocess.check_call(['git'] + list(args))


def create_git_tag():
    now = datetime.date.today()
    git("clone", "git@github.wsgc.com:eCommerce-DevOps/rundeck-jobs.git")
    os.chdir('rundeck-jobs')
    git("tag", "rundeck_deletion_tag_" + str(now))
    git("push", "--tags")
    os.chdir('../')

if __name__ == '__main__':
    main()
