#!/bin/bash
#
# createShortcut.sh
#
# Interactive script for creating a shortcut, and its `java.yaml` file
# that points to the dp-sites repo corresponding to this shortcut.
#
# We ask the user for an organization and branch for their Java, but
# not the repository, because that should always be named "dp-sites".
# Users may change that manually, but we won't bother the user with it
# here.

tmp_fldr="/tmp/svn_shortcut_manage"
if [[ -e "$tmp_fldr" ]]; then
    echo "$tmp_fldr already exists. You must remove this directory before running this script." 1>&2
    exit 1
fi

mkdir $tmp_fldr

shrt_template="shortcut_dp_template"

svn_shrtcuts_url="https://repos.wsgc.com/svn/shortcuts/evolution/branches"
svn co $svn_shrtcuts_url/$shrt_template $tmp_fldr/$shrt_template --ignore-externals

# List the sites that the user is likely to want to create a shortcut from.
sites_we_care_about="admin gr mg pb pk pt we ws rj corp"

###Which sites to create
siteSelection() {
    echo "Choose which sites to include from the list below. Use spaces between each site (e.g., ws pb, or 'all' for all)."
    echo "$sites_we_care_about"
    read brandInput
    if [[ $brandInput == "all" ]]; then
        brandInput=$sites_we_care_about
    fi
    Brands=($brandInput)
    echo " "
    echo " "
}

# Test whether an list of values contains a specific value
# arrayContainsValue <list> <value>
# Returns 0 if value is found, 1 otherwise
arrayContainsValue() {
    local n=$#
    local value=${!n}
    for ((i=1; i < $#; i++)) {
            if [[ "${!i}" == "${value}" ]]; then
                return 0
            fi
        }
        return 1
}

setSites() {
    echo "Where do you want the SITES shortcut to point? (trunk or branch name)"
    read branch_name
    if [[ "$branch_name" != "trunk" ]]; then
        shortcut_target="branches/$branch_name"
    else
        shortcut_target="trunk"
    fi

    ##Always create Common for sites.
    echo "Creating externals for 'common/*'"
    echo "^/../core/ecommerce/sites/common/content/$shortcut_target  content" > $tmp_fldr/$shrt_template/svn.common.externals.txt
    echo "^/../core/ecommerce/sites/common/messages/$shortcut_target  messages" >> $tmp_fldr/$shrt_template/svn.common.externals.txt
    echo "^/../core/ecommerce/sites/common/ui-tests/$shortcut_target  ui-tests" >> $tmp_fldr/$shrt_template/svn.common.externals.txt
    svn propset svn:externals -F $tmp_fldr/$shrt_template/svn.common.externals.txt $tmp_fldr/$shrt_template/sites/common

    ##generage props per site, only create the property if the selected site is in our known list of sites.
    for site in $sites_we_care_about
    do
        if arrayContainsValue "${Brands[@]}" "${site}"; then
            extFile="$tmp_fldr/$shrt_template/svn.$site.externals.txt"
            echo "^/../core/ecommerce/sites/$site/content/$shortcut_target  content" >"$extFile"
            echo "^/../core/ecommerce/sites/$site/messages/$shortcut_target  messages" >>"$extFile"

            if [[ $site != 'admin' ]]; then
                echo "^/../core/ecommerce/sites/$site/misc/$shortcut_target  misc" >>"$extFile"
            fi

            svn propset svn:externals -F "$extFile" $tmp_fldr/$shrt_template/sites/$site
        else
            echo "Removing: $site from the shortcut"
            svn rm $tmp_fldr/$shrt_template/sites/$site
        fi
    done
}

selectJava() {
    # Get the GHE organization and branch for their dp-sites
    # repository, and write the information to java.yaml.
    local DEFAULT_ORG="eCommerce-Bedrock"
    local DEFAULT_REPO="dp-sites"
    local DEFAULT_BRANCH="release"

    while :
    do
        echo
        echo "What is the GitHub Organization that holds the $DEFAULT_REPO Java repository"
        echo "that best goes with this content (default: $DEFAULT_ORG)?"
        local ghe_organization
        read ghe_organization
        if [[ $ghe_organization = "" ]]; then
            ghe_organization=$DEFAULT_ORG
        fi

        echo "Which branch in $ghe_organization/$DEFAULT_REPO would"
        echo "you like to use (default: $DEFAULT_BRANCH)?"
        local ghe_branch
        read ghe_branch
        if [[ $ghe_branch = "" ]]; then
            ghe_branch=$DEFAULT_BRANCH
        fi

        local GHE_URL="git@github.wsgc.com:$ghe_organization/$DEFAULT_REPO"
        local REFS
        if REFS=$(git ls-remote -q --heads --refs "$GHE_URL" 2>/dev/null); then
            if echo "$REFS" | grep -q "refs/heads/$ghe_branch"; then
                # We found what they specified.
                break
            else
                echo
                echo "I was unable to find a branch named '$ghe_branch' in"
                echo "$ghe_organization/$DEFAULT_REPO.  Please try again."
            fi
        else
            echo
            echo "I was unable to find a repository named '$DEFAULT_REPO' in"
            echo "the organization '$ghe_organization'.  Please try again."
        fi
    done

    # Write their selections to java.yaml.
    #
    # Note: we can't use -i to edit in place, as that's an extension
    # whose syntax differs between MacOS and CentOS.
    local JAVA_YAML="$tmp_fldr/$shrt_template/java.yaml"
    local JAVA_YAML_TMP="${JAVA_YAML}.tmp"

    sed \
        -e "s,^\\(organization:\\).*\$,\\1 $ghe_organization," \
        -e "s,^\\(branch:\\).*\$,\\1 $ghe_branch," \
        <"$JAVA_YAML" >"$JAVA_YAML_TMP"
    mv "$JAVA_YAML_TMP" "$JAVA_YAML"
}

svnCommitChanges() {
    echo "Below is a summary of your Shortcut changes...."
    echo
    svn propget svn:externals $tmp_fldr/$shrt_template/common
    svn propget svn:externals $tmp_fldr/$shrt_template/sites/*
    svn status $tmp_fldr/$shrt_template/

    echo "Do you want to commit this change? (y/n)"
    read commit_answer

    if [[ "$commit_answer" = "y" ]]; then
        shrt_cut="";
        while [[ "$shrt_cut" == "" ]]; do
            echo "Please enter the name of the shortcut you want to create...."
            read shrt_cut
            clean_shortcut_name=`echo "$shrt_cut" | sed -e 's/[^-a-zA_Z0-9_]//g'`
            if [[ "$shrt_cut" != "$clean_shortcut_name" ]]; then
                echo "Shortcut name contains invalid characters"
                echo "only letters, numbers, underscore and hyphen allowed"
                shrt_cut=""
            fi
        done

        new_shortcut_url="$svn_shrtcuts_url/$shrt_cut/"

        if svn info "$new_shortcut_url" &>/dev/null; then
            echo "$new_shortcut_url already exists in SVN. Do you want to replace it? (y/n)"
            read rpl_answer
            if [[ "$rpl_answer" == "y" ]]; then
                svn rm "$new_shortcut_url" -m "Deleting shortcut '$shrt_cut' in preparation for recreating it"
            else
                echo "Try again with unique shortcut name...."
                return 1
            fi
        fi
        svn cp "$tmp_fldr/$shrt_template" "$new_shortcut_url" -m "[BRANCH] Creating new shortcut '$shrt_cut'"
    fi
}

cleanTempDir() {
    rm -rf $tmp_fldr
}

##Process request for a new shortcut
siteSelection
setSites
selectJava
svnCommitChanges
cleanTempDir
