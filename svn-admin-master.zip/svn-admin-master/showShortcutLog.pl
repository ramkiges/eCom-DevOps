#!/usr/bin/perl -w

#This scope of the script is to aid Developers to get ALL of the SVN Commit Info about the Branches they are working on, by passing the Shortcut URL they use and the date upto which they desire to know this info as command-line Arguments.

use strict;
use warnings;

# getting URL and Cutoff date from command prompt
my ($remote) = 0;
my ($shortcutname) = $ARGV[0];
my ($cutoffdate) = $ARGV[1];
my ($cutoffenddate) = $ARGV[2];
my ($branchurl)= '';
my $shortcuturl = "";
if (@ARGV < 1) {
    die("Usage Error: Please pass SVN shortcut name(name alone, URL is not needed) and an optional cut-off date up to which you'd like to see the log messages in the format of YYYY-MM-DD\n");
}
if (!defined($cutoffdate)) {
    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time - (24 * 60 * 60));
    ++$mon;
    if (length($mday) < 2) { $mday = "0$mday"; }
    if (length($mon) < 2) { $mon = "0$mon"; }
    $year += 1900;
    $cutoffdate = "$year-$mon-$mday";
    $cutoffenddate = "HEAD";
    print STDERR "No cutoff specified, using yesterday ($cutoffdate)\n";
} else {
    if($cutoffdate !~ /^\d{4}-\d{2}-\d{2}$/){
	print STDERR "Usage Error: Invalid cut-off date. Please pass SVN shortcut name and cut-off date in the format YYYY-MM-DD as Arguments\n";
	exit 1;
    }
}

if (defined($cutoffenddate) && ($cutoffenddate ne 'HEAD')) {
  if ($cutoffenddate ne 'HEAD') {
    if($cutoffenddate !~ /^\d{4}-\d{2}-\d{2}$/){
	print STDERR "Usage Error: Invalid cut-off end date. Please pass SVN shortcut name, a cut-off date, and a cut-off end date in the format YYYY-MM-DD as Arguments\n";
	exit 1;
    }
  }
} else {
    $cutoffenddate = "HEAD";
}

my ($branchpath);

if ($shortcutname eq 'trunk') {
    $branchpath = "trunk";
} else {
    # validate the shortcut name is present
    my $found = 0;
    open(FH1, "svn --non-interactive ls https://repos.wsgc.com/svn/shortcuts/evolution/branches/|") || die("FAILED to valid Shortcut name: $!");
    while(<FH1>) {
	chomp($_);
	if ($_ =~ m:^(.+)/$:) {
	    if ($1 eq $shortcutname) {
		$found = 1;
		# Dont terminate early, it makes svn unhappy
	    }
	}
    }
    close(FH1);
    if (!$found) {
	print STDERR "Cannot find shortcut '$shortcutname'. Please provide a valid shortcut name.\n";
	exit 1;
    }
    $branchpath = "branches/$shortcutname";
}

$shortcuturl = "https://repos.wsgc.com/svn/shortcuts/evolution/" . $branchpath;
print STDERR "Running svn log for " . $shortcuturl . "\n";

#output and HTML page with the log of changes
my $srcFile = "";
my $destFile = "";
if ($remote == 1) {
  $srcFile = "/apps/devops/scripts/changelog_$shortcutname.html";
  $destFile = "/var/log/weblogs/devops/changelog_$shortcutname.html";
} else {
  $srcFile = "changelog_$shortcutname.html";
}
open(FILEOUT, ">$srcFile"); 
print FILEOUT '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">', "\n";
print FILEOUT '<html><head><title>Subversion Change Log</title></head><body>',"\n";
print FILEOUT "<h1>SHORTCUT: $shortcutname - changes since $cutoffdate</h1>\n";

open(EXTERNALS, "svn --non-interactive propget --depth=infinity svn:externals '$shortcuturl/'|") || die("FAILED to get externals with svn propget:$!");
while(<EXTERNALS>) {
   chomp($_);
   next if $_ =~ /^\s*$/; # removing blank lines
   $_ =~ /\s*(\^\/\.\..+?)\s+(\w+)\s*$/;
   my ($branchurl) = $1;
   my ($branchid) = $2;
   $branchurl =~ s/^\^\/\.\./https\:\/\/repos\.wsgc\.com\/svn/ig; # replace ^/.. with https://repos.wsgc.com/svn
   
   print STDERR "  [$branchid] $branchurl\n";
   print FILEOUT "<b>Branch: $branchurl</b>\n";
   print FILEOUT "<pre>\n";
   if (($cutoffenddate eq 'HEAD')) {
       open(SVNLOG, "svn --non-interactive log -v -r {$cutoffdate}:$cutoffenddate '$branchurl'|") || die("FAILED to open svn log: $!");
   } else {
       open(SVNLOG, "svn --non-interactive log -v -r {$cutoffdate}:{$cutoffenddate} '$branchurl'|") || die("FAILED to open svn log: $!");
   }
   while (<SVNLOG>) {
       chomp($_);
       if ($_ =~ /^[-]{10,}\s*$/) {
	   print FILEOUT "<hr />";
	   next
       }
       $_ =~ s/\&/\&amp;/g;
       $_ =~ s/\</\&lt;/g;
       $_ =~ s/\>/\&gt;/g;
       if ($_ =~ /^r(\d+)\s*[|]/) {
	   print FILEOUT "<b>$_</b>\n";
       } else {
	   print FILEOUT "$_\n";
       }
   }
   print FILEOUT "</pre>\n";
   close(SVNLOG);
}
close(EXTERNALS);

print FILEOUT "<p>Generated: ",scalar(localtime(time)),"</p>\n";
print FILEOUT "</body></html>";
close(FILEOUT);

if ($remote == 1) {
  system("cp", $srcFile, $destFile);
}

print "Your Report has been outputted to $srcFile\n"; 
exit 0;
