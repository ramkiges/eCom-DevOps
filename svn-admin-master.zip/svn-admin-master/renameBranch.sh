#!/bin/bash

###reneame branch name
renameBranchName(){
  echo "What is the name of the branch you want to rename?"
  read rnm_branch
  echo " "
}

###reneame branch name
newBranchName(){
  echo "What is the new name of the branch?"
  read new_branch
  echo " "
}
###Branch for baselogic
renameBranch(){
    svn_url="https://repos.wsgc.com/svn/core/ecommerce"
    date=`date +%Y%m%d`
    commit_msg="Renaming svn branch "
    sites="ws we pt pk pb mg gr admin corp corpadmin"
    echo "Renaming branch for baselogic..."
    svn rename $svn_url/platform/baselogic/branches/$rnm_branch $svn_url/platform/baselogic/branches/$new_branch -m "$commit_msg $rnm_branch"
    echo " "
    echo "Renaming branch for components..."
    svn rename $svn_url/platform/components/branches/$rnm_branch $svn_url/platform/components/branches/$new_branch -m "$commit_msg $rnm_branch"
    echo " "
	for i in $sites; 
	do 
	    echo "Renaming branch for site: $i..."
	    svn rename $svn_url/sites/$i/war/branches/$rnm_branch $svn_url/sites/$i/war/branches/$new_branch -m "$commit_msg $rnm_branch"
	    svn rename $svn_url/sites/$i/content/branches/$rnm_branch $svn_url/sites/$i/content/branches/$new_branch -m "$commit_msg $rnm_branch"
	    svn rename $svn_url/sites/$i/messages/branches/$rnm_branch $svn_url/sites/$i/messages/branches/$new_branch -m "$commit_msg $rnm_branch"
	    svn rename $svn_url/sites/$i/misc/branches/$rnm_branch $svn_url/sites/$i/misc/branches/$new_branch -m "$commit_msg $rnm_branch"
	    echo " "
	done
	echo "Renaming branch for common content..."
	svn rename $svn_url/sites/common/content/branches/$rnm_branch $svn_url/sites/common/content/branches/$new_branch -m "$commit_msg $rnm_branch"
	svn rename $svn_url/sites/common/messages/branches/$rnm_branch $svn_url/sites/common/messages/branches/$new_branch -m "$commit_msg $rnm_branch"
  svn rename $svn_url/sites/common/ui-tests/branches/$rnm_branch $svn_url/sites/common/ui-tests/branches/$new_branch -m "$commit_msg $rnm_branch"
	echo " "
}

renameBranchName
newBranchName
renameBranch

