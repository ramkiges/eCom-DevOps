#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my ($path,$shortcutname,$excludename,$dry);

# ---------------------------------------------------------------------------
sub get_options()
{
    GetOptions(
        "p|path=s" => \$path,
        "s|shortcut=s" => \$shortcutname,
        "x|exclude=s" => \$excludename,
        "d|dryrun" => \$dry,
	);

    if (!$path || !$shortcutname) {
        print "Usage: $0 -p|-path=<path> -s|-shortcut <shortcutname> -d|-dryrun\n\n";
        print "Options:\n";
        print "-p or -path : path of working directory root (parent of sites and platform)\n";
        print "-s or -shortcut : shortcut name to merge from\n";
        print "-x or -exclude : exclude name either content or java\n";
        print "-d : dry-run\n";
	print "\n";
#        print "\n\nThe scope of the script is to aid Merging of set of branches between provided through an input file-name OR a shortcut name. This script will fetch latest revisions for all SVN Branches it found, calculates the start revisions(the revision after the last merged svn revision) and end revisions( svn revision # of the latest commit for the Branch) and executes the svn merge at their respective Target Folders.Here are the valid options that can be passed to the script: \n\n";
	
        exit 1;
    }
}

sub get_shortcut_externals($)
{
    my ($shortcutname) = @_;

    my ($shortcuturl) = "https://repos.wsgc.com/svn/shortcuts/evolution/branches/${shortcutname}/";
    my ($shortcutlen) = length($shortcuturl);
    open(EXTERNALS, "svn propget --depth=infinity svn:externals '$shortcuturl'|")
	|| die("Failed to get externals for '$shortcuturl': $!");
    my ($exturl) = $shortcuturl;
    my (%externals) = ();
    while(<EXTERNALS>) {
	chomp($_);
	# Find and remove external names
	if ($_ =~ s/^(https:\S+) \- //) {
	    $exturl = $1;
	    # print STDERR "Looking at external for '$exturl'\n";
	}
	next if ($_ =~ /^\s*$/); # Skip blank lines
	if ($_ =~ m:^\^/[.][.]/(\S+)\s+(\S+)\s*$:) {
	    my ($srcurl) = "https://repos.wsgc.com/svn/$1";
	    my ($targetfile) = $2;
	    
	    # Sanity check location of shortcut
	    if (substr($exturl, 0, $shortcutlen) ne $shortcuturl) {
		die("Unexpected external location '$exturl'!");
	    }
	    # Figure out relative path of shortcut from root
	    my ($targetdir) = substr($exturl, $shortcutlen);
	    unless ($targetdir =~ m:/$:) { $targetdir .= "/"; }
	    $targetdir .= $targetfile;
	    $externals{$targetdir} = $srcurl;
	    next;
	}
	die("Unknown content in external: $_\n");
    }
    close(EXTERNALS) || die("Failed to complete externals for '$shortcuturl': $!");
    
    return %externals;
}

sub get_svn_revision($) {
    my ($url) = @_;
    open(SVNINFO, "svn info --non-interactive '$url'|") || die("Failed to run svn info for '$url': $!");
    my ($rev, $uuid, $root);
    while(<SVNINFO>) {
	chomp($_);
	if ($_ =~ /^Revision: (\d+)$/) { $rev = $1; }
	if ($_ =~ /^Repository Root: (\S+)$/) { $root = $1; }
	if ($_ =~ /^Repository UUID: (\S+)$/) { $uuid = $1; }
    }
    close(SVNINFO) || die("Failed to complete svn info for '$url': $!");
    if (!defined($rev)) { die("No revision for '$url'!"); }
    if (!defined($root)) { die("No root for '$url'!"); }
    if (!defined($uuid)) { die("No UUID for '$url'!"); }
    return $rev, $root, $uuid;
}

sub get_svn_url_base($) {
    my ($url) = @_;
    $url =~ s:/$::;
    if ($url =~ s:/trunk$::) { return $url; }
    if ($url =~ s:/tags/[^/]+$::) { return $url; }
    if ($url =~ s:/branches/[^/]+$::) { return $url; }
    die("Invalid SVN project URL '$url'");
}

sub get_svn_url_type($) {
    my ($url) = @_;
    $url =~ s:/$::;
    if ($url =~ m:/trunk$:) { return "trunk", ""; }
    if ($url =~ m:/tags/([^/]+)$:) { return "tag", $1; }
    if ($url =~ m:/branches/([^/]+)$:) { return "branch", $1; }
    die("Invalid SVN project URL '$url'");
}

sub verify_merge_target($$) {
    my ($targetdir, $mergesource) = @_;

    # print STDERR "STATUS: Verifying merge into $targetdir from $mergesource\n";

    my ($pathdir) = $path . "/" . $targetdir;
    if (! -d $pathdir) {
	die("ERROR: Merge target '$pathdir' is not a directory!");
    }
    open(SVNINFO, "svn info '$pathdir'|") || die("Failed to run svn info on '$pathdir': $!");
    my ($url);
    while(<SVNINFO>) {
	chomp($_);
	if ($_ =~ /^URL: (\S+)$/) { $url = $1; }
    }
    close(SVNINFO) || die("Failed to complete svn info on '$pathdir': $!");
    if (!defined($url)) {
	die("No URL in svn info on '$pathdir'");
    }

    my ($workingbase) = get_svn_url_base($url);
    my ($sourcebase) = get_svn_url_base($mergesource);
    if ($workingbase ne $sourcebase) {
	die("Incompatible paths: $sourcebase cannot merge into $workingbase (in $pathdir)\n");
    }
    open(SVNUPDATE, "svn update --non-interactive '$pathdir'|") || die("Failed to start svn update in '$pathdir': $!");
    while(<SVNUPDATE>) {
	chomp($_);
	print "  [$targetdir] $_\n";
    }
    close(SVNUPDATE) || die("Failed to finish svn update in '$pathdir': $!");

    open(SVNSTATUS, "svn status '$pathdir'|") || die("Failed to start svn status in '$pathdir': $!");
    my ($anyStatus) = 0;
    while(<SVNSTATUS>) {
	chomp($_);
	$anyStatus = 1;
	print "  [$targetdir] $_\n";
    }
    close(SVNSTATUS) || die("Failed to finish svn status in '$pathdir': $!");
    if ($anyStatus) {
	die("ERROR: Non-clean merge target in $pathdir\n");
    }
}

my ($checkrev, $checkuuid); # Slightly ugly having these here, ah well
sub get_merge_source_info($)
{
    my ($sourceurl) = @_;
    my ($revision, $root, $uuid) = get_svn_revision($sourceurl);
    if (!defined($checkrev)) {
	$checkuuid = $uuid;
	$checkrev = $revision;
	print "  Merging from repository $root revision $revision\n";
    } else {
	if ($checkuuid ne $uuid) {
	    die("Inconsistent repository for $sourceurl (uuid: $uuid)\n");
	}
    }
    my ($info) = {
	'sourceurl' => $sourceurl,
	'sourcerev' => $checkrev, # Use first revision seen
	'sourceroot' => $root,
	'sourceuuid' => $uuid
    };
    return $info;
}

sub perform_merge($$)
{
    my ($targetdir, $info) = @_;
    my ($pathdir) = $path . "/" . $targetdir;

    print "  [$targetdir] Merging from $info->{'sourceurl'} $info->{'sourcerev'}\n";

    my ($root) = $info->{'sourceroot'};
    my ($sourceurl) = $info->{'sourceurl'};
    my ($sourcerev) = $info->{'sourcerev'};
    my ($rootlen) = length($root);
    if (substr($sourceurl, 0, $rootlen) ne $root) {
	die("Inconsistent root and URL: $root / $sourceurl\n");
    }
    my ($sourcepath) = substr($sourceurl, $rootlen);

    open(MERGEINFO, "svn propget svn:mergeinfo '$pathdir'|") || die("Failed to get mergeinfo for '$pathdir': $!");
    my ($revlist);
    while(<MERGEINFO>) {
	chomp($_);
	if ($_ =~ /^([^:]+):([0-9-]+)$/) {
	    if ($1 eq $sourcepath) { $revlist = $2; }
	}
    }
    close(MERGEINFO) || die("Failed to end mergeinfo for '$pathdir': $!");
    my $startrev;
    if (!defined($revlist)) {
	print "  [$targetdir] No revlist - first time merge\n";
	$startrev = 0;
    } else {
	my $lastrev = -1;
	my $re;
	for $re (split(/[,]/, $revlist)) {
	    if ($re =~ /^\d+$/) {
		if ($re > $lastrev) { $lastrev = $re; }
	    } elsif ($re =~ /^(\d+)-(\d+)$/) {
		if ($2 > $lastrev) { $lastrev = $2; }
	    } else {
		die("Unexpected '$re' in revision list '$revlist' for '$pathdir'\n");
	    }
	}
	if ($lastrev == -1) {
	    die("Revision list yielded nothing for '$revlist' in '$pathdir'!\n");
	}
	$startrev = $lastrev;
	print "  [$targetdir] Last merged revision $lastrev\n";
    }

    if ($startrev == $sourcerev) {
	print "  [$targetdir] Already merged. Skipping.\n";
	return;
    } elsif ($startrev > $sourcerev) {
	die("Bizarre start revision $startrev > $sourcerev for '$pathdir' and '$sourceurl'\n");
    }
    my $mergecmd;
    if ($dry){
    ($mergecmd) = "svn merge --non-interactive --dry-run '$sourceurl'" . '@' . "$sourcerev --accept postpone '$pathdir'";
    }
    else {
    ($mergecmd) = "svn merge --non-interactive -r$startrev:$sourcerev '$sourceurl'" . '@' . "$sourcerev --accept postpone '$pathdir'";
    }
    print "\$mergecmd: $mergecmd\n";
    print "  [$targetdir] $mergecmd\n";
    open(SVNMERGE, "$mergecmd|") || die("Failed to start merge in '$pathdir': $!");
    my ($filecount) = 0;
    my ($confcount) = 0;
    while(<SVNMERGE>) {
	chomp($_);
	print "  [$targetdir] $_\n";
	if ($_ = m:^([A-Z ]{5}):) {
	    ++$filecount;
	    if ($1 =~ /C/) {
		++$confcount;
	    }
	}
    }
    close(SVNMERGE) || die("Failed to end merge in '$pathdir': $!");
    $info->{'merges'} = $filecount;
    $info->{'conflicts'} = $confcount;
}

# ---------------------------------------------------------------------------


# checking if all the mandatory parameters are entered in the command prompt
get_options();

print "STATUS: Discovering merge targets...\n";
my (%externals);
%externals = get_shortcut_externals($shortcutname);

if ( defined($excludename)) {
    if ( $excludename eq "content" ) {
        my @content = ("misc" , "messages" , "content"); 
        print "Excluding content...@content\n";
        for my $elem (@content) {
            my @matching_keys = grep { 0 <= index $_, $elem } keys %externals;
            delete @externals{@matching_keys};
        }
    }
    elsif ( $excludename eq "java" ) {
        my @java = ("war" , "baselogic" , "components");
        print "Excluding java...@java \n";
        for my $elem (@java) {
            my @matching_keys = grep { 0 <= index $_, $elem } keys %externals;
            delete @externals{@matching_keys};
        }
    }
    else {
        print ("Invalid exclude name...'$excludename'\n");
        exit 0;
    }
}
print "STATUS: Determining which items to merge...\n";
my (%mergedetails) = ();
my $targetdir;
for $targetdir (sort(keys(%externals))) {
    my ($sourceurl) = $externals{$targetdir};
    my ($type, $id) = get_svn_url_type($sourceurl);
    if ($type ne 'branch') {
	print "  [$targetdir] Not merging '$sourceurl': Not a branch\n";
	next;
    }
    $mergedetails{$targetdir} = get_merge_source_info($sourceurl);
    print "  [$targetdir] $sourceurl\n";
}
    
print "STATUS: Updating and verifying working directory...\n";
for $targetdir (sort(keys(%mergedetails))) {
    my ($info) = $mergedetails{$targetdir};
    verify_merge_target($targetdir, $info->{'sourceurl'});
}

print "STATUS: Performing merges...\n";
for $targetdir (sort(keys(%mergedetails))) {
    my ($info) = $mergedetails{$targetdir};
    perform_merge($targetdir, $info);
}

print "RESULT SUMMARY\n";
for $targetdir (sort(keys(%mergedetails))) {
    my ($info) = $mergedetails{$targetdir};
    if (!defined($info->{'merges'})) {
	print "  [$targetdir] SKIPPED\n";
    } elsif ($info->{'conflicts'} == 0) {
	print "  [$targetdir] MERGED (Merges: $info->{'merges'})\n";
    } else {
	print "  [$targetdir] CONFLICTS (Merges: $info->{'merges'}; Conflicts: $info->{'conflicts'})\n";
    }
}

print "Done.\n";

exit 0;
