#!/bin/bash

set -e
set -o nounset

svn_url="https://repos.wsgc.com/svn/core"
svn_sites_url="$svn_url/ecommerce/sites"

commit_msg="[BRANCH] Creating a new branch from"
havebranch=0

if [[ $# > 0 && -n $1 ]]; then
    inRepo=$1
else
    inRepo=""
fi

if [[ $# > 1 && -n $2 ]]; then
    inMaster=$2
else
    inMaster=""
fi

# Corp doesn't work in CI and shortcuts aren't how people are going to
# work on it, so drop it from our concern.
sites_we_care_about="admin gr mg pb pk pt we ws rj corp"

doesSvnUrlExist() {
    svn info "$1" &>/dev/null
}

##Check for the existence of the branch
chkForBranch() {
    for s in $sites_we_care_about common; do
        for repo in content misc messages war; do
            if doesSvnUrlExist "$svn_sites_url/$s/$repo/branches/$new_branch/"; then
                havebranch=1
            fi
        done
    done
}

##Check for the existence of the branch in common
chkForBranchCommon() {
    if doesSvnUrlExist "$svn_sites_url/common/content/branches/$new_branch/"; then
        haveCommonbranch=1
    fi
}

###New branch name
getNewBranch() {
    new_branch=""
    while [[ "$new_branch" == "" ]]; do
        if [[ $inRepo == "" ]]; then
            echo "What is the name of the NEW branch? (standard format = '<prefix>-wrk-<YYMMDD>')"
            read new_branch
        else
            new_branch="${inRepo}"
        fi

        clean_branch_name=`echo "$new_branch" | sed -e 's/[^-a-z0-9_]//g'`
        if [[ "$new_branch" != "$clean_branch_name" ]]; then
            echo "Branch name contains invalid characters"
            echo "only lowercase letters, numbers, underscore and hyphen allowed"
            new_branch=""
            inRepo=""
        fi
        if [[ "$new_branch" != "" ]]; then
            chkForBranch
            if [[ "$havebranch" == 1 ]]; then
                echo "The branch you have requested already exists for some part of code tree. Do you want to pick a new name? (y/n)"
                read redo_yno
                if [[ $redo_yno = 'y' ]]; then
                    new_branch=""
                    inRepo=""
                else
                    exit 1
                fi
            fi
        fi
    done
}

###branch creation
getMasterBranch() {
    ####Find master branch name
    if [[ $inMaster == "" ]]; then
        echo "Please enter the name of the branch you want to copy from: (for /Trunk enter 'trunk')"
        read repo_name
    else
        repo_name="${inMaster}"
    fi

    if [[ $repo_name == "trunk" ]]; then
        old_branch="trunk"
    else
        old_branch="branches/$repo_name"
    fi
    getRevisionInfo "$old_branch"
    echo
}

###Ask Revision Number
getRevisionInfo() {
    local OLD_BRANCH_NAME=$1
    while true; do
        echo "Please enter a revision number or type HEAD for the latest revision..."
        read rev_number

        echo "Do you wish to copy $OLD_BRANCH_NAME from $rev_number? (y/n)"
        read yno_rev_copy
        if [[ $yno_rev_copy == y ]]; then
            break
        fi
    done
}

###getSitesNeeded sites to create
getSitesNeeded() {
    echo "What sites would you like to create from the list below? Please use spaces between each site.. (i.e. ws pb pk, 'all' for all)"
    echo "$sites_we_care_about"
    read brand_answer

    if [[ $brand_answer == "all" ]]; then
        brand_answer=$sites_we_care_about
    fi

    echo
    echo
}

getSitesandCheck(){
    echo "Do you need to create a site specific branch? [y/n]"
    read keep_going
    if [[ $keep_going = y ]]; then
        while : ; do
            getSitesNeeded
            foundInvalidSite=""
            foundDuplicateSites=""
            for site in $brand_answer; do
                if ! [[ $site =~ ^(admin|gr|mg|pb|pk|pt|we|ws|rj|corp)$ ]]; then
                    echo "$site is not a valid site"
                    foundInvalidSite="Yes"
                fi
            done
            getduplicateSite=$(echo "$brand_answer" | tr " " "\n" | sort | uniq -d)
            if [[ -n $getduplicateSite ]]; then
                echo "Below site(s) selected multiple times :"
                echo "$getduplicateSite"
                foundDuplicateSites="Yes"
            fi
            if [[ $foundInvalidSite != "Yes" && $foundDuplicateSites != "Yes" ]]; then
                break
            fi
            echo ""
            echo "Please select sites again"
            echo ""
        done
    fi
}

###Content Site
createContent() {
    echo "Do you want to branch CONTENT for ($brand_answer)? (y/n)"
    read cnt_yno
    if [[ $cnt_yno == y ]]; then
        echo "Creating common branches...."
        svn copy -r$rev_number $svn_url/ecommerce/sites/common/content/$old_branch $svn_url/ecommerce/sites/common/content/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"
        svn copy -r$rev_number $svn_url/ecommerce/sites/common/messages/$old_branch $svn_url/ecommerce/sites/common/messages/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"
        svn copy -r$rev_number $svn_url/ecommerce/sites/common/ui-tests/$old_branch $svn_url/ecommerce/sites/common/ui-tests/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"

        echo "Creating a branch for $brand_answer Content...."
        for i in $brand_answer; do
            svn copy -r$rev_number $svn_url/ecommerce/sites/$i/content/$old_branch $svn_url/ecommerce/sites/$i/content/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"
            svn copy -r$rev_number $svn_url/ecommerce/sites/$i/messages/$old_branch $svn_url/ecommerce/sites/$i/messages/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"
            if [[ $i != admin ]] && [[ $i != common ]]; then
                svn copy -r$rev_number $svn_url/ecommerce/sites/$i/misc/$old_branch $svn_url/ecommerce/sites/$i/misc/branches/$new_branch -m"$commit_msg $old_branch to $new_branch"
            fi
        done
        echo
    fi
    echo
    echo
}

getNewBranch
getMasterBranch

echo "You have requested a branch called ${new_branch} based off ${old_branch}.... "

getSitesandCheck
createContent
