#!/usr/bin/perl 
use strict;
#use warnings;
#use diagnostics;

my $inputfile = shift;
my $commitmessage = '"[DELETE]"';
open(FH, "<$inputfile") || die "cannot open the file\n";
while(<FH>) {
my $branchurl = $_;
if (($inputfile =~ /trunk/)|| ($inputfile =~ /branches\/$/)){ next;}
else{
print "deleting $branchurl\n";
system ("svn delete -m $commitmessage $branchurl");
}
}
close(FH);

exit 0;
