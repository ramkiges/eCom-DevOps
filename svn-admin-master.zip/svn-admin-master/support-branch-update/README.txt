This script is created to support the BREADS when they asked to roll a "release" into the support branch.

The script requires the following options.

[-r <release name (i.e allspice, basil)>]
[-b <brand: mg, pb, pk, pt, we, ws>]
[-w <release war version >]  

Release Name is name we assign to each release.  In 2016 we used SNL characters, so name examples are dunn, farely and gottfried.

Brand is our 6 brands:  mg, pb, pk, pt, we, ws

The release war version is the war release version that has been
deployed into production.  So currently Gottfried release is at
2.3.2.1.  A good place to see what version prod is using is the
"release matrix" page here:

    https://confluence.wsgc.com/display/ES/Release+Matrix

If you want the head of a release *branch* rather than the released
*tag*, you would use, e.g., "2.3.2.x"

EXAMPLE:

    ./update_support_branch.sh -r gottfried -b pk -w 2.3.2.2
