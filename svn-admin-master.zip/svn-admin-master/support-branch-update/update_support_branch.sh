#!/bin/bash
#
# update_support_branch.sh -r <releaseName> -b <brand> -w <warVersion>
#
# Create a "fix" branch (e.g., "mg_fix") and shortcut (e.g.,
# "mg_support) for a given brand, from a given release (e.g., athens),
# tied to a particular version of the dp-sites repo (e.g., 2.5.30.x).
#
# If the fix branch already exists, move it to a backup before
# replacing it.

set -e
set -o nounset

SVN_SITES_URL="https://repos.wsgc.com/svn/core/ecommerce/sites"
SVN_SHORTCUTS_BRANCHES="https://repos.wsgc.com/svn/shortcuts/evolution/branches"

TESTING="false" # If "true", we will not commit any changes.

SITE_EXTERNALS_TEMPLATE="^/../core/ecommerce/sites/@BRAND@/content/branches/@BRAND@_fix content
^/../core/ecommerce/sites/@BRAND@/messages/branches/@BRAND@_fix messages
^/../core/ecommerce/sites/@BRAND@/misc/branches/@BRAND@_fix misc
"

COMMON_EXTERNALS_TEMPLATE="^/../core/ecommerce/sites/common/content/branches/release-@RELEASE@ content
^/../core/ecommerce/sites/common/messages/branches/release-@RELEASE@ messages
^/../core/ecommerce/sites/common/ui-tests/branches/release-@RELEASE@ ui-tests
"

helpAndDie() {
    if [[ $# == 1 ]]; then
        echo "$1" >&2
    fi

    echo "usage: $0 -r <release (e.g., athens)> -b <brand> -w <war version (e.g., 2.5.30.6)>" >&2
    exit 1
}

while getopts ":r:b:w:" o; do
    case "$o" in
    r)
        release=$OPTARG
        ;;
    b)
        brand=$OPTARG
        if ! [[ $brand =~ ^(mg|pb|pk|pt|we|ws)$ ]]; then
            echo "Unrecognized brand '$brand'" >&2
            helpAndDie
        fi
        ;;
    w)
        releaseWarVersion=$OPTARG
        ;;
    *)
        helpAndDie
        ;;
    esac
done
shift $((OPTIND - 1))

# Check that all parameters are set.
set +o nounset
if [[ -z $release || -z $brand || -z $releaseWarVersion ]]; then
    helpAndDie
fi
set -o nounset

svnUrlExists() {
    svn info "$1" &>/dev/null
}

sanityCheck() {
    if ! svnUrlExists "$SVN_SHORTCUTS_BRANCHES/${release}-shortcut"; then
        helpAndDie "Release '$release' does not appear to exist"
    fi
}

copySupportBranch() {
    local FIX_BRANCH="${brand}_fix"

    local TODAY=$(date +%Y%m%d)
    local BACKUP_FIX_BRANCH="${brand}_fix_${TODAY}"

    for site in "$brand" common; do
        for repo in content messages misc; do
            local FIX_BRANCH_URL="$SVN_SITES_URL/$site/$repo/branches/$FIX_BRANCH"

            # Back up the current branch if it exists.
            if svnUrlExists "$FIX_BRANCH_URL"; then
                local BACKUP_URL="$SVN_SITES_URL/$site/$repo/branches/$BACKUP_FIX_BRANCH"
                if [[ $TESTING == true ]]; then
                    echo "Would back up $FIX_BRANCH_URL to $BACKUP_URL"
                else
                    svn mv "$FIX_BRANCH_URL" "$BACKUP_URL" -m "backing up $brand fix branch"
                fi
            fi

            # Create the new branch.
            local SRC_URL="$SVN_SITES_URL/$site/$repo/branches/release-$release"
            if svnUrlExists "$SRC_URL"; then
                if [[ $TESTING == true ]]; then
                    echo "Would copy $SRC_URL to $FIX_BRANCH_URL"
                else
                    svn copy "$SRC_URL" "$FIX_BRANCH_URL" -m "[BRANCH] create new $brand fix branch"
                fi
            fi
        done
    done
}

updateShortcut() {
    # Modify SVN shortcut to use $release version
    local SHORTCUT_NAME="${brand}_support"
    local SHORTCUT_URL="$SVN_SHORTCUTS_BRANCHES/$SHORTCUT_NAME"

    if ! svnUrlExists "$SHORTCUT_URL"; then
        echo "Error: we expected $SHORTCUT_URL to exist; please create/copy one." >&2
        exit 1
    fi

    echo "Existing shortcut externals:"
    svn propget svn:externals "$SHORTCUT_URL/sites/$brand"

    # Check out the shortcut.
    local SVN_WORK_DIR=$(mktemp -d)
    svn checkout --ignore-externals "$SHORTCUT_URL" "$SVN_WORK_DIR"

    # Update the brand externals.
    echo "Updating the brand externals."
    local SITE_EXTERNALS=${SITE_EXTERNALS_TEMPLATE//@BRAND@/$brand}
    svn propset svn:externals "$SITE_EXTERNALS" "$SVN_WORK_DIR/sites/$brand"

    # Update the common/content externals.
    echo "Updating the sites/common externals."
    local COMMON_EXTERNALS=${COMMON_EXTERNALS_TEMPLATE//@RELEASE@/$release}
    svn propset svn:externals "$COMMON_EXTERNALS" "$SVN_WORK_DIR/sites/common"

    # Give the shortcut the latest copies of java.yaml and
    # checkoutJava.sh.
    local JAVA_YAML="java.yaml"
    local DP_TEMPLATE_URL="$SVN_SHORTCUTS_BRANCHES/shortcut_dp_template"

    for filename in "$JAVA_YAML" "checkoutJava.sh"; do
        local SRC_URL="$DP_TEMPLATE_URL/$filename"
        local DEST_FNAME="$SVN_WORK_DIR/$filename"
        if [[ -f $DEST_FNAME ]]; then
            # Make sure the shortcut's copy of the file is current.
            svn cat "$SRC_URL" >"$DEST_FNAME"
        else
            # Add the file to the shortcut.
            svn copy "$SRC_URL" "$DEST_FNAME"
        fi
    done

    # Update java.yaml to point to the desired war branch.
    echo "Updating the WAR version."
    local WAR_BRANCH="release-$releaseWarVersion"
    local JAVA_YAML_TMP="${JAVA_YAML}.tmp"

    sed -e "s,^ *\\(branch:\\).*\$,\\1 $WAR_BRANCH," <"$SVN_WORK_DIR/$JAVA_YAML" >"$SVN_WORK_DIR/$JAVA_YAML_TMP"
    mv "$SVN_WORK_DIR/$JAVA_YAML_TMP" "$SVN_WORK_DIR/$JAVA_YAML"

    if [[ $TESTING == true ]]; then
        echo "The changes that would have been committed to the shortcut are:"
        svn diff "$SVN_WORK_DIR"
    else
        # Commit changes.
        echo "Committing changes to the $SHORTCUT_NAME shortcut"
        svn commit "$SVN_WORK_DIR" -m "[DEVOPS] update shortcut for $brand"
    fi

    rm -rf "$SVN_WORK_DIR"
}

sanityCheck
copySupportBranch
updateShortcut
