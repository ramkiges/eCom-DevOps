# release-tools-configs
Config files for release-tools

https://confluence.wsgc.com/display/EE/Create+Release+Artifact+and+Configs

These files are used by 

  https://ecombuild.wsgc.com/jenkins/view/release-tools/job/create-release-artifact-configs/
  https://ecombuild.wsgc.com/jenkins/view/release-tools/job/self-service-release-artifact/
 
