# toolchain-jenkins-slave-config-macos
Files and documentation regarding the setup of the Mac Mini Jenkins nodes
and the mobile_ios_app Jenkins pipeline.

#### `/app-config/`
- `certificate:` Contains the `Certificate.P12` file,
  which is required when deploying to TestFlight. There should
  be only one certificate.  The certificate references the provisioning profiles
  of the applications: there is a one-to-many relationship between a `Certificate.P12`
  and `provisioning profiles`. The certificate is protected by a password, which
  can be obtained from a member of the Tahoe Team.

  Install the certificate with "`open <certName>`" on the Mac, and it will ask for the
  password and load it into the keychain (which will also ask for a password, for the
  keychain itself).

  To use the new cert, get a new provisioning profile from the developers that uses it.

  If your build is failing to sign, look for an instruction near the end like this:
  ```
  /usr/bin/codesign --force --sign B8EEA617D681AA38D65D71FC3BE313BB16A4F43B --preserve-metadata\=identifier,entitlements,flags /Users/jenkins/Library/Developer/Xcode/DerivedData/WSIRegistry-axsxqyvzoiooybeuosxbtehxihzn/Build/Intermediates.noindex/ArchiveIntermediates/WSIRegistryPK-Release/InstallationBuildProductsLocation/Applications/PB\ Kids.app/Frameworks/ScanditCaptureCore.framework
  ```
  and run it manually from the command-line.  If it asks you for the keychain password,
  enter it, and click "Always allow".

  If you still have problems, this site has some extra voodoo to perform:
  https://medium.com/@ceyhunkeklik/how-to-fix-ios-application-code-signing-error-4818bd331327

- `provisioning-profiles:` Each application has a "provisioning profile", which
  the developer will provide.  We manually copy it into:
  ```
   Library/MobileDevice/Provisioning Profiles/<projectKey>.mobileprovision
  ```
  where `<projectKey>` matches what the user has specified for `projectKey`
  in their Jenkinsfile.  Additionally (instead of?), there should be a copy
  of the profile named according to its UUID: from StackOverflow, for the privisioning
  profile file `adhoc.mobileprovision`:
  ```
    uuid=`grep UUID -A1 -a adhoc.mobileprovision | grep -io "[-A-F0-9]\{36\}"`
    cp adhoc.mobileprovision ~/Library/MobileDevice/Provisioning\ Profiles/$uuid.mobileprovision
  ```

  These files are not secret.  (Perhaps they could live with the code, or
  in a separate repo that is the config/deployment for the code.)

#### `/plist/`
- The apps' `.plist` files.  There is one per app, and on the Mac Minis they
  live here:
  ```
    toolchain-jenkins-slave-config-macos/plist/<projectKey>.plist
  ```
  They reference the iOS Provisioning Profiles, and in particular, the
  `provisioningProfiles` key's value must correspond to the suffix of
  the "`application-identifier`" in the application's provisioning profile, or
  you will get an error during the export step suggesting you add a
  profile to the "provisioningProfiles" dictionary in your Export Options
  property list.

#### `/scripts/`
- `increment_version:` Allows the CI/CD pipeline to increment the version
  number of the iOS application from the Jenkinsfile.
 
- `xcresult_to_xml:` Script from SonarQube which converts unit tests output
  to be readable by SonarQube.

#### Misc
- The pipeline uses the `jenkins_devv.keychain` keychain (with two "v"s).
  The password for this keychain is available from a Tahoe member, and is
  stored as the Jenkins secret `jenkins_devv_keychain_password`.

- It is necessary for the pipeline to unlock the keychain as part of its
  run: it is not enough to manually unlock the keychain in another session,
  either from the GUI or the CLI.  Once unlocked, the pipeline may access
  the values of keychain items without offering further credentials.

- The pipeline keeps an app-specific password for the
  `ecomTahoe@wsgc.com` Apple ID in the keychain item named
  "`MY_SECRET`".  This password is also available from Tahoe members.

  Note: when you change the password for the ecomTahoe@wsgc.com Apple
  ID, it wipes out any app-specific passwords for the account.  You
  will thus need to generate a new one, and update hte `MY_SECRET`
  keychain item.
