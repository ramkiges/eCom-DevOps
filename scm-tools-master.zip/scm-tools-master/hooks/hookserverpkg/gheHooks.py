"""
gheHooks.py

Routines implementing GitHub Enterprise hooks, triggered by our package's Flask application.
"""

import os
import shutil
import uuid
import sys
import re
import json
import yaml
import threading
import git
import copy

from time import sleep
from random import random
from deepmerge import always_merger

import flask

# Include the top-level directory in the lookup path, so we can find the wsgc libs.
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
import wsgc.util
import wsgc.gheTools
import wsgc.ecomjira
import wsgc.prJenkinsfileCheck
import wsgc.semver
import hooks.hookserverpkg.helmMemoryCheck


from . import application
from . import hooksUtil


@application.route('/ghe_event_handler', methods=['GET', 'POST'])
def gheEventHandler_hook():
    try:
        # Handle a hook request.
        request = flask.request

        def isFlagSet(flagName):
            return request.args.get(flagName, '0') == '1'

        isJiraPREnabled = isFlagSet('jirapr')
        isPRJenkinsfileCheckEnabled = isFlagSet('prJenkinsfileCheck')
        isSemVerTagCheckEnabled = isFlagSet('semVerTagCheck')
        isPythonHelmAppSemVerCheckEnabled = isFlagSet('pythonAppSemVerCheck')
        isNodeSemVerCheckEnabled = isFlagSet('nodeSemVerCheck')
        isNodeAppSemVerCheckEnabled = isFlagSet('nodeAppSemVerCheck')
        isHelmChartSemVerCheckEnabled = isFlagSet('helmChartSemVerCheck')
        isHelmProjectSemVerCheckEnabled = isFlagSet('helmProjectSemVerCheck')
        isDockerfileSemVerCheckEnabled = isFlagSet('dockerfileSemVerCheck')
        isWebComponentJestSemverCheckEnabled = isFlagSet('webComponentJestSemVerCheck')
        isNPMPackageSemverCheckEnabled = isFlagSet('npmPackageSemVerCheck')
        isJSPackageSemverCheckEnabled = isFlagSet('jsPackageSemVerCheck')
        isEnvManifestPRCheckEnabled = isFlagSet('envManifestPR')
        isAkamaiManifestPRCheckEnabled = isFlagSet('akamaiManifestPR')
        isPRTagCheckEnabled = isFlagSet('prTagCheck')
        isHelmMemoryCheckEnabled = isFlagSet('helmMemoryCheck')

        if request.mimetype != 'application/json':
            raise Exception("Content-type must be 'application/json'")

        eventType = request.environ['HTTP_X_GITHUB_EVENT']

        def getPayload(request):
            """Return the json body of the request as a dict"""
            return json.loads(request.get_data().decode('utf-8'))

        if eventType == 'push':
            payload = getPayload(request)
            launchEnvSettingsIfNecessary(pushInfo=payload)

        elif eventType == 'pull_request':
            payload = getPayload(request)
            action = payload['action']

            if action in ('opened', 'synchronize'):
                if isPRJenkinsfileCheckEnabled:
                    doPRJenkinsfileCheck(pullRequest=payload['pull_request'])

            if isJiraPREnabled:
                # Log interesting PR actions in the Jira ticket, if there is one.
                if action in ['opened', 'closed', 'reopened']:
                    doPRJiraUpdate(action=action,
                                   actor=payload['sender']['login'],
                                   pullRequest=payload['pull_request'])

            if isSemVerTagCheckEnabled and action in ('opened', 'edited', 'synchronize'):
                doPRSemVerTagCheck(pullRequest=payload['pull_request'])

            if isPRTagCheckEnabled and action in ('opened', 'edited', 'synchronize', 'reopened'):
                doPRTagCheck(pullRequest=payload['pull_request'])

            if isHelmMemoryCheckEnabled and action in ('opened', 'edited', 'synchronize', 'reopened'):
                hooks.hookserverpkg.helmMemoryCheck.doHelmMemoryCheck(pullRequest=payload['pull_request'])
            #
            # Semantic Version Checks.
            #
            if isPythonHelmAppSemVerCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='PythonApp', shouldUpdateVersion=True)

            if isNodeSemVerCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='Node', shouldUpdateVersion=False)

            if isNodeAppSemVerCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='NodeApp', shouldUpdateVersion=False)

            if isHelmChartSemVerCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='HelmChart', shouldUpdateVersion=True)

            if isHelmProjectSemVerCheckEnabled:
                if action in ['labeled', 'ready_for_review']:
                    # A label was written, which we're going to assume was from previous action in the else below.
                    doMergePRIfLabeled(pullRequest=payload['pull_request'])
                elif action not in ['closed', 'unlabeled']:
                    # Do two things here:
                    # 1) Validate the project.yaml semver update using the usual prama
                    doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='HelmProject',
                                    shouldUpdateVersion=True)
                    # 2) Check if one (and only one) values.yaml has had *only* its tag value update
                    #    - If so, as long as the new value is in the form of a semver, pass new "automatcially merge flag".
                    doAutoMergabilityCheck(pullRequest=payload['pull_request'], tagType='HelmProjectDockerTag')

            if isDockerfileSemVerCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='Dockerfile',
                                shouldUpdateVersion=True)

            if isWebComponentJestSemverCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='WebComponentJest',
                                shouldUpdateVersion=False)

            if isNPMPackageSemverCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='NPMPackage',
                                shouldUpdateVersion=False)

            if isJSPackageSemverCheckEnabled:
                doPRSemVerCheck(pullRequest=payload['pull_request'], pipelineType='JSPackage',
                                shouldUpdateVersion=False)

            if isEnvManifestPRCheckEnabled and action in ('opened', 'reopened', 'synchronize', 'ready_for_review', 'labeled'):
                if payload['pull_request']['draft'] == False:
                    checkManifestSharedServiceChanged(pullRequest=payload['pull_request'])

            if isAkamaiManifestPRCheckEnabled and action in ('opened', 'reopened', 'synchronize', 'ready_for_review', 'labeled' ):
                if payload['pull_request']['draft'] == False:
                    checkAkamaiCommonRoutesChanged(pullRequest=payload['pull_request'])

        elif eventType == 'ping':
            payload = getPayload(request)
            hookInfo = payload['hook']['url'] if 'url' in payload['hook'] else payload['hook']
            application.logger.info("ping received: hook_id=%s, hook=%s", payload['hook_id'], hookInfo)

        else:
            application.logger.info("Unhandled event type '%s'", eventType)

    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    # Return success to the caller.  Any string will do; it will be seen as the body of the
    # response.
    return 'Success'


def launchEnvSettingsIfNecessary(pushInfo):
    """Run environment settings Jenkins job
    if the caller is an environment settings
    repository"""

    if pushInfo['deleted']:
        return  # Branch deleted; do nothing.

    orgName, repoName = pushInfo['repository']['full_name'].split('/', 2)

    # Only trigger if the caller repo name is 'environment-settings'
    if repoName == 'environment-settings':
        threading.Thread(target=launchEnvSettingsJob,
                         kwargs={
                             'pushInfo': pushInfo,
                             'orgName': orgName,
                             'repoName': repoName,
                         }).start()


def launchEnvSettingsJob(pushInfo, orgName, repoName):
    """
    Trigger jenkins job that is responsible for assembling
    environment settings file
    :param pushInfo: GHE Payload dict
    :param orgName: GHE Organization name
    :param repoName: GHE repository name
    :return:
    """
    ref = pushInfo['ref']
    cloneUrl = pushInfo['repository']['ssh_url']

    formDict = {
        'gheOrganization': orgName,
        'repoShortName': repoName,
        'branch': ref,
        'gheRepoCheckoutUrl': cloneUrl,
    }
    jenkinsJob = 'env-settings-hook'
    url = '{}/view/frontend/job/{}/buildWithParameters'.format(hooksUtil.JENKINS_URL, jenkinsJob)
    wsgc.util.callJenkinsURL(url=url, formDict=formDict)
    application.logger.info('Jenkins environment settings job call was successful')


def doPRJiraUpdate(action, actor, pullRequest):
    # Read the PR description, and if there's something that looks like
    # a Jira ticket in it, update the Jira ticket describing the action.

    prUrl = pullRequest['html_url']
    prTitle = pullRequest['title']
    prBody = pullRequest['body']

    prText = prTitle
    if prBody:
        prText += f"\n{prBody}"

    matchResult = re.search(r'\[([A-Za-z]+-\d+)\]', prText)
    if matchResult:
        # This is recognizable as a Jira ticket.
        jiraIssue = matchResult.group(1)
    else:
        application.logger.warning('Jira issue marker not found in pr %s', prUrl)
        return

    # Humanize the name of the action.
    if action == 'closed':
        humanAction = 'merged' if pullRequest['merged'] else 'closed without merging'
    elif action == 'synchronize':
        humanAction = 'updated'
    else:
        humanAction = action

    jiraComment = 'Pull request {} by [~{}]: {} : "{}"'.format(humanAction, actor, prUrl, prTitle)

    # Read the Jira credentials if we don't already have them.
    if 'jiraUserAndPass' not in flask.g:
        flask.g.jiraUserAndPass = {
            'user': wsgc.util.getCredential('jira', 'user'),
            'password': wsgc.util.getCredential('jira', 'password'),
        }

    # Talk to Jira in background so GHE doesn't have to wait.
    threading.Thread(target=addJiraComment,
                     kwargs={
                         'authUser': flask.g.jiraUserAndPass['user'],
                         'authPassword': flask.g.jiraUserAndPass['password'],
                         'jiraIssue': jiraIssue,
                         'jiraComment': jiraComment,
                     }).start()


def addJiraComment(authUser, authPassword, jiraIssue, jiraComment):
    url = '{}/rest/api/2/issue/{}/comment'.format(hooksUtil.JIRA_URL, jiraIssue)

    formDict = {'body': jiraComment}

    wsgc.util.callURL(url=url,
                      action='post',
                      formDict=formDict,
                      authUser=authUser, authPassword=authPassword)

    application.logger.info('Successfully added comment to Jira %s', jiraIssue)

    # Adding the comment adds the user to the watchers list, which
    # clutters it and generates noise email.  Remove it.
    removeJiraWatcher(jiraIssue=jiraIssue,
                      userToRemove=authUser,
                      authUser=authUser, authPassword=authPassword)


def removeJiraWatcher(jiraIssue, userToRemove, authUser, authPassword):
    url = '{}/rest/api/2/issue/{}/watchers'.format(hooksUtil.JIRA_URL, jiraIssue)

    # Jira watchers are deleted with query parameters, not form variables.
    params = {'username': userToRemove}

    wsgc.util.callURL(url=url,
                      action='delete',
                      params=params,
                      authUser=authUser, authPassword=authPassword)

    application.logger.info('Successfully removed %s as a watcher of %s', userToRemove, jiraIssue)


def doMergePRIfLabeled(pullRequest):
    targetOrgName = pullRequest['base']['repo']['owner']['login']
    targetRepoName = pullRequest['base']['repo']['name']
    prNumber = pullRequest['number']

    prLabels = wsgc.gheTools.getPRLabels(orgName=targetOrgName,
                                         repoName=targetRepoName,
                                         prNumber=prNumber)
    if ('auto-mergable' in prLabels) and ('valid-semver' in prLabels):
        if not wsgc.gheTools.checkIfAlreadyMerged(orgName=targetOrgName,
                                    repoName=targetRepoName,
                                    prNumber=prNumber):
            application.logger.info('PR has necessary labels; auto-merging...')

            wsgc.gheTools.addPRReview(orgName=targetOrgName,
                                      repoName=targetRepoName,
                                      prNumber=prNumber,
                                      reviewStatus='APPROVE',
                                      reviewComment='Approved by auto-merge process')

            wsgc.gheTools.mergePullRequest(orgName=targetOrgName,
                                           repoName=targetRepoName,
                                           prNumber=prNumber,
                                           mergeTags='AUTO-MERGE',
                                           mergeTitle='Merge of version-only change',
                                           mergeTriggerType='auto-merge')


def doPRTagCheck(pullRequest):
    """
    Ensure PR has a valid JIRA or INC/SERREQ/CHG/RLSE SNOW tag(s) in the PR title and commits in the form of [ISSUE-1234]
    Also tags [EMERGENCY] and [CLEANUP] are valid tags.
    Following the conventions in here http://reference.wsgc.com/standards/doc/std-0121/commit-tagging-conventions-1.1.0/
    """

    prTitle = pullRequest['title']
    prHtmlUrl = pullRequest['html_url']
    prNumber = pullRequest['number']
    orgName = pullRequest['base']['repo']['owner']['login']
    repoName = pullRequest['base']['repo']['name']
    prCommitID = pullRequest['head']['sha']

    # Check for tags in pr title
    if not checkForTags(orgName, repoName, prCommitID, prHtmlUrl, prTitle, "PR title"):
        return

    prCommits = wsgc.gheTools.getPRCommits(orgName, repoName, prNumber)
    commitMessage = ""
    for prCommit in prCommits:
        commitMessage += prCommit["commit"]["message"] + " "

    # Check for tags in pr commits
    if not checkForTags(orgName, repoName, prCommitID, prHtmlUrl, commitMessage, "PR commits"):
        return

    msg = "PR tag check successful"
    updateStatusForPRTagCheck(orgName, repoName, prCommitID, wsgc.gheTools.GHE_STATE_SUCCESS, prHtmlUrl, msg)


def checkForTags(orgName, repoName, prCommitID, prHtmlUrl, message, logText):
    """
    Checks whether one of the mandatory tags is present in the given message
    """

    validJiraTickets = set()
    invalidJiraTickets = set()
    otherAllowedTags = set()
    serviceNowTags = set()

    jiraTicketsMatch = re.findall(r'\[\s*(([A-Za-z]+)-\d+)\s*\]', message, re.IGNORECASE)
    if jiraTicketsMatch:
        for jiraTicketMatch in jiraTicketsMatch:
            jiraTicket = jiraTicketMatch[0]
            jiraOrg = jiraTicketMatch[1]
            if jiraOrg.lower() != "mfe":
                isValid = validateJIRAIdentifier(jiraTicket)
                if isValid:
                    validJiraTickets.add(jiraTicket)
                else:
                    invalidJiraTickets.add(jiraTicket)

    otherAllowedTagsMatch = re.findall(r'\[\s*(EMERGENCY|CLEANUP)\s*\]', message, re.IGNORECASE)
    if otherAllowedTagsMatch:
        otherAllowedTags = set(otherAllowedTagsMatch)

    serviceNowTagsMatch = re.findall(r'\[\s*(INC\d+|SERREQ\d+|RLSE\d+|CHG\d+)\s*\]', message, re.IGNORECASE)
    if serviceNowTagsMatch:
        serviceNowTags = set(serviceNowTagsMatch)

    if not (validJiraTickets or otherAllowedTags or serviceNowTags):
        if invalidJiraTickets:
            invalidJiraTickets = ",".join(invalidJiraTickets)
            msg = f"JIRA tickets {invalidJiraTickets} in {logText} does not exist. JIRA tickets should be a valid one."
        else:
            msg = f"Missing one of the mandatory PR tags [JIRA-1234],[INCXX],[SERREQXX],[CHGXX],[RLSEXX],[EMERGENCY]," \
                  f"[CLEANUP] in {logText}."
        updateStatusForPRTagCheck(orgName, repoName, prCommitID, wsgc.gheTools.GHE_STATE_FAILURE, prHtmlUrl, msg)
        return False

    return True


def updateStatusForPRTagCheck(orgName, repoName, prCommitID, statusState, prHtmlUrl, msg):
    """
    Update the status for the PR tag check to the PR
    """

    application.logger.info('Setting status to %s for PR commit %s in %s/%s (%s): %s',
                            statusState, prCommitID, orgName, repoName, prHtmlUrl, msg)

    # Talk to GHE in the background so we don't have to wait.
    threading.Thread(target=updatePRStatus,
                     kwargs={
                         'orgName': orgName,
                         'repoName': repoName,
                         'prCommitID': prCommitID,
                         'statusName': wsgc.gheTools.GHE_STATUS_PR_TAG_CONVENTION,
                         'statusState': statusState,
                         'msg': msg,
                     }).start()


def validateJIRAIdentifier(jiraID):
    """
    Check if the JIRA identifier tag in the commit message and PR title is a valid ticket or not
    """

    isValid = True
    jiraIssue, jiraError = wsgc.ecomjira.getJiraIssue(jiraID)
    if not jiraIssue:
        if jiraError:
            if jiraError.status_code == 404 and "Issue Does Not Exist" in jiraError.text:
                isValid = False

    return isValid


def doPRSemVerTagCheck(pullRequest):
    # Ensure that the PR title has exactly one "semantic versioning" tag as described in
    # http://reference.wsgc.com/standards/doc/std-0121/commit-tagging-conventions-1.1.0/ (or its
    # latest-version replacement), or a '[RELEASE] vX.Y.Z' tag, but not both.
    #
    # Note that the label must be standalone (e.g., not [JIRA-1234,MINOR]), but it may appear
    # anywhere in the PR title, and there must not be more than one semantic versioning tag.
    prTitle = pullRequest['title']
    prHtmlUrl = pullRequest['html_url']
    orgName = pullRequest['base']['repo']['owner']['login']
    repoName = pullRequest['base']['repo']['name']
    prCommitID = pullRequest['head']['sha']

    VALID_TAGS = {'MAJOR', 'MINOR', 'PATCH', 'RELEASE'}

    foundSemVerTags = re.findall(r'\[({})\]'.format('|'.join(VALID_TAGS)), prTitle)
    numSemVerTags = len(foundSemVerTags)

    if numSemVerTags == 1:
        if foundSemVerTags[0] == 'RELEASE':
            # Validate that it is followed by a version number.
            match = re.search(r'\[RELEASE\]\s*(v\d+(?:\.\d+)*)', prTitle)
            if match:
                statusState = wsgc.gheTools.GHE_STATE_SUCCESS
                msg = "Explicit release version '{}' found in PR title".format(match.group(1))
            else:
                statusState = wsgc.gheTools.GHE_STATE_FAILURE
                msg = "[RELEASE] tag not followed by version of the form vX.Y.Z (for any number of components)."
        else:
            statusState = wsgc.gheTools.GHE_STATE_SUCCESS
            msg = "Semantic versioning tag '{}' found in PR title".format(foundSemVerTags[0])
    else:
        statusState = wsgc.gheTools.GHE_STATE_FAILURE
        if numSemVerTags == 0:
            msg = 'Missing semantic versioning tag in PR title'
        else:
            msg = 'Multiple semantic versioning tags found in PR title ({})'.format(', '.join(foundSemVerTags))

    application.logger.info('Setting status to %s for PR commit %s in %s/%s (%s): %s',
                            statusState, prCommitID, orgName, repoName, prHtmlUrl, msg)

    # Talk to GHE in the background so we don't have to wait.
    threading.Thread(target=updatePRStatus,
                     kwargs={
                         'orgName': orgName,
                         'repoName': repoName,
                         'prCommitID': prCommitID,
                         'statusName': wsgc.gheTools.GHE_STATUS_SEMVER_TAG,
                         'statusState': statusState,
                         'msg': msg,
                     }).start()


def doPRJenkinsfileCheck(pullRequest):
    """
    Make sure that the PR isn't introducing customization to the Jenkinsfile that we wouldn't expect
    to see across branches/orgs.
    """

    def jenkinsfileDiffCheckFn(prDiff):
        violations = wsgc.prJenkinsfileCheck.checkDiff(prDiff)
        infoUrl = "https://confluence.wsgc.com/display/TAH/Pipeline+DSL#PipelineDSL-Branch-SpecificSettings"
        return violations, infoUrl

    doPRDiffCheck(pullRequest=pullRequest,
                  statusName=wsgc.gheTools.GHE_STATUS_CI_JENKINSFILE,
                  diffCheckFn=jenkinsfileDiffCheckFn)


def doAutoMergabilityCheck(pullRequest, tagType):
    """
    Check if the PR is eligible to be AutoMerged.
    wsgc.gheTools.checkForAutoMergability(prDiff)
    """
    targetOrgName = pullRequest['base']['repo']['owner']['login']
    targetRepoName = pullRequest['base']['repo']['name']
    prNumber = pullRequest['number']

    def semverDiffCheckFn(prDiff):
        # Artificially slow ourselves down a random amount between 0 and 4 seconds
        # in order to _hopefully_ prevent double dipping
        sleepyTime = round((random() * 4), 1)
        sleep(sleepyTime)

        semverConfig = wsgc.semver.OTHER_SEMVERS[tagType]
        semverFilename = semverConfig['filename']
        searchTemplate = semverConfig['searchTemplate']
        violations = wsgc.gheTools.checkForAutoMergability(prDiff=prDiff,
                                                           semverFilename=semverFilename,
                                                           searchTemplate=searchTemplate)
        infoUrl = "https://confluence.wsgc.com/display/TAH/Helm+Project+Versions#HelmProjectVersions-HelmProjectAutomergability"

        return violations, infoUrl

    doPRDiffCheck(pullRequest=pullRequest,
                  statusName=wsgc.gheTools.GHE_STATUS_CI_AUTO_MERGABLE,
                  diffCheckFn=semverDiffCheckFn,
                  labelName='auto-mergable')


def doPRSemVerCheck(pullRequest, pipelineType, shouldUpdateVersion):
    """
    Make sure that the PR has customized its semver.
    """

    targetOrgName = pullRequest['base']['repo']['owner']['login']
    targetRepoName = pullRequest['base']['repo']['name']

    prNumber = pullRequest['number']

    def semverDiffCheckFn(prDiff):
        semverConfig = wsgc.semver.PIPELINE_SEMVER_CONFIGS[pipelineType]
        semverFilename = semverConfig['filename']
        searchTemplate = semverConfig['searchTemplate']
        violations = wsgc.gheTools.checkForUpdatedSemver(prDiff=prDiff,
                                                         semverFilename=semverFilename,
                                                         searchTemplate=searchTemplate,
                                                         shouldUpdateVersion=shouldUpdateVersion)
        infoUrl = "https://confluence.wsgc.com/display/TAH/Helm+Project+Versions"

        return violations, infoUrl

    if shouldUpdateVersion:
        statusName = wsgc.gheTools.GHE_STATUS_CI_UPDATE_SEMVER
    else:
        statusName = wsgc.gheTools.GHE_STATUS_CI_KEEP_SEMVER

    if pipelineType == 'HelmProject':
        labelName = 'valid-semver'
    else:
        labelName = None

    doPRDiffCheck(pullRequest=pullRequest,
                  statusName=statusName,
                  diffCheckFn=semverDiffCheckFn,
                  labelName=labelName)


def doPRDiffCheck(pullRequest, statusName, diffCheckFn, labelName=None):
    """
    Generic PR-diff checking function; customize by passing a CI status name, and a
    diffCheckFn.

    The diffCheckFn must take one parameter, the PR diff, and return (violations,
    infoUrl), where violations is a possibly empty list of infractions, and infoUrl will
    be used for the "Details" link in GHE for the status check.
    """
    targetOrgName = pullRequest['base']['repo']['owner']['login']
    targetRepoName = pullRequest['base']['repo']['name']

    prNumber = pullRequest['number']
    prCommitID = pullRequest['head']['sha']

    theArgs = {
        'targetOrgName': targetOrgName,
        'targetRepoName': targetRepoName,
        'prNumber': prNumber,
        'prCommitID': prCommitID,
        'statusName': statusName,
        'diffCheckFn': diffCheckFn,
        'labelName': labelName,
    }

    # Background this so GHE doesn't have to wait while we analyze the diff.
    threading.Thread(target=doPRDiffCheck_Thread, kwargs=theArgs).start()


def doPRDiffCheck_Thread(targetOrgName, targetRepoName, prNumber, prCommitID, statusName, diffCheckFn, labelName):
    # Set the status to 'pending' to indicate that we're calculating the result.
    updatePRStatus(orgName=targetOrgName,
                   repoName=targetRepoName,
                   prCommitID=prCommitID,
                   statusName=statusName,
                   statusState=wsgc.gheTools.GHE_STATE_PENDING)

    prDiff = wsgc.gheTools.getPRDiff(orgName=targetOrgName,
                                     repoName=targetRepoName,
                                     prNumber=prNumber)

    violations, infoUrl = diffCheckFn(prDiff)
    statusState, msg = hooksUtil.parsePRViolations(violations)

    updatePRStatus(orgName=targetOrgName,
                   repoName=targetRepoName,
                   prCommitID=prCommitID,
                   statusName=statusName,
                   targetUrl=infoUrl,
                   statusState=statusState,
                   msg=msg)

    if labelName:
        if statusState == wsgc.gheTools.GHE_STATE_SUCCESS:
            wsgc.gheTools.addPRLabel(orgName=targetOrgName,
                                     repoName=targetRepoName,
                                     prNumber=prNumber,
                                     labelName=labelName)
        elif statusState == wsgc.gheTools.GHE_STATE_FAILURE:
            wsgc.gheTools.delPRLabel(orgName=targetOrgName,
                                     repoName=targetRepoName,
                                     prNumber=prNumber,
                                     labelName=labelName)

    application.logger.info('PR %s in %s/%s status updated to %s%s',
                            prNumber,
                            targetOrgName,
                            targetRepoName,
                            statusState,
                            " ({})".format(msg) if msg else "")


@application.route('/updatePRStatus')
def updatePRStatus_hook():
    # Jenkins is calling us with the results of a build.  We will update the PR with the result.
    #
    # NOTE: A user may push multiple times to a PR branch before we've finished any of our tests,
    # and we have no guarantee that they'll come back in an order that works well for us.  This is
    # not a problem: because the status is attached to the sha1 that was pushed, and not the PR
    # itself, the PR will use whatever status is attatched to its end at the time.  So we may
    # _needlessly_ update the status of a sha1 that is no longer relevant, but it won't be an
    # _error_ to do so.
    request = flask.request
    orgName = request.args['orgName']
    repoName = request.args['repoName']
    prCommitID = request.args['prCommitID']
    statusName = request.args['statusName']
    status = request.args['status']
    jobURL = request.args['jobURL']
    msg = request.args.get('msg', None)

    # Update the PR status accordingly.
    updatePRStatus(orgName=orgName,
                   repoName=repoName,
                   prCommitID=prCommitID,
                   statusName=statusName,
                   statusState=status,
                   targetUrl=jobURL,
                   msg=msg)

    return 'Success'  # Flask return.


def updatePRStatus(orgName, repoName, prCommitID, statusName, statusState, targetUrl='', msg=None):
    if not statusState in wsgc.gheTools.GHE_STATUS_VALID_STATES:
        raise Exception("Error: Invalid status state '{}'".format(statusState))

    if msg is not None:
        description = msg
    else:
        description = wsgc.gheTools.GHE_STATUSES[statusName]['description']

    wsgc.gheTools.writeStatus(orgName=orgName,
                              repoName=repoName,
                              commitID=prCommitID,
                              statusName=statusName,
                              statusState=statusState,
                              targetUrl=targetUrl,
                              description=description)


def checkManifestSharedServiceChanged(pullRequest):
    """
    UUID is used for temporary directory names where the base and head branches will be pulled.
    The UUID directory should be removed after all necessary steps are done. 
    """
    currentUUID = str(uuid.uuid4())
    tmpUUIDDir = f'/tmp/{currentUUID}'

    # head* == information about source repo, branch, etc.
    headRepoDir = f'{tmpUUIDDir}/head'
    headOrgName = pullRequest['head']['repo']['owner']['login']
    headRepoName = pullRequest['head']['repo']['name']
    headBranchName = pullRequest['head']['ref']
    headRepoCloneURL = ''

    # base* == information about target repo, branch, etc.
    baseOrgName = pullRequest['base']['repo']['owner']['login']
    baseRepoName = pullRequest['base']['repo']['name']
    baseBranchName = pullRequest['base']['ref']
    baseManifestBody = ''
    baseRepoDir = f'{tmpUUIDDir}/base'
    baseRepoCloneURL = ''

    formattedPRDiff = {}
    manifestPath = ''

    prNumber = pullRequest['number']
    prTitle = pullRequest['title']
    requestPRReviewGroups = ['manifest-super-friends']
    requestPRReviewRequired = False

    sharedEntryChanged = False
    sharedServiceReviewComment = None
    deletedServiceIsShared = False

    mandatoryBuildContexts = ['continuous-integration/jenkins/pr-merge']
    optionalBuildContexts = ['ci-jenkinsfile-check']

    disabledFixedVersionFlag = False
    disabledFixedVersionFlagComment = None

    disabledProtectedFlag = False
    disabledProtectedFlagComment = None

    def envManifestInfoBodyConstructor(manifestPath: str) -> dict:
        """
        Creating a dictionary of dictionaries with structured PR Diff data. 

        'manifestChangedApps' will be filled with a list of changed applications at later steps.
        """
        manifestEnv = re.sub('.*manifest/|/.*.yaml', '', manifestPath)
        manifestType = 'env' if 'env-manifest' in manifestPath else 'serv'
        result = {
            f'{manifestEnv}_{manifestType}': {
                'manifestPath': manifestPath,
                'manifestChangedApps': [],
                'manifestChangedSharedApps': {},
                'metadata': {
                    'head': {
                        'require_fixed_versions': '',
                        'protected': ''
                    },
                    'base': {
                        'require_fixed_versions': '',
                        'protected': ''
                    }
                }
            }          
        }
        return result

    def envManifestCompareAppConfig(primaryManifest: dict, secondaryManifest: dict):
        """
        Compares each app dictionary between two manifests ( head and base ), if two app dictionaries are not equal, 
        we consider that application has changed and put the application name into the result list. 
        Also, KeyError tells us that the application dictionary is present only in one manifest,
        and the application name will be added to the result list also. 
        """
        changedApps = []
        addedORdeletedApps = {}
        for appName in primaryManifest['services']:
            primaryApp = primaryManifest['services'][appName]
            primaryAppEnv = primaryApp.get('env', primaryManifest['env'])
            try:
                secondaryApp = secondaryManifest['services'][appName]
                secondaryAppEnv = secondaryApp.get('env', secondaryManifest['env'])
                if primaryApp != secondaryApp:
                    if primaryAppEnv != secondaryAppEnv:
                        addedORdeletedApps[appName] = {'env':primaryAppEnv}
                    else:
                        changedApps.append(appName)
            except KeyError:
                addedORdeletedApps[appName] = {'env':primaryAppEnv}

        return changedApps, addedORdeletedApps

    def findAppSubscribers(envName: str, appName: str, manifestLocation : str = f'{headRepoDir}/manifest/env-manifest'):
        subscribers = []
        for manifestEnv in os.listdir(manifestLocation):
            with open(f'{manifestLocation}/{manifestEnv}/services-manifest.yaml', 'r') as stream:
                manifest = yaml.safe_load(stream)

            for currentName in manifest['services']:
                if 'frontend' not in currentName and currentName == appName:
                    currentEnv = manifest['services'][currentName]['configuration']['services-collection-manifest']
                    if currentEnv == envName and manifestEnv != envName:
                        subscribers.append(manifestEnv)

        return subscribers

    def constructSharedAppChangedMessage(formattedPRDiff: dict):
        """
        Example:
        formattedPRDiff:
            qa35:
                manifestPath: manifest/qa35/qa35-services-manifest.yaml
                manifestChangedApps: ecom-svc-catalog
                manifestChangedSharedApps:
                    - ecom-svc-catalog:
                        consumers:
                            - qa48
                            - qa16
                            - qa49
            qa5:
                manifestPath: manifest/qa5/qa5-services-manifest.yaml
                manifestChangedApps: pricing-singleuse-batch-generator
                manifestChangedSharedApps:
                    - pricing-singleuse-batch-generator:
                        consumers:
                            - qa15
                            - qa34
                            - qa16

        The message:
        Changes affect one or more shared services:

        Manifest: manifest/qa35/qa35-services-manifest.yaml
        App name: ecom-svc-catalog
        App env: qa5
        App subscribers: [qa16, qa48, qa49]
            
        Manifest: manifest/qa5/qa5-services-manifest.yaml
        App name: pricing-singleuse-batch-generator
        App env: qa5
        App subscribers: [qa15, qa16, qa34]
        """
        result = None
        messageHeader = "**Changes affect one or more services that has subscribers in other environments:**\n***"
        messageBody = ""
        for envName, value in formattedPRDiff.items():
            manifestPath = formattedPRDiff[envName]['manifestPath']
            if value['manifestChangedSharedApps']:
                messageBody = f'{messageBody}\nManifest: `{manifestPath}`\n'
                for changedAppName, appInfo in value['manifestChangedSharedApps'].items():
                    messageBody = f'{messageBody}App name: `{changedAppName}`\nApp env: `{envName.split("_")[0]}`\n'
                    if appInfo:
                        messageBody = f'''{messageBody}App subscribers: `{appInfo["consumers"]}`\n***\n'''
                    else:
                        messageBody = f'''{messageBody}App subscribers: `No subscribers`\n***\n'''
        messageBody = f'{messageBody}There are subscribers present for changed services in other env-manifests. Additional review is required.'
        result = f'{messageHeader}\n{messageBody}'
        return result

    def getManifestMetadataItem(manifestBody: dict, metadataItemName: str) -> str:
        result = ""
        if 'metadata' in manifestBody:
            if metadataItemName in manifestBody['metadata']:
                result = manifestBody['metadata'][metadataItemName]
        return result

    def constructChangedMetadataMessage(formattedPRDiff: dict, changedMetadataItem: str, changeType: str = ''):
        result = ""
        messageBody = ""
        if changeType == 'TrueToFalse':
            messageHeader = f"**Changing the `{changedMetadataItem}` from `True` to `False` requires a review:**\n***"
            for _, value in formattedPRDiff.items():
                if (value['metadata']['head'][changedMetadataItem] == False) and (value['metadata']['base'][changedMetadataItem] == True):
                    messageBody = f"{messageBody}\nManifest: `{value['manifestPath']}`\n"
        result = f'{messageHeader}\n{messageBody}'
        return result

    prDiff = wsgc.gheTools.getPRDiff(orgName=baseOrgName, repoName=baseRepoName, prNumber=prNumber)

    parsedPRDiff = wsgc.gheTools.parsePRDiff(prDiff)

    """
    Clone head and base repos.
    """
    headRepoCloneURL = wsgc.gheTools.makeGHETokenUrl(orgName=headOrgName, repoName=headRepoName)
    baseRepoCloneURL = wsgc.gheTools.makeGHETokenUrl(orgName=baseOrgName, repoName=baseRepoName)
    headCloneRepo = git.Repo.clone_from(headRepoCloneURL, headRepoDir)
    baseCloneRepo = git.Repo.clone_from(baseRepoCloneURL, baseRepoDir)
    headCloneRepo.git.checkout(headBranchName)
    baseCloneRepo.git.checkout(baseBranchName)

    """
    Rebase head branch.
    """
    upstream = headCloneRepo.create_remote(baseOrgName, baseRepoCloneURL)
    upstream.fetch()

    try: 
        git.Repo(headRepoDir).git.rebase(f'{baseOrgName}/{baseBranchName}')
    except:
        shutil.rmtree(tmpUUIDDir)
        wsgc.gheTools.addPRReview(
            orgName=baseOrgName, repoName=baseRepoName, prNumber=prNumber, reviewStatus='COMMENT',
            reviewComment=f'PR conflict detected, please resolve it by rebasing from `{baseOrgName}/{baseBranchName}`.')
        return

    """
    As we are interested in changed manifests only, we can get manifest file paths from parsed PR and put them into 'changedManifests' list.
    """
    for key in parsedPRDiff:
        if 'manifest/' in key:
            formattedPRDiff = always_merger.merge(formattedPRDiff, envManifestInfoBodyConstructor(key))

    for envName in formattedPRDiff:
        envType = envName.split('_')[1]
        manifestPath = formattedPRDiff[envName]['manifestPath']
        headManifestBody=yaml.safe_load(open(f'{headRepoDir}/{manifestPath}', 'r'))
        baseManifestBody=yaml.safe_load(open(f'{baseRepoDir}/{manifestPath}', 'r'))
        if envType == 'env':
            # Populating the formattedPRDiff environment entry with the required metadata.
            formattedPRDiff[envName]['metadata']['head']['require_fixed_versions'] = getManifestMetadataItem(manifestBody=headManifestBody, metadataItemName='require_fixed_versions')
            formattedPRDiff[envName]['metadata']['base']['require_fixed_versions'] = getManifestMetadataItem(manifestBody=baseManifestBody, metadataItemName='require_fixed_versions')
            formattedPRDiff[envName]['metadata']['head']['protected'] = getManifestMetadataItem(manifestBody=headManifestBody, metadataItemName='protected')
            formattedPRDiff[envName]['metadata']['base']['protected'] = getManifestMetadataItem(manifestBody=baseManifestBody, metadataItemName='protected')

            # Changing the manifest metadata `require_fixed_versions` flag from `True` to `False` requires a review.
            if (formattedPRDiff[envName]['metadata']['head']['require_fixed_versions'] == False) and (formattedPRDiff[envName]['metadata']['base']['require_fixed_versions'] == True):
                disabledFixedVersionFlag = True
                requestPRReviewRequired = True

            # Changing the manifest metadata `protected` flag from `True` to `False` requires a review.
            if (formattedPRDiff[envName]['metadata']['head']['protected'] == False) and (formattedPRDiff[envName]['metadata']['base']['protected'] == True):
                disabledProtectedFlag = True
                requestPRReviewRequired = True
        else:
            headManifestChanges, addedApps = envManifestCompareAppConfig(primaryManifest=headManifestBody, secondaryManifest=baseManifestBody)
            baseManifestChanges, deletedApps = envManifestCompareAppConfig(primaryManifest=baseManifestBody, secondaryManifest=headManifestBody)

            manifestChangedApps = headManifestChanges + baseManifestChanges 
            if addedApps:
                manifestChangedApps += addedApps.keys()
            if deletedApps:
                formattedPRDiff[envName]['manifestDeletedApps'] = deletedApps
            formattedPRDiff[envName]['manifestChangedApps'] = list(dict.fromkeys(manifestChangedApps))

        if formattedPRDiff[envName]['manifestChangedApps'] and envType == 'serv':
            for changedAppName in formattedPRDiff[envName]['manifestChangedApps']:

                headSearchResult = findAppSubscribers(
                    envName=envName.split('_')[0], appName=changedAppName)

                if headSearchResult:
                    formattedPRDiff[envName]['manifestChangedSharedApps'][changedAppName] = {}
                    formattedPRDiff[envName]['manifestChangedSharedApps'][changedAppName]['consumers'] = headSearchResult

        if formattedPRDiff[envName]['manifestChangedSharedApps']:
            sharedEntryChanged = True
            requestPRReviewRequired = True

        if 'manifestDeletedApps' in formattedPRDiff[envName]:
            temp = copy.deepcopy(formattedPRDiff[envName]['manifestDeletedApps'])
            for deletedAppName, deletedAppInfo in formattedPRDiff[envName]['manifestDeletedApps'].items():
                    headSearchResult = findAppSubscribers(
                        envName=deletedAppInfo['env'], appName=deletedAppName)

                    if headSearchResult:
                        deletedServiceIsShared = True
                        requestPRReviewRequired = True
                        temp[deletedAppName]['consumers'] = headSearchResult
                    else:
                        del temp[deletedAppName]

            formattedPRDiff[envName]['manifestDeletedApps'] = temp

    if deletedServiceIsShared:
        comment = '**Deleted service has subscribers in other environments:**\n***'
        for envName, envInfo in formattedPRDiff.items():
            if envInfo.get('manifestDeletedApps', {}):
                manifestPath = envInfo['manifestPath']
                comment += f'\nManifest: `{manifestPath}`\n'
                for AppName, AppInfo in envInfo['manifestDeletedApps'].items():
                    if isinstance(AppInfo['consumers'], list):
                        comment += f'App name: `{AppName}`\nApp env: `{AppInfo["env"]}`\nApp subscribers:`{AppInfo["consumers"]}`'
                    else:
                        comment += AppInfo['consumers']+'\n***'

        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='REQUEST_CHANGES',
            reviewComment=comment)

    if sharedEntryChanged:
        sharedServiceReviewComment = constructSharedAppChangedMessage(formattedPRDiff=formattedPRDiff)
        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='COMMENT',
            reviewComment=sharedServiceReviewComment)

    elif not sharedEntryChanged and not deletedServiceIsShared:
        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='COMMENT',
            reviewComment='Waiting for the build result.')

    if disabledFixedVersionFlag:
        disabledFixedVersionFlagComment = constructChangedMetadataMessage(
            formattedPRDiff=formattedPRDiff,
            changedMetadataItem='require_fixed_versions',
            changeType='TrueToFalse')

        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='COMMENT',
            reviewComment=disabledFixedVersionFlagComment)

    if disabledProtectedFlag:
        disabledProtectedFlagComment = constructChangedMetadataMessage(
            formattedPRDiff=formattedPRDiff,
            changedMetadataItem='protected',
            changeType='TrueToFalse')

        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='COMMENT',
            reviewComment=disabledProtectedFlagComment)

    if requestPRReviewRequired:
        wsgc.gheTools.requestPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            groupList=requestPRReviewGroups)

    buildSummaryMessage, buildResult = getGHEBuildsResult(
        prStatusLink=pullRequest['_links']['statuses']['href'],
        mandatoryContextNames=mandatoryBuildContexts,
        sleepInit=30,
        maxTries=60,
        sleepReTry=20,
        optionalContextNames=optionalBuildContexts,
        printOptionalContextStatus=False,
        applyOptionalContextStatus=True)

    wsgc.gheTools.addPRReview(
        orgName=baseOrgName,
        repoName=baseRepoName,
        prNumber=prNumber,
        reviewStatus='COMMENT',
        reviewComment=buildSummaryMessage)

    if buildResult and not requestPRReviewRequired:        
        wsgc.gheTools.addPRReview(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            reviewStatus='COMMENT',
            reviewComment='Approved by the auto-merge process as the build was successful.')

        wsgc.gheTools.mergePullRequest(
            orgName=baseOrgName,
            repoName=baseRepoName,
            prNumber=prNumber,
            mergeTags='AUTO-MERGE',
            mergeTitle=prTitle,
            mergeTriggerType='auto-merge')
    """
    Purge cloned local repos.  
    """
    shutil.rmtree(tmpUUIDDir)


def checkAkamaiCommonRoutesChanged(pullRequest):
    currentUUID = str(uuid.uuid4())
    tmpUUIDDir = f'/tmp/{currentUUID}'

    headRepoDir = f'{tmpUUIDDir}/head'
    headOrgName = pullRequest['head']['repo']['owner']['login']
    headRepoName = pullRequest['head']['repo']['name']
    headBranchName = pullRequest['head']['ref']
    headRepoCloneURL = ""

    baseOrgName = pullRequest['base']['repo']['owner']['login']
    baseRepoName = pullRequest['base']['repo']['name']
    baseBranchName = pullRequest['base']['ref']
    baseManifestBody = ""
    baseRepoDir = f'{tmpUUIDDir}/base'
    baseRepoCloneURL = ""

    formattedPRDiff = []
    manifestPath = ""

    prNumber = pullRequest['number']
    prTitle = pullRequest['title']
    requestPRReviewGroups = ['manifest-super-friends']
    requestPRReviewRequired = False

    mandatoryBuildContexts = ['continuous-integration/jenkins/pr-merge']
    optionalBuildContexts = ['ci-jenkinsfile-check']

    def akamaiManifestInfoBodyConstructor(manifestPath: str) -> dict:
        """
        Example1:
        manifestPath = 'manifest/USA/mg-test/qa/qa28/microservice.json'
        ->
        manifestEnvGroupName = 'qa'
        manifestEnvName = 'qa28'
        ---

        Example2:
        manifestPath = 'manifest/USA/mg-test/common/microservice.json'
        ->
        manifestEnvGroupName = 'common'
        manifestEnvName = ''    
        """

        manifestEnvGroupName = manifestPath.split('/')[3]

        if manifestEnvGroupName == 'common':
            manifestEnvName = ''
        else:
            manifestEnvName = manifestPath.split('/')[4]

        result = {
            'manifestPath': manifestPath,
            'manifestEnvGroupName': manifestEnvGroupName,
            'manifestEnvName': manifestEnvName,
            'manifestChangedFields': ''
        }

        return result
    
    def get_path_values(criteria, return_excludes = False):
        """
        Get MATCHES_ONE_OF and DOES_NOT_MATCH_ONE_OF 
        path values (by default or exclude_common_values if specified) 
        from the passed criteria
        """
        values = 'values'
        if return_excludes:
            values = 'exclude_common_values'
        for obj in criteria:
            if obj['name'] == 'path':
                if obj['options']['matchOperator'] == 'MATCHES_ONE_OF':
                    match = obj['options'].get(values, [])
                if obj['options']['matchOperator'] == 'DOES_NOT_MATCH_ONE_OF':
                    not_match = obj['options'].get(values, [])
        return match, not_match

    prDiff = wsgc.gheTools.getPRDiff(orgName=baseOrgName, repoName=baseRepoName, prNumber=prNumber)

    parsedPRDiff = wsgc.gheTools.parsePRDiff(prDiff)

    headRepoCloneURL = wsgc.gheTools.makeGHETokenUrl(orgName=headOrgName, repoName=headRepoName)
    baseRepoCloneURL = wsgc.gheTools.makeGHETokenUrl(orgName=baseOrgName, repoName=baseRepoName)
    headCloneRepo = git.Repo.clone_from(headRepoCloneURL, headRepoDir)
    baseCloneRepo = git.Repo.clone_from(baseRepoCloneURL, baseRepoDir)
    headCloneRepo.git.checkout(headBranchName)
    baseCloneRepo.git.checkout(baseBranchName)

    upstream = headCloneRepo.create_remote(baseOrgName, baseRepoCloneURL)
    upstream.fetch()

    try: 
        git.Repo(headRepoDir).git.rebase(f'{baseOrgName}/{baseBranchName}')
    except:
        shutil.rmtree(tmpUUIDDir)
        wsgc.gheTools.addPRReview(orgName=baseOrgName,
                                  repoName=baseRepoName,
                                  prNumber=prNumber,
                                  reviewStatus='COMMENT',
                                  reviewComment=f'PR conflict detected, please resolve it by rebasing from `{baseOrgName}/{baseBranchName}`.')
        return 0

    for path in parsedPRDiff:
        if "manifest/" in path:
            formattedPRDiff.append(akamaiManifestInfoBodyConstructor(path))

    for formattedPRDiffEntry in formattedPRDiff:
        manifestPath = formattedPRDiffEntry['manifestPath']

        headManifestBody=json.load(open(f'{headRepoDir}/{manifestPath}', "r"))
        baseManifestBody=json.load(open(f'{baseRepoDir}/{manifestPath}', "r"))

        manifestChangedFields = []
        for key in headManifestBody:
            if headManifestBody[key] != baseManifestBody[key]:
                manifestChangedFields.append(key)

        formattedPRDiffEntry['manifestChangedFields'] = manifestChangedFields
        formattedPRDiffEntry['list_match'], formattedPRDiffEntry['list_not_match'] = [], []
        if formattedPRDiffEntry['manifestEnvGroupName'] == 'common' and formattedPRDiffEntry['manifestChangedFields'] != []:
            match_after, not_match_after = get_path_values(headManifestBody['criteria'])
            match_before, not_match_before = get_path_values(baseManifestBody['criteria'])
            removed_match = set(match_before) - set(match_after)
            removed_not_match = set(not_match_before) - set(not_match_after)
            if removed_match or removed_not_match:
                brand_path = manifestPath.split('common')[0]
                brand_full_path = headRepoDir +'/'+ brand_path
                manifset_type = manifestPath.split('/')[-1]
                for env_group in os.listdir(brand_full_path):
                    if env_group != 'common':
                        for env in os.listdir(brand_full_path + env_group):
                            if env != 'common':
                                manifest_path = f'{env_group}/{env}/{manifset_type}'
                                manifest = json.load(open(f'{brand_full_path}{manifest_path}', 'r'))
                                exclude_match_values, exclude_not_match_values = get_path_values(manifest['criteria'], True)
                                if removed_match & set(exclude_match_values):
                                    formattedPRDiffEntry['list_match'].append(brand_path + manifest_path)
                                if removed_not_match & set(exclude_not_match_values):
                                    formattedPRDiffEntry['list_not_match'].append(brand_path + manifest_path)

    comment_list = []
    for formattedPRDiffEntry in formattedPRDiff:
        if (formattedPRDiffEntry['manifestEnvGroupName'] == 'common') or (formattedPRDiffEntry['manifestEnvGroupName'] == 'uat'):
            requestPRReviewRequired = True

            if formattedPRDiffEntry['list_match']:
                comment = f"""Routes removed from 'MATCHES_ONE_OF' in **{formattedPRDiffEntry['manifestPath']}**
                    need to be deleted from 'exclude_common_values' in next manifests as well:\n""" + '\n'.join([f'`{path}`' for path in formattedPRDiffEntry['list_match']])
                comment_list.append(comment)

            if formattedPRDiffEntry['list_not_match']:
                comment = f"""Routes removed from 'DOES_NOT_MATCH_ONE_OF' in **{formattedPRDiffEntry['manifestPath']}**
                    need to be deleted from 'exclude_common_values' in next manifests as well:\n""" + '\n'.join([f'`{path}`' for path in formattedPRDiffEntry['list_not_match']])
                comment_list.append(comment)

    if requestPRReviewRequired:   
        wsgc.gheTools.addPRReview(orgName=baseOrgName,
                                repoName=baseRepoName,
                                prNumber=prNumber,
                                reviewStatus='COMMENT',
                                reviewComment="Changes affect common or uat routes and additional approval is required")
        if comment_list:
            for comment in comment_list:
                wsgc.gheTools.addPRReview(orgName=baseOrgName, repoName=baseRepoName, prNumber=prNumber, reviewStatus='COMMENT', reviewComment=comment)

        wsgc.gheTools.requestPRReview(orgName=baseOrgName,
                                      repoName=baseRepoName,
                                      prNumber=prNumber,
                                      groupList=requestPRReviewGroups)
    else:
        wsgc.gheTools.addPRReview(orgName=baseOrgName,
                                repoName=baseRepoName,
                                prNumber=prNumber,
                                reviewStatus='COMMENT',
                                reviewComment='No common routes changed, waiting for the build result.')

    buildSummaryMessage = str
    buildResult = bool

    buildSummaryMessage, buildResult = getGHEBuildsResult(prStatusLink = pullRequest['_links']['statuses']['href'],
                                                          mandatoryContextNames = mandatoryBuildContexts,
                                                          sleepInit = 30,
                                                          maxTries = 60,
                                                          sleepReTry = 20,
                                                          optionalContextNames = optionalBuildContexts,
                                                          printOptionalContextStatus = False,
                                                          applyOptionalContextStatus = True)

    wsgc.gheTools.addPRReview(orgName=baseOrgName,
                            repoName=baseRepoName,
                            prNumber=prNumber,
                            reviewStatus='COMMENT',
                            reviewComment=buildSummaryMessage)

    if (requestPRReviewRequired == False) and (buildResult == True):
        wsgc.gheTools.addPRReview(orgName=baseOrgName,
                                  repoName=baseRepoName,
                                  prNumber=prNumber,
                                  reviewStatus='COMMENT',
                                  reviewComment='Approved by the auto-merge process as no common or uat routes changed, and the build was successful.')
        wsgc.gheTools.mergePullRequest(orgName=baseOrgName,
                                        repoName=baseRepoName,
                                        prNumber=prNumber,
                                        mergeTags='AUTO-MERGE',
                                        mergeTitle=prTitle,
                                        mergeTriggerType='auto-merge')
            
    shutil.rmtree(tmpUUIDDir)


def getGHEBuildsResult(prStatusLink: str,
                       mandatoryContextNames: list,
                       sleepInit: int = 15,  
                       maxTries: int = 30, 
                       sleepReTry: int = 10, 
                       optionalContextNames: list = [],
                       printOptionalContextStatus: bool = False,
                       applyOptionalContextStatus: bool = False):
    """
    Args:
        prStatusLink: pullRequest['_links']['statuses']['href'], api page that contains information about all related CI builds.
        mandatoryContextNames: Context names ( GHE build names ) that should be present.
        sleepInit: Github needs some time to initiate CI build. Usually, 15-20s is enough. 
        maxTries: How many tries if one of the build has `pending` state.
        sleepReTry: How many seconds between `maxTries`.
        optionalContextNames: Context names ( GHE build names ) that optionally should be present. 
        printOptionalContextStatus: Post messages with results for optional context build to pull request thread.
        applyOptionalContextStatus: Return `False` if one of the optional contexts build fails.  In context absence, the `True` will be returned.
    Returns:
        buildResult: The overall result of the builds. Depends on `mandatoryContextNames`, `applyOptionalContextStatus`.
        summaryMessage: The message contains build results and error messages.
    """

    def getSummaryStatusMessageForBuilds(buildStatuses: dict, contextNames: list):
        """
        Args:
            buildStatuses: The dictionary from the `parseGHEBuildStatusesPage` function.
            contextNames: Context names for which the status will be generated for.
        Returns: 
            result: The message with CI build state for requsted contexts.
        Message example: 
            CI build name: continuous-integration/jenkins/pr-merge \n
            CI build status: success \n
            CI build URL: https://ecombuild.wsgc.com/jenkins/job/eCommerce-Echo/job/akamai-manifest/job/PR-30/2/display/redirect
        """
        result = ""
        for contextName in contextNames:
            if buildStatuses.get(contextName):
                result = f'''{result} \nCI build name: `{contextName}`\nCI build status: `{buildStatuses[contextName]['state']}` \nCI build URL: {buildStatuses[contextName]['target_url']} \n'''
        return result


    def getSummaryStatusForBuilds(buildStatuses: dict, contextNames: list, absentContextFail: bool = True):
        """
        Args:
            buildStatuses: The dictionary from the `parseGHEBuildStatusesPage` function.
            contextNames: Context names for which the status will be checked.
            absentContextFail: Return a `False` result if one of the contexts is missing.
        Returns:
            errorsMsg: `str` Error messages for requested context builds.
            result: `bool` Overall result for the requested build contexts.
        """
        result = True
        unknownStateDetected = False
        result_statuses = []
        known_statuses = ['error', 'pending', 'success']
        errorsMsg = ""

        for contextName in contextNames:
            if buildStatuses.get(contextName):
                if buildStatuses[contextName]['state'] in known_statuses:
                    result_statuses.append(buildStatuses[contextName]['state'])
                else:
                    unknownStateDetected = True
            else:
                if absentContextFail:
                    errorsMsg = f'''{errorsMsg} \nERROR: Didn't find `{contextName}` build.\n'''
                    result = False
                
        result_statuses = list(set(result_statuses))

        if unknownStateDetected:
            errorsMsg = f'''{errorsMsg} \nERROR: One of the builds did not have a successful status.\n'''
            result = False

        if 'error' in result_statuses:
            errorsMsg = f'''{errorsMsg} \nERROR: One of the CI builds failed. Please resolve the issue for proceeding with merge/auto-merge.\n'''
            result = False

        if 'pending' in result_statuses:
            errorsMsg = f'''{errorsMsg} \nERROR: One of the CI builds still pending. Please check the build or increase the `maxTries` param for the build check function.\n'''
            result = False
        return errorsMsg, result

    def parseGHEBuildStatusesPage(statusLinkBody: list) -> dict:
        """
        Args:
            The body from github api page with all context builds for a single pull request. \n
            pullRequest['_links']['statuses']['href']     
        Returns:
            result: A dictionary with all unique found build contexts with their current state and target URL.
        Example result dictionary:
          {
              'continuous-integration/jenkins/pr-merge': {
                  'state': 'pending', \n
                  'target_url': 'https://ecombuild.wsgc.com/jenkins/job/eCommerce-DevOps/job/env-manifest/job/PR-1141/1/display/redirect'
              }, 
              'ci-jenkinsfile-check': {
                  'state': 'success', \n
                  'target_url': 'https://confluence.wsgc.com/display/TAH/Pipeline+DSL#PipelineDSL-Branch-SpecificSettings'
              }
          }
        """
        result = {}
        for item in statusLinkBody:
            if item['context'] in result:
                if result[item['context']]['state'] == 'pending':
                    result[item['context']]['state'] = item['state']
                if result[item['context']]['target_url'] == None:
                    result[item['context']]['target_url'] = item['target_url']
            else:
                result[item['context']] = {}
                result[item['context']]['state'] = ''
                result[item['context']]['target_url'] = ''
                result[item['context']]['state'] = item['state']
                result[item['context']]['target_url'] = item['target_url']
        return result


    def detectGHEBuildsPendingState(buildStatuses: dict, contextNames: list) -> bool:
        """
        Args:
            buildStatuses: The dictionary from the `parseGHEBuildStatusesPage` function.
            contextNames: `list` of contexts that will be checked.
        Returns:
            `True`: if one of the contexts from the `contextNames` has a `pending` state or doesn't present in `buildStatuses`.
            `False`: if none of the contexts from the `contextNames` has a `pending` state and all of them are present in `buildStatuses`.
        """
        result = bool
        result_list = []

        for contextName in contextNames:
            if buildStatuses.get(contextName):
                result_list.append(buildStatuses[contextName]['state'])
            else:
                result_list.append('pending')

        result_list = list(set(result_list))
        if 'pending' in result_list:
            result = True
        else:
            result = False
        return result

    """
    Wait github initialize ci builds.
    """
    sleep(sleepInit)
    
    mandatoryBuildResult = bool
    mandatoryBuildStatusMessage = str
    mandatoryBuildErrorMessage = str

    optionalBuildsResult = bool
    optionalBuildStatusMessage = str
    optionalBuildErrorMessage = str

    buildResult = bool
    summaryMessage = str
    
    for try_num in range(maxTries):
        statusLinkBody = []
        statusLinkBody = wsgc.gheTools.getGHEApiPage(prStatusLink)

        buildStatuses = {}
        mandatoryContextsPendingState = bool
        optionalContextsPendingState = bool
        buildStatuses = parseGHEBuildStatusesPage(statusLinkBody = statusLinkBody)

        mandatoryContextsPendingState = detectGHEBuildsPendingState(buildStatuses = buildStatuses, 
                                                                    contextNames = mandatoryContextNames)
        optionalContextsPendingState = detectGHEBuildsPendingState(buildStatuses = buildStatuses, 
                                                                    contextNames = optionalContextNames)

        if printOptionalContextStatus:
            if mandatoryContextsPendingState or optionalContextsPendingState:
                pass
            else:
                break
        else:
            if mandatoryContextsPendingState:
                pass
            else:
                break
        sleep(sleepReTry)

    mandatoryBuildStatusMessage = getSummaryStatusMessageForBuilds(buildStatuses = buildStatuses, 
                                                                   contextNames = mandatoryContextNames)
    optionalBuildStatusMessage = getSummaryStatusMessageForBuilds(buildStatuses = buildStatuses, 
                                                                  contextNames = optionalContextNames)

    mandatoryBuildErrorMessage, mandatoryBuildResult = getSummaryStatusForBuilds(buildStatuses = buildStatuses, 
                                                                                 contextNames = mandatoryContextNames)
    optionalBuildErrorMessage, optionalBuildsResult = getSummaryStatusForBuilds(buildStatuses = buildStatuses, 
                                                                                contextNames = optionalContextNames, 
                                                                                absentContextFail = False)
    summaryMessage = mandatoryBuildStatusMessage + optionalBuildStatusMessage if printOptionalContextStatus else mandatoryBuildStatusMessage

    if mandatoryBuildErrorMessage:
        summaryMessage = summaryMessage + mandatoryBuildErrorMessage

    if optionalBuildErrorMessage and printOptionalContextStatus:
        summaryMessage = summaryMessage + optionalBuildErrorMessage

    if applyOptionalContextStatus:
        buildResult = True if (mandatoryBuildResult and optionalBuildsResult) else False
    else:
        buildResult = mandatoryBuildResult

    return summaryMessage, buildResult
