import os
import uuid
import sys
import re
import threading
import git

from . import application


# Include the top-level directory in the lookup path, so we can find the wsgc libs.
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
import wsgc.util
import wsgc.gheTools


VALUES_FILE_REGEX_MATCH = r"config/?(.*)/values\.yaml"
NESTED_ENV_SEPARATOR = "_"
SUPPORTED_CHART_NAMES = [
    "spring-boot-chart",
    "trillium-chart",
    "spring-tomcat-registryv2-chart",
    "spring-tomcat-8-chart",
    "spring-tomcat-xcadmin-chart"
]


def getValuesFiles(headRepoDir, env):
    """
    Return the list of values.yaml files for this project, in the order in which they
    should be passed to Helm (higher precedence last).

    """
    valuesFiles = [os.path.join(headRepoDir, 'config', 'values.yaml')]

    configDir = os.path.join(headRepoDir, 'config')
    for appEnvSubdir in env.split(NESTED_ENV_SEPARATOR):
        configDir = os.path.join(configDir, appEnvSubdir)
        envValueFile = os.path.join(configDir, 'values.yaml')
        if os.path.exists(envValueFile):
            valuesFiles.append(envValueFile)

    return valuesFiles


def doHelmMemoryCheck(pullRequest):
    """
    Ensure that the heapMax in the PR is not greater than the resources limit defined in the config
    """

    currentUUID = str(uuid.uuid4())
    tmpUUIDDir = f'/tmp/{currentUUID}'

    headRepoDir = f'{tmpUUIDDir}/head'
    headOrgName = pullRequest['head']['repo']['owner']['login']
    headRepoName = pullRequest['head']['repo']['name']
    headBranchName = pullRequest['head']['ref']

    prCommitID = pullRequest['head']['sha']
    prHtmlUrl = pullRequest['html_url']
    prNumber = pullRequest['number']

    baseOrgName = pullRequest['base']['repo']['owner']['login']
    baseRepoName = pullRequest['base']['repo']['name']

    prDiff = wsgc.gheTools.getPRDiff(orgName=baseOrgName, repoName=baseRepoName, prNumber=prNumber)

    parsedPRDiff = wsgc.gheTools.parsePRDiff(prDiff)

    isCommonValuesUpdated = False
    doMemCheck = False
    envsUpdated = []
    for key in parsedPRDiff.keys():
        # Check if there is a change in values.yaml file
        match = re.match(VALUES_FILE_REGEX_MATCH, key)
        if match:
            env = match.group(1)
            # Check if the change is related to the heap params or resources limit params
            for hunk in parsedPRDiff[key]:
                if any(item in hunk for item in ['heapMax', 'heapMin']) or all(item in hunk for item in ['resources', 'limits', 'memory']):
                    # selected candidate for check
                    doMemCheck = True
                    if not env:
                        isCommonValuesUpdated = True
                    else:
                        if env not in envsUpdated:
                            envsUpdated.append(env)

    if doMemCheck:
        application.logger.info(f"Running helm memory check for {headRepoName} for pr {prNumber}")
        headRepoCloneURL = wsgc.gheTools.makeGHETokenUrl(orgName=headOrgName, repoName=headRepoName)
        headCloneRepo = git.Repo.clone_from(headRepoCloneURL, headRepoDir)
        headCloneRepo.git.checkout(headBranchName)

        if isCommonValuesUpdated:
            # Check for all the env
            envsToCheck = os.listdir(f"{headRepoDir}/config/")
            for env in envsToCheck:
                if os.path.isdir(f"{headRepoDir}/config/{env}"):
                    valuesFile = getValuesFiles(headRepoDir, env)
                    values = wsgc.util.readCombinedYaml(valuesFile)
                    isSuccess, output = performMemCheck(values)
                    if not isSuccess:
                        msg = f"heapMax cannot be greater than memory limit for env {env}"
                        if output:
                            msg = f"{msg} for {output}"
                        updateStatusForHelmMemoryCheck(baseOrgName, baseRepoName, prCommitID,
                                                       wsgc.gheTools.GHE_STATE_FAILURE, prHtmlUrl, msg)
                        return
        else:
            # Only check for updated env
            for env in envsUpdated:
                valuesFile = getValuesFiles(headRepoDir, env)
                values = wsgc.util.readCombinedYaml(valuesFile)
                isSuccess, output = performMemCheck(values)
                if not isSuccess:
                    msg = f"heapMax cannot be greater than memory limit for env {env}"
                    if output:
                        msg = f"{msg} for {output}"
                    updateStatusForHelmMemoryCheck(baseOrgName, baseRepoName, prCommitID,
                                                   wsgc.gheTools.GHE_STATE_FAILURE, prHtmlUrl, msg)
                    return

    msg = "Helm memory limit check successful"
    updateStatusForHelmMemoryCheck(baseOrgName, baseRepoName, prCommitID,
                                   wsgc.gheTools.GHE_STATE_SUCCESS, prHtmlUrl, msg)


def performMemCheck(values):
    """
    Retrieve the heapMax and the resource memory limit values and compare
    for supported charts
    """

    chartName = values["deployment"]["chart"]["name"]
    if chartName in SUPPORTED_CHART_NAMES:
        application.logger.info(f"Running helm memory check for chart: {chartName}")
        brands = values.get('brands')
        if brands:
            failedBrands = []
            for brand in brands:
                brandName = brand['name']
                heapMax = getHeapMax(brand)
                resourceMemLimit = getMemResourceLimit(brand)
                if not heapMax:
                    heapMax = getHeapMax(values)
                if not resourceMemLimit:
                    resourceMemLimit = getMemResourceLimit(values)

                if heapMax and resourceMemLimit:
                    if not compareMemCheck(heapMax, resourceMemLimit):
                        failedBrands.append(brandName)
            if failedBrands:
                return False, ",".join(failedBrands)
        else:
            heapMax = getHeapMax(values)
            resourceMemLimit = getMemResourceLimit(values)
            if heapMax and resourceMemLimit:
                if not compareMemCheck(heapMax, resourceMemLimit):
                    return False, None
    return True, None


def getHeapMax(values):
    """
    Retrieve heapMax from values and return
    """

    heapMax = None
    if "jvm" in values:
        if "heapMax" in values["jvm"]:
            heapMax = values["jvm"]["heapMax"]
    return heapMax


def getMemResourceLimit(values):
    """
    Retrieve resources memory limit from values and return
    """

    resourceMemLimit = None
    if "resources" in values:
        if "limits" in values["resources"]:
            if "memory" in values["resources"]["limits"]:
                resourceMemLimit = values["resources"]["limits"]["memory"]
    return resourceMemLimit


def compareMemCheck(heapMax, resourceMemLimit):
    """
    Compare heapMax and resource memory limit to ensure heapMax is not greater than memory limit
    """

    # Comparison unit used in mb, so convert all other units to mb
    if "g" in heapMax:
        heapMax = int(heapMax.replace("g", ""))*1024
    elif "m" in heapMax:
        heapMax = int(heapMax.replace("m", ""))
    elif "k" in heapMax:
        heapMax = int(heapMax.replace("k", ""))/1024
    else:
        heapMax = int(heapMax)/1024/1024

    if "Gi" in resourceMemLimit or "G" in resourceMemLimit:
        resourceMemLimit = int(resourceMemLimit.replace("Gi", "").replace("G", ""))*1024
    elif "Mi" in resourceMemLimit or "M" in resourceMemLimit:
        resourceMemLimit = int(resourceMemLimit.replace("Mi", "").replace("M", ""))
    elif "Ki" in resourceMemLimit or "K" in resourceMemLimit:
        resourceMemLimit = int(resourceMemLimit.replace("Ki", "").replace("K", ""))/1024
    else:
        resourceMemLimit = int(resourceMemLimit)/1024/1024

    if resourceMemLimit >= heapMax:
        return True
    return False


def updateStatusForHelmMemoryCheck(orgName, repoName, prCommitID, statusState, prHtmlUrl, msg):
    application.logger.info('Setting status to %s for PR commit %s in %s/%s (%s): %s',
                            statusState, prCommitID, orgName, repoName, prHtmlUrl, msg)

    # Talk to GHE in the background so we don't have to wait.
    threading.Thread(target=updatePRStatus,
                     kwargs={
                         'orgName': orgName,
                         'repoName': repoName,
                         'prCommitID': prCommitID,
                         'statusName': wsgc.gheTools.GHE_STATUS_PR_HELM_MEM_CHECK,
                         'statusState': statusState,
                         'msg': msg,
                     }).start()


def updatePRStatus(orgName, repoName, prCommitID, statusName, statusState, targetUrl='', msg=None):
    if not statusState in wsgc.gheTools.GHE_STATUS_VALID_STATES:
        raise Exception("Error: Invalid status state '{}'".format(statusState))

    if msg is not None:
        description = msg
    else:
        description = wsgc.gheTools.GHE_STATUSES[statusName]['description']

    wsgc.gheTools.writeStatus(orgName=orgName,
                              repoName=repoName,
                              commitID=prCommitID,
                              statusName=statusName,
                              statusState=statusState,
                              targetUrl=targetUrl,
                              description=description)
