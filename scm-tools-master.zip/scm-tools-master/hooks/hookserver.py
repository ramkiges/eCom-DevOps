# hookserver.py
#
# In order to break the hookserver Flask application into multiple files for organizational
# purposes, we need to make a package out of it; see:
#
#   http://flask.pocoo.org/docs/0.11/patterns/packages/
#
# for details.
#
# This wrapper turns that Python package into a WSGI application, recognizable to Flask.
#
# Importing the package triggers the creation of the application and loading of sub-modules, via the
# package's __init__.py file.

from hookserverpkg import application
