Webhook Server
==============
This web server is written to respond to hook events from GitHub
Enterprise, and from curl requests in WSI's Subversion post-commit
hooks.

The server is in `hookserver.py` and the modules in `hookserverpkg/`,
and is written using Python 3 and the Flask web application framework.

Flask was chosen because our webhook server is a web server in only
the simplest sense: it reacts to GET and POST requests, but our
callers aren't looking for complex content in response.  Flask fits
that need nicely, as it puts very little machinery between our code
and the web server.  Other minimal frameworks exist (e.g., Pyramid),
and would also be suitable should Flask prove insufficent down the
road.

As with any WSGI-compatible application framework, you need a separate
web server to bind ports and relay requests to the application.  How
you do this for the webhook server depends on whether you're deploying
it to production or developing it:

* Production: The wsgc-devops-toolchain-scm-webhook-config package
  configures Apache with a mod_wsgi.so listener, calling
  /apps/scm-tools/hooks/hookserver.py as its application, running as
  the user svnowner.  This uses SSL to secure the connection.

* Development: You can run a simple standalone server for development
  by setting the following environment variables:

  ```
  export FLASK_APP=</path/to/hookserver.py>
  export FLASK_DEBUG=1
  flask run --host=0
  ```

  As with any script in scm-tools, your Python environment should be
  pointing to wsgc-devops-toolchain-python3, or any similar
  environment that includes the list of Python packages configured in
  that package.
