#!/usr/bin/env python3
"""
Writer module to write the change log to markdown file
"""
import os
import re
from datetime import datetime


def writeIndividualChangeLog(individualChangeLog):
    """
    Write the individual repo changelog file
    """

    if individualChangeLog:
        changelogFileName = "CHANGELOG.md"

        with open(changelogFileName, 'w') as f:
            changeLogOutput = individualChangeLog["changeLogOutput"]
            newtags = individualChangeLog["newtags"]
            appRepoName = individualChangeLog["appRepoName"]
            appOrgName = individualChangeLog["appOrgName"]
            appBranch = individualChangeLog["appBranch"]

            # prod version details to be only written to the release branch instead of having multiple copies in each of
            # the release-x.x branch which are not always maintained and the prod version will soon get outdated unless
            # maintaining the overhead of updating in each of those files every time.
            if appBranch == "release":
                f.write("**Version running in prod:**\n")
                # creating a table
                f.write("|Service|Version|Version created on|Version deployed on|Version created from branch|\n")
                f.write("|-|-|-|-|-|\n")
                prodVersion = individualChangeLog["prodVersion"]
                for version in prodVersion:
                    appVersionOriginal = version["appVersionOriginal"]
                    appVersion = version["appVersion"]
                    tagDate = version["tagDate"]
                    releaseBranch = version["releaseBranch"]
                    appDeployDate = version["appDeployDate"]
                    service = version["service"]
                    if "brands" in version:
                        brands = version["brands"]
                        service = f"{service} for {brands}"

                    tagUrl = f"https://github.wsgc.com/{appOrgName}/{appRepoName}/tree/{appVersionOriginal}"
                    f.write(f"|{service}|[{appVersion}]({tagUrl})|{tagDate}|{appDeployDate}|{releaseBranch}\n")

            f.write(f"\n**Tags and commits:**\n")
            for tag in newtags:
                if tag in changeLogOutput:
                    changeLogOutputList = changeLogOutput[tag]["tagOutput"]
                    originalTag = changeLogOutput[tag]["originalTag"]

                    if tag == '':
                        f.write("- Untagged commits\n")
                    else:
                        tagUrl = f"https://github.wsgc.com/{appOrgName}/{appRepoName}/tree/{originalTag}"
                        f.write(f"- [{tag}]({tagUrl})\n")
                    # Creating a table for list of commits in the tag
                    f.write("  |Commit|Datetime|Origin Org/Branch|Committer|Approvers|JIRA issues|PR|\n")
                    f.write("  |-|-|-|-|-|-|-|\n")
                    for changeLogOutputObj in changeLogOutputList:
                        commitSha = changeLogOutputObj["commitSha"][0:8]
                        commitDate = changeLogOutputObj["commitDate"]
                        commitDateStripTime = datetime.strptime(commitDate, '%Y-%m-%dT%H:%M:%SZ')
                        commitHtmlUrl = changeLogOutputObj["commitHtmlUrl"]
                        commitAuthorName = changeLogOutputObj["commitAuthorName"]
                        jiraTickets = changeLogOutputObj["jiraTickets"]
                        originOrgBranch = changeLogOutputObj["originOrgBranch"]
                        prApprovers = changeLogOutputObj["prApprovers"]
                        prApprovers = " <br> ".join(prApprovers)
                        prUrl = changeLogOutputObj["prUrl"]
                        prUrlText = ""
                        if prUrl:
                            prUrlText = f"[PR]({prUrl})"
                        jiraIssues = ""
                        for jiraTicket in jiraTickets:
                            jiraTicketUrl = f"https://jira.wsgc.com/browse/{jiraTicket}"
                            jiraIssues += f"[{jiraTicket}]({jiraTicketUrl}) <br> "
                        f.write(
                            f"  |[{commitSha}]({commitHtmlUrl})|{commitDate}|{originOrgBranch}|{commitAuthorName}|{prApprovers}|{jiraIssues}|{prUrlText}\n")
                    f.write("\n")


def updateIndividualChangeLog(individualChangeLog):
    """
    Update the individual repo change log file
    """

    if individualChangeLog:
        changeLogLines = []
        changelogFileName = "CHANGELOG.md"
        if os.path.exists(changelogFileName):
            with open(changelogFileName, 'r') as f:
                changeLogLines = f.readlines()

        # Write to the changelog files any new tags/commits.
        writeIndividualChangeLog(individualChangeLog)

        startLookingForLastTag = False
        startCopying = False
        EXTRACT_TAG_REGEX = r'-\s*\[(.*)\](.*)'

        # Write the rest of the tags to the changelog file from the current file
        with open(changelogFileName, 'a') as f:
            for line in changeLogLines:
                if startLookingForLastTag:
                    match = re.search(EXTRACT_TAG_REGEX, line)
                    if match:
                        startCopying = True
                        startLookingForLastTag = False

                if "Tags and commits" in line:
                    startLookingForLastTag = True

                if startCopying:
                    f.write(line)


def writeServicesChangeLogFile(serviceChangeLogDetails):
    """
    Write the change log details for each service to its own markdown file
    """

    uberChangeLog = {}
    appsToUpdateDeployVersionInChangelog = []
    for service, changeLogDetails in serviceChangeLogDetails.items():
        changeLogFile = f"{service}.md"

        # Extract prod version from the current changelog file
        currentProdVersion = None
        if os.path.exists(changeLogFile):
            with open(changeLogFile, 'r') as f:
                changeLogLines = f.readlines()

            EXTRACT_PROD_VERSION = r'\|\[(.*)\](.*)'
            for line in changeLogLines:
                match = re.search(EXTRACT_PROD_VERSION, line)
                if match:
                    currentProdVersion = match.group(1)
                    break

        with open(changeLogFile, 'w') as f:
            for changeLogDetailsObj in changeLogDetails:
                releaseChangeLog = changeLogDetailsObj["releaseChangeLog"]
                appVersionOriginal = changeLogDetailsObj["appVersionOriginal"]
                appVersion = changeLogDetailsObj["appVersion"]
                tagDate = changeLogDetailsObj["tagDate"]
                releaseBranch = changeLogDetailsObj["releaseBranch"]
                displayAppName = changeLogDetailsObj["displayAppName"]
                appRepoName = changeLogDetailsObj["appRepoName"]
                appOrgName = changeLogDetailsObj["appOrgName"]
                appDeployDate = changeLogDetailsObj["appDeployDate"]
                brands = changeLogDetailsObj["brands"]

                # Compare current prod version and the new computed version. If different, add the repo to update the
                # individual changelog
                if appVersion != currentProdVersion:
                    appsToUpdateDeployVersionInChangelog.append(appRepoName)
                f.write(f"## {displayAppName}\n")
                f.write("**Version running in prod:**\n")
                # creating a table
                f.write("|Version|Version created on|Version deployed on|Version created from branch|\n")
                f.write("|-|-|-|-|\n")
                tagUrl = f"https://github.wsgc.com/{appOrgName}/{appRepoName}/tree/{appVersionOriginal}"
                f.write(f"|[{appVersion}]({tagUrl})|{tagDate}|{appDeployDate}|{releaseBranch}\n")

                lastUpdateDate = datetime.strptime(tagDate, '%Y-%m-%dT%H:%M:%SZ')
                print(f"releaseChangeLog: {releaseChangeLog}")
                if releaseChangeLog:
                    for releaseBranch, releaseChangeLogObj in releaseChangeLog.items():
                        newtags = releaseChangeLogObj["newtags"]
                        changeLogOutput = releaseChangeLogObj["changeLogOutput"]
                        f.write(f"\n**New tags and commits from `{releaseBranch}` branch:**\n")
                        for tag in newtags:
                            if tag in changeLogOutput:
                                changeLogOutputList = changeLogOutput[tag]
                                if tag == '':
                                    f.write("- Untagged commits\n")
                                else:
                                    tagUrl = f"https://github.wsgc.com/{appOrgName}/{appRepoName}/tree/{tag}"
                                    f.write(f"- [{tag}]({tagUrl})\n")
                                # Creating a table for list of commits in the tag
                                f.write("  |Commit|Datetime|Origin Org/Branch|Committer|Approvers|JIRA issues|PR|\n")
                                f.write("  |-|-|-|-|-|-|-|\n")
                                for changeLogOutputObj in changeLogOutputList:
                                    commitSha = changeLogOutputObj["commitSha"][0:8]
                                    commitDate = changeLogOutputObj["commitDate"]
                                    commitDateStripTime = datetime.strptime(commitDate, '%Y-%m-%dT%H:%M:%SZ')
                                    if commitDateStripTime > lastUpdateDate:
                                        lastUpdateDate = commitDateStripTime
                                    commitHtmlUrl = changeLogOutputObj["commitHtmlUrl"]
                                    commitAuthorName = changeLogOutputObj["commitAuthorName"]
                                    jiraTickets = changeLogOutputObj["jiraTickets"]
                                    originOrgBranch = changeLogOutputObj["originOrgBranch"]
                                    prApprovers = changeLogOutputObj["prApprovers"]
                                    prApprovers = " <br> ".join(prApprovers)
                                    prUrl = changeLogOutputObj["prUrl"]
                                    prUrlText = ""
                                    if prUrl:
                                        prUrlText = f"[PR]({prUrl})"
                                    jiraIssues = ""
                                    for jiraTicket in jiraTickets:
                                        jiraTicketUrl = f"https://jira.wsgc.com/browse/{jiraTicket}"
                                        jiraIssues += f"[{jiraTicket}]({jiraTicketUrl}) <br> "
                                    f.write(f"  |[{commitSha}]({commitHtmlUrl})|{commitDate}|{originOrgBranch}|{commitAuthorName}|{prApprovers}|{jiraIssues}|{prUrlText}\n")
                                f.write("\n")
                else:
                    f.write("\nNo new tags or commits since the last prod version\n")
                if brands:
                    brands = brands.split(",")
                    for brand in brands:
                        uberChangeLog[f"{service}-{brand}"] = {
                            "service": service,
                            "brand": brand,
                            "lastUpdateDate": lastUpdateDate,
                            "appDeployDate": appDeployDate,
                            "appVersion": appVersion,
                            "tagUrl": tagUrl,
                            "changeLogFile": changeLogFile,
                            "displayAppName": displayAppName,
                        }
                else:
                    uberChangeLog[service] = {
                        "service": service,
                        "lastUpdateDate": lastUpdateDate,
                        "appDeployDate": appDeployDate,
                        "appVersion": appVersion,
                        "tagUrl": tagUrl,
                        "changeLogFile": changeLogFile,
                        "displayAppName": displayAppName,
                    }

    return uberChangeLog, appsToUpdateDeployVersionInChangelog


def writeBrandConfigsChangeLogFile(brandConfigChangeLogOutput):
    """
    Write the change log details for all brand configs to a single markdown file
    """

    uberChangeLog = {}
    if brandConfigChangeLogOutput:
        for brandconfigApp, brandConfigChangeLog in brandConfigChangeLogOutput.items():
            changeLogFile = f"{brandconfigApp}.md"
            with open(changeLogFile, 'w') as f:
                prodCommit = brandConfigChangeLog["prodCommit"]
                prodCommitCreationDate = brandConfigChangeLog["prodCommitCreationDate"]
                commitsOutput = brandConfigChangeLog["commitsOutput"]
                f.write(f"## {brandconfigApp}\n")
                f.write("**Commit running in prod:**\n")
                prodCommitUrl = f"https://github.wsgc.com/eCommerce-Bedrock/{brandconfigApp}/commit/{prodCommit}"
                f.write(f"[{prodCommit}]({prodCommitUrl}) created on {prodCommitCreationDate}\n")

                lastUpdateDate = datetime.strptime(prodCommitCreationDate, '%Y-%m-%dT%H:%M:%SZ')
                if commitsOutput:
                    f.write(f"\n**New commits:**\n")
                    f.write("  |Commit|Datetime|Origin Org/Branch|Committer|Approvers|JIRA issues|PR|\n")
                    f.write("  |-|-|-|-|-|-|-|\n")
                    for commitOutput in commitsOutput:
                        commitSha = commitOutput["commitSha"][0:8]
                        commitDate = commitOutput["commitDate"]
                        lastUpdateDate = datetime.strptime(commitDate, '%Y-%m-%dT%H:%M:%SZ')
                        commitHtmlUrl = commitOutput["commitHtmlUrl"]
                        commitAuthorName = commitOutput["commitAuthorName"]
                        jiraTickets = commitOutput["jiraTickets"]
                        originOrgBranch = commitOutput["originOrgBranch"]
                        prApprovers = commitOutput["prApprovers"]
                        prApprovers = " <br> ".join(prApprovers)
                        prUrl = commitOutput["prUrl"]
                        prUrlText = ""
                        if prUrl:
                            prUrlText = f"[PR]({prUrl})"
                        jiraIssues = ""
                        for jiraTicket in jiraTickets:
                            jiraTicketUrl = f"https://jira.wsgc.com/browse/{jiraTicket}"
                            jiraIssues += f"[{jiraTicket}]({jiraTicketUrl}) <br> "
                        f.write(f"  |[{commitSha}]({commitHtmlUrl})|{commitDate}|{originOrgBranch}|{commitAuthorName}|{prApprovers}|{jiraIssues}|{prUrlText}\n")
                else:
                    f.write("\nNo new commits since the last commit running in prod\n")

                uberChangeLog[brandconfigApp] = {
                    "service": brandconfigApp,
                    "lastUpdateDate": lastUpdateDate,
                    "appDeployDate": None,
                    "appVersion": prodCommit,
                    "commitUrl": prodCommitUrl,
                    "changeLogFile": changeLogFile,
                    "displayAppName": brandconfigApp,
                }

    return uberChangeLog


def writeUberChangeLog(uberChangeLogDetails):
    """
    Write the parent change log file table that consists of links to individual service change log along with
    the version of the service in prod, when that version was deployed and last update date to the bedrock repo
    for that service.
    """

    if uberChangeLogDetails:
        sortedChangeLog = dict(sorted(uberChangeLogDetails.items(), key=lambda item: item[1]['lastUpdateDate'],
                                      reverse=True))
        os.chdir("../")
        with open(f"parent-changelog.md", 'w') as f:
            f.write("**Entries are sorted based on last update to the bedrock repo:**\n")
            f.write("|Service Changelog|Version in Prod|Deploy date|Last update to repo|\n")
            f.write("|-|-|-|-|\n")
            for service, changelog in sortedChangeLog.items():
                changeLogFile = changelog["changeLogFile"]
                displayAppName = changelog["displayAppName"]
                displayAppName = displayAppName.replace(",", "").replace(" ", "-")
                serviceChangeLogUrl = f"https://github.wsgc.com/eCommerce-Release-Management/release-changelog/blob/release/changelog/{changeLogFile}#{displayAppName}"
                appVersion = changelog["appVersion"]
                if "tagUrl" in changelog:
                    appVersionUrl = changelog["tagUrl"]
                if "commitUrl" in changelog:
                    appVersionUrl = changelog["commitUrl"]
                    appVersion = appVersion[0:8]
                appDeployDate = changelog.get("appDeployDate", None)
                if appDeployDate is None:
                    appDeployDate = "Not supported yet"
                lastUpdateDate = changelog["lastUpdateDate"]
                lastUpdateDate = lastUpdateDate.strftime('%Y-%m-%dT%H:%M:%SZ')
                f.write(
                    f"|[{service}]({serviceChangeLogUrl})|[{appVersion}]({appVersionUrl})|{appDeployDate}|{lastUpdateDate}\n")


def updateUberChangeLog(uberChangeLogDetails):
    """
    Update the parent change log file with only the service that was triggered from the bedrock release build.
    """

    if uberChangeLogDetails:
        #  Read the current parent changelog
        with open(f"../parent-changelog.md", 'r') as f:
            changeLogLines = f.readlines()

        # Copy the changelog header lines as it is and then convert all the individual changelog lines for each service
        # into a changelog object so we can then use the writeUberChangeLog module to update the complete parent change
        # log file
        startUpdatingNewEntries = False
        for line in changeLogLines:
            if startUpdatingNewEntries:
                splits = line.split("|")

                serviceDetails = splits[1]
                serviceName, serviceRepoUrl = serviceDetails.split("]")
                serviceName = serviceName.replace("[", "")
                if serviceName not in uberChangeLogDetails:
                    changeLogFile, displayAppName = serviceRepoUrl.split('/')[-1].split("#")
                    appVersionDetails = splits[2]
                    appVersion, appVersionUrl = appVersionDetails.split("]")
                    appDeployDate = splits[3].strip()
                    lastUpdateDate = splits[4].strip()
                    lastUpdateDate = datetime.strptime(lastUpdateDate, '%Y-%m-%dT%H:%M:%SZ')
                    changelog = {"changeLogFile": changeLogFile, "displayAppName": displayAppName.replace(")", ""),
                                 "appVersion": appVersion.replace("[", ""),
                                 "tagUrl": appVersionUrl.replace("(", "").replace(")", ""),
                                 "appDeployDate": appDeployDate, "lastUpdateDate": lastUpdateDate}
                    uberChangeLogDetails[serviceName] = changelog

            if "|-|" in line:
                startUpdatingNewEntries = True
        writeUberChangeLog(uberChangeLogDetails)


def extractLastTagFromChangeLogFile():
    """
    Extract the most recent tag from the existing changelog file
    """

    changelogFileName = "CHANGELOG.md"
    if os.path.exists(changelogFileName):
        with open(changelogFileName, 'r') as f:
            changeLogLines = f.readlines()

        startLookingForLastTag = False
        EXTRACT_TAG_REGEX = r'-\s*\[(.*)\](.*)'
        for line in changeLogLines:
            if startLookingForLastTag:
                match = re.search(EXTRACT_TAG_REGEX, line)
                if match:
                    tag = match.group(1)
                    return tag
            if "Tags and commits" in line:
                startLookingForLastTag = True
    else:
        return None
