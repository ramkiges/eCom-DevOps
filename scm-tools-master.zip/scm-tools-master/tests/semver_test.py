"""
semver_test.py

Unit tests for wsgc/semver.py.

Run from top-level scm-tools dir as 'PYTHONPATH=. tests/semver_test.py'.
"""
import unittest
import re

from wsgc import semver


class SemVerTestCase(unittest.TestCase):
    def test_compare(self):
        self.assertEqual(semver.Semver(1, 0, 0), semver.Semver(1, 0, 0))
        self.assertLess(semver.Semver(3, 0, 0), semver.Semver(10, 0, 0))
        self.assertLess(semver.Semver(3, 4, 5), semver.Semver(4, 2, 1))
        self.assertLess(semver.Semver(1, 2, 3), semver.Semver(1, 2, 4))
        self.assertLess(semver.Semver(1, 0, 0, 'extra'), semver.Semver(1, 0, 0))
        self.assertLess(semver.Semver(4, 5, 6, 'alpha1'), semver.Semver(4, 5, 6, 'alpha2'))

        # Can create with strings or whole numbers, interchangeably.
        self.assertEqual(semver.Semver('3', '42', 6, 'extra'), semver.Semver(3, 42, 6, 'extra'))

    def test_creation_errors(self):
        with self.assertRaises(TypeError):
            semver.Semver(1)
        with self.assertRaises(TypeError):
            semver.Semver(1, 2)
        with self.assertRaises(TypeError):
            semver.Semver(1, 2, 3, 4, 5)
        with self.assertRaises(ValueError):
            semver.Semver('one', 'two', 'three', 'extra')
        with self.assertRaises(ValueError):
            # No leading zeros allowed.
            semver.Semver('3', '042', 6, 'extra')

    def test_regex(self):
        # Semver has an unanchored regex; test whether it matches what
        # we expect when we anchor it.
        fullMatch = r'^{}$'.format(semver.Semver.regex)
        self.assertRegex('1.0.0', fullMatch)
        self.assertRegex('0.0.0', fullMatch)
        self.assertRegex('1.2.3-extra', fullMatch)
        self.assertRegex('40.0.0-something+else', fullMatch)

        # Test whether it correctly fails to match non-semvers.
        self.assertNotRegex('01.2.3', fullMatch)
        self.assertNotRegex('1.2.03', fullMatch)
        self.assertNotRegex('0.2-foo', fullMatch)
        self.assertNotRegex('0.2', fullMatch)
        self.assertNotRegex('1.2.3.4', fullMatch)
        self.assertNotRegex('1.2.3.4-extra', fullMatch)

        # Test the unanchored regex with good matches.
        goodPairs = (
            ('  1.2.3 ', semver.Semver(1, 2, 3)),
            (' 0.1.0-extra', semver.Semver(0, 1, 0, 'extra')),
            (' 42.88.9-extra+sp8cialchars', semver.Semver(42, 88, 9, 'extra+sp8cialchars')),
            ('3.6.2    ', semver.Semver('3', 6, '2')),
        )
        for inputStr, val in goodPairs:
            with self.subTest(inputStr=inputStr, val=val):
                match = re.search(semver.Semver.regex, inputStr)
                self.assertEqual(semver.Semver(*match.groups()), val)

        # Test unanchored matches with strings that don't contain semvers.
        badStrings = (
            '  1.2 ',
            ' 0.1.0.extra',  # Needs '-', not '.' before extra
            '3.06.2    ',
            '1.2.03',  # Don't just match up through 0 and stop
        )
        for inputStr in badStrings:
            with self.subTest(inputStr=inputStr):
                self.assertFalse(re.search(semver.Semver.regex, inputStr))

    def test_parse(self):
        """Check Semver.parse(str)."""
        self.assertEqual(semver.Semver.parse('1.2.3'), semver.Semver(1, 2, 3))
        self.assertEqual(semver.Semver.parse('1.2.0-extra+stuff'), semver.Semver(1, 2, 0, 'extra+stuff'))

        with self.assertRaises(ValueError):
            semver.Semver.parse(' 1.2.3 ')
        with self.assertRaises(ValueError):
            semver.Semver.parse('1.2.03')
        with self.assertRaises(ValueError):
            semver.Semver.parse('1.2.3.extra')  # . instead of -

    def test_bumpViolations(self):
        def t(oldVerStr, newVerStr, violations=None):
            """
            Helper function for testing whether the two versions
            violate the version-bump rules as the list of violations
            expects (including no violations).
            """
            oldver = None if oldVerStr is None else semver.Semver.parse(oldVerStr)
            newver = None if newVerStr is None else semver.Semver.parse(newVerStr)
            if violations is None:
                violations = []

            self.assertEqual(semver.getSemverBumpViolations(oldver, newver),
                             violations)

        # Happy cases: one-bump version updates.
        t('0.0.0', '0.0.1')
        t('0.0.1', '0.0.2')
        t('0.10.1', '0.10.2')
        t('7.8.9', '7.8.10')
        t('7.8.9', '7.9.0')
        t('7.8.9', '8.0.0')
        t(None, '4.2.6')
        t('3.4.6-something', '3.4.6')
        t('3.4.6-something', '4.0.0')

        # Unhappy cases.
        t(None, None, ['No version update found'])
        t('0.0.0', '0.0.0', ['No version update found'])
        t('3.4.5-x', '3.4.5-x', ['No version update found'])
        t('1.0.0', None, ['Semver 1.0.0 removed with no replacement'])
        t('1.0.0', '1.0.0-x', ['1.0.0-x is not a release version'])
        t('6.7.8', '6.6.23', ['Version decreased instead of increasing'])
        t('6.7.8', '8.0.0', ['Major version increased by more than 1'])
        t('6.7.8', '7.1.0', ['Major version bumped: minor and patch must be zero'])
        t('6.7.8', '7.0.5', ['Major version bumped: minor and patch must be zero'])
        t('6.7.8', '7.2.6', ['Major version bumped: minor and patch must be zero'])
        t('6.7.8', '6.10.0', ['Minor version increased by more than 1'])
        t('6.7.8', '6.8.2', ['Minor version bumped: patch must be zero'])
        t('6.7.8', '6.7.10', ['Patch increased by more than 1'])


if __name__ == '__main__':
    unittest.main()
