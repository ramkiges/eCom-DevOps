# Testing the `svnLocks.py` Library

## Running the Tests

From the top-level of the repository, run:
 ```
 PYTHONPATH=. tests/svnLocks/svnLocks_test.py
 ```

## Structure of the Tests

All test data is in `tests/svnLocks/data`.  All file paths given in
the following description are relative to that directory.

All tests are run for each username in `usernames`.  The template
files in `grant` and `revoke` consist of `.before` and `.after` images
of example `access.conf` files, with the string `__USERNAME__`
standing in for the username under test.

`releaseName` contains the release name being tested.  It currently
consists of (and must consist of) a single release name, but you're
free to arrange your template files how you wish, to position that
release anywhere you'd like.

All templates in `grant` test granting access, and all in `revoke`
test revoking access.
