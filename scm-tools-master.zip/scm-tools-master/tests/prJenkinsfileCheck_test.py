#!/usr/bin/env python3
"""
prJenkinsfileCheck_test.py

Unit tests for wsgc/prJenkinsfileCheck.py.

Run from top-level scm-tools dir as 'PYTHONPATH=. tests/prJenkinsfileCheck_test.py'.
"""

import unittest

from wsgc import prJenkinsfileCheck

class TestPRJenkinsfileCheck(unittest.TestCase):
    def test_good_01(self):
        """This passes because the offending assignment is commented out."""
        INPUT = """diff --git a/Jenkinsfile b/Jenkinsfile
index 0891859..c81ebc5 100644
--- a/Jenkinsfile
+++ b/Jenkinsfile
@@ -1,4 +1,14 @@
 // Some comment here
 // Another comment
 
-plumber('Service') {}
+plumber('Service') {
+   // dependencyOverrides = [
+   //   ["baselogic.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"],
+   //   ["rpm.maven.version": "0.0.buggy.version.3"],
+   //   ["components.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"]
+   // ]
+
+    jdk = "1.6"
+}
"""
        self.assertEqual(prJenkinsfileCheck.checkDiff(INPUT), [])


    def test_bad_01(self):
        """This fails because the text adds two illegal assignments."""
        INPUT = """diff --git a/Jenkinsfile b/Jenkinsfile
index 0891859..c81ebc5 100644
--- a/Jenkinsfile
+++ b/Jenkinsfile
@@ -1,4 +1,14 @@
 // Some comment here
 // Another comment
 
-plumber('Service') {}
+plumber('Service') {
+   dependencyOverrides = [
+        ["baselogic.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"],
+        ["rpm.maven.version": "0.0.buggy.version.3"],
+        ["components.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"]
+    ]
+
+   publishBranches = ["foo", "bar"]
+
+    jdk = "1.6"
+}
"""
        self.assertEqual(prJenkinsfileCheck.checkDiff(INPUT),
                         ["Branch-specific assignments: dependencyOverrides, publishBranches"])

    def test_bad_02(self):
        """This includes a library decl, several valid assignments, and one invalid one that doesn't begin its line."""
        INPUT = """diff --git a/Jenkinsfile b/Jenkinsfile
index 0891859..14bd205 100644
--- a/Jenkinsfile
+++ b/Jenkinsfile
@@ -1,4 +1,21 @@
 // Uncomment this to use the pipeline-commons from the specified branch.
-// @Library('commons@tah-1184-mvn-install') _
+@Library('commons@pete-test') _
 
-plumber('Service') {}
+plumber('Petetest') {
+    cmd = "something"; badthing = "something else"
+    enableSonar7Features="heynow"
+    id+=42
+    mavenParameters = ['something': hey]
+    refresh = "scooby"
+    target = "like kmart, only fancier"
+
+    // dependencyOverrides = [
+    //     ["baselogic.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"],
+    //     ["rpm.maven.version": "0.0.buggy.version.3"],
+    //     ["components.version": "ci_eCommerce-Tahoe_tah-1234-foo-bar-SNAPSHOT"]
+    // ]
+
+    // publishBranches = ["foo", "bar"]
+
+    jdk = "1.6"
+}
diff --git a/foobar.txt b/foobar.txt
new file mode 100644
index 0000000..f1beb8e
--- /dev/null
+++ b/foobar.txt
@@ -0,0 +1 @@
+Testing.
diff --git a/pom.xml b/pom.xml
index dce8854..d1a886a 100644
--- a/pom.xml
+++ b/pom.xml
@@ -1,10 +1,14 @@
-<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
+<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">
   <modelVersion>4.0.0</modelVersion>
 
-  <groupId>com.wsgc.devops.petetest</groupId>
-  <artifactId>pete-test</artifactId>
-  <version>1.0-SNAPSHOT</version>
-  <name>pete-test</name>
-  <description>Testing pom for Pete Harlan</description>
+  <groupId>com.wsgc.ecommerce.pete.test</groupId>
+  <artifactId>pete-is-testing</artifactId>
   <packaging>pom</packaging>
+  <version>1-SNAPSHOT</version>
+
+  <name>pete-is-testing</name>
+
+  <properties>
+    <baselogic.version>2.5-SNAPSHOT</baselogic.version>
+  </properties>
 </project>
"""
        self.assertEqual(prJenkinsfileCheck.checkDiff(INPUT),
                         ["Customized Library Import", "Branch-specific assignments: badthing"])


if __name__ == '__main__':
    unittest.main()
