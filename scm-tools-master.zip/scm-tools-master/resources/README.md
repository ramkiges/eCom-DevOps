The file commit_id.template is used when building our RPM, to store
our commit ID for use by scripts that choose to report to the user
which version of the code generated their output.
