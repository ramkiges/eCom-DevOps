#!/usr/bin/env python3

import json
import random
import string

AKAMAI_VARIABLES = {}  # store the akamai variables defined in the rules
CHILD_RULES = {}  # store the parsed akamai rules with key as rule name and values as rule Details
RULE_MAP = {}  # store all the parsed rules in this map where key is the child rule filename and value is all the rule details for that child including its children


def processAllRules(workDirPath):
    """
    Parse all akamai child rules under main.json in property-snippets and populate the parsed details in a dict
    """
    pathToProperties = f"{workDirPath}/property-snippets"

    # main.json is the parent rule of all child rules
    mainRule = "%s/%s" % (pathToProperties, "main.json")
    with open(mainRule, 'r') as fi:
        rulesContent = json.load(fi)
        rules = rulesContent["rules"]
        childRules = rules["children"]
        variables = rules["variables"]

        # Variables in Akamai start and end with  {{ and }} respectively and are used in rules with user. prefix.
        # Store it like that in a map
        for variable in variables:
            if "value" in variable:
                AKAMAI_VARIABLES["{{user." + variable["name"] + "}}"] = variable["value"]

        for childRule in childRules:
            childRuleFileName = childRule[len('#include:'):]
            fullChildRuleFileName = "%s/%s" % (pathToProperties, childRuleFileName)

            with open(fullChildRuleFileName, 'r') as f:
                childRulesContent = json.load(f)
                childRuleName = childRulesContent['name']

                # store the eligible criteria and behaviour elements of the rule to be parsed in childRuleElements
                childRuleElements = {}
                parseRule(childRulesContent, False, childRuleElements, childRuleName)
                if childRuleElements:
                    # encapsulate the parsed rule details along with parentRule and then store it in a dict
                    childRuleParsed = {"name": childRuleName, "rules": childRuleElements, "parentRuleName": None}
                    CHILD_RULES[childRuleName] = childRuleParsed

            simplifiedRules = simplifyRules(CHILD_RULES)
            if simplifiedRules:
                RULE_MAP[childRuleFileName] = simplifiedRules

            # clear the childRules mapping before processing the next rule
            CHILD_RULES.clear()

    return RULE_MAP


def parseRule(rulesContent, isParentCriteria, childRuleElements, childRuleName):
    """
    Parse akamai rule object for criteria and behavior along with its child rules.
    """
    if "criteria" in rulesContent:
        parsedCriterias = parseCriteria(rulesContent["criteria"])
        if parsedCriterias:
            if isParentCriteria:
                childRuleElements["criterias"] = parsedCriterias
            else:
                childRuleElements["criterias"] = parsedCriterias
                isParentCriteria = True

    # Proceed for behavior only if there is any criteria in akamai parent rule else no use
    if isParentCriteria and ("behaviors" in rulesContent):
        parsedBehaviors = parseBehavior(rulesContent["behaviors"])
        if parsedBehaviors:
            childRuleElements["behaviors"] = parsedBehaviors

    # process child rules
    if "children" in rulesContent:
        parseChildren(rulesContent["children"], isParentCriteria, childRuleName)


def parseCriteria(criteriaJson):
    """
    Parse akamai rule criteria object and filter out only the ones we are interested in.
    """
    parsedCriterias = []
    for criteria in criteriaJson:
        criteriaName = criteria["name"]
        # we are only interested in hostname, path and the requestCookie criteria.
        # hostname is needed so we for which hosts, rules are defined and define those in nginx config for routing.
        # path is needed so we know on which endpoints to route the requests coming for a matched hostname, 
        # basically including the exclusion and inclusion rules.
        # requestCookie is needed especially for prod and preprd env as based on the cookie value, it decides
        # whether to route to east origin or west.
        if (criteriaName in ["hostname", "path"]) or \
                (criteriaName == "requestCookie" and criteria["options"]["cookieName"] == "WSIDC"):
            parsedCriterias.append(criteria)

    return parsedCriterias


def parseBehavior(behaviorJson):
    """
    Parse akamai rule behavior object and filter out only the ones we are interested in.
    """
    parsedBehaviors = []
    for behavior in behaviorJson:
        behaviorName = behavior["name"]
        # filter only the behavior needed
        # we only need origin and rewriteUrl behaviors.
        # origin behavior of type CUSTOMER is needed to know where to route the request matching
        # the defined criteria.
        # rewriteUrl is needed as if present it specifies what to reqrite the request url before
        # sending it to origin. This as of now is only defined in non-prod rules.
        if (behaviorName in ["origin"] and behavior["options"]["originType"] == "CUSTOMER") or \
                (behaviorName == "rewriteUrl"):
            parsedBehaviors.append(behavior)

    return parsedBehaviors


def parseChildren(childRulesContent, isParentCriteria, parentName):
    """
    Parse the akamai children of children rules recursively
    """
    for childRuleContent in childRulesContent:
        childRuleName = childRuleContent["name"]

        # possible that multiple rules might have the same name. Solve that by adding some random characters
        if childRuleName in CHILD_RULES:
            childRuleName = childRuleName + ''.join(random.choice(string.ascii_lowercase) for i in range(10))
        childRuleContent["name"] = childRuleName

        # recursively process the child rules
        childRuleElements = {}
        parseRule(childRuleContent, isParentCriteria, childRuleElements, childRuleName)

        if childRuleElements:
            childRuleParsed = {"name": childRuleName, "rules": childRuleElements, "parentRuleName": parentName}
            CHILD_RULES[childRuleName] = childRuleParsed


def simplifyRules(childRules):
    """
    childRules contains the rules mapping with each rule as a child or parent in its own key. The value object of that rule
    contains which parent rule it belongs to.
    This will simply the rules to follow a nested hierarchy by having child rules as an array within the parent rule.
    simplifiedRules has format as
    {
        ruleName: <name>,
        rules: {
            criterias: [],
            behaviors: []
        },
        children: [
            {
                ruleName: <name>,
                rules: {
                    criterias: [],
                    behaviors: []
                },
                children: []
            }
        ]
    }
    """
    childRulesCopy = childRules.copy()
    simplifiedRules = {}

    for childRuleName, childRuleObject in childRules.items():
        if childRuleName in childRulesCopy:
            childRulesCopy.pop(childRuleName, None)
            parentRuleName = childRuleObject['parentRuleName']

            while parentRuleName is not None and parentRuleName in childRules:
                childRulesCopy.pop(parentRuleName, None)
                parentRuleObject = childRules[parentRuleName]
                childRuleObject = childRules[childRuleName]
                parentRuleObject["children"] = [childRuleObject]
                childRuleName = parentRuleName
                parentRuleName = parentRuleObject['parentRuleName']

            if childRuleName in simplifiedRules:
                childRules[childRuleName]["children"] = simplifiedRules[childRuleName]["children"] + \
                                                        childRules[childRuleName]["children"]
            simplifiedRules[childRuleName] = childRules[childRuleName].copy()

    return simplifiedRules

