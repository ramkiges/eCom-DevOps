#!/usr/bin/env python3
"""
svnLocks.py

Library routines for managing the access.conf file, specifically, which users are allowed to update
the locked-down common/content repos for release branches.
"""

import sys
import re


class ConfFile:
    """
    Object representing a configuration file, along with a logical representation of a single
    release-branch section.

    By "logical representation", we mean that we will represent every line of the file literally
    until the section, at which point we will represent every line of the form "user = rw" as a list
    of usernames.  Other lines in the section (e.g., "@foo = rw", or "#user = rw") will be left
    alone.

    Note: functionality is intentionally limited to our immediate need; this isn't a full-blown
    model of a Subverison config file.

    Note 2: for testing purposes, we allow the caller to pass in the contents of the file, so we
    don't have to read it from disk.  This allows the caller to vary the contents algorithmically
    without having to write files to disk.
    """
    def __init__(self, confFilename, releaseName, confFileContents=None):
        self.confFilename = confFilename

        if confFileContents is None:
            with open(confFilename) as f:
                confFileContents = f.read()

        confFileLines = confFileContents.splitlines()

        self.origConfFileLines = confFileLines

        # Store a parsed version of ourself.
        self.releaseName = releaseName
        self.parsedRelease = parseRelease(releaseName=releaseName, confFileLines=confFileLines)

    def grantWriteAccess(self, username):
        """Grant access.  Returns True if the user previously lacked access"""
        if username in self.parsedRelease["sectionUsernames"]:
            return False  # No-op.

        self.parsedRelease["sectionUsernames"].append(username)
        return True

    def revokeWriteAccess(self, username):
        """Revoke access.  Returns True if the user had access (i.e., if we did anything)"""
        try:
            self.parsedRelease["sectionUsernames"].remove(username)
        except ValueError:
            return False  # No-op.

        return True

    def asStr(self, original=False):
        if original:
            lines = self.origConfFileLines
        else:
            parsedRelease = self.parsedRelease

            lines = (parsedRelease["preSectionLines"] +
                     [parsedRelease["sectionHeader"]] +
                     parsedRelease["sectionOtherLines"] +
                     ["{} = rw".format(x) for x in parsedRelease["sectionUsernames"]] +
                     [""] +
                     parsedRelease["postSectionLines"])

        return "".join(line + "\n" for line in lines)

    def write(self):
        originalStr = self.asStr(original=True)
        newStr = self.asStr(original=False)

        if newStr != originalStr:
            with open(self.confFilename, "w") as f:
                f.write(newStr)


def parseRelease(releaseName, confFileLines):
    # Digest the 'release' section of the file so it's easier to manipulate, and return it as a
    # dict.

    # States for a simple state-machine.
    S_LOOKING = "looking"
    S_IN_SECTION = "in section"
    S_POST_SECTION = "post section"

    state = S_LOOKING

    sectionHeader = "[core:/ecommerce/sites/common/content/branches/release-{}]".format(releaseName)
    preSectionLines = []
    sectionUsernames = []
    sectionOtherLines = []
    postSectionLines = []

    for line in confFileLines:
        if state == S_LOOKING:
            if line == sectionHeader:
                state = S_IN_SECTION
            else:
                preSectionLines.append(line)

        elif state == S_IN_SECTION:
            if re.search(r"^\s*\[", line):
                # Section has ended.
                state = S_POST_SECTION
                postSectionLines.append(line)
                continue

            # Is this a normal username, or something else (e.g., comment, group, blank line)?
            match = re.match(r"^\s*([a-z0-9]+)\s*=\s*rw\s*$", line)
            if match:
                sectionUsernames.append(match.group(1))
            elif re.match(r"^\s*$", line):
                pass # Ignore blank lines
            else:
                sectionOtherLines.append(line)

        elif state == S_POST_SECTION:
            postSectionLines.append(line)

        else:
            assert False, "unexpected state '{}'".format(state)

    if state == S_LOOKING:
        sys.exit("Unable to find release-{} section in file".format(releaseName))

    parsedRelease = {
        "sectionHeader": sectionHeader,
        "preSectionLines": preSectionLines,
        "sectionUsernames": sectionUsernames,
        "sectionOtherLines": sectionOtherLines,
        "postSectionLines": postSectionLines,
    }

    return parsedRelease
