"""
repo.py

Abstract base Repo class.  Overridden in svnTools and gheTools.
"""

import os
from abc import ABC, abstractmethod


class UrlError(Exception):
    """Exception representing a problem parsing a repository Url"""
    pass


class Repo(ABC):
    """
    Abstract base class for SCM repositories.
    """
    def __init__(self, repoUrl, branchName, workDir):
        self.repoUrl = repoUrl
        self.branchName = branchName

        if workDir is None:
            workDir = os.getcwd()
        else:
            workDir = os.path.abspath(workDir)

        self.workDir = workDir

    @abstractmethod
    def getCIBuildVersion(self):
        """Return Maven project version for this repo in CI"""

    @abstractmethod
    def getPomVersion(self):
        """Return the project version as reported by pom.xml"""
