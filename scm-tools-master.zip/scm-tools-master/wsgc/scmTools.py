"""
scmTools.py

SCM-agnostic tools that depend on SCM-specific libraries.
"""

from wsgc import util
from wsgc import pomutils
from wsgc import svnTools
from wsgc import gheTools


class RepoCreationError(Exception):
    """
    Exception indicating a problem when creating a Repo object.
    """


def RepoFactory(repoUrl=None, branchName=None, workDir=None):
    """
    Factory for creating a Repo object.
    """
    if repoUrl:
        if gheTools.isGHEUrl(repoUrl):
            cls = gheTools.GitRepo
        elif svnTools.isSvnUrl(repoUrl):
            cls = svnTools.SvnRepo
        else:
            raise RepoCreationError("Unable to determine type of repo from url '{}'".format(repoUrl))
    else:
        if workDir is None:
            workDir = '.'

        if gheTools.isGitWorkDir(workDir=workDir):
            cls = gheTools.GitRepo
        elif svnTools.isSvnWorkDir(workDir=workDir):
            cls = svnTools.SvnRepo
        else:
            raise RepoCreationError("We don't appear to be at the top level of a repository")

    return cls(repoUrl=repoUrl, branchName=branchName, workDir=workDir)


def getCIBuildVersion(repoUrl=None, branchName=None, workDir=None):
    repo = RepoFactory(repoUrl=repoUrl, branchName=branchName, workDir=workDir)
    return repo.getCIBuildVersion()


def applyCIBuildVersions(workDir='.', repoUrl=None, branchName=None, verbose=True):
    repo = RepoFactory(repoUrl=repoUrl, branchName=branchName, workDir=workDir)

    ciVersion = repo.getCIBuildVersion()

    if verbose:
        print("Setting project version to {}".format(ciVersion))

    with util.chdirTmp(workDir):
        pomutils.setProjectVersion(ciVersion)
