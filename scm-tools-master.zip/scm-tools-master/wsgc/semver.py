"""
semver.py

Library of routines for processing Semantic Versions.
"""
import re

# Representation of here in each project we can expect to find
# the project's semantic version.
#
# We use the name of the pipeline that handle the project
# as the key to this dict:
#
#   <pipelineType>: {filename: <fname>, searchTemplate: <regex>}
#
# 'filename' is the file in the project's repo that contains the
# project's version.  'searchTemplate' is a regex that matches a
# line containing the semver, with the semver itself represented by '{}'.
PIPELINE_SEMVER_CONFIGS = {
    'HelmChart': {
        'filename': 'Chart.yaml',
        'searchTemplate': r'^version\s*:\s*{}',
    },
    'HelmProject': {
        'filename': 'project.yaml',
        'searchTemplate': r'\bversion\s*:\s*{}',
    },
    'PythonApp': {
        'filename': 'app.yaml',
        'searchTemplate': r'\bversion\s*:\s*{}',
    },
    'Node': {
        'filename': 'package.json',
        'searchTemplate': r'"version"\s*:\s*"{}",',
    },
    'NodeApp': {
        'filename': 'package.json',
        'searchTemplate': r'"version"\s*:\s*"{}",',
    },
    'Dockerfile': {
        'filename': 'project.yaml',
        'searchTemplate': r'\bversion\s*:\s*{}',
    },
    'WebComponentJest': {
        'filename': 'lerna.json',
        'searchTemplate': r'"version"\s*:\s*"{}"',
    },
    'NPMPackage': {
        'filename': 'lerna.json',
        'searchTemplate': r'"version"\s*:\s*"{}"',
    },
    'JSPackage': {
        'filename': 'lerna.json',
        'searchTemplate': r'"version"\s*:\s*"{}"',
    },
}

# Other semantic versions that we might need to match against.
#
# An example is the Docker image tag in a Helm Project's
# `values.yaml`
OTHER_SEMVERS = {
    'HelmProjectDockerTag': {
        'filename': 'config/values.yaml',
        'searchTemplate': r'\btag\s*:\s+{}',
    },
}


class Semver:
    """Representation of a semantic version"""
    regex = r'(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?!\.|\d)(?:-(.+))?'

    def __init__(self, major, minor, patch, extra=None):
        self.major = int(major)
        self.minor = int(minor)
        self.patch = int(patch)
        self.extra = extra

        # major, minor, and patch were all valid ints or
        # we would have thrown a ValueError, but make sure
        # that they don't contain leading zeros either.
        for val in major, minor, patch:
            if isinstance(val, str) and re.match(r'0\d', val):
                raise ValueError('Leading zeros not allowed in semver ({})'.format(val))

    @staticmethod
    def parse(verStr):
        """Return Semver object, or raise ValueError if verStr isn't a semver"""
        match = re.match(r'{}$'.format(Semver.regex), verStr)
        if match:
            return Semver(*match.groups())

        raise ValueError('Cannot parse as semver: {}'.format(verStr))

    def __iter__(self):
        """Enables tuple() and auto-unpacking"""
        return (x for x in (self.major, self.minor, self.patch, self.extra))

    def __eq__(self, other):
        return other is not None and tuple(self) == tuple(other)

    def __lt__(self, other):
        selfNumerics = (self.major, self.minor, self.patch)
        otherNumerics = (other.major, other.minor, other.patch)
        if selfNumerics < otherNumerics:
            return True
        if selfNumerics > otherNumerics:
            return False

        # The numeric parts are the same.
        return (self.extra is not None and
                (other.extra is None or self.extra < other.extra))

    def __gt__(self, other):
        return other < self

    def __str__(self):
        """Print ourselves in a user-friendly way"""
        semverStr = '{}.{}.{}'.format(self.major, self.minor, self.patch)

        if self.extra is not None:
            semverStr += '-{}'.format(self.extra)

        return semverStr

    def __repr__(self):
        return '{}({!r}, {!r}, {!r}, {!r})'.format(type(self).__name__,
                                                   self.major, self.minor, self.patch, self.extra)


def getSemverBumpViolations(oldver, newver):
    """
    Return list of problems when a semver changes from oldver to newver.
    Returns empty list if there are no problems.

    If old is None, we don't consider that a violation, as long as there's
    a new version and it doesn't have an "extra" component.
    """
    violations = []

    if oldver == newver:
        violations.append('No version update found')
    elif newver is None:
        violations.append('Semver {} removed with no replacement'.format(oldver))
    elif newver.extra is not None:
        violations.append('{} is not a release version'.format(newver))
    elif oldver is None:
        pass  # newver has no extra, so there are no more checks to make.
    elif newver < oldver:
        violations.append('Version decreased instead of increasing')
    elif newver.major > oldver.major:
        if newver.major - oldver.major != 1:
            violations.append('Major version increased by more than 1')
        if newver.minor != 0 or newver.patch != 0:
            violations.append('Major version bumped: minor and patch must be zero')
    elif newver.minor > oldver.minor:
        if newver.minor - oldver.minor != 1:
            violations.append('Minor version increased by more than 1')
        if newver.patch != 0:
            violations.append('Minor version bumped: patch must be zero')
    elif newver.patch > oldver.patch:
        if newver.patch - oldver.patch != 1:
            violations.append('Patch increased by more than 1')

    return violations
