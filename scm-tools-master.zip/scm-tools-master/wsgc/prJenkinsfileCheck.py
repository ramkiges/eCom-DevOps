"""
prJenkinsfileCheck.py

Library for checking a diff to see if it's introducing anything it shouldn't with Jenkinsfile.
Examples include adding lines that update dependencyOverrides or publishBranches, or any other
variable not on our whitelist.
"""

import re


# See https://confluence.wsgc.com/display/TAH/Pipeline+DSL for a list of the variables that we
# expect to live in Jenkinsfile outside of a work-branch context.  (This page includes variables,
# like publishBranches, that could exist on a release branch (say), but where updates via PRs are
# not expected to happen.  In those cases where there has to be an update to them, it may be forced
# through, but should not be able to happen by accident.)
#
# See https://confluence.wsgc.com/display/TAH/Jenkinsfile%3A+Branch-Specific+Settings for the
# specific variables we allow; that page must be kept in sync with this script.
WHITELISTED_VAR_NAMES = {
    "buildNumber",
    "cmd",
    "credentials",
    "customConfigs",
    "debugScheme",
    "enableSonar7Features",
    "endToEndScheme",
    "id",
    "imageName",
    "jdk",
    "slowBuildsDownByDisablingConcurrentTestRuns",
    "mavenParameters",
    "projectKey",
    "projectName",
    "refresh",
    "registry",
    "releaseScheme",
    "stubRunners",
    "target",
    "unitTestScheme",
    "versionNumber",
    "xcodeWorkspace",
}


def checkDiff(prDiff):
    """
    Return a list of strings describing violations found in the diff, according to WSI's policy
    regarding what may or may not appear in a PR for a Jenkinsfile.
    """
    # State machine states.
    S_FIND_JENKINSFILE = "Find Jenkinsfile"
    S_IN_JENKINSFILE = "In Jenkinsfile"

    state = S_FIND_JENKINSFILE

    customLibraryFound = False
    badVars = []

    for line in prDiff.splitlines():
        if state == S_FIND_JENKINSFILE:
            if re.match(r"diff --git a/.* b/Jenkinsfile$", line):
                state = S_IN_JENKINSFILE

        elif state == S_IN_JENKINSFILE:
            match = re.match(r"\+\s*(?:.*;\s*)?(\w+)\s*.?=", line)
            if match:
                # Adding a variable assignment.  Is it legal?
                varName = match.group(1)
                if varName not in WHITELISTED_VAR_NAMES:
                    badVars.append(varName)
            elif re.match(r"\+\s*@Library", line):
                customLibraryFound = True

            if line.startswith("diff --git a/"):
                # Jenkinsfile section is over.
                break

        else:
            assert False

    violations = []

    if customLibraryFound:
        violations.append("Customized Library Import")

    if badVars:
        badVarsMsg = "Branch-specific assignments: {}".format(", ".join(badVars))
        violations.append(badVarsMsg)

    return violations
