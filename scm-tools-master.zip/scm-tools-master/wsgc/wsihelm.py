"""
wsihelm.py

Library of routines for interacting with WSI's Helm repositories.
"""

import sys
import os
import re
import hashlib
from collections import namedtuple
import tempfile
import requests
import yaml

from wsgc import artifactory
from wsgc import util


# The location in prod Artifactory where we publish the "unrepackaged" charts.  By "unrepackaged", we
# mean that mvnrelease has published individual tgz and config zip artifacts from a release of a
# k8s-package repository.  It is "unrepackaged", in the sense that for Jukebox deployments, we bundle
# the tarball and zip together into a single tarball (and publish the result into a proper Helm repo,
# rather than this Maven repo).
UNREPACKAGED_CHARTS_AF_URL = artifactory.PROD_ARTIFACTORY_URL
UNREPACKAGED_CHARTS_REPO = 'wsgc-releases'
UNREPACKAGED_CHARTS_URL = '{}/{}'.format(UNREPACKAGED_CHARTS_AF_URL, UNREPACKAGED_CHARTS_REPO)
UNREPACKAGED_CHARTS_REPO_SUBPATH = 'com/wsgc/devops/k8s'
UNREPACKAGED_PROD_CHARTS_URL = '{}/simple/{}/{}'.format(UNREPACKAGED_CHARTS_AF_URL, UNREPACKAGED_CHARTS_REPO,
                                                        UNREPACKAGED_CHARTS_REPO_SUBPATH)

# The location of the repackaged-for-Jukebox charts.
JUKEBOX_PROD_AF_URL = artifactory.SNAPSHOT_ARTIFACTORY_URL
JUKEBOX_PROD_CHARTS_REPO = 'helm-prod'
JUKEBOX_PROD_CHARTS_URL = '{}/{}'.format(JUKEBOX_PROD_AF_URL, JUKEBOX_PROD_CHARTS_REPO)
JUKEBOX_PROD_CHARTS_INDEX = '{}/index.yaml'.format(JUKEBOX_PROD_CHARTS_URL)

# The non-release-versions, but still repackaged, charts.
JUKEBOX_SNAPSHOT_CHARTS_REPO = 'jukebox'
JUKEBOX_SNAPSHOT_CHARTS_URL = '{}/{}'.format(artifactory.SNAPSHOT_ARTIFACTORY_URL, JUKEBOX_SNAPSHOT_CHARTS_REPO)
JUKEBOX_SNAPSHOT_CHARTS_INDEX = '{}/index.yaml'.format(JUKEBOX_SNAPSHOT_CHARTS_URL)

# The 'Chart' and 'RepackagedChart' classes, used and returned by various routines below.
Chart = namedtuple('Chart', 'repoName packageName packageVersion appVersion')
RepackagedChart = namedtuple('RepackagedChart', 'chart chartPath')


def getPublishedCharts():
    """
    Return a set of Charts that are available at the prod Maven artifactory in
    un-repackaged form.
    """
    publishedCharts = set()

    # Look for unrepackaged charts in the prod artifactory.  Use AQL because there
    # is no index.yaml (because this is a Maven repo, not a Helm repo).
    aql = 'search/pattern'
    params = {'pattern': '{}:{}/*/*'.format(UNREPACKAGED_CHARTS_REPO, UNREPACKAGED_CHARTS_REPO_SUBPATH)}
    username = util.getCredential('artifactory_prod', 'username_ro')
    password = util.getCredential('artifactory_prod', 'username_ro_password')
    response = artifactory.callAQL(serverUrl=UNREPACKAGED_CHARTS_AF_URL,
                                   aql=aql,
                                   params=params,
                                   username=username, password=password)

    mavenMetadataPaths = response['files']

    for mavenMetadataPath in mavenMetadataPaths:
        # We have a path to the maven-metadata.xml for a package; the contents of this
        # metadata will give us the package name and all its versions present in the repo.
        match = re.match(r'(.*)/(.*)/maven-metadata.xml$', mavenMetadataPath)
        if not match:
            sys.exit('Unexpected metadata {} in {}'.format(mavenMetadataPath, response))
        packageParentDir, repoName = match.groups()
        metadataURL = '{}/{}'.format(UNREPACKAGED_CHARTS_URL, mavenMetadataPath)
        metadataText = util.callURL(url=metadataURL).text
        metadataXML = util.Xml(metadataText)
        packageVersions = metadataXML.xpathText('versioning/versions/')

        for packageVersion in packageVersions:
            # Read Helm package name and app version from pom.
            pomFilename = '{}-{}.pom'.format(repoName, packageVersion)
            packageVersionPath = '{}/{}/{}'.format(packageParentDir, repoName, packageVersion)
            pomURL = '{}/{}/{}'.format(UNREPACKAGED_CHARTS_URL, packageVersionPath, pomFilename)
            pomXml = util.Xml(util.callURL(url=pomURL).text)
            packageName = pomXml.xpathTextOneValue('properties/helm.project.name')
            appVersion = pomXml.xpathTextOneValue('properties/app.version')

            # Add this to the set of charts.
            publishedCharts.add(Chart(repoName=repoName,
                                      packageName=packageName,
                                      packageVersion=packageVersion,
                                      appVersion=appVersion))

    return publishedCharts


def getRepackagedCharts(*, isSnapshot):
    """
    Return a list of Chart objects that are already present on the
    repackaged-for-jukebox Helm repo.

    If isSnapshot is true, this will be for the non-release versions,
    otherwise we will return the info for released versions.
    """
    # Get the charts index.yaml.
    username = util.getCredential('artifactory_nonprod', 'username_ro')
    password = util.getCredential('artifactory_nonprod', 'username_ro_password')

    if isSnapshot:
        indexUrl = JUKEBOX_SNAPSHOT_CHARTS_INDEX
        chartsRepo = JUKEBOX_SNAPSHOT_CHARTS_REPO
    else:
        indexUrl = JUKEBOX_PROD_CHARTS_INDEX
        chartsRepo = JUKEBOX_PROD_CHARTS_REPO

    response = util.callURL(indexUrl, authUser=username, authPassword=password)
    chartsIndex = yaml.safe_load(response.text)

    # Gather them into a set of charts
    repackagedCharts = set()
    try:
        for packageName, chartsData in chartsIndex['entries'].items():
            for chartData in chartsData:
                packageName = chartData['name']
                packageVersion = chartData['version']
                appVersion = chartData['appVersion']

                # Figure out repo name backwards from the download URL.
                repoName = None
                for packageUrl in chartData['urls']:
                    matchRE = r'{}/(.*?)-\d'.format(re.escape(chartsRepo))
                    match = re.search(r'{}/(.*?)-\d'.format(re.escape(chartsRepo)), packageUrl)
                    if match:
                        repoName = match.group(1)
                        break
                    print('no match for [{}] in [{}]'.format(matchRE, packageUrl))

                if repoName is None:
                    print('Error finding repoName in {}; skipping'.format(chartData), file=sys.stderr)
                    continue

                repackagedCharts.add(Chart(repoName=repoName,
                                           packageName=packageName,
                                           packageVersion=packageVersion,
                                           appVersion=appVersion))
    except KeyError:
        pass  # No charts available.

    return repackagedCharts


def repackageChart(chart):
    """
    Download the tarball and zip for <chart> from the prod server, and combine them
    by copying the zip's contents into the 'config' directory of the tarball and re-tarring
    it.  Return a RepackagedChart object pointing to the tarball we created.
    """
    print('Repackaging {}'.format(chart))

    # Filesystem destination for the repackaged chart.
    repackagedTarballFname = os.path.abspath('{}-{}.tgz'.format(chart.packageName, chart.packageVersion))

    repoName, packageName, packageVersion = chart.repoName, chart.packageName, chart.packageVersion

    with tempfile.TemporaryDirectory(dir='.') as workDir:
        with util.chdirTmp(workDir):
            chartBaseUrl = '{}/{}/{}'.format(UNREPACKAGED_PROD_CHARTS_URL, repoName, packageVersion)
            tarballUrl = '{}/{}-{}-helm.tgz'.format(chartBaseUrl, repoName, packageVersion)
            configZipUrl = '{}/{}-{}-helm-config.zip'.format(chartBaseUrl, repoName, packageVersion)

            # The names of the files we're doing to download them to.  Not important what we
            # call them, but must not clash with the name of an app or be "helm-config", as
            # those are the names of the directories they will expand to.
            tarballFilename = 'chart.tgz'
            configZipFilename = 'config.zip'

            username = util.getCredential('artifactory_prod', 'username_ro')
            password = util.getCredential('artifactory_prod', 'username_ro_password')

            try:
                util.downloadFile(tarballUrl, tarballFilename, authUser=username, authPassword=password)
                util.downloadFile(configZipUrl, configZipFilename, authUser=username, authPassword=password)
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 404:
                    # Not all the packages ever released conform to our current naming conventions; the violators
                    # may be skipped.
                    print('404 Error downloading {}; skipping package'.format(e.response.request.url), file=sys.stderr)
                    return None

                raise e

            # Expand the tarball and the config zip.
            util.run(['tar', 'xf', tarballFilename])
            util.run(['unzip', configZipFilename])

            # The config zip puts all its files in this parent directory.
            configZipTopLevelDir = 'helm-config'

            # The tarball puts its content in a dir named after the app.
            tarballTopLevelDir = packageName

            # Copy the contents of the config zip's helm-config dir into
            # this directory within the tarball.
            destDir = '{}/config'.format(tarballTopLevelDir)
            for filename in os.listdir(configZipTopLevelDir):
                srcFileOrDir = os.path.join(configZipTopLevelDir, filename)
                util.copyPath(src=srcFileOrDir, destDir=destDir)

            # Rebuild the new tarball.
            util.run(['tar', 'cfz', repackagedTarballFname, tarballTopLevelDir])

    return RepackagedChart(chart=chart, chartPath=repackagedTarballFname)


def publishRepackagedChart(repackagedChart):
    """
    Upload the tarball to the jukebox chart repository.
    """
    print('Publishing repackaged chart {}'.format(repackagedChart))
    repoName = repackagedChart.chart.repoName
    packageVersion = repackagedChart.chart.packageVersion
    tarballFilename = repackagedChart.chartPath

    username = util.getCredential('artifactory_nonprod', 'username_rw')
    password = util.getCredential('artifactory_nonprod', 'username_rw_password')

    chartName = '{}-{}.tgz'.format(repoName, packageVersion)
    url = '{}/{}'.format(JUKEBOX_PROD_CHARTS_URL, chartName)

    with open(tarballFilename, 'rb') as f:
        tarballData = f.read()

    sha1Hex = hashlib.sha1(tarballData).hexdigest()
    headers = {'X-Checksum-Sha1': sha1Hex}
    util.callURL(url, action='put', formDict=tarballData, headers=headers,
                 postIsJSON=False, authUser=username, authPassword=password)
