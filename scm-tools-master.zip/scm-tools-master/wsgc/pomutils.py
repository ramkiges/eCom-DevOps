"""
pomutils.py -- utility routines for dealing with pom.xml files
"""

import sys
import re
import subprocess
import logging
import itertools

# Can't do, e.g., 'from wsgc import svnTools' here because they import us.
import wsgc.svnTools
import wsgc.util
from wsgc.util import run


class VersionChoice:
    """A decision on how a version conflict was resolved"""
    def __init__(self, propertyName, srcUrl, destUrl, oldVersion, newVersion, useVersion):
        self.propertyName = propertyName
        self.srcUrl = srcUrl
        self.destUrl = destUrl
        self.oldVersion = oldVersion
        self.newVersion = newVersion
        self.useVersion = useVersion


def getPomVersions():
    # For the repo in the current directory, return a dictionary of:
    #
    #   projectName: <projectName>
    #   projectVersion: <version>
    #   propertyVersions: {propertyName: <version>, ...}
    #
    # Exits with an error status if pomhelper fails.
    #
    # Example pomhelper output:
    #
    # Project: com.wsgc.ecommerce.baselogic:wsgc-baselogic 2.3.15-SNAPSHOT
    #
    # Property Versions:
    #   ${google.geocoder.version} = 0.15
    #     com.google.code.geocoder-java:geocoder-java
    #
    #   ${aosauthentication.version} = 1.1.1
    #     com.wsgc.aosauthentication:aosauthentication-impl
    #     com.wsgc.aosauthentication:aoslandingservice-api
    #     com.wsgc.aosauthentication:aoslandingservice-impl
    #
    #   ${project.version} = 2.3.15-SNAPSHOT
    #     com.wsgc.ecommerce.baselogic:wsgc-activity-model
    #     com.wsgc.ecommerce.baselogic:wsgc-address-service-api
    #
    # [...]
    #
    #   ${commons.pool.version} = 1.5.3
    #     org.apache.commons:com.springsource.org.apache.commons.pool
    #
    #   ${jsoup.version} = 1.6.3
    #     org.jsoup:jsoup
    #
    #   ${jaxb.basics.version} = 0.6.5
    #     org.jvnet.jaxb2_commons:jaxb2-basics-runtime
    #
    # Explicit Versions:
    #     com.endeca:endeca-content = 2.1.0
    #     com.endeca:endeca_logging = 6.1.2
    #     com.endeca:endeca_logging = 6.4.1
    #
    # Each header "${google.geocoder.version} = X.Y.Z" will appear
    # only once. (Anything else would trigger a nonzero exit code.)
    #
    # If a deeper pom.xml specfies a parent version id inconsistent
    # with the root pom.xml's version id, pomhelper will exit with a
    # nonzero exit code and a message regarding
    # "ProjectStructureException".
    #
    # Throws a subprocess.CalledProcessError if pomhelper has trouble.
    output = run('pomhelper . --propartifacts')

    projectName = None
    projectVersion = None
    propertyVersions = {}

    STATE_HEADER = 'header'
    STATE_PROPERTY_VERSIONS = 'property versions'
    STATE_EXPLICIT_VERSIONS = 'explicit versions'
    state = STATE_HEADER

    for line in output.splitlines():
        if re.match(r'\s*$', line):
            continue

        if state == STATE_HEADER:
            if re.match(r'Property Versions:\s*$', line):
                if projectName is None:
                    sys.exit("pomhelper missing 'Project:' header")
                else:
                    state = STATE_PROPERTY_VERSIONS
                    continue # Header for next section

            result = re.match(r'Project: com\.wsgc\.ecommerce\.(.*?):\S+ (.+)$', line)
            if result:
                projectName, projectVersion = result.groups()
            else:
                # sites/admin/content has a pom.xml file that doesn't follow our
                # usual conventions and doesn't produce a meaningful build. Ignore.
                logging.warning('Unexpected beginning of pomhelper output: %s. Ignoring pomfile resolution', line)
                return None

        elif state == STATE_PROPERTY_VERSIONS:
            if re.match(r'Explicit Versions:\s*$', line):
                state = STATE_EXPLICIT_VERSIONS
                continue # Header for next section

            result = re.match(r'\s*\$\{(.*?)\.version\} = (\S+)\s*$', line)
            if result:
                propertyName, propertyVersion = result.groups()
                propertyVersions[propertyName] = propertyVersion
            else:
                # Ignore; this is a module referencing the given version
                pass

        elif state == STATE_EXPLICIT_VERSIONS:
            # Don't worry about these for now.
            break

    return {
        'projectName': projectName,
        'projectVersion': projectVersion,
        'propertyVersions': propertyVersions,
    }


def isPropertyVersionWeCareAboutChanging(propertyName):
    # When merging, we use pomhelper to notice when property versions
    # have changed, and for certain properties we have to pay close
    # attention to whether those changes are the right thing.
    #
    # This routine defines which properties are of interest.
    return (propertyName == 'ec' or
            propertyName == 'project' or
            wsgc.util.isPlatformLayerName(propertyName))


class MergedVersionError(Exception):
    def __init__(self, msg):
        super().__init__()
        self.msg = msg


def getMergedPomProjectVersion(propertyName, oldVersion, newVersion, srcUrl, destUrl,
                               interestingVersionChoices):
    # Return the correct version to use when a pom.xml file merge between srcUrl
    # and destUrl resulted in a change from oldVersion to newVersion. Raises a
    # MergedVersionError() exception on error.
    #
    # interestingVersionChoices is an array of VersionChoice objects for any
    # changes that we want to summarize for the user at the end of the merge
    # process (e.g., minor version bumps).

    if oldVersion == newVersion:
        return oldVersion # Nothing to do

    srcUrlType, srcBranchName = wsgc.svnTools.getUrlTypeAndBranchName(srcUrl)
    destUrlType, destBranchName = wsgc.svnTools.getUrlTypeAndBranchName(destUrl)

    def parseVersion(versionStr):
        # Returns (numerics, isSnapshot), where numerics is a list of
        # integers comprising the dotted-numbers prefix of the version
        # or None if there is no such prefix, and isSnapshot is true
        # iff the version string ends with "-SNAPSHOT".
        result = re.match(r'((?:\d+\.)*\d+)(-SNAPSHOT)?$', versionStr)
        if result:
            numerics = [int(x) for x in result.group(1).split('.')]
            isSnapshot = result.group(2) != ''
            return numerics, isSnapshot
        else:
            return None, versionStr.endswith('-SNAPSHOT')

    def numericListCompare(a, b):
        # Returns -1, 0 or 1 comparing lists of numbers a and b.  If
        # one is a strict prefix of the other, it is less-than.
        for aItem, bItem in itertools.zip_longest(a, b):
            if aItem is None:
                return -1 # a is a strict prefix of b
            if bItem is None:
                return 1  # b is a strict prefix of a
            if aItem != bItem:
                return -1 if aItem < bItem else 1
        return 0

    def die(errStr):
        msg = 'Error in version change when merging {} to {}.\n'.format(srcUrl, destBranchName)
        msg += errStr + '.\n'
        msg += 'Version changed from {} to {}; please resolve manually'.format(oldVersion, newVersion)
        raise MergedVersionError(msg=msg)

    # Merging isn't done to/from tags.  If you want to merge from a tag, create
    # a branch from the tag and merge from the branch.
    if srcUrlType == 'tag' or destUrlType == 'tag':
        die('You are not allowed to merge to/from tags')

    # The rules for when to accept a version change, when to reject a
    # version change and when to error out depend on what types of
    # branches we're dealing with.  There are three types, development
    # branches, trunk, and release branches.

    srcIsRelease = wsgc.svnTools.isReleaseBranchName(srcBranchName)
    destIsRelease = wsgc.svnTools.isReleaseBranchName(destBranchName)

    srcIsTrunk = srcUrlType == 'trunk'
    destIsTrunk = destUrlType == 'trunk'

    oldNumerics, oldIsSnapshot = parseVersion(oldVersion)
    newNumerics, newIsSnapshot = parseVersion(newVersion)

    if srcIsRelease and destIsRelease:
        # Under normal circumstances this won't arise, even if you're merging from an older release
        # to a newer one, because the merge won't touch the newer-release's versions.  It _will_
        # happen if the newer release was merged to the older release for some reason (perhaps
        # manually), or during unit testing.
        #
        # Note that you typically do NOT want to merge from a newer release to an older release, but
        # this code doesn't stop you from doing that: the place to guard against that would be in
        # the script that's trying to do merges, not this routine that is trying only to make sense
        # out of version changes that occurred as the result of a merge.
        if not oldIsSnapshot or not newIsSnapshot:
            die('I expected the release branches to both be snapshots')

        if numericListCompare(oldNumerics, newNumerics) < 1:
            die('Version increased when merging release branches; that seems wrong to me')

        return oldVersion

    if srcIsRelease and not destIsRelease:
        # Release branch -> trunk or work branch
        #
        #  Keep the trunk/work-branch version, but error out if:
        #    a. the release version doesn't look like a numeric series
        #    b. dest is trunk and trunk version doesn't look numeric
        #    c. release and trunk major versions differ
        #    d. release and trunk minor versions differ by more than 1
        if newNumerics is None:
            die('I expected src version {} to be numeric, as it is a non-dev branch'.format(newVersion))

        if destIsTrunk:
            if not oldNumerics:
                die('I expected dest version {} to be numeric, as it is trunk'.format(oldVersion))

            if oldNumerics[0] != newNumerics[0]:
                die('Major versions differ')

            if len(oldNumerics) > 1 and len(newNumerics) > 1:
                # Compare minor versions.
                oldMinor, newMinor = oldNumerics[1], newNumerics[1]
                if abs(newMinor - oldMinor) > 1:
                    die('Minor versions differ by more than 1')

                if newMinor == oldMinor + 1:
                    useNumerics = oldNumerics[:1] + [newMinor] + oldNumerics[1:]
                    useVersion = '.'.join(useNumerics)
                    if oldIsSnapshot:
                        useVersion += '-SNAPSHOT'
                    logging.info('Minor version updated from %s to %s; using %s', oldMinor, newMinor, useVersion)
                    interestingVersionChoices.append(VersionChoice(propertyName=propertyName,
                                                                   srcUrl=srcUrl, destUrl=destUrl,
                                                                   oldVersion=oldVersion, newVersion=newVersion,
                                                                   useVersion=useVersion))
                    return useVersion
        else:
            # Old version wasn't numeric, so we're a work branch.  Just keep our version.
            logging.debug('Keeping work branch version %s (discarding %s)', oldVersion, newVersion)
            return oldVersion

        logging.debug('Keeping trunk version %s (discarding %s)', oldVersion, newVersion)
        return oldVersion

    if srcIsTrunk and destIsRelease:
        # trunk -> release branch
        #
        # Error out; trunk should never merge into a release branch.  This decision should have been
        # made earlier in the process, but make it again here to protect against caller error.
        die('Merging from trunk to release branch is not allowed')

    if not srcIsTrunk and destIsRelease:
        # work branch -> release branch
        #
        # This is nonstandard, but is sometimes allowed (e.g., when there's an emergency fix or when
        # the release branch is not yet live).
        if oldNumerics and not newNumerics:
            # The work branch defined a work-branch-specific version that we don't need to carry
            # over.
            return oldVersion

        # This isn't the specific case we were looking for, so bail.
        die("I don't know how to resolve the version changing from {} to {}".format(oldVersion, newVersion))

    if not srcIsRelease and not destIsRelease:
        # Trunk or development branch <-> trunk or development branch
        #
        # If both versions are strictly numeric, take the greater of the two.
        #
        # Otherwise, let the destination keep its version unchanged.
        if oldNumerics and newNumerics and not oldIsSnapshot and not newIsSnapshot:
            # Both are strictly numeric.
            useVersion = oldVersion if numericListCompare(oldNumerics, newNumerics) > 0 else newVersion
            interestingVersionChoices.append(VersionChoice(propertyName=propertyName,
                                                           srcUrl=srcUrl, destUrl=destUrl,
                                                           oldVersion=oldVersion, newVersion=newVersion,
                                                           useVersion=useVersion))
            return useVersion

        return oldVersion

    die("I don't know how to resolve these versions")


def setProjectVersion(projectVersion):
    run(['mvn', '-B', 'versions:set', '-DnewVersion={}'.format(projectVersion)])


def setPropertyVersion(propertyName, propertyVersion):
    logging.info('Setting property %s to %s', propertyName, propertyVersion)

    try:
        run(['mvn', '-B', 'versions:set-property',
             '-Dproperty={}.version'.format(propertyName),
             '-DnewVersion={}'.format(propertyVersion)])
    except subprocess.CalledProcessError as e:
        sys.exit('Error calling mvn versions: {}'.format(e.output))


def verifyPlatformLayerVersions(theseVersions, priorPlatformVersions):
    # Check to see if the versions in theseVersions point to the right versions in
    # priorPlatformVersions.
    #
    # Returns (errMsg, dependsOnPlatformLayers), where errMsg is None on success, and
    # dependsOnPlatformLayers is a list of platform layers that theseVersions depend on exactly.
    errMsg = None
    dependsOnPlatformLayers = []

    projectName = theseVersions['projectName']

    for platformLayer in wsgc.util.PLATFORM_LAYERS:
        versionsUsedByThisProject = theseVersions['propertyVersions']

        if platformLayer in versionsUsedByThisProject:
            versionUsedByThisProject = versionsUsedByThisProject[platformLayer]

            if platformLayer in priorPlatformVersions:
                lowerLayerVersion = priorPlatformVersions[platformLayer]

                if versionUsedByThisProject == lowerLayerVersion:
                    # Dependency is correct.  Record the dependency so if a layer changes we can
                    # build layers that depend on it.
                    dependsOnPlatformLayers.append(platformLayer)
                    logging.info('%s references version %s of %s, which is correct',
                                 projectName, versionUsedByThisProject, platformLayer)
                else:
                    errMsg = "{} references version {} of {}, which doesn't match {}".format(projectName,
                                                                                             versionUsedByThisProject,
                                                                                             platformLayer,
                                                                                             lowerLayerVersion)
            else:
                logging.warning('%s references version %s of %s, for which we have no version information',
                                projectName, versionUsedByThisProject, platformLayer)

    return (errMsg, dependsOnPlatformLayers)
