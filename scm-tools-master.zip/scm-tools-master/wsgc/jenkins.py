"""
jenkins.py

Library of routines for talking to Jenkins.

This is limited by Jenkins's REST API.  Notably, it's not going to help you with folders, which
doesn't expose a REST API.  But if you just want to grab a normal job XML or upload one, this can be
useful.
"""

import sys
import re
import urllib.parse
import time
import requests

from . import util

JENKINS_URL = "https://ecombuild.wsgc.com/jenkins"

# The success status string as returned by Jenkins.
STATUS_SUCCESS = "SUCCESS"


def callJenkins(endpoint, dieOnError=True, returnRawResponse=False, **otherArgs):
    """
    Call the Jenkins endpoint, which may be either a full URL or a relative URL like "/api/...".
    If the URL appears to specify JSON, convert the output to JSON before returning it to caller.
    If "formDict" is included as an argument, the action is POST, otherwise it is GET.
    For full usage, see util.callJenkinsURL().
    """
    url = endpoint if endpoint.startswith("http") else JENKINS_URL + endpoint

    if "action" not in otherArgs:
        otherArgs["action"] = "post" if "formDict" in otherArgs else "get"

    try:
        response = util.callJenkinsURL(url=url, **otherArgs)
    except requests.exceptions.HTTPError as e:
        if dieOnError:
            sys.exit(e)
        raise e  # Let caller handle it.

    if returnRawResponse:
        return response

    return response.json() if "/api/json" in url else response.text


def getJobNames(viewName=None):
    """Return a list of job names, restricted to viewName if not None"""
    endpoint = "/view/{}/api/json/".format(urllib.parse.quote(viewName)) if viewName else "/api/json/"

    try:
        result = callJenkins(endpoint=endpoint,
                             params={"tree": "jobs[name]"},
                             dieOnError=False)
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return []  # No jobs in this view because it doesn't exist

        raise e

    return [x["name"] for x in result["jobs"]]


def getViews(viewsCache=None):
    """
    Returns {viewName: [job, ...], ...}

    This is relatively expensive but the data is very commonly needed, so a process that needs to do
    several operations may reuse the data by passing it around.  If they've passed it to us, just
    return it.
    """
    if viewsCache is not None:
        return viewsCache

    result = callJenkins(endpoint="/api/json",
                         params={"tree": "views[name,jobs[name]]"})

    views = {}

    for view in result["views"]:
        jobs = [x["name"] for x in view["jobs"]]
        views[view["name"]] = jobs

    return views


def createJob(jobName, jobXml, viewName=None):
    callJenkins(endpoint="/createItem",
                params={"name": jobName},
                headers={"Content-Type": "text/xml"},
                formDict=jobXml)

    print("Created job", jobName)

    if viewName is not None:
        addJobToView(jobName=jobName, viewName=viewName)


def getJobXml(jobName):
    return callJenkins(endpoint="/job/{}/config.xml".format(jobName))


def updateJobXml(jobName, jobXml):
    callJenkins(endpoint="/job/{}/config.xml".format(jobName),
                headers={"Content-Type": "text/xml"},
                formDict=jobXml)

    print("Updated job", jobName)


def deleteJob(jobName):
    callJenkins(endpoint="/job/{}/doDelete".format(jobName),
                formDict='')

    print("Deleted job", jobName)


def viewExists(viewName, viewsCache=None):
    return viewName in getViews(viewsCache)


def createView(viewName, viewsCache=None):
    if not re.match(r'[-a-zA-Z_0-9+.]+$', viewName):
        sys.exit("Bad characters found in view name '{}'".format(viewName))

    views = getViews(viewsCache)

    if viewName in views:
        sys.exit("View {} already exists".format(viewName))

    scriptText = """
       def jenkins = jenkins.model.Jenkins.instance.getInstance()
       jenkins.instance.addView(new ListView("{}", jenkins))
    """.format(viewName)

    runGroovyScript(scriptText)

    if viewsCache is not None:
        # Update the user's cache with this new, empty view.
        viewsCache[viewName] = []


def deleteView(viewName, viewsCache=None):
    views = getViews(viewsCache)

    if viewName not in views:
        sys.exit("View {} does not exist".format(viewName))

    callJenkins(endpoint="/view/{}/doDelete".format(viewName),
                formDict='')

    print("Deleted view", viewName)


def addJobToView(*, jobName, viewName, createViewIfNecessary=True, viewsCache=None):
    views = getViews(viewsCache)

    if viewName not in views:
        if createViewIfNecessary:
            createView(viewName, viewsCache=viewsCache)
        else:
            sys.exit("View {} does not exist".format(viewName))

    callJenkins(endpoint="/view/{}/addJobToView".format(viewName),
                params={"name": jobName},
                formDict='')

    print("Added job {} to view {}".format(jobName, viewName))


def removeJobFromView(*, jobName, viewName, viewsCache=None):
    views = getViews(viewsCache)

    if viewName not in views:
        sys.exit("Cannot remove job {} from view {} because the view doesn't exist".format(jobName, viewName))

    if jobName not in views[viewName]:
        sys.exit("Job {} is not in view {}".format(jobName, viewName))

    callJenkins(endpoint="/view/{}/removeJobFromView".format(viewName),
                params={"name": jobName},
                formDict='')

    print("Removed job {} from view {}".format(jobName, viewName))

    if viewsCache:
        viewsCache[viewName].remove(jobName)


def deleteEmptyViews(viewsCache=None):
    views = getViews(viewsCache)

    removedViews = []

    for viewName, jobs in views.items():
        if not jobs:
            deleteView(viewName)
            removedViews.append(viewName)

    return removedViews


def runGroovyScript(scriptText):
    return callJenkins(endpoint="/scriptText",
                       formDict={"script": scriptText})


def getOrgRepos(orgName):
    """
    Return a list of {name: <repoName>, url: <repoUrl>} for each Jenkins repo in the GHE org.
    """
    reposResult = callJenkins(endpoint="/job/{}/api/json".format(orgName),
                              params={"tree": "jobs[name,url]"})

    retval = []

    for repoInfo in reposResult["jobs"]:
        repoName = repoInfo["name"]
        repoUrl = repoInfo["url"]

        if repoUrl.endswith("/"):
            repoUrl = repoUrl[:-1]

        retval.append({"name": repoName, "url": repoUrl})

    return retval


def getLastBuildEpoch(jobUrl):
    """
    Get the epoch of the last build for this job.  If there have been no builds, return None.
    """
    lastBuildEpochUrl = "{}/lastBuild/api/json".format(jobUrl)

    try:
        lastBuildEpochResult = callJenkins(endpoint=lastBuildEpochUrl,
                                           params={"tree": "timestamp"},
                                           dieOnError=False)
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return None  # No prior builds

        raise e  # Let caller decide what to do.

    # Jenkins's last build times are in millisecond-based epochs; use integers like a normal person.
    return int(lastBuildEpochResult["timestamp"] / 1000)


def repoUrlToBranchUrl(repoUrl, branchName):
    """
    Given a URL to a GHE repo's pipeline view, return the URL of the specific branch job within that repo.
    """
    return "{}/job/{}".format(repoUrl, branchName)


def jobNameToJobUrl(jobName):
    """
    Given a job name, return the URL of the job.
    """
    return "{}/job/{}".format(JENKINS_URL, jobName)


def triggerBuild(jobUrl, formDict=None):
    """
    Trigger a build of the given job.  On success, return the location of the item in the queue.
    Callers may use this location to follow up on the status of the job.
    """
    if formDict:
        endpoint = "{}/buildWithParameters".format(jobUrl)
    else:
        endpoint = "{}/build".format(jobUrl)
        formDict = {}

    # POST is required for either endpoint, even if there is no form content.
    response = callJenkins(endpoint=endpoint, action="post", formDict=formDict, returnRawResponse=True)

    if response.status_code == 201 and 'Location' in response.headers:
        return stripTrailingSlash(response.headers['Location'])

    return None


def waitForJobStart(jobQueueUrl):
    """Wait for the job to start, and return the execution URL"""
    jobRunInfoUrl = "{}/api/json".format(jobQueueUrl)

    # Wait for job to start running.
    while True:
        jobStatus = callJenkins(endpoint=jobRunInfoUrl)
        if "executable" in jobStatus and "url" in jobStatus["executable"]:
            break
        time.sleep(5)

    return stripTrailingSlash(jobStatus["executable"]["url"])


def showConsoleOutput(jobQueueUrl):
    """Wait for job to complete, streaming its output to stdout.  Return jobExitCode."""
    jobExecutionUrl = waitForJobStart(jobQueueUrl)
    print("Job URL: {}".format(jobExecutionUrl))

    consoleOutputUrl = "{}/logText/progressiveText".format(jobExecutionUrl)

    start = 0
    NEXT_START_HEADER = 'X-Text-Size'
    MORE_DATA_HEADER = 'X-More-Data'

    # Sometimes we get a Tomcat 502 proxy error; we want to retry in that case,
    # but we don't want to retry infinitely.
    numProxyRetries = 0
    MAX_NUM_PROXY_RETRIES = 4
    RETRY_SLEEP_SECONDS = 20

    while True:
        nextChunkUrl = "{}?start={}".format(consoleOutputUrl, start)

        try:
            response = callJenkins(nextChunkUrl, returnRawResponse=True, dieOnError=False)
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 502:
                if numProxyRetries < MAX_NUM_PROXY_RETRIES:
                    print("Error from Jenkins: '{}'\nSleeping {} seconds and retrying".format(e, RETRY_SLEEP_SECONDS))
                    numProxyRetries += 1
                    time.sleep(RETRY_SLEEP_SECONDS)
                    continue
            sys.exit(e)

        numProxyRetries = 0
        print(response.text, end="")
        if MORE_DATA_HEADER in response.headers:
            start = response.headers[NEXT_START_HEADER]
        else:
            break
        time.sleep(5)

    return getJobExecutionResult(jobExecutionUrl)


def waitForCompletion(jobQueueUrl):
    """Wait for the job to complete.  Return jobExecutionUrl, jobExitStatus"""
    jobExecutionUrl = waitForJobStart(jobQueueUrl)

    jobStatus = None

    while jobStatus is None:
        jobStatus = getJobExecutionResult(jobExecutionUrl)

    return jobExecutionUrl, jobStatus


def getJobExecutionResult(jobExecutionUrl):
    """
    Return the status of the job as reported by Jenkins (e.g., "SUCCESS").
    Return None if the job hasn't yet completed.
    """
    return callJenkins("{}/api/json?tree=result".format(jobExecutionUrl))["result"]


def stripTrailingSlash(s):
    return s[:-1] if s.endswith("/") else s
