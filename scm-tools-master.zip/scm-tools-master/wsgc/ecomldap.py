#!/bin/env python
"""
wsgc/ecomldap.py

Connecting to the server is expensive enough that if you're doing a lot of ldap lookups in sequence
it pays to get the connection yourself, pass it to ldapLookup() and then pass it to closeConnection
when you're done.

If you're just going to do one or two lookups, just use ldapLookupOne(), which gets/terminates the
connection for you.

For example, auditing all the unique names in the Subversion access file by reconnecting every time
takes around two minutes total, while reusing the connection lowers that to around fifteen seconds.
"""

import sys
import logging
import ldap3
import contextlib

from wsgc import util

# The eComm LDAP server
LDAP_SERVER_URI = 'ldaps://ldaprck.wsgc.com'
LDAP_SERVER_PORT = 3269


def getLDAPConnection():
    # Get credentials and connect to the ldap server.
    ldapUser = util.getCredential('ldap', 'user')
    ldapPass = util.getCredential('ldap', 'password')

    try:
        ldapServer = ldap3.Server(LDAP_SERVER_URI, port=LDAP_SERVER_PORT, get_info=ldap3.ALL)
        ldapConnection = ldap3.Connection(ldapServer, auto_bind=True, client_strategy=ldap3.SYNC,
                                          user=ldapUser, password=ldapPass,
                                          authentication=ldap3.SIMPLE, check_names=True)
    except ldap3.core.exceptions.LDAPSocketOpenError as e:
        logging.error("Error connecting to LDAP server '%s': %s", LDAP_SERVER_URI, e)
        return None

    return ldapConnection


def closeLDAPConnection(ldapConnection):
    ldapConnection.unbind()


@contextlib.contextmanager
def ldapConnection():
    """Context manager for an LDAP Connection"""
    ldapConnection = getLDAPConnection()
    yield ldapConnection
    ldapConnection.unbind()


def ldapLookup(ldapConnection,
               username=None, firstName=None, lastName=None, commonName=None,
               lookupProperty='mail', bases=None, filters=None,
               includeInactive=False, returnQueryAlso=False):
    if filters is None:
        # Look for user info.
        filters = ['(objectClass=user)']

    # Specify the user we're interested in.
    userFilters = []
    if username is not None:
        userFilters.append('(sAMAccountName={})'.format(username))

    if firstName is not None:
        userFilters.append('(givenName={})'.format(firstName))

    if lastName is not None:
        userFilters.append('(sn={})'.format(lastName))

    if commonName is not None:
        userFilters.append('(cn={})'.format(commonName))

    if not userFilters:
        sys.exit('You must pass a filter to ldapLookup!')

    filters += userFilters

    if not includeInactive:
        # We're not interested in inactive users.
        filters.append('(!(userAccountControl:1.2.840.113556.1.4.803:=2))')

    # 'And' them together.
    filterstr = "(&{})".format(''.join(filters))

    if bases is None:
        # Try different OUs: 'WSGC Users' for normal users and 'Resources' for service accounts.
        # This should be kept up-to-date with the Subversion Apache configuration on repos.wsgc.com.
        bases = ['OU={},DC=wsgc,DC=com'.format(ou) for ou in ('WSGC Users', 'Resources')]

    didFindResults = False
    queryString = None
    for base in bases:
        queryString = "property: '{}', filter: '{}', base: '{}'".format(lookupProperty, filterstr, base)
        if ldapConnection.search(search_base=base,
                                 search_scope=ldap3.SUBTREE,
                                 search_filter=filterstr,
                                 attributes=[lookupProperty]):
            didFindResults = True
            break

    if not didFindResults:
        retval = None
    elif len(ldapConnection.response) != 1:
        # The purpose of this routine is to look up information on
        # single individuals.
        retval = None
    else:
        attrs = ldapConnection.response[0]['attributes']
        retval = attrs.get(lookupProperty, None)

    return (retval, queryString) if returnQueryAlso else retval


def ldapLookupOne(username=None, firstName=None, lastName=None, lookupProperty='mail', includeInactive=False):
    """One-off call to ldapLookup(), so the caller doesn't have to get/end the connection themselves."""
    with ldapConnection() as connection:
        return ldapLookup(ldapConnection=connection,
                          username=username,
                          firstName=firstName,
                          lastName=lastName,
                          lookupProperty=lookupProperty,
                          includeInactive=includeInactive)
