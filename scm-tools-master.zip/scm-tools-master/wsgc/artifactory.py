"""
artifactory.py

Routines to support talking to the WSI Artifactory instances.
"""

import hashlib

from wsgc import util

PROD_ARTIFACTORY_URL = 'https://artifactory.wsgc.com/artifactory'
SNAPSHOT_ARTIFACTORY_URL = 'https://snapshotrepo.wsgc.com/artifactory'


def callAQL(*, serverUrl, aql, params, username, password):
    """
    Wrapper around util.callURL() that knows how to send Artifactory
    Query Language (AQL) queries.
    """
    url = '{}/api/{}'.format(serverUrl, aql)

    response = util.callURL(url=url,
                            params=params,
                            authUser=username, authPassword=password)

    return response.json()


def uploadFile(serverUrl, repoName, pathname):
    """Upload the file to Artifactory."""
    if serverUrl == SNAPSHOT_ARTIFACTORY_URL:
        username = util.getCredential('artifactory_nonprod', 'username_rw')
        password = util.getCredential('artifactory_nonprod', 'username_rw_password')
    else:
        assert serverUrl == PROD_ARTIFACTORY_URL
        username = util.getCredential('artifactory_prod', 'username_rw')
        password = util.getCredential('artifactory_prod', 'username_rw_password')

    basename = pathname.split('/')[-1]
    url = '{}/{}/{}'.format(serverUrl, repoName, basename)

    with open(pathname, 'rb') as f:
        fileContents = f.read()

    sha1Hex = hashlib.sha1(fileContents).hexdigest()
    headers = {'X-Checksum-Sha1': sha1Hex}
    util.callURL(url, action='put', formDict=fileContents, headers=headers,
                 postIsJSON=False, authUser=username, authPassword=password)


def getFileList(serverUrl, repoName, folder=''):
    """Get list of files in repository, rooted at folder."""
    url = '{}/api/storage/{}/{}'.format(serverUrl, repoName, folder)

    authUser = util.getCredential('artifactory_nonprod', 'username_admin')
    authPassword = util.getCredential('artifactory_nonprod', 'password_admin')

    params = {
        'list': '1',
        'deep': '1',
        'mdTimestamps': '1',
        'listFolders': '0',
        'includeRootPath': '1',
    }

    response = util.callURL(url, params=params, authUser=authUser, authPassword=authPassword).json()

    # The response contains a 'created' header and the 'files'; return the latter.
    return response['files']


def removeArtifact(serverUrl, repoName, path):
    """Remove the artifact at path"""
    url = '{}/{}/{}'.format(serverUrl, repoName, path)

    authUser = util.getCredential('artifactory_nonprod', 'username_admin')
    authPassword = util.getCredential('artifactory_nonprod', 'password_admin')

    util.callURL(url, action='delete', authUser=authUser, authPassword=authPassword)


def deleteEmptyDirs(serverUrl, repoName):
    """
    Run the deleteEmptyDirs plugin, documented here:

    https://github.com/jfrog/artifactory-user-plugins/tree/master/cleanup/deleteEmptyDirs

    This plugin runs automatically via quartz; this is for manual runs only, which you should
    not need to do under normal circumstances.

    We run the plugin with async=1, because otherwise we hit a 1min timeout from Apache
    (or nginx or whatever), even when there is nothing to do.
    """
    url = '{}/api/plugins/execute/deleteEmptyDirsPlugin'.format(serverUrl)

    params = {
        'params': 'paths={}'.format(repoName),
        'async': '1',
    }

    authUser = util.getCredential('artifactory_nonprod', 'username_admin')
    authPassword = util.getCredential('artifactory_nonprod', 'password_admin')

    util.callURL(url, action='post', params=params, authUser=authUser, authPassword=authPassword)


def reloadPlugins(serverUrl):
    """Tell the server to notice changes to plugins, and new plugins."""
    url = '{}/api/plugins/reload'.format(serverUrl)

    authUser = util.getCredential('artifactory_nonprod', 'username_admin')
    authPassword = util.getCredential('artifactory_nonprod', 'password_admin')

    return util.callURL(url, action='post', authUser=authUser, authPassword=authPassword).text
