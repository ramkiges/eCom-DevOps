#!/bin/env python
"""
Routines for interacting with the WSI eCommerce Jira server.

Requires the user to have entered Jira credentials in ~/.credentials (and for some operations, those
need to have admin rights).
"""

import sys
import requests

import jira

from wsgc import util

# The eComm LDAP server
JIRA_SERVER_URI = 'https://jira.wsgc.com'


def getJiraConnection():
    # Get credentials and connect to Jira.  The connection can't be reused, so don't bother caching
    # it.
    configSection = 'jira'
    jiraUser = util.getCredential(configSection, 'user')
    jiraPass = util.getCredential(configSection, 'password')

    # Disable warnings, or we'll get a warning about the invalid cert every time we do an operation.
    requests.packages.urllib3.disable_warnings()

    jiraLibOptions = {
        # Python doesn't know about WSGC-RootCA, and our cert currently doesn't identify a
        # subjectAltName; one day we will want to make our cert good and tell Python about it, but
        # until then don't verify the host.
        'verify': False,

        # Disable phone-home version check.
        'check_update': False,
    }

    return jira.JIRA(JIRA_SERVER_URI, options=jiraLibOptions, basic_auth=(jiraUser, jiraPass))


def getJiraGroupMembers(groupName):
    """
    Returns a dictionary of {<username>: <userDataDict>} for every Jira user in the 'jira-users' group.
    """
    connection = getJiraConnection()
    users_dict = connection.group_members(groupName)
    return users_dict


def getJiraUser(username):
    return getJiraConnection().user(username).raw


def removeUserFromAllGroups(username):
    connection = getJiraConnection()

    fullUserObj = connection.user(username, expand=['groups'])
    for groupInfo in fullUserObj.raw['groups']['items']:
        groupName = groupInfo['name']
        print("Removing {} from {}".format(username, groupName))
        connection.remove_user_from_group(username, groupName)


def searchIssues(jql):
    connection = getJiraConnection()
    return connection.search_issues(jql)


def getJiraIssue(jiraID, fields=None):
    jiraIssue = None
    jiraError = None
    connection = getJiraConnection()
    try:
        if fields:
            fields = ','.join(fields)
            jiraIssue = connection.issue(jiraID, fields=fields)
        else:
            jiraIssue = connection.issue(jiraID)
    except jira.exceptions.JIRAError as e:
        jiraError = e
        print(f"Error: {e.status_code} {e.text}")
    return jiraIssue, jiraError


def getJiraComment(jiraIssue, commentID):
    connection = getJiraConnection()
    return connection.comment(jiraIssue, commentID)


if __name__ == '__main__':
    try:
        print('there are {} users'.format(len(getJiraGroupMembers('jira-users'))))
    except KeyboardInterrupt:
        # Don't dump stack, just exit.
        sys.exit(' Interrupted by user')  # The space leaves room after the echoed ^C.
