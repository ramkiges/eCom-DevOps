### scm-tools

This is a collection of tools for interacting with source code
management (Subversion and Git), and for talking to various DevOps
REST interfaces (Jira, Artifactory, Confluence, Jenkins, Rundeck).

You need Python 3.8 or higher, along with some additional Python
packages specified in `requirements.txt`, to run most of the scripts
in this repository.  The `package wsgc-devops-toolchain-python3`
installs a suitable version of Python and the required packages in
`/apps/python3` on a CentOS 7 box.


#### Scripts Run From Cron on the Tools Box

The box `ecom-devops-tools-1` runs a bunch of jobs out of `svnowner`'s
crontab.  We keep a manually-backed-up copy of that crontab in
`data/crontabs/merge-o-tron` in this repository.

This is a rundown of the scripts that are currently listed there,
followed in other sections by other scripts in this repo that are
worth pointing out.  (Scripts not mentioned in this README are either
too one-off to mention, or someone added a script without updating
this file.)

**launch**: Shell wrapper put in front of crontab entries, which sets
up the environment appropriately before invoking the script that is
given as its arguments.  This is needed because the environment that
`cron` gives you can be fairly generic.  This puts "/apps/python3/bin"
in the PATH, sets the locale to UTF-8, etc.

**mergeShortcuts**: Perform a merge of two "DP" Subversion shortcuts.
There are numerous options to this script, which is the workhorse of
the daily merge process.

**performMergeSeries**: Wrapper script that calls **mergeShortcuts** for
each of the daily merges in sequence.  The data file that directs the
daily merges is `data/merges.daily.txt`.

**reTriggerOldBuilds**: Initiate a Jenkins build of the release branch
of every repo in an org that hasn't been built in the past week.  We
do this to make it easier to track down builds that bit-rotted despite
the code not changing, due to environmental drift.  Perhaps nobody
actually notices the results, but it can help when looking into a new
build failure to see when the last time was the code did build.

**pruneArtifactoryRPMs**: After Artifactory version 3, it lost the
ability to keep only the two most recent snapshot RPMs for a given
project (because it no longer models "snapshot" as an RPM property,
because they are no longer kept in Maven repos).  We publish tens of
thousands of RPMs a day to the snapshot artifactory; this script culls
older versions in order to keep the size of the repository down,
saving both disk space and the time for it to generate a new index.

**pathWatchdog**: Look for recent updates to a Subversion repository
and send an email if changes are seen on paths that the user is
interested in.  This has been put to various uses over the years, but
currently watches Subversion's `access.conf` file so we will be
alerted if someone manages to mess with it.

**confluencePageUpdater**: Update a given Confluence page with the
output of a script passed in as its arguments, if the new output of
the script would modify the contents of the page.  We use this to keep
updated pages in Confluence that:

* List the GHE webhooks: this is useful for when you need to modify a
  webhook and wonder whether/where it is used.  (**gheHooksReport**)

* List the GHE org owners for each org: this is something you can
  direct users to who want access to an org and don't know whom to
  ask, since GHE doesn't expose org roles to normal users.
  (**gheOrgOwnerReport**)

* Show the auto-merge status of each shortcut that is the target of an
  auto-merge.  This lets users answer "which changes am I missing in
  my shortcut, and when was the last time the merge happened?"
  (**mergeStatusReport**)

**Various Auditing Scripts**:

* **auditSubversionAccess**: Show users in Subversion's `access.conf`
   file that no longer have active LDAP accounts.  This output gets
   emailed once a week, and we then manually remove their access.  You
   may run this script manually against your local copy of the file
   whenever editing it to catch typos in syntax or usernames, or to
   confirm that you've removed the users who are no longer active.

* **auditGitHubAccess**: Suspend GHE accounts whose AD accounts are no
   longer active.  Can also suspend accounts for users who haven't
   logged into GHE for a period of time.  (That period of time is
   configured in GHE, not in the script.)  Can also be used to list
   all active users, for the purposes of submitting data for audits.

   This script differs from the other audit scripts in that it does
   the deactivation of the user's GHE account itself, rather than
   requiring a person to do the work.  Part of why this is considered
   okay for this script to do that is that if it suspends someone
   mistakenly due to a bug in the script or in LDAP, they can
   re-activate their account simply by logging in again.

* **auditRundeckAccess**: Show users in Rundeck's
   `/etc/rundeck/wsi.realm.properties` file that no longer have active
   AD access.  This gets emailed out every week, and we manually
   remove them from `rundeck.wsgc.com`, and then manually copy the
   updated config file into (the version controlled-copy of that
   file)[https://github.wsgc.com/eCommerce-DevOps/toolchain-rundeck-config/blob/master/src/main/resources/sys/etc/rundeck/wsi.realm.properties]
   and PR that change into bedrock.

* **sendComplianceAuditEmail**: This is a script we run weekly that
   audits the non-overlap of who can commit code and who can deploy to
   production.  This siloing is part of our SOX compliance mandate.
   This script calls out to other scripts, like
   **auditGHEOrgWriteAccess**, to do some of its work.

* **auditGHELicense**: This sends email alerts if the number of
   available GHE licenses drops below configurable thresholds.  Our
   team has managed this traditionally, but ownership of this script
   is likely to move to Sam Gaddam's tools team soon (as of Oct 2021).

* **auditGHERepoConfigs**: Alert if certain hooks aren't enabled for
   repos in the given org.  Useful for keeping up-to-date with
   changing requirements like which arguments to the ecom-webhooks
   server should exist for which repos.

   **This can also be used to fix the hook-argument problems it finds,
   by passing the `--doRepair` option.  This isn't automated, in
   order that a bug or other confusion on the part of this script
   doesn't wreak havoc.  First run it without `--doRepair`, and then
   run it again with the option if the script's corrections appear
   sane.**

**gheManagePreReceiveHooks**: Very similar to **auditGHERepoConfigs**,
to the point where they should probably be folded together.  This
one specifically makes sure that the pre-receive hook is in place
for repos that auto-bump their semvers, to enforce that a PR not be
merged unless it contains severity tags telling us _how_ to bump the
version.


#### Scripts Used by Jenkins

**applyCIBuildVersion**: Customize the given Maven project's `pom.xml`
files to build the "CI version" of the project.  You can check what
that version would be with the **getCIBuildVersion** script.  As this
is mostly used now only for Maven projects that are _not_ built via
pipeline, it is not used very often.  (The `DPSites` pipeline is an
exception, but one that could probably be changed to no loner use this
script, using the mechanism that the `Service` pipeline uses instead.)

**backupJenkinsConfigs**: Called from Jenkins to do what it says.

**doesDockerTagExist**: Used by CI to know whether we've already
  published a Docker image.

**getGHERootRepo**: Used by CI to know how to tell Sonar what branch
  it should compare this branch to.

**createBranchAndShortcut**: Called from the Jenkins job
  create-hotfix-shortcut, to do what it says.

**manageSvnBranchLocks**: Called periodically from Jenkins to re-lock
  the `common/content` branches of "locked" Subversion release
  shortcuts.

**parseTmplNumber**: Used by the `create-hotfix-shortcut` in the
  unusual case where someone wants a hotfix created from the exact
  content version that is live for a particular brand.

**updateHelmConfigImageTag**: Called when auto-updating Helm Project
  config repos when the application gets a patchlevel version bump.
  This idea never really took off, because it is designed to not touch
  production, and they typically use the one version in
  `config/values.yaml` for all the environments, including production.


#### Scripts Housed Here But Used Elsewhere

**checkoutJava.sh**: The master copy of the script that sits at the
  root of all shortcuts, which helps users manually check out the Java
  corresponding to the content repos in their shortcut.


#### Scripts That You Might Want to Use Relatively Often

**createGHERepo**: Creates a new repo in GHE, handling a lot of the
  housekeeping, particularly for bedrock repos.  Branch protection
  still must be done manually.

**runJenkinsJob**: Run a Jenkins job from the command-line, possibly
  waiting for and streaming its output.  Used by some Mead tools.

**showCommits**: Give a brief list of the commits to all externals of
  a Subversion shortcut.  Useful to see the last time a shortcut saw any
  updates.

**showUserGroups**: Look up what AD groups a user belongs to.


#### Scripts That You Might Want to Use in Unusual Situations

**auditSonarLOC**: The Sonar server's self-reported lines-of-code
  count per project assumes that the main branch of a project contains
  as many lines as the branches of that project, but the total against
  the license is measured is the highest line count of any branch in
  the repo.  So Sonar can tell you you're bumping against the limit,
  but it doesn't do a good job of showing you which repos are using
  all the lines.  This script calculates the true count per project,
  and shows which branches exceed the count of the main branch, and by
  what percent.

  This is one of those scripts that's useful when you're close to the
  LOC limit, and you'll never run otherwise.  We've got massive
  headroom now, so this won't be needed for a very long time.

**cleanRepo**: Undo local changes to a Subversion working directory,
  including descending into externals if you're in a shortcut.  Useful
  for cleaning the slate before starting a merge.  (Note: does not
  remove ignored directories.)

**deleteJenkinsJobs**: Does what it says.

**deleteShortcutAndBranches**: Are you sorry you created that
  Subversion shortcut?  This is the easiest way to delete it and all
  the various branches that its externals point to.

**deleteUnversionedJobs**: Useful for listing and, in a different mode,
  deleting Jenkins jobs that aren't versioned in the "jenkins-jobs"
  repo.  None of the pipeline jobs are in jenkins-jobs, so the "list"
  mode lists all of them, but every once in a while it's useful to see
  how many stray jobs were meant to be deleted and weren't (like
  builders for shortcuts that are no longer used), and this script is
  good for that.  List the jobs, prune them down to the ones you want
  to nuke, and feed that into the "delete" mode of the script.


#### Scripts That Are Mostly Obsolete

Developers used to customize the project versions when they created
branches, in order that their artifacts not overwrite the
release-branch ones when their branches built in CI.

This created endless headaches; these scripts were written to soothe
those headaches.

Some time ago we started auto-customizing their versions on the fly
when we build in CI, removing the requirement that users commit these
changes, so the scripts aren't really needed anymore, and could be
removed.

**resolveProjectVersions**: When pom.xml files have conflicts because of
project version number changes, and the conflicts all follow the same
pattern, this script can help fix them up.

**updateParentGroupVersions**: If new pom.xml files merge into a branch,
they likely refer to the parent pom version of the originating branch,
not of the destination branch.  This script may be used to update them
to the destination's parent pom version.


#### Webhook Server

The webhook server is located in the `hooks` directory; see
`hooks/README.md` for details.


#### Creating an RPM

Use `mvn clean package` to build an RPM that installs this repository
in /apps/scm-tools.


#### Creating PyPi packages

The `wsgc` directory contains library routines that can be built and distributed
as a PyPi package (using the included `setup.py`).
The shortest instructions for this are:
1. increment the version number in `setup.py`
2. run `python setup.py sdist bdist_wheel`
3. run `twine upload --repository-url https://snapshotrepo.wsgc.com/artifactory/api/pypi/wsgc-pypi-local dist/*`
from the root of this repo with a properly configured python3 build environment.
See
https://confluence.wsgc.com/display/ES/Creating+a+PyPi+Package
for more information.


#### Further Reading

See
https://confluence.wsgc.com/display/GED/Setting+Up+a+Merge-Automation+Machine
for details about the automated merge process.
