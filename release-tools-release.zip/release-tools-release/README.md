# release-tools
Tools used for self service, and assisted releases of code

* manage-automerge - used to add/remove of automerge entries in merges-daily.txt - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/manage-automerge/
* publish-npm-artifact - used to publish NPM artifacts - called from Jenkins  https://ecombuild.wsgc.com/jenkins/view/release-tools/job/publish-npm-artifact/
* roll2suppport - script for creating support branches; underlying script has issues - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/roll-to-support/
* create-release-branch - creates a release branch - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/create-release-branch/
* create-release-artifact - wrapper around mvnrelease - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/create-release-artifact/
* create-release-artifact-configs - creates release artifacts and updates config packages - configs are in https://github.wsgc.com/eCommerce-DevOps/release-tools-configs - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/create-release-artifact-configs/
* update-yum-repos - forces a cache refresh - needs to be updated to work with updated cache servers
* create-dp-release-artifacts - creates a release of DP for prod/aktest - called from Jenkins https://ecombuild.wsgc.com/jenkins/view/release-tools/job/create-dp-release-artifacts/

