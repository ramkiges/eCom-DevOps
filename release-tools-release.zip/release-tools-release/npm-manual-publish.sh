#!/bin/sh
#https://confluence.wsgc.com/display/ES/Publishing+NPM+artifacts

echo "Deprecated"
exit 255

# Notice: this script is being fine-tuned.  hotfix release branch names have
#         been inconsistent, recent examples: hotfix-1.0.1 or release-1.0.x
#         and this affects how to do the hotfix branch checkout.
#
# Instructions: 
#   Set COMMIT_LEVEL
#   Leave DRY_RUN null.  unless you want a dry-run.
#   Set one SCM
#   Set either REL *or* HOTFIX_BRANCH value
#   -  setting HOTFIX_BRANCH will automatically set COMMIT_LEVEL to patch
#   -  REL versions should come from the current version according to the
#      respective git repo

# Settings
COMMIT_LEVEL=minor     # patch, minor, major (hotfix uses patch)
DRY_RUN=""             # non-null for dry run output

#####
# un-comment the appropriate repo and update the release version
#####

# SCM=git@github.wsgc.com:eCommerce-Bedrock/dp-foundation.git
# REL=2.9.27

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-pwa.git
# REL=4.2.1

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-stores.git
# REL=1.0.2 # current rev 

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-product.git
# #REL=4.3.0
# HOTFIX_BRANCH=release-4.1.4

#SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-order.git
#REL=1.4.4

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-common.git
# REL=4.4.0

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-shop.git
# REL=1.1.0

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-search.git
# # REL=1.7.1
# HOTFIX_BRANCH=release-2.0

#SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-registry.git
#REL=3.5.1
# HOTFIX_BRANCH=release-2.16

# SCM=git@github.wsgc.com:eCommerce-Bedrock/web-component-ecom-search.git
# HOTFIX_BRANCH=release-1.0.x
# REL=1.0.4

# SCM=git@github.wsgc.com:eCommerce-Meru/pricing-service.git
# HOTFIX_BRANCH=hotfix-1.5.6.x

SCM=git@github.wsgc.com:eCommerce-Bedrock/js-ecom-common.git
REL=1.1.0


###########
# checks
if [ ! -z "$HOTFIX_BRANCH" ] ; then
  # echo "Setting hotfix COMMIT_LEVEL to patch"
  COMMIT_LEVEL=patch
  REL=$HOTFIX_BRANCH
fi

if [ -z "$SCM" -o -z "$REL" ]
then
  echo "Need to set SCM, and REL or HOTFIX_BRANCH"
  exit 1
fi

if [ ! -z "$DRY_RUN" ] ; then 
  CMD=echo # just echo most commands
else
  CMD="" 
fi

# last chance to back out
echo "You (`whoami`) are generating the following npm: "
echo "SCM    = $SCM"
echo "REL    = $REL"
echo "COMMIT = $COMMIT_LEVEL"
if [ ! -z "$HOTFIX_BRANCH" ] ; then
  echo "*** HOTFIX PATCH $HOTFIX ***"
fi
if [ ! -z "$DRY_RUN" ] ; then
  echo "*** DRY RUN ENABLED ***"
fi
echo "You have 5 seconds to abort this script..."
sleep 10  # slowly count to five

NAME=$(basename $SCM | sed -e s/\.git//g)
LOG="/home/node/logs/npm-publish-$NAME.log"
TMP=/tmp/npm-manual
rm -rf $TMP
mkdir -p $TMP

cat > $LOG << EOF
$(date +'%Y-%m-%d %H:%M')
npm publish
SCM:	$SCM
COMMIT:	$COMMIT_LEVEL
REL:	$REL
HOTFIX:	$HOTFIX_BRANCH
***
EOF
chmod 644 $LOG

$CMD npm config set registry https://npmrepo.wsgc.com/repository/wsgc-npm-local
$CMD npm config set _auth d3NnYy1ucG0tdXNlcjp0aHgxMTM4TlBN

set -x
$CMD git clone $SCM $TMP/$NAME || exit 1
$CMD cd $TMP/$NAME

if [ -z "$HOTFIX_BRANCH" ] ; then
  $CMD git remote add upstream $SCM || exit 1
fi

$CMD git fetch --all || exit 1

$CMD git config -l
$CMD git branch -a
$CMD git tag | tail

if [ -z "$HOTFIX_BRANCH" ] ; then 
  # regular npm release
  $CMD git checkout release || exit 1
else
  # hotfix patch
  $CMD git checkout $HOTFIX_BRANCH || exit 1
fi

# echo PAUSE
# read a

echo DEBUG
pwd
ls -lsFrtR .npmrc lerna* publish*

if [ -z "$HOTFIX_BRANCH" ] ; then
  # regular npm release
  $CMD lerna publish -m "[RELEASE] %s" --ignore-scripts --exact --force-publish=* --yes --cd-version=$COMMIT_LEVEL --npm-tag $REL
  ret=$?
  echo "*** lerna failure" >> $LOG
  cat /usr/npm/_logs/* >> $LOG
  [ $ret != 0 ] && exit 1
  git tag v${REL}
else
  # hotfix patch
  $CMD lerna publish -m "[RELEASE] %s" --ignore-scripts --exact --force-publish=* --yes --cd-version=$COMMIT_LEVEL --npm-tag $HOTFIX_BRANCH
  ret=$?
  echo "*** lerna failure" >> $LOG
  cat /usr/npm/_logs/* >> $LOG
  [ $ret != 0 ] && exit 1
  git tag v${HOTFIX_BRANCH}
fi

$CMD git push  || exit 1

if [ -n "$DRY_RUN" ] ; then
  echo "END OF DRY RUN (no changes)"
fi
