#!/bin/sh
# This script creates an HTML table matrix of releases and their associated versions of foundation, baselogic, etc, etc etc
# this script runs in /apps/scripts/env_summary
export PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/apps/mead-tools:/apps:/apps/scripts/env_summary:~/bin
export ARTIFACTORY="https://artifactory.wsgc.com/artifactory"
export CONFIGS="/wsgc-devops-releases/com/wsgc/devops"
export RELEASES="/wsgc-releases/com/wsgc"
RELEASE_TOOLS="git@github.wsgc.com:eCommerce-DevOps/release-tools.git"

# list of parent packages
PARENTS="\
wsgc-devops-root \
wsgc-devops-application \
wsgc-tomcat-parent:6.0  \
wsgc-tomcat-parent:8.0 \
wsgc-tomcat-parent:8.5 \
wsgc-tomcat-parent:9.0 \
wsgc-rerun-modules-parent \
wsgc-devops-frontend-common \
wsgc-devops-toolchain-node-common \
wsgc-k8s-packages-parent \
wsgc-apmagents \
"

# this is the Confluence space in which the page will reside
DOC_SPACE="ES"
PAGENAME="Service Matrix"

# this is expected to be in the same directory as the script
SERVICE_MATRIX="$(dirname $0)/service-matrix.txt"

# this is a pipe-delimited list of packages to ignore
SERVICE_IGNORE="jms"

# jenkins job to run this script
JENKINS="https://ecombuild.wsgc.com/jenkins/job/generate-service-matrix/"

# artifactory login
LOGIN="devops_ro:hC8ib-mmeEls"
TIMEOUT="--connect-timeout 10  --max-time 20"
RUNTIME="/bin/timeout --preserve-status -k 60s 60s"

KEY_EXCLUDE="<!--|-->|projectparent|modelVersion|java|tomcat|mq.version|junit|oracle|gnu|spring"

if [ -d /apps/scripts/env_summary ]
then
	basedir="/apps/scripts/env_summary"
else
	basedir=/tmp
fi
cclidir="$basedir/atlassian-cli-3.2.0"
umask 000

BailOut() {
	[ -n "$1" ] && echo "Error: $*"
	echo "Usage: $(basename $0) [release1] [release2] ... "
	exit 1
}

HTML() {
	echo "$*" >> $OUTFILE
}

getPOM() {
	REPO=$1
	POM=$(curl $TIMEOUT --user "$LOGIN" -s -k $REPO | grep -i "\.pom" | head -1 | awk -F '[""]' '{ print $2 }')
	if [ -n "$POM" ] 
	then
		curl $TIMEOUT --user "$LOGIN" -s --insecure $REPO$POM -O 
		# this is still a work-in-progress
		key=$(egrep -i 'artifactVersion>|author.version>|war.version>|jar.version>' $POM | egrep -iv "$KEY_EXCLUDE|<version>" | awk -F '[<>]' '{ print $2 }' | head -1)
		if [ -n "$key" ]
		then
			echo "	key:$key" >&2
			propget -f $POM -p "$key"
		else
			echo "	key:<none>" >&2
		fi
	fi
}

timeStamp() { echo ">>>> $* $(date +'%Y-%m-%d %H:%M:%S') <<<<"; }

## see if another one is running
#PID=$(ps -ef |grep "$(basename $0)" | egrep -ivw "vim|grep|$$" | awk '{ print $2 }')
#[ -n "$PID" ] && echo kill $PID

cd /tmp
rm -rf /tmp/release-tools
git clone $RELEASE_TOOLS 
cd release-tools
#cp -p $(basename $0) getversion $(basename $SERVICE_MATRIX) $basedir
#cd /tmp
#rm -rf /tmp/release-tools

[ -z "$GETVERSION" ] && GETVERSION=$(which getversion)
[ -e "$GETVERSION" ] || BailOut "Can't find \"getversion\" ($GETVERSION)"
echo "getversion: $(ls -l $GETVERSION)"
set -x
cp $GETVERSION $basedir
cp $SERVICE_MATRIX $basedir
cp $0 $basedir 
set +x

OUTFILE=/tmp/service-matrix.html
rm -f $OUTFILE

HTML
HTML "<h3>Services</h3>"
HTML "<table border='1' cellpadding='1' cellspacing='1'>"
HTML "<tr>"
HTML "	<th style='text-align: center' rowspan='2'>Service</th>"
HTML "	<th style='text-align: center' rowspan='2'>Released<br>Version</br></th>"
HTML "	<th style='text-align: center' rowspan='2'>Common<br>Package</br><br>Updated</br></th>"
HTML "	<th style='text-align: center' colspan='4'>Production Version</th>"
#HTML "	<th style='text-align: center' rowspan='2'><br>UAT</br>Version</th>"
HTML "</tr>"
HTML "<tr>"
HTML "	<th style='text-align: center'>Config</th>"
HTML "	<th style='text-align: center'>Config-AB</th>"
HTML "	<th style='text-align: center'>Config-RK</th>"
HTML "	<th style='text-align: center'>Config-SAC</th>"
HTML "</tr>"

for line in $(sort -u $SERVICE_MATRIX | egrep -v "^#")
#for line in $(cat $SERVICE_MATRIX | egrep -v "^#")
do
    #echo "$line"
	# need to clear these in case there isn't a config
	cfg_com_ver=
	cfg_com_art=
	cfg_com_url=
	cfg_uat_ver=
	cfg_uat_art=
	cfg_uat_url=
	cfg_gen_ver=
	cfg_gen_art=
	cfg_gen_url=
	cfg_ab_ver=
	cfg_ab_art=
	cfg_ab_url=
	cfg_rk_ver=
	cfg_rk_art=
	cfg_rk_url=
	cfg_sac_ver=
	cfg_sac_art=
	cfg_sac_url=

	cfg_com_date=
	cfg_uat_date=
	cfg_gen_date=
	cfg_ab_date=
	cfg_rk_date=
	cfg_sac_date=

	svc=$(echo "$line" | awk -F\| '{ print $1 }')
	echo "$svc" | egrep -iq "$SERVICE_IGNORE" && continue

	echo
	timeStamp "Service: $svc"

	svc_ver=$($RUNTIME $GETVERSION $svc 2>/dev/null)
	if [ -z "$svc_ver" ]
	then
		echo "getversion doesn't know \"$svc\""
		echo
		continue
	fi

	cfg_com=$(echo "$line" | awk -F\| '{ print $2 }')
	cfg_gen=$(echo "$line" | awk -F\| '{ print $3 }')
	cfg_ab=$(echo "$line" | awk -F\| '{ print $4 }')
	cfg_rk=$(echo "$line" | awk -F\| '{ print $5 }')
	cfg_sac=$(echo "$line" | awk -F\| '{ print $6 }')
	cfg_qa=$(echo "$line" | awk -F\| '{ print $7 }')
	
	svc_date=$(TIMESTAMP=1 $GETVERSION $svc | grep -i "timestamp=" | awk -F= '{ print $2 }')
	svc_link=$(SHOWLINK=1 $GETVERSION $svc | grep -i "Artifact=" | awk -F= '{ print $2 }')

	# if we have any one of the discreet configs, then use those
	CFG="${cfg_gen}${cfg_ab}${cfg_rk}${cfg_sac}"

	if [ -n "$CFG" ]
	then
		if [ -n "$cfg_com" ] 
		then
			timeStamp "	cfg_com: $cfg_com"
			cfg_com_ver=$($GETVERSION $cfg_com)
			cfg_com_date=$(SHOWTIME=1 $GETVERSION $cfg_com | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_com_url=$(SHOWREPO=1 $GETVERSION $cfg_com | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_com_url"
			grep -iq $cfg_com $GETVERSION || echo "$cfg_com ) lookUp \"$(echo "$cfg_com_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;; "
			cfg_com_art=$(getPOM "$cfg_com_url/$cfg_com_ver/")
			echo "	$cfg_com_url"
		fi
		if [ -n "$cfg_uat" ] 
		then
			timeStamp "	cfg_gen: $cfg_uat"
			cfg_uat_ver=$($GETVERSION $cfg_uat)
			cfg_uat_date=$(SHOWTIME=1 $GETVERSION $cfg_uat | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_uat_url=$(SHOWREPO=1 $GETVERSION $cfg_uat | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_uat_url"
			grep -iq $cfg_uat $GETVERSION || echo "$cfg_uat ) lookUp \"$(echo "$cfg_uat_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;;"
			cfg_uat_art=$(getPOM "$cfg_uat_url/$cfg_uat_ver/")
			echo "	$cfg_uat_url"
		fi
		if [ -n "$cfg_gen" ] 
		then
			timeStamp "	cfg_gen: $cfg_gen"
			cfg_gen_ver=$($GETVERSION $cfg_gen)
			cfg_gen_date=$(SHOWTIME=1 $GETVERSION $cfg_gen | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_gen_url=$(SHOWREPO=1 $GETVERSION $cfg_gen | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_gen_url"
			grep -iq $cfg_gen $GETVERSION || echo "$cfg_gen ) lookUp \"$(echo "$cfg_gen_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;;"
			cfg_gen_art=$(getPOM "$cfg_gen_url/$cfg_gen_ver/")
			echo "	$cfg_gen_url"
		fi
		if [ -n "$cfg_ab" ]  
		then
			timeStamp "	cfg_ab:  $cfg_ab"
			cfg_ab_ver=$($GETVERSION $cfg_ab)
			cfg_ab_date=$(SHOWTIME=1 $GETVERSION $cfg_ab | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_ab_url=$(SHOWREPO=1 $GETVERSION $cfg_ab | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_ab_url"
			[ -n "$cfg_ab_url" ] && grep -iq $cfg_ab $GETVERSION || echo "$cfg_ab ) lookUp \"$(echo "$cfg_ab_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;;"
			cfg_ab_art=$(getPOM "$cfg_ab_url/$cfg_ab_ver/")
			echo "	$cfg_ab_url"
		fi
		if [ -n "$cfg_rk" ]  
		then
			timeStamp "	cfg_rk:  $cfg_rk"
			cfg_rk_ver=$($GETVERSION $cfg_rk)
			cfg_rk_date=$(SHOWTIME=1 $GETVERSION $cfg_rk | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_rk_url=$(SHOWREPO=1 $GETVERSION $cfg_rk | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_rk_url"
			[ -n "$cfg_rk_url" ] && grep -iq $cfg_rk $GETVERSION || echo "$cfg_rk ) lookUp \"$(echo "$cfg_rk_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;;"
			cfg_rk_art=$(getPOM "$cfg_rk_url/$cfg_rk_ver/")
			echo "	$cfg_rk_url"
		fi
		if [ -n "$cfg_sac" ]  
		then
			timeStamp "	cfg_sac: $cfg_sac"
			cfg_sac_ver=$($GETVERSION $cfg_sac)
			cfg_sac_date=$(SHOWTIME=1 $GETVERSION $cfg_sac | grep -i timestamp | awk -F= '{ print $2 }')
			cfg_sav_url=$(SHOWREPO=1 $GETVERSION $cfg_sac | grep -i "repo=" | awk -F= '{ print $2 }')
			#echo "		$cfg_sav_url"
			[ -n "$cfg_sac_url" ] && grep -iq $cfg_sac $GETVERSION || echo "$cfg_sac ) lookUp \"$(echo "$cfg_sav_url" | sed -es%$ARTIFACTORY%%g -es%$CONFIGS%\$CONFIGS%g)\"; exit 0;;"
			cfg_sac_art=$(getPOM "$cfg_sav_url/$cfg_sac_ver/")
			echo "	$cfg_sac_url"
		fi
	else
		echo "No configs for $svc"
		#cfg=$(SHOWCONF=1 $GETVERSION $svc)
	fi

	HTML
	HTML "<tr>"
	HTML "  <th>$svc</th>"
	HTML "  <td><a href=\"$svc_link\">$svc_ver</a><br><font size='-2'>$svc_date</font></br></td>"
	HTML "  <td><i><a href=\"$cfg_com_url\">$cfg_com_art</a></i><br><font size='-2'>$cfg_com_date</font></br></td>"
	HTML "  <td><a href=\"$cfg_gen_url\">$cfg_gen_art</a><br><font size='-2'>$cfg_gen_date</font></br></td>"
	HTML "  <td><a href=\"$cfg_ab_url\" >$cfg_ab_art </a><br><font size='-2'>$cfg_ab_date</font></br></td>"
	HTML "  <td><a href=\"$cfg_rk_url\" >$cfg_rk_art </a><br><font size='-2'>$cfg_rk_date</font></br></td>"
	HTML "  <td><a href=\"$cfg_sac_url\">$cfg_sac_art</a><br><font size='-2'>$cfg_sac_date</font></br></td>"
	HTML "</tr>"
done
HTML "</table>"

HTML "<p></p>"
HTML "<table border='1'>"
HTML "<tr><th colspan='3' style='text-align:center'>Parent Config Packages</th></tr>"
HTML "<tr>"
HTML "<th style='text-align:center'>Artifact</th>"
HTML "<th style='text-align:center'>Version</th>"
HTML "<th style='text-align:center'>Date</th>"
HTML "</tr>"

for artifact in $PARENTS
do
    echo "$artifact" | grep -q ':' && { rel=$(echo "$artifact" | awk -F: '{ print $2 }'); artifact=$(echo "$artifact" | awk -F: '{ print $1 }'); } || rel=
    echo  "parent: $artifact $ver"
	version=$($GETVERSION $artifact $rel)
	link=$(SHOWLINK=1 $GETVERSION $artifact $rel | grep -i "Artifact=" | awk -F= '{ print $2 }')
	date=$(TIMESTAMP=1 $GETVERSION $artifact $rel | grep -i "timestamp=" | awk -F= '{ print $2 }')
	HTML "<tr>"
	HTML "	<th>$artifact $rel</th>"
	if [ -n "$link" ]
	then
		HTML "	<td style='text-align:right'><a href=\"$link\">$version</a></td>"
	else
		HTML "	<td style='text-align:right'>$version</td>"
	fi
	HTML "	<td style='text-align:right'>$date</td>"
	HTML "</tr>"
	done

  REPO=https://repos.wsgc.com/svn/devops/application/common/service/wsgc-apmagents/trunk/pom.xml 
  APPAGENT_VERSION=$(svn cat $REPO | grep "<apmagents.dist.version>" | awk -F '[<>]' '{ print $3 }')
  MACHAGENT_VERSION=$(svn cat $REPO | grep "<apmagents.machineagent.version>" | awk -F '[<>]' '{ print $3 }')
  set -x
  APMAGENT_DATE=$(svn info $REPO | grep -i date | awk -F 'Last Changed Date:' '{ print $2 }' | awk '{ print $1, $2 }')
  set +x
  HTML "<tr><th>AppDyanmics App Agent</th><td style='text-align:right'>$APPAGENT_VERSION</td><td>$APMAGENT_DATE</td></tr>"
  HTML "<tr><th>AppDyanmics Machine Agent</th><td style='text-align:right'>$MACHAGENT_VERSION</td><td>$APMAGENT_DATE</td></tr>"
HTML "</table>"


echo

HTML "<p>Created by <a href='$JENKINS'>$(basename $JENKINS)</a></p>"

chmod 777 $OUTFILE

# update confluence page
sh $cclidir/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose 
[ $? -eq 0 ] && rm $OUTFILE

exit 0

