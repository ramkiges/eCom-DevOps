#!/bin/sh
# This script creates an HTML table matrix of releases and their associated versions of foundation, baselogic, etc, etc etc
# this script runs in /apps/scripts/env_summary
# https://github.wsgc.com/tfitzpatrick/release-tools/blob/master/release-matrix.sh
PATH=/apps/mead-tools:/apps:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/apps/scripts/env_summary:~/bin
NS="http://maven.apache.org/POM/4.0.0"
DEBUG=true
umask 000

# list of releases - put these in reverse order so the newest releases will appear at the top of the table
# if a release is in the list, but not in svn, it will simply be skipped
MARKET_LIST="$(dirname $0)/market-list.txt"
RELEASE_TOOLS="git@github.wsgc.com:eCommerce-DevOps/release-tools.git"
DP_SITES="git@github.wsgc.com:eCommerce-Bedrock/dp-sites.git"
DP_BASELOGIC="git@github.wsgc.com:eCommerce-Bedrock/dp-baselogic.git"
DP_LOGIN="pkqaenv:Ca8tWh33l"
CURRENT_RELEASES="trunk"
OUTFILE=/tmp/release-matrix.html

COLOR_CFG="#0000ff"
COLOR_DEP="#009933"

RUNDECK_REPO=git@github.wsgc.com:eCommerce-DevOps/toolchain-resource-model.git

# the number of releases to show on the page
[[ -z $DISPLAY_COUNT ]] && DISPLAY_COUNT=3
MERGE_COUNT=$(expr $DISPLAY_COUNT \* 2)

# this is the Confluence space in which the page will reside
DOC_SPACE="ES"
PAGENAME="DP Release Matrix"

# jenkins job to run this script
JENKINS_JOB="https://ecombuild.wsgc.com/jenkins/job/generate-release-matrix/"
FRONTEND="https://repos.wsgc.com/svn/devops/application/frontend-2.1/prd/config/app/trunk"

basedir="/apps/scripts/env_summary"
cclidir="$basedir/atlassian-cli-3.2.0"

BailOut() {
	[ -n "$1" ] && echo "$(basename $0)/$(hostname --short) - Error: $*"
	echo "Usage: $(basename $0) [release1] [release2] ... "
	exit 1
}

HTML() {
	echo "$*" >> $OUTFILE
}

echo "hostname: $(hostname)"
echo "DISPLAY_COUNT: $DISPLAY_COUNT"

# getversion is a release-tools script to handle figuring out the version
GETVERSION=$(which getversion)
[ -e $GETVERSION ] || BailOut "Can't find \"getversion\" ($GETVERSION)"

ART_CRED=~/.artifactory
[ -f $ART_CRED ] || BailOut "Can't find cred file $ART_CRED"
[ -z "$ART_RO_USER" ] && ART_RO_USER=$(grep ART_RO_USER $ART_CRED | grep -iv "^.*#" | tail -1 | awk -F= '{ print $2 }')
[ -z "$ART_RO_PASS" ] && ART_RO_PASS=$(grep ART_RO_PASS $ART_CRED | grep -iv "^.*#" | tail -1 | awk -F= '{ print $2 }')
[ -z "$ART_RO_USER" ] && BailOut "Can't parse artifactory pass from $ART_CRED"
[ -z "$ART_RO_PASS" ] && BailOut "Can't parse artifactory pass from $ART_CRED"
LOGIN="$ART_RO_USER:$ART_RO_PASS"

rm -rf /tmp/rundeck
git clone --depth 1 -q $RUNDECK_REPO /tmp/rundeck

# get latest release list
rm -rf /tmp/release-tools
git clone -q $RELEASE_TOOLS /tmp/release-tools || BailOut "Could not clone $RELEASE_TOOLS"
cd /tmp/release-tools || BailOut "Unable to cd to /tmp/release-tools"

OUTFILE=/tmp/release-matrix.html
rm -f $OUTFILE

HTML "See also: <a href='https://confluence.wsgc.com/display/ES/MFE+Deployment+Matrix'>MFE Deployment Matrix</a>"

HTML "<p><b>Please note:</b> <font color='red'><i>99.xx.xx</i></font> releases are for internal testing purposes and are not for general consumption or deployment.</p>"

HTML "<table border='1'>"
HTML "<tr>"
HTML "<th>&nbsp;</th>"
for header in Foundation Baselogic Admin $(getbrandlist -a | tr '[:lower:]' '[:upper:]')
do
	HTML "  <th style='text-align:center'>$header</th>"
done
HTML "</tr>"

[[ -e /apps/mead-tools/jenkins-job-properties.txt ]] || BailOut "Can't find /apps/mead-tools/jenkins-job-properties.txt"
count=0
for release in $(grep "^releases=" /apps/mead-tools/jenkins-job-properties.txt | awk -F= '{ print $2 }' | sed -es/','/'\n'/g)
do
    release_display=$(echo "$release" | sed -es/release-//g)
    echo "--- Trying $release..."
    reldir=$(echo "$release" | tr "A-Z" "a-z")

	# do a basic test to see if the release is valid
    RELEASE=$($GETVERSION admin $reldir 2>/dev/null)
	if [ -z "$RELEASE" ] 
	then
		#echo "Release $reldir doesn't appear to be valid - skipping"
		HTML "<!-- $release not available yet -->"
		continue
	fi

    # add this release to a list we will use for the automerge script
    CURRENT_RELEASES="$CURRENT_RELEASES,$release"

    ## if we've displayed enough releases, break out of loop
    # please note: we keep running past the "show count" so that we can built a list of releases for the merge job"
    count=$(expr $count + 1)
    [ $count -gt $MERGE_COUNT ] && break
    [ $count -gt $DISPLAY_COUNT ] && continue

    echo "*****"
    RELEASE_VERSION=$($GETVERSION admin $reldir 2>/dev/null | awk 'BEGIN{FS=OFS="."}{NF--; print}')
    echo "Release: $release ($RELEASE_VERSION)"

    FOUNDATION=$($GETVERSION foundation $release)
	  FOUNDATION_DATE=$(TIMESTAMP=1 $GETVERSION foundation $FOUNDATION | grep -i "timestamp=" | awk -F= '{ print $2 }')
    echo "Foundation: $FOUNDATION ($FOUNDATION_DATE)"

    # get the baselogic version associated with the release
    BASELOGIC=$($GETVERSION baselogic $release)
	  BASELOGIC_DATE=$(TIMESTAMP=1 $GETVERSION baselogic $BASELOGIC| grep -i "timestamp=" | awk -F= '{ print $2 }')
    echo "Baselogic: $BASELOGIC ($BASELOGIC_DATE)"

	HTML "<tr>"
	HTML "  <th style='text-align:center'>$release_display</th>"

	HTML "  <td style='vertical-align:center'>$FOUNDATION<br><font size='-2'>$FOUNDATION_DATE</font></br></td>"
	HTML "  <td style='vertical-align:center'>$BASELOGIC<br><font size='-2'>$BASELOGIC_DATE</font></br></td>"
#	HTML "  <td style='vertical-align:center'>$COMPONENTS<br><font size='-2'>$COMPONENTS_DATE</font></br></td>"

  for artifact in admin $(getbrandlist -a)
	do
		version=$($GETVERSION $artifact $reldir)
		link=$(SHOWLINK=1 $GETVERSION $artifact $reldir | grep -i "artifact=" | awk -F= '{ print $2 }')
		date=$(TIMESTAMP=1 $GETVERSION $artifact $reldir | grep -i "timestamp=" | awk -F= '{ print $2 }')
		HTML "  <td>"
		if [ -n "$link" ]
		then
            link=$(echo "$link" | sed -es/"artifactory.wsgc.com"/"$LOGIN@artifactory.wsgc.com"/g)
			HTML "  <a href=\"$link\">$version</a>"
		else
			HTML "  $version"
		fi
		HTML "    <br><font size='-2'>$date</font></br>"
		HTML "  </td>"
	done
	HTML "</tr>"
	HTML
    ## if we've displayed enough releases, break out of loop
    #count=$(expr $count + 1)
    #[ $count -eq $DISPLAY_COUNT ] && break
done
HTML "</table>"

HTML "<h3>Production Frontend WAR Versions</h3>"
#HTML "These are the war versions configured in the production frontend POMs"

# new table for configured market war versions
HTML "<!-- new table -->"
HTML "<table border='1'>"
HTML "<tr>"
HTML "<th style='text-align:center'>&nbsp;</th>"
for brand in $(getbrandlist -p | tr "[:lower:]" "[:upper:]")
do
  HTML "<th style='text-align:center'>$brand</th>"
done
HTML "</tr>"

cat $MARKET_LIST |
while read line
do
  market=$(echo $line | awk -F: '{ print $1 }')
  label=$(echo $line | awk -F: '{ print $2 }')
  [[ $market = "usa" ]] && token= || token="${market}."
  [[ $market = "usa" ]] && tag="prd" || tag="${market}prd"
  echo "* Fetch $label war versions"

  HTML "<tr>"
  #HTML "<th style='text-align:center'>$label<br><font color='$COLOR_CFG'>Configured</br></font><br><font color='$COLOR_DEP'>Deployed</font></br></th>"
  HTML "<th style='text-align:center'>"
  HTML "  $label"
  HTML "  <br><font color='$COLOR_DEP' size='-2'><i>Deployed</i></font></br>"
  HTML "  <font color='$COLOR_CFG' size='-2'><i>Configured</i></font>"
  HTML "</th>"
  for brand in $(getbrandlist -p)
  do
    summary=
    dep_version=
	  cfg_version=$(svn cat $FRONTEND/$brand/pom.xml | grep -i "<frontend.${token}war.version>" | awk -F '[<>]' '{ print $3 }')

    #grep -ihr "frontend" /tmp/rundeck | egrep -vi "preprd|ecm" | grep -i "$tag" | grep -i ",$brand," | awk -F\" '{ print $2 }' | awk -F\. '{ print $1 }' | sort -r
    for host in $(grep -ihr "frontend" /tmp/rundeck | egrep -vi "preprd|ecm" | grep -i "$tag" | grep -i ",$brand," | awk -F\" '{ print $2 }' | awk -F\. '{ print $1 }' | sort -r) 
    do
      summary="https://${host}.wsgc.com/admin/summary.html"
      dep_version=$(curl -qsk --user $DP_LOGIN $summary | grep "id='WAR'" |awk -F '[<>]' '{ print $9 }' | awk -F- '{ print $1 }')
      [[ -n $dep_version ]] && { echo "$brand $dep_version https://$host/admin/summary.html"; break; }
    done 
    [[ -z $dep_version ]] && echo ">>> unable to get deployed version for $brand $market <<<"

    #HTML "<td style='text-align:right'>$cfg_version<br>$dep_version</br></td>"
    #HTML "<td style='text-align:right'>$dep_version</td>"

    HTML "<td style='text-align:left'>"
    HTML "  <font color='$COLOR_DEP'>$dep_version</font>"
    HTML "  <br><font color='$COLOR_CFG'>$cfg_version</font></br>"
    HTML "</td>"
  done
  HTML "</tr>"
done

HTML "</table>"


echo "* Fetch parent artifact versions"
HTML "<p></p>"
HTML "<table border='1'>"
HTML "<tr><th colspan='3' style='text-align:center'>Config Versions</th></tr>"
HTML "<tr>"
HTML "<th style='text-align:center'>Artifact</th>"
HTML "<th style='text-align:center'>Version</th>"
HTML "<th style='text-align:center'>Date</th>"
HTML "</tr>"

for artifact in \
    wsgc-devops-frontend-prd-config-app \
    wsgc-devops-frontend-common \
    wsgc-devops-frontend-role \
    wsgc-devops-frontend-service-tomcat8 \
    wsgc-devops-toolchain-node-prd \
    wsgc-devops-application \
    wsgc-apmagents 
do
  echo "--- $artifact"  
	version=$($GETVERSION $artifact)
	link=$(SHOWLINK=1 $GETVERSION $artifact | grep -i "Artifact=" | awk -F= '{ print $2 }')
	date=$(TIMESTAMP=1 $GETVERSION $artifact | grep -i "timestamp=" | awk -F= '{ print $2 }')
	HTML "<tr>"
	HTML "	<th>$artifact</th>"
	if [ -n "$link" ]
	then
        link=$(echo "$link" | sed -es/"artifactory.wsgc.com"/"$LOGIN@artifactory.wsgc.com"/g)
		HTML "	<td style='text-align:right'><a href=\"$link\">$version</a></td>"
	else
		HTML "	<td style='text-align:right'>$version</td>"
	fi
	HTML "	<td style='text-align:right'>$date</td>"
	HTML "</tr>"
	done

  # capture AppDynamics version
  REPO=git@github.wsgc.com:eCommerce-DevOps/wsgc-apmagents.git
  TMP=$(mktemp -d -t tmp.$(basename $0).XXX)
  git clone -q --depth 1 $REPO $TMP
  APPAGENT_VERSION=$(grep "<apmagents.dist.version>" $TMP/pom.xml | awk -F '[<>]' '{ print $3 }')
  MCHAGENT_VERSION=$(grep "<apmagents.machineagent.version>" $TMP/pom.xml | awk -F '[<>]' '{ print $3 }')
  MCHAGENT_VERSION=$(sed -es/'${apmagents.dist.version}'/$APPAGENT_VERSION/g <<< $MCHAGENT_VERSION)
  #APMAGENT_DATE=$(svn info $REPO | grep -i date | awk -F 'Last Changed Date:' '{ print $2 }' | awk '{ print $1, $2 }')
  HTML "<tr><th>AppDyanmics App Agent</th><td style='text-align:right'>$APPAGENT_VERSION</td><th></th></tr>"
  HTML "<tr><th>AppDyanmics Machine Agent</th><td style='text-align:right'>$MCHAGENT_VERSION</td><th></th></tr>"
  rm -rf $TMP
HTML "</table>"

HTML "<p>Created by <a href='$JENKINS_JOB'>$(basename $JENKINS_JOB)</a></p>"
HTML "The list of releases is maintained at <a href='https://github.wsgc.com/eCommerce-DevOps/release-tools/blob/release/release-list.txt'>eCommerce-DevOps/release-tools</a>"

chmod 777 $OUTFILE

# update confluence page
sh $cclidir/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose 
[ $? -eq 0 ] && rm $OUTFILE

#
echo "Current releases: $CURRENT_RELEASES"
rm -rf /tmp/release-tools-configs
git clone -q git@github.wsgc.com:eCommerce-DevOps/release-tools-configs.git /tmp/release-tools-configs
cd /tmp/release-tools-configs
echo "sources=$CURRENT_RELEASES" > manage-automerge-releases.list
git commit manage-automerge-releases.list -m "Update release list"
git push
rm -rf /tmp/release-tools-configs /tmp/rundeck

exit 0
