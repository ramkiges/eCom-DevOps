package com.wsgc.devops.mvnrelease

/**
 * Describe class propose
 *
 * @author bvale
 *
 */
class Constants {

    static final MVNRELEASE_SSH_VOLUME = "mvnrelease-git:/home/mvnrelease/.ssh"
    static final MVNRELEASE_SVN_VOLUME = "mvnrelease-subversion:/home/mvnrelease/.subversion"
    static final MVNRELEASE_CONFIG_VOLUME = "mvnrelease-config:/usr/src/mvnrelease/config"
    static final MVNRELEASE_MAVEN_VOLUME = "/apps/maven/localrepo:/home/mvnrelease/.mvnrelease/localrepo"
    static final MVNRELEASE_CONFIG_PATH = "/usr/src/mvnrelease/config"
    static final REGISTRY = "snapshotrepo.wsgc.com"
    static final DEFAULT_IMAGE = REGISTRY + '/ecommerce-docker-repo/mvnrelease'
    static final VALID_CHARACTERS = /^[\-\s\[\]a-zA-Z0-9_,\.?!]+$/

}
