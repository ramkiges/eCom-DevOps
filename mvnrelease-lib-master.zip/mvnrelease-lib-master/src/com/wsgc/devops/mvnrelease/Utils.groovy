package com.wsgc.devops.mvnrelease

/**
 * mvnrelease utilities
 *
 * @author bvale
 *
 */
class Utils {

    /**
     * Check if a git or svn repository belongs to DevOps group
     * @param repository A git or svn url
     * @return true if repository belongs to DevOps group
     */
    static boolean isDevOpsRepo(repository) {
        return repository =~ /https:\/\/repos.wsgc.com\/svn\/devops\/|eCommerce-DevOps/
    }

    /**
     * Includes ticket number inside commit message of scm tag
     * @param ticket A JIRA ticket number, E.g: MEAD-321
     * @param commitMessage
     * @return A message with ticket number appended
     */
    static String includeTicket(String ticket, String commitMessage) {
        if (ticket) {
            if (ticket =~ /\[.*]/ ) return "$ticket $commitMessage"
            return "[$ticket] $commitMessage"
        }
        return commitMessage
    }

    /**
     * Check if a given commit message is valid
     * A Valid commit message should match VALID_CHARACTERS regex
     * @param message
     * @return true if message does not contain invalid characters
     */
    static boolean validMessage(String message) {
        return message =~ Constants.VALID_CHARACTERS
    }
}
