MVNRelease Shared Library
========

`mvnrelease-lib` is a Jenkins shared library to perform maven releases using [mvnrelease](https://github.wsgc.com/eCommerce-Bedrock/mvnrelease).


`mvnrelease-lib` provides a Jenkins pipeline global function `mvnrelease` with has almost the same parameters as `mvnrelease`.

It spins a docker container that contains all building blocks that `mvnrelease` needs.

Here's an example:

```groovy
library 'mvnrelease'

pipeline {
    agent {
        label 'docker'
    }
    stages {
        stage('Release the Kraken') {
            steps {
                script {
                    mvnrelease (
                        repository: 'http://repos.wsgc.com/svn/devops/myapp',
                        reason: 'New version of my app',
                        ticket: 'MEAD-5542',
                        depVersion: 'myapp.war.version=1.0'
                    )
                }
            }
        }
    }
}
```

Note that this library works only on nodes where we  have `docker` installed
