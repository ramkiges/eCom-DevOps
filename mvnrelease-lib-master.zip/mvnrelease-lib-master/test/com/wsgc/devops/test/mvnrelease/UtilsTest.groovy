package com.wsgc.devops.test.mvnrelease

import static com.wsgc.devops.mvnrelease.Utils.*

/**
 * Describe class purpose
 *
 * @author bvale
 *
 */
class UtilsTest extends GroovyTestCase {

    void testIsDevOpsRepo() {

        [
                [repo: "https://repos.wsgc.com/svn/devops/application/invent/prdrk/trunk", expected: true],
                [repo: "git@github.wsgc.com:eCommerce-DevOps/registry-ab-migrator.git", expected: true],
                [repo: "git@github.wsgc.com:bvale/registry-ab-migrator.git", expected: false],
                [repo: "https://repos.wsgc.com/svn/core/ecommerce/sites/ws/war/trunk", expected: false],
                [repo: "https://github.wsgc.com/eCommerce-DevOps/mvnrelease.git", expected: true],
        ].each { test->
            assertEquals(test.expected, isDevOpsRepo(test.repo))
        }
    }

    void testIncludeTicket() {
        [
                [ticket: 'MEADINF-340', commitMessage: "Very nice release", expected: "[MEADINF-340] Very nice release" ],
                [ticket: '[MEADINF-340]', commitMessage: "Very nice release", expected: "[MEADINF-340] Very nice release" ],
                [ticket: '', commitMessage: "Very nice release", expected: "Very nice release"]
        ].each { test->
            assertEquals(test.expected, includeTicket(test.ticket, test.commitMessage))
        }
    }

    void testInvalid() {
        [
                [message: '[MEADINF-340] Cool commit', expected: true],
                [message: '[MEADINF-340] Cool. hey, nice', expected: true],
                [message: '[MEADINF-340] Cool. hey, nice?!', expected: true],
                [message: '; rm -rf *', expected: false],
                [message: 'hey $s', expected: false]
        ].each { test->
            println("CASE: ${test.message}")
            assertEquals(test.expected, validMessage(test.message))
        }
    }
}
