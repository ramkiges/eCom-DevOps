import static com.wsgc.devops.mvnrelease.Utils.*
import static com.wsgc.devops.mvnrelease.Constants.*

def call(config) {

    if (!config?.repository) {
        error "Repository is a mandatory parameter"
    }

    def repository = config.repository
    def message = (config.reason) ? config.reason : 'Automatic Jenkins Release'
    def depVersion = ""

    if (!validMessage(message)) {
        error "Message contains illegal characters. Message should match the following regex: $VALID_CHARACTERS"
    }

    if(config.depVersion) {
        depVersion = config.depVersion.split(',').collect{ "--depversion=${it.trim()}" }.join(" ")
    }

    message = includeTicket(config?.ticket, message)

    def mvnreleaseConfig = (isDevOpsRepo(repository)) ? 'mvnrelease-devops.properties' : 'mvnrelease.properties'

    def bindVolumes = "-v $MVNRELEASE_CONFIG_VOLUME -v $MVNRELEASE_MAVEN_VOLUME -v $MVNRELEASE_SSH_VOLUME -v $MVNRELEASE_SVN_VOLUME"

    withDockerRegistry([credentialsId: 'docker-dev-artifactory', url: "https://$REGISTRY"]) {
        docker.image(DEFAULT_IMAGE).inside(bindVolumes) {
            sh "mvnrelease --non-interactive --config=$MVNRELEASE_CONFIG_PATH/$mvnreleaseConfig " +
                "publish $repository final --reason=\"$message\" $depVersion"
        }
    }

    if (config?.refreshYUM) {
        withCredentials([string(credentialsId: 'SNAPSHOT_API_TOKEN', variable: 'snapshotApiToken')]) {
            echo "Running rerun artifactory:yum-createrepo command..."
            // set +x is required, otherwise jenkins will show the secret (api token) content
            def cmd = """set +x
                       /usr/bin/rerun artifactory:yum-createrepo \\
                       |--repo-url ${env.SNAPSHOT_URL} \\
                       |--admin-passwd ${env.snapshotApiToken} \\
                       |--repo-id ${env.SNAPSHOT_REPOID}
                       """.stripMargin()
            sh cmd
        }
    }
}

return this
