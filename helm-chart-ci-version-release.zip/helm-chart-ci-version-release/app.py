#!/usr/bin/env python3

"""
A script which applies CI Customized Versions to Helm Charts using SEMVER formatted versioning for dev versions.
"""

import argparse
import yaml


def load_yaml_file(path):
    """
    Load yaml file, loads the contents of the yaml file and returns them as a dictionary.
    :param path: The path to the Yaml file to load
    :return: The dict for the yaml file
    """
    with open(path, 'r') as file_data:
        return yaml.safe_load(file_data)


def write_to_yaml_file(path, file_contents):
    """
    Write to yaml file, writes a dictionary out to a yaml file at the specified path.
    :param path: The path to the Yaml file to write
    :param file_contents: The contents to write to the Yaml file
    :return: void
    """
    with open(path, 'w') as file_handle:
        yaml.dump(file_contents, file_handle)


def ci_version(ghe_org, ghe_branch, version):
    """
    This performs the customized version logic, following SEMVER syntax for dev versioning.
    :param ghe_org: The github enterprise organization
    :param ghe_branch: The github enterprise branch name
    :param version: The current version from the chart
    :return:
    """
    return "{}-{}{}".format(version, clean_ghe_values(ghe_org), clean_ghe_values(ghe_branch))


def clean_ghe_values(value):
    """
    Clean GHE Values cleans up the org and branch to replace any characters which aren't invalid.
    :param value: The thing to clean
    :return: The cleansed version of the input
    """
    return value.replace('-', '').replace('/', '').replace('_', '').lower()


def main():
    # Define and fetch the parameters
    parser = argparse.ArgumentParser()
    parser.add_argument("chart_file", type=str, help='The path to the chart YAML file')
    parser.add_argument("ghe_org", type=str, help='The Git Hub Enterprise Organization the CI build is running against')
    parser.add_argument("ghe_branch", type=str, help='The branch name the CI build is running against')
    args = parser.parse_args()

    # load the chart file
    chart = load_yaml_file(args.chart_file)
    # customize the version
    chart['version'] = ci_version(args.ghe_org, args.ghe_branch, chart['version'])
    # write it back to the original yaml file
    write_to_yaml_file(args.chart_file, chart)
    print(chart['version'])


if __name__ == '__main__':
    main()
