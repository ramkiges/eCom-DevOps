# helm-chart-ci-version
A simple python script to perform customize version against a Helm chart

To build a development environment the scripts should be run in the following order.

1) Setup your local env

        python3 -m venv venv
        source venv/bin/activate
        pip install --upgrade pip
        pip install --upgrade setuptools
        pip install -r requirements.txt -r dev-requirements.txt
        
1) Build the local container


    docker build . -t helm-chart-ci-version

1) Run the local container passing in the GHE Org and Branch


    docker run -v /chartlocation:/chart helm-chart-ci-version /src/app.py /chart/Chart.yaml ecommerceTahoe TAH-1234

1) Running tests


    python -m pytest
