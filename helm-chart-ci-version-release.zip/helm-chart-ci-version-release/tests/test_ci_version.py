import pytest
from tempfile import mkstemp
from app import load_yaml_file, ci_version, write_to_yaml_file


def test_load_chart_yaml():
    """test_load_chart_yaml tests to ensure that we can load yaml files."""
    chart = load_yaml_file("tests/Chart.yaml")
    assert (chart['version'] == "0.1.0")


def test_ci_version():
    """test_ci_version performs various validations against the customized ci version implementation."""
    custom_version = ci_version("Org", "Branch", "0.2.0")
    assert (custom_version == "0.2.0-orgbranch")
    custom_version = ci_version("org-with-dashes", "branch", "0.2.0")
    assert (custom_version == "0.2.0-orgwithdashesbranch")
    custom_version = ci_version("org", "branch-with-dashes", "0.2.0")
    assert (custom_version == "0.2.0-orgbranchwithdashes")
    custom_version = ci_version("org", "feature/branch", "0.2.0")
    assert (custom_version == "0.2.0-orgfeaturebranch")
    custom_version = ci_version("org", "feature_branch", "0.2.0")
    assert (custom_version == "0.2.0-orgfeaturebranch")


def test_write_to_yaml_file():
    """test_write_to_yaml_file tests that the write to yaml file functionality works as needed."""
    chart = load_yaml_file("tests/Chart.yaml")
    chart['version'] = "new"
    _, new_file = mkstemp()
    write_to_yaml_file(new_file, chart)
    new_chart = load_yaml_file(new_file)
    assert (new_chart['version'] == "new")
