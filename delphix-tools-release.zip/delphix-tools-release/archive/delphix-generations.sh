#!/bin/sh
# Thom Fitzpatrick
# this script selects generation values from one env and inserts them into another
# it is still in the experimental phase
PATH=/apps:/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:~/bin:/apps/jdk8/bin:/apps/java/bin:/apps/jdk7/bin:/opt/oracle/product/11.2.0/client_1/bin:/apps/scm-tools
export PATH
. /apps/buildsystem/bin/env.sh
FRONTEND="https://repos.wsgc.com/svn/devops/application/frontend-2.1"
JENKINS_URL="https://ecombuild.wsgc.com/jenkins"
DEPLOYMENTS="https://repos.wsgc.com/svn/deployments/content/trunk/deploy/properties/"
JENKINS=$(which jenkins-jnlp 2>/dev/null)
#SRC_TABLE="WW_ARTIFACT_ARCHIVE_LOCATOR"
SRC_TABLE="WW_GENERATION_SCHEDULE"

BRAND=$1
shift
ENV=$1
shift
DEFAULT_LIST=$(echo "$*" | tr "a-z" "A-Z")

# Jira icons
ICON_FAIL=" (x) "
ICON_SUCC=" (/) "
ICON_WARN=" (!) "
ICON_INFO=" (i) "

umask 000
[ -z "$DEFAULT_LIST" ] && DEFAULT_LIST="ECMCS ECMHOMEPAGE ECMMSG ECMPAGES ECMPROMOS ENDECA HOMEPAGE PROMOS REGLANDING RECIPE ODIS_SERVICE FEED_ID DOMAIN_KEY IDEAS CAT TMPL MISC MSG"
#[ -z "$DEFAULT_LIST" ] && DEFAULT_LIST="ECMPROMOS"

BailOut() {
	[ -n "$1" ] && echo "$*"
	echo "Usage: $(basename $0) <brand> <src_env> [subsys]"
	exit 1
}

[ -z "$BRAND" ] && BailOut "Need brand"
[ -z "$ENV" ] && BailOut "Need env "
#[ "$ENV" = "int" ] && BailOut "I'm sorry $(logname), I can't let you do that"
#[ "$ENV" = "int1" ] && BailOut "I'm sorry $(logname), I can't let you do that"
#[ "$ENV" = "int2" ] && BailOut "I'm sorry $(logname), I can't let you do that"

DB_ENV=$ENV

# source env translations
[ "$ENV" = "int" ] && DB_ENV="integration"
[ "$ENV" = "int2" ] && DB_ENV="integration2"
[ "$ENV" = "rgs1" ] && DB_ENV="regression"

[ "$DB_ENV" = "ecmint" ] && DB_ENV="ecmprvint"
#[ "$DB_ENV" = "ecmqa1" ] && DB_ENV="ecmprev"
[ "$DB_ENV" = "ecmprd1" ] && DB_ENV="ecmprvprd"

for script in getschema getdb geturls sqlplus
do
    which $script >/dev/null 2>&1 || BailOut "Can't find $script"
done

SITE=$(brand2site $BRAND)
[ -z "$SITE" ] && BailOut "Invalid brand"

JMX_PORT=39667
for dir in /wsgc/bin /apps ~/bin
do
	[ -f $dir/jmxclient.jar ] && { JMX_JAR=$dir/jmxclient.jar; break; }
done

SCHEMA=$(getschema $BRAND $ENV)
[ -z "$SCHEMA" ] && BailOut "Can't find schema for source ($BRAND $ENV)"
DB=$(getdb $SCHEMA)
[ -z "$DB" ] && BailOut "Can't get creds for $SCHEMA $BRAND $ENV"
dbHost=$(echo "$DB" | awk -F\| '{ print $1 }')
dbOwner=$(echo "$DB" | awk -F\| '{ print $2 }' | tr "a-z" "A-Z")
dbUser=$(echo "$DB" | awk -F\| '{ print $3 }')
dbPass=$(echo "$DB" | awk -F\| '{ print $4 }')
dbSID=$(echo "$DB" | awk -F\| '{ print $5 }' | tr "a-z" "A-Z")
dbPort=$(echo "$DB" | awk -F\| '{ print $6 }')

echo "Update generations for $BRAND $ENV"
echo "DB: $dbHost  $dbSID    $dbOwner  $dbUser"
#echo "Options:"
#echo "Deploy CONTENT:           $DEPLOY_CONTENT"
#echo "Deploy WAR:               $DEPLOY_WAR"
#echo "Update Admin (600):       $ADMIN"
#echo "Update ARCHIVE_LOCATOR:   $UPDATE_ARCHIVE_LOCATOR"

# get list of relevant subsystems
Q="set heading off; 
SELECT DISTINCT SUBSYSTEM FROM WW_GENERATION_SCHEDULE WHERE (SITE = '$SITE' and installation = 'qa') ORDER BY SUBSYSTEM;"
#echo "$Q"

#SUBSYS_LIST=$(echo "$Q" | sqlplus -S "${dbUser}/${dbPass}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${dbHost})(PORT=${dbPort}))(CONNECT_DATA=(SID=${dbSID})))" | egrep -vi "selected" ) 
SUBSYS_LIST=$DEFAULT_LIST
#echo "Existing SubSystems (from DB): $SUBSYS_LIST"

# for updating existing envs - this seems to work well
for SUBSYS in $SUBSYS_LIST
do
	echo "$SUBSYS" | egrep -iq "^[a-z]" || continue
	#echo "$SUBSYS" | egrep -iq "MSG|MISC|TMPL" && continue

    if [ "$SRC_TABLE" = "WW_GENERATION_SCHEDULE" ]
    then
	    OLDGEN_SQL="set heading off; 
select GENERATION from 
(SELECT GENERATION FROM $SRC_TABLE WHERE (SITE = '$SITE' and installation = 'qa' and subsystem = '$SUBSYS') order by START_TIME desc)
where rownum = 1;"
    fi

    if [ "$SRC_TABLE" = "WW_ARTIFACT_ARCHIVE_LOCATOR" ]
    then
	    OLDGEN_SQL="set heading off; 
select GENERATION from 
(SELECT GENERATION FROM $SRC_TABLE WHERE (SITE = '$SITE' and subsystem = '$SUBSYS') order by TSTAMP desc)
where rownum = 1;"
    fi

    # grab current generation from destination
	OLDGEN=$(echo "$OLDGEN_SQL" | sqlplus -S "${dbUser}/${dbPass}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${dbHost})(PORT=${dbPort}))(CONNECT_DATA=(SID=${dbSID})))" | egrep -iv "selected|error" | tr '\n' ' ' | awk '{ print $1 }' )
    echo ">$SUBSYS   $OLDGEN"
    [ -z "$OLDGEN" ] && { echo "Old '$SUBSYS' generation in $SRC_TABLE is blank - skipping"; continue; }

	I="set heading off;
set pagesize 0;
INSERT INTO $dbOwner.WW_GENERATION_SCHEDULE (GENERATION, SITE, INSTALLATION, SUBSYSTEM, START_TIME, REFRESH) 
VALUES ($OLDGEN, $SITE, '$ENV', '$SUBSYS', SYSDATE, 0);
commit;"

    echo "$I"
	echo "$I" | sqlplus -S "${dbUser}/${dbPass}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${dbHost})(PORT=${dbPort}))(CONNECT_DATA=(SID=${dbSID})))" 
    echo
done

exit 0

