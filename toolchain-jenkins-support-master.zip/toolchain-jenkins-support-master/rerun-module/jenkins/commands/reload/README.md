Usage
-----

* Reloads the main Jenkins configuration file to the running instance in order to make it current:
<pre>
[anthony@centos62 ~]$ rerun jenkins:reload
reloading http://localhost:8080
</pre>
