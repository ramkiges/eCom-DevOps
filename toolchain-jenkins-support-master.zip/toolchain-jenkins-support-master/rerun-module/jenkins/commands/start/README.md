Usage
-----

* Uses sudo(8) privileges to start the Jenkins system service checking the log to confirm it is properly running:
<pre>
[anthony@centos62 ~]$ rerun jenkins:start
Starting Jenkins                                           [  OK  ]
</pre>
