Usage
-----

* Uses sudo(8) privileges to stop the Jenkins system service:
<pre>
[anthony@centos62 ~]$ rerun jenkins:stop
Shutting down Jenkins                                      [  OK  ]
</pre>
