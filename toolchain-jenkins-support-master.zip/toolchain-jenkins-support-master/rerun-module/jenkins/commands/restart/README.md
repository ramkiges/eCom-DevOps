Usage
-----

* Combines jenkins:stop and jenkins:start into a single command to reliably restart the Jenkins system service:
<pre>
[anthony@centos62 ~]$ rerun jenkins:restart
Shutting down Jenkins                                      [  OK  ]
Starting Jenkins                                           [  OK  ]
</pre>
