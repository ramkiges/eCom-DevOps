#!/usr/bin/env roundup
#
#/ usage:  rerun stubbs:test -m trunk -p install-frontend-builders-shrtct [--answers <>]
#

# Helpers
# -------
[[ -f ./functions.sh ]] && . ./functions.sh

# The Plan
# --------
describe "install-frontend-builders-shrtct"

# ------------------------------
# Replace this test. 
it_fails_without_a_real_test() {
    exit 1
}
# ------------------------------

