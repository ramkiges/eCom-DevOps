#!/usr/bin/env roundup
#
#/ usage:  rerun stubbs:test -m trunk -p uninstall-frontend-war [--answers <>]
#

# Helpers
# -------
[[ -f ./functions.sh ]] && . ./functions.sh

# The Plan
# --------
describe "uninstall-frontend-war"

# ------------------------------
# Replace this test. 
it_fails_without_a_real_test() {
    exit 1
}
# ------------------------------

