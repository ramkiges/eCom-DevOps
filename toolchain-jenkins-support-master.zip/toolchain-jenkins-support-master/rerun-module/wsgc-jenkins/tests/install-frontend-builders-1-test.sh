#!/usr/bin/env roundup
#
#/ usage:  rerun stubbs:test -m wsgc-jenkins -p install-frontend-builders [--answers <>]
#

# Helpers
# -------
[[ -f ./functions.sh ]] && . ./functions.sh

# The Plan
# --------
describe "install-frontend-builders"

# ------------------------------
# Replace this test. 
it_fails_without_a_real_test() {
    exit 1
}
# ------------------------------

