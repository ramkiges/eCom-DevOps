# Shell functions for the wsgc-jenkins module.
#/ usage: source RERUN_MODULE_DIR/lib/functions.sh command
#

# Read rerun's public functions
. $RERUN || {
    echo >&2 "ERROR: Failed sourcing rerun function library: \"$RERUN\""
    return 1
}

# Check usage. Argument should be command name.
[[ $# = 1 ]] || rerun_option_usage

# Source the option parser script.
#
if [[ -r $RERUN_MODULE_DIR/commands/$1/options.sh ]] 
then
    . $RERUN_MODULE_DIR/commands/$1/options.sh || {
        rerun_die "Failed loading options parser."
    }
fi

# - - -
# Your functions declared here.
# - - -
GIT_JENKINS_TEMPLATES_URL="git@github.wsgc.com:eCommerce-DevOps/jenkins-templates.git"
GIT_JENKINS_JOBS_URL="git@github.wsgc.com:eCommerce-DevOps/jenkins-jobs.git"
CI_USERNAME="svcaecjnk"
CI_PASSWORD="1122e94d6eb6cbd6609e08c97aa6aef2b1"
JENKINS_URL="https://ecombuild.wsgc.com/jenkins"

# Build builders for the following sites.
# This can be overridden on the command line with the `brand` options
SITES_WE_DEPLOY="mg pb pk pt we ws"

gitPushDir() {
    # Attempt to do a "git push" from $1; if it fails, presume that we
    # aren't up-to-date and try again.  Fail after a few rounds of this.
    local DIR="$1"

    local n=0
    while ! git -C "$DIR" push -q; do
        if ! git -C "$DIR" pull -q; then
            echo "Error in git pull in $DIR" >&2
            exit 1
        fi

        if [[ $((n++)) > 3 ]]; then
            echo "Too many tries pushing commit from $DIR" >&2
            exit 1
        fi
    done
}
