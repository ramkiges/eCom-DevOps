# _rerun_options_parse_ - Parse the command arguments and set option variables.
#
#     rerun_options_parse "$@"
#
# Arguments:
#
# * the command options and their arguments
#
# Notes:
#
# * Sets shell variables for any parsed options.
# * The "-?" help argument prints command usage and will exit 2.
# * Return 0 for successful option parse.
#
rerun_options_parse() {
    while [[ $# -gt 0 ]]; do
        OPT=$1
        case "$OPT" in
            --env) rerun_option_check $# "$OPT"; ENV=$2 ; shift ;;
            --content_shortcut_name) rerun_option_check $# "$OPT"; CONTENT_SHORTCUT_NAME=$2 ; shift ;;
            --affinity_team) rerun_option_check $# "$OPT"; AFFINITY_TEAM=$2 ; shift ;;
            --brand) rerun_option_check $# "$OPT"; BRAND=$2 ; shift ;;
            --auto_deploy) rerun_option_check $# "$OPT"; AUTO_DEPLOY=$2 ; shift ;;
            --market) rerun_option_check $# "$OPT"; MARKET=$2 ; shift ;;
            # help option
            -?)
                rerun_option_usage
                exit 2
                ;;
            # end of options, just arguments left
            *)
              break
        esac
        shift
    done

    # Check that required options are set.
    for varname in ENV CONTENT_SHORTCUT_NAME AFFINITY_TEAM
    do
        if [[ -z ${!varname} ]]; then
            optionName=$(echo "$varname" | tr A-Z a-z)
            echo "Missing required option: --$optionName" >&2
            return 2
        fi
    done

    # passing in the optional 'brand' parameter overrides the default list of brands
    if [[ -n "${BRAND}" ]]; then
        echo "SITES_WE_DEPLOY overridden with $BRAND"
        SITES_WE_DEPLOY="${BRAND}"
    fi

    return 0
}

# Initialize the options variables to defaults.
ENV=
CONTENT_SHORTCUT_NAME=
AFFINITY_TEAM=
BRAND=
AUTO_DEPLOY="0"
MARKET=
