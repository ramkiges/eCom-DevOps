#/ usage: trunk:update-frontend-builders-shrtct  --shortcut_name <>  --capability_team <>  --team_name <>

# _rerun_options_parse_ - Parse the command arguments and set option variables.
#
#     rerun_options_parse "$@"
#
# Arguments:
#
# * the command options and their arguments
#
# Notes:
#
# * Sets shell variables for any parsed options.
# * The "-?" help argument prints command usage and will exit 2.
# * Return 0 for successful option parse.
#
rerun_options_parse() {

    while [ "$#" -gt 0 ]; do
        OPT="$1"
        case "$OPT" in
            --shortcut_name) rerun_option_check $# $1; SHORTCUT_NAME=$2 ; shift ;;
            --capability_team) rerun_option_check $# $1; CAPABILITY_TEAM=$2 ; shift ;;
            --team_name) rerun_option_check $# $1; TEAM_NAME=$2 ; shift ;;
            --keep_jobs) rerun_option_check $# $1; KEEP_JOBS="$2" ; shift ;;

            -\?)
                rerun_option_usage
                exit 2
                ;;

            *)
                # We have no arguments, just options.
                rerun_option_usage
                exit 1
                ;;
        esac
        shift
    done

    # Check required options are set
    [ -z "$SHORTCUT_NAME" ] && { echo >&2 "missing required option: --shortcut_name" ; return 2 ; }
    [ -z "$CAPABILITY_TEAM" ] && { echo >&2 "missing required option: --capability_team" ; return 2 ; }
    [ -z "$TEAM_NAME" ] && { echo >&2 "missing required option: --team_name" ; return 2 ; }

    return 0
}


# Initialize the options variables to null.
SHORTCUT_NAME=
CAPABILITY_TEAM=
TEAM_NAME=
KEEP_JOBS=""
