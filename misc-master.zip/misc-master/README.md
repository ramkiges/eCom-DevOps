# misc

A grab-bag of useful but homeless DevOps stuff.

NOTE: This repository is the worst place for a script to live.  If you
have any other option outside a personal repo, put it there instead.
That this repository exists at all reflects a failure of imagination.
If your script is used in an automated way, please create a proper
repository for that process and put it there.

- `createCSR.sh`: Generates a CSR appropriate for signing by the WSI
  root authority.  This takes care of some of the tricky bits required
  to make Chrome happy:

    - Uses subjectAltName

    - Asks to be signed by SHA-256 (which may end up being SHA-512,
      but is notably _not_ SHA-1)

  This generates a key and a CSR that goes with it.

- `settings.xml.devops`: A file you can drop in `~/.m2/settings.xml`,
  add the correct password where indicated, and build devops Maven
  projects in your local environment.  See the comment at the top of
  the file for details on what else you need to do to build
  successfully.  Get the password from a friendly DevOps engineer, and
  don't share it outside the group.

- `makeCustomFixBranch`: Create a branch that's like a
  `<brand>_support` branch, but with a custom name, and without wiping
  out any existing support branches. See MEAD-2511 for details.

- `oracle-dot-profiles`: Contains source files that live on the prod oracle database 
  server at path `/home/rundeck/.profile` which is used by the 
  rundeck DB export job to set the variables needed for export to work.
