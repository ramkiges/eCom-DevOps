package com.wsgc.ecommerce.buildsystem.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.CommandResultInfo;

/**
 * Utilities for launching processes that launch separate threads to populate a {@link CommandResultInfo} for understanding the results later.
 * 
 * @author chunt
 * @version $Id$ 
 */
public final class ProcessUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessUtil.class);
    private static final String LIB = "lib";
    private static final int EXIT_CODE_SUCCESS = 0;

    /**
     * Utility class, hidden default ctor.
     * 
     * @throws IllegalAccessException
     *             if used
     */
    private ProcessUtil() throws IllegalAccessException {
        throw new IllegalAccessException("Utility class not meant for instantiation.");
    }

     /**
      * Traditional entry point for the rest of the build system.  Called by runBuildRequest, runPostBuildCommand methods,
     * the process launcher is friendly to the
      * build command scripts in that they expect to always be launched with knowledge as to where their "lib" directory is, so string 
      * is constructed from the buildSystemHomeExeDir param and added to the environment of the process
      * 
     * @param commandResultInfo pre-made {@link CommandResultInfo} to populate with interesting details about how the process went
     * @param command the command line of the process to launch
     * @param workingDir the working directory of the process after it starts.
     * @param buildSystemHomeExeDir configuration setting pointing to the build scripts home directory
     * @param env an optional map of environmental variables to start the process with
     * @return the original {@link CommandResultInfo} altered by the addition of process output or error state
     */
    public static CommandResultInfo runBuildCommand(CommandResultInfo commandResultInfo, List<String> command, File workingDir, String buildSystemHomeExeDir, 
            Map<String, String> env)  {

        List<String> modifiableCommand = new ArrayList<String>(command);

        /*  ProcessBuilder has an environment true but can't find the executable on the path 
         *  until after the process starts... We actually seem to need the absolute path to the command 
         *  to start the process that creates the environment that holds the path.  
         */
        String commandAbsolutePath = buildSystemHomeExeDir + File.separatorChar + modifiableCommand.remove(0);
        modifiableCommand.add(0, commandAbsolutePath);

        String buildSystemLibDir = buildSystemHomeExeDir + File.separatorChar + LIB;      
        env.put("LIB", buildSystemLibDir);
        return runCommand(commandResultInfo, modifiableCommand, workingDir, env);

    }

    /**
     * Convenience method to run a command with null environment.
     * 
     * @param commandResultInfo the object to be returned after the process runs. 
     * @param command the command line of the process to start
     * @param workingDir the designated working directory of the new process being started
     * @return the original {@link CommandResultInfo} altered by the addition of process output or error state
     */
    public static CommandResultInfo runCommand(CommandResultInfo commandResultInfo, List<String> command, File workingDir)  {
        return runCommand(commandResultInfo, command, workingDir, null);        
    }   
    
    /**
     * Creates a process using the list of commands as arguments. Starts a separate thread to read standard out and err
     * of the new process into the {@link CommandResultInfo} passed in case anyone cares about what happened during the life of
     * this process. This method does everything it can to return with out throwing an exception and puts any errors or stack traces 
     * in the {@link CommandResultInfo} that both accepts and returns.
     * 
     * @param commandResultInfo the object to be returned after the process runs. 
     * @param command the command line of the process to start
     * @param workingDir the designated working directory of the new process being started
     * @param env an optional map of environmental variables to start the process with
     * @return the original {@link CommandResultInfo} altered by the addition of process output or error state
     */
    public static CommandResultInfo runCommand(CommandResultInfo commandResultInfo, List<String> command, File workingDir, Map<String, String> env)  {

        commandResultInfo.setStartTime(System.currentTimeMillis());
        commandResultInfo.addCommands(command);
        commandResultInfo.setDirectory(workingDir);

        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.redirectErrorStream(true);
        processBuilder.directory(workingDir);

        if (env != null) {
            for (String key : env.keySet()) {
                LOGGER.debug("Adding build command environmental variable {}={}", key, env.get(key));
                processBuilder.environment().put(key, env.get(key));
            }
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("\nLaunching command process:" + command + "\n" + "In directory:" 
                    + ((processBuilder.directory() != null) 
                            ? processBuilder.directory().getAbsolutePath() 
                                    : " null ")
                                    + "\n" + "With environment:"
                                    + processBuilder.environment());
        }
        Process process = null;
        try {
            /*
             *  The question now is will the input stream fill before we can start the reader thread?
             *  We put the debugging statement outside of the calls to further reduce that already small chance.
             * 
            /////////////////////////////////////////////////////////////////////////////////////////////
             */ process = processBuilder.start();
             // Actually the process input stream. We don't use it.
             /* */ process.getOutputStream().close();
             /* */ CommandResultBuilder commandResultBuilder = new CommandResultBuilder(commandResultInfo, process.getInputStream());
             /* */ Thread commandResultBuilderThread = new Thread(commandResultBuilder);
             /* */ commandResultBuilderThread.start();
             /////////////////////////////////////////////////////////////////////////////////////////////
             LOGGER.debug("Started command process {}", process);

             int exitCode = process.waitFor();
             // wait for the output draining thread to finish too.
             commandResultBuilderThread.join();

             commandResultInfo.setExitCode(exitCode);
             commandResultInfo.setSuccessStatus((exitCode == EXIT_CODE_SUCCESS));
             commandResultInfo.setEndTime(System.currentTimeMillis());

        } catch (IOException e) {
            commandResultInfo.setLastException("Failed to launch:" + command  + " Reason:" + e, e);
            commandResultInfo.setSuccessStatus(false);
            commandResultInfo.setExitCode(-1);
            return commandResultInfo;

            /*
             * NOTE it is dubious to try and stop threads, worse for threads threads that start processes.
             */
        } catch (InterruptedException e) {
            commandResultInfo.setLastException("Process interrupted:" + command + " Reason:" + e, e);
            commandResultInfo.setSuccessStatus(false);
            commandResultInfo.setExitCode(-1);
            Thread.currentThread().interrupt();
            return commandResultInfo;
        } finally {
            commandResultInfo.lockResults();
        }
        LOGGER.debug("Ending command process:{} commandResultInfo:{}", process, commandResultInfo);
        return commandResultInfo;
    }

    /**
     * Run command null working directory and null environment, useful for processes like some {@link SvnUtil} methods
     * that don't need a working dir or an environment.
     * 
     * @param commandResultInfo
     *            the object to be returned after the process runs.
     * @param command
     *            the command line of the process to start
     * @return the original {@link CommandResultInfo} altered by the addition of process output or error state
     */
    public static CommandResultInfo runCommand(CommandResultInfo commandResultInfo, List<String> command) {
        return runCommand(commandResultInfo, command, null);
    }

}
