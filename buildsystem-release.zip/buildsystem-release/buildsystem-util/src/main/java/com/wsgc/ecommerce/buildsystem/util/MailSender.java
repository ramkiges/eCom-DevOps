package com.wsgc.ecommerce.buildsystem.util;


import java.io.File;
import java.util.Collection;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Provides mail sending services.
  *
 * @author Daniel Stephens
 * @version $Id$
 */
public class MailSender {
    private final Log log = LogFactory.getLog(getClass());
    
    /**
     * Sends an email message without an attachment.
     * 
     * @param smtpServer the SMTP server to use
     * @param fromAddress the source email address
     * @param toAddresses the destination email addresses
     * @param subject the message subject
     * @param body the message body
     * 
     * @throws AddressException if the addresses are invalid
     * @throws MessagingException if message sending fails
     */
    public void sendMessage(String smtpServer, String fromAddress, Collection<String> toAddresses, String subject, String body)
    throws AddressException, MessagingException {
        sendMessage(smtpServer, fromAddress, toAddresses, subject, body, null);
    }

    /**
     * Sends an email message with an optional attachment.
     * 
     * @param smtpServer the SMTP server to use
     * @param fromAddress the source email address
     * @param toAddresses the destination email addresses
     * @param subject the message subject
     * @param body the message body
     * @param attachmentFile the file to attach, which will retain its original name, <code>null</code> for no attachment
     * 
     * @throws AddressException if the addresses are invalid
     * @throws MessagingException if message sending fails
     */
    public void sendMessage(String smtpServer, String fromAddress, Collection<String> toAddresses, String subject, String body, File attachmentFile)
    throws AddressException, MessagingException {
        sendMessage(smtpServer, fromAddress, toAddresses, subject, body, attachmentFile,
                    (attachmentFile == null) ? null : attachmentFile.getName());
    }

    /**
     * Sends an email message with an optional attachment.
     * 
     * @param smtpServer the SMTP server to use
     * @param fromAddress the source email address
     * @param toAddresses the destination email addresses
     * @param subject the message subject
     * @param body the message body
     * @param attachmentFile the file to attach,  <code>null</code> for no attachment
     * @param attachmentName the name to use for the attachment, ignored if attachmentFile is <code>null</code>
     * 
     * @throws AddressException if the addresses are invalid
     * @throws MessagingException if message sending fails
     */
    public void sendMessage(String smtpServer, String fromAddress, Collection<String> toAddresses, String subject,
                            String body, File attachmentFile, String attachmentName) throws AddressException, MessagingException {
        // Get system properties
        Properties props = System.getProperties();

        // Setup mail server
        props.put("mail.smtp.host", smtpServer);
        //props.put("mail.smtp.host", "rkmail1.wsgc.com");
        //props.put("mail.smtp.port", 25);
        //props.put("mail.debug", true);
        
        log.info("Creating message: '" + subject + "' -> " + toAddresses);

        // Get session
        Session session = Session.getDefaultInstance(props, null);

        // Define message
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromAddress));

        for (String recipient : toAddresses) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        }

        message.setSubject(subject);

        // Create the message part
        BodyPart messageBodyPart = new MimeBodyPart();

        // Fill the message
        messageBodyPart.setText(body);
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);

        if (attachmentFile != null) {
            // Part two is file attachment
            messageBodyPart = new MimeBodyPart();
            FileDataSource source;
            source = new FileDataSource(attachmentFile);
            messageBodyPart.setFileName(attachmentName);
            messageBodyPart.setDataHandler(new DataHandler(source));
            multipart.addBodyPart(messageBodyPart);
        }

        // Put parts in message
        message.setContent(multipart);

        // Send the message
        Transport.send(message);
        log.info("Sent.");
    }
}
