package com.wsgc.ecommerce.buildsystem.util.exception;

/**
 * 
 * Custom unchecked exceptions for the {@link FileUtil} operations.
 * 
 * DEBATABLE does your world really -need- an unchecked custom throwable?
 * Defend your answer
 *  
 * @author chunt
 * @version $Id$
 * 
 */
public class FileUtilRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 1L;


    /**
     * @param arg0 the detail message
     * @param arg1 the original cause
     */
    public FileUtilRuntimeException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    /**
     * @param arg0 the detail message
     */
    public FileUtilRuntimeException(String arg0) {
        super(arg0);
    }

    /**
     * @param arg0 the original cause
     */
    public FileUtilRuntimeException(Throwable arg0) {
        super(arg0);
    }

}
