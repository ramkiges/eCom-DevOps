package com.wsgc.ecommerce.buildsystem.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A random collection of file utilities. The goal of the build system was not to create a new collection of utilities
 * but there is no reason to throw away code that ended up being useful and there is no other logical place to store it.
 * 
 * @author chunt
 * @version $Id$
 */
public final class FileUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(com.wsgc.ecommerce.buildsystem.util.FileUtil.class);
    private static final String WELL_THIS_IS_UNEXPECTED = "Unexpected file system state: ";

    /**
     * Throw an exception if the file specified doesn't actually exist on the file system.
     * 
     * @param file
     *            the file to check
     * @throws IOException
     *             if the file does not exist.
     */
    public static void checkExists(File file) throws IOException {
        if (!file.exists()) {
            throw new FileNotFoundException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " does not exist.");
        }
    }

    /**
     * Checks to ensure a file is NOT on the file system.
     * 
     * @param file
     *            the file you DON'T what to see living on your local file system.
     * @throws IOException
     *             if the File specified is actually found on the file system.
     */
    public static void checkDoesNotExist(File file) throws IOException {
        if (file.exists()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " does exist.");
        }
    }

    /**
     * Verifies the file exists, and is readable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not readable.
     */
    public static void checkFileExistsReadable(File file) throws IOException {
        checkFileExists(file);
        checkReadable(file);
    }

    /**
     * Verifies the file exists, and is readable and writable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not readable or is not writable.
     */
    public static void checkFileExistsRW(File file) throws IOException {
        checkFileExists(file);
        checkReadable(file);
        checkWritable(file);
    }
    /**
     * Verifies the file exists, is empty and is readable and writable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist, is not empty or is not readable or is not writable.
     */
    public static void checkFileExistsRWEmpty(File file) throws IOException {
        checkFileExists(file);
        checkFileEmpty(file);
        checkReadable(file);
        checkWritable(file);
    }
    
    /**
     * Verifies the file exists, is both readable by this process. and has some content.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not readable or is 'empty'.
     */
    public static void checkFileExistsReadableNotEmpty(File file) throws IOException {
        checkFileExists(file);
        checkReadable(file);
        checkFileNotEmpty(file);
    }

    /**
     * Verifies the file exists, and is executable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not executable.
     */
    public static void checkFileExistsExectable(File file) throws IOException {
        checkFileExists(file);
        checkExecutable(file);
    }

    /**
     * Verifies the File exists, is a Directory and is executable by this process.
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not a directory or is not executable.
     */
    public static void checkDirExistsReadable(File dir) throws IOException {
        checkDirExists(dir);
        checkReadable(dir);
    }

    /**
     * Verifies the File exists, is a Directory and is both readable and writable by this process.
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not a directory or is not readable and writable.
     */
    public static void checkDirExistsRW(File dir) throws IOException {
        checkDirExists(dir);
        checkReadable(dir);
        checkWritable(dir);
    }

    /**
     * Verifies the File exists, is a Directory and is both readable and writable by this process and empty.
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not a directory or is not readable and writable or is not empty.
     */
    public static void checkDirExistsRWEmpty(File dir) throws IOException {
        checkDirExists(dir);
        checkReadable(dir);
        checkWritable(dir);
        checkDirEmpty(dir);
    }

    /**
     * Verifies the File exists, is a Directory and is both readable and writable by this process and not empty.
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not a directory or is not readable and writable or is empty.
     */
    public static void checkDirExistsReadableNotEmpty(File dir) throws IOException {
        checkDirExists(dir);
        checkReadable(dir);
        checkDirNotEmpty(dir);
    }

    /**
     * Verifies the File exists, and is a Directory.
     * 
     * @param dir
     *            the File to verify (as a directory)
     * @throws IOException
     *             if the file does not exist or is not a directory.
     */
    public static void checkDirExists(File dir) throws IOException {
        if (!dir.isDirectory()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + dir.getAbsolutePath() + " is not a directory.");
        }
    }

    /**
     * Verifies the File exists, and is a file (as opposed to a directory).
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file does not exist or is not a file.
     */
    public static void checkFileExists(File file) throws IOException {
        checkExists(file);
        if (!file.isFile()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " is not a file.");
        }
    }

    /**
     * Verifies the File is readable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file is not readable.
     */
    public static void checkReadable(File file) throws IOException {
        if (!file.canRead()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " is not readable.");
        }
    }

    /**
     * Verifies the File exists, and is executable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file is not executable.
     */
    public static void checkExecutable(File file) throws IOException {
        if (!file.canExecute()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " is not executable.");
        }
    }

    /**
     * Verifies the File is writable by this process.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file is not writable.
     */
    public static void checkWritable(File file) throws IOException {
        if (!file.canWrite()) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " is not writable.");
        }
    }

    /**
     * Verifies the File length is not zero.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file length is zero
     */
    public static void checkFileNotEmpty(File file) throws IOException {
        if (file.length() == 0L) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " file has zero length. Was expecting some content.");
        }
    }
    
    /**
     * Verifies the File length is zero.
     * 
     * @param file
     *            the File to verify
     * @throws IOException
     *             if the file length is not zero
     */
    public static void checkFileEmpty(File file) throws IOException {
        if (file.length() != 0L) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + file.getAbsolutePath() + " file has length " + file.length() 
                    + ". Was expecting it to be empty.");
        }
    }
    
    /**
     * Verifies the File is an empty directory
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file is not a directory or if the directory has children.
     */
    public static void checkDirEmpty(File dir) throws IOException {
        checkDirExists(dir);
        File[] files = dir.listFiles();
        if (files.length != 0) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + dir.getAbsolutePath() + " directory is not empty.");
        }
    }

    /**
     * Verifies the File is a directory, and that is has children
     * 
     * @param dir
     *            the File to verify
     * @throws IOException
     *             if the file is not a directory or if the directory has no children.
     */
    public static void checkDirNotEmpty(File dir) throws IOException {
        checkDirExists(dir);
        File[] files = dir.listFiles();
        if (files.length == 0) {
            throw new IOException(WELL_THIS_IS_UNEXPECTED + dir.getAbsolutePath() + " directory has no entries.");
        }
    }

    /**
     * Convenience method to remove a directory silently.
     * 
     * @param dir
     *            the directory to remove.
     */
    public static void removeDirectory(File dir) {
        try {
            removeDirectory(dir, false);
        } catch (IOException ioe) {
            /*
             * This can not happen because we are asking to not throw exceptions. So when it actually does...go ahead
             * and end the universe.
             */
            throw new Error(ioe);
        }
    }

    /**
     * Recursively remove a directory and all its subdirectory, optionally throw an error.
     * 
     * @param dir
     *            the directory to remove
     * @param exceptionOnFailure
     *            whether or not to throw an exception if the removal is reported to be unsuccessful.
     * @throws IOException
     *             if exceptionOnFailure is <code>true</code> and a directory is reported to still 'exist' after our
     *             call to have it removed finishes.
     */
    public static void removeDirectory(File dir, boolean exceptionOnFailure) throws IOException {
        checkDirExists(dir);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    removeDirectory(file, exceptionOnFailure);
                } else {
                    file.delete();
                }
            }
        }
        dir.delete();
        if (dir.exists()) {
            String message = WELL_THIS_IS_UNEXPECTED + dir.getAbsolutePath() + " directory is not empty after removal attempt.";
            LOGGER.warn(message);
            if (exceptionOnFailure) {
                // I was "almost sure" this is a bad idea but have not seen trouble from it so far.
                throw new IOException(message);
            }
        }
    }

    /**
     * Disabled default constructor
     */
    private FileUtil() {
        throw new IllegalAccessError("Utility class not meant for instantiation.");
    }

    /**
     * 
     * Recursively determine the number of bytes this directory and its children take up.
     * 
     * @param directory
     *            to get the size of.
     * @return the number of bytes in this directory and all its children.
     */
    public static long folderSize(File directory) {
        long length = 0;
        for (File file : directory.listFiles()) {
            if (file.isFile()) {
                length += file.length();
            } else {
                length += folderSize(file);
            }
        }
        return length;
    }

    /**
     * 
     * This method uses a buffered reader to convert a file on disk to a String in memory. It has been described as 'a
     * performance and stability disaster waiting to happen', so you are responsible for not making this 'too big" a
     * string.
     * 
     * 
     * @param file
     *            the file to read (hopefully a small file).
     * @return the files contents assembled to a single String.
     * @throws IOException
     *             if any error occurs finding or reading the file.
     */
    public static String readAsString(File file) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(file));
        StringBuilder b = new StringBuilder();
        while (true) {
            int ch = r.read();
            if (ch == -1) {
                break;
            }
            b.append((char) ch);
        }
        r.close();
        return b.toString();
    }

    /**
     * Append a copy of one file to another using buffered streams that are not character-centric. If the destination
     * file does not exist, it will be silently created if possible.
     * 
     * @param src
     *            file to append with.
     * @param dest
     *            file to append to.
     * @throws IOException
     *             for the usual host of possible file operation troubles.
     */
    public static void appendFiles(File src, File dest) throws IOException {

        FileUtil.checkFileExistsRW(src);
        if (!dest.exists()) {
            dest.createNewFile();
        }
        FileUtil.checkFileExistsRW(dest);

        BufferedInputStream reader = new BufferedInputStream(new FileInputStream(src));
        BufferedOutputStream writer = new BufferedOutputStream(new FileOutputStream(dest, true));

        while (true) {
            int i = reader.read();
            if (i == -1) {
                break;
            }
            writer.write(i);
        }
        reader.close();
        writer.close();
    }

    /**
     * Copy a file to a new location. The destination must not exist.
     * 
     * @param src
     *            the file to copy from.
     * @param dest
     *            the file to copy to.
     * @throws IOException
     *             if the destination exists or there is trouble writing our copy to it.
     */
    public static void copyFile(File src, File dest) throws IOException {
        checkFileExistsReadable(src);
        checkDoesNotExist(dest);
        /*
         * Copy is different from 'move' a file (which would be better accomplished with a File.rename() operation).
         */
        appendFiles(src, dest);
    }

    /**
     * Convenience method to silently remove all empty directories below a given level.
     * 
     * @param dir
     *            the to inspect.
     */
    public static void removeEmptyDirectories(File dir) {
        try {
            removeEmptyDirectories(dir, false);
        } catch (IOException ioe) {
            /*
             * This can not happen because we are asking to not throw exceptions. So when it actually does...go ahead
             * and end the universe.
             */
            throw new Error(ioe);
        }
    }

    /**
     * Remove all empty directories at or below a given directory. This method recursively looks for and deletes empty
     * directories from the file system. Optionally throwing an error if delete was attempted but not successful.
     * 
     * @param dir
     *            the directory to inspect and potentially remove.
     * @param exceptionOnFailure
     *            whether to throw an exception if an attempt to remove an empty directory fails.
     * @throws IOException
     *             if exceptionOnFailure is <code>true</code> and there is a failure to delete detected.
     */
    public static void removeEmptyDirectories(File dir, boolean exceptionOnFailure) throws IOException {

        // Hello are you a directory?
        if (dir.isDirectory()) {
            // yes I am a directory.
            // Are you an empty directory?
            File[] files = dir.listFiles();

            if (files != null) {
                // no, I am a directory that has files.

                // Then let me see all your pretty files.
                for (File file : files) {
                    // is this file of yours a directory? ...careful how you answer.
                    if (file.isDirectory()) {
                        removeEmptyDirectories(file, exceptionOnFailure);
                    }
                }

                /*
                 * Ok, the files you had that where directories have been inspected too, Any empty directories there
                 * have been deleted. We are done with you.
                 */
                return;

            } else {
                // Yes I am an empty directory

                // Ok then, please remove yourself from my file system.
                dir.delete();
                if (dir.exists()) {
                    String message = WELL_THIS_IS_UNEXPECTED + dir.getAbsolutePath()
                            + " directory is not empty after removal attempt.";
                    LOGGER.warn(message);
                    if (exceptionOnFailure) {
                        // again, I am almost sure this is a bad idea.
                        throw new IOException(message);
                    }
                }
            }
        }
    }
}
