package com.wsgc.ecommerce.buildsystem.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.CommandResultInfo;
import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/**
 * Collection of commonly used SVN processes. These methods where later refactored to use {@link ProcessUtil} classes to populate 
 * {@link CommandResultInfo}.  Switch and Checkout are the only svn util's that return {@link CommandResultInfo}'s for external error
 * processing. The rest of the methods either return on success or throw and exception after parsing their own results. 
 * 
 * @author chunt
 * @version $Id$ 
 */
public final class SvnUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(SvnUtil.class);
    private static final String CURRENT_DIR_NOT_WORING_COPY = "svn: '.' is not a working copy";

    /** svn log revision example
      "r154971 | chunt | 2011-06-10 09:47:04 -0700 (Fri, 10 Jun 2011) | 1 line"
     */  
    private static String revisionReEx = "^r(\\d+?)\\s\\|\\s(.*?)\\s\\|\\s(.*?)\\s\\|\\s(.*?)$";
    private static Pattern revisionPattern = Pattern.compile(revisionReEx);
        
    /** 
     * This is the limit we allow for writing a SVN response to a local StringBuilder and ultimately to a exception detail message.
     */
    private static final int SVN_MAX_RESPONSE_SIZE = 2048;
    
    /**
     * Used to move the extract from the source directory to a extract working directory. If the destination directory
     * does not exist, an attempt will be made to create it. We use Rsync but later the "svn export" command was
     * rediscovered so there is at least one alternative (commented out at the moment). Note, the output from this process is too variable 
     * to safely trap and put into a exception detail message.
     * 
     * @param srcDir
     *            where to copy from
     * @param destDir
     *            where to copy to
     * @throws SourceException
     *             if the process reports a error.
     */
  public static void copyNonSvnFiles(File srcDir, File destDir) throws SourceException {
        try {
            destDir.mkdirs();
            FileUtil.checkDirExistsRWEmpty(destDir);

            String sourceAbsolutePath = srcDir.getAbsolutePath();
            String destAbsolutePath = destDir.getAbsolutePath();

            String sourceAbsolutePathWithTrailingSlash = sourceAbsolutePath + File.separatorChar;
            String destAbsolutePathWithTrailingSlash = destAbsolutePath + File.separatorChar;

            List<String> command = new ArrayList<String>();
           
            // one way.
            command.add("rsync");
            command.add("-a");
            command.add("--exclude=.svn");
            command.add(sourceAbsolutePathWithTrailingSlash);
            command.add(destAbsolutePathWithTrailingSlash);

            /** another way.
            command.add("svn");
            command.add("export");
             command.add("--non-interactive");  ??
             command.add(sourceAbsolutePathWithTrailingSlash);  ??
             command.add(destAbsolutePathWithTrailingSlash);  ??
            */
            
            CommandResultInfo tmpDirCommandResultInfo = new CommandResultInfo(null);
            ProcessUtil.runCommand(tmpDirCommandResultInfo, command);
            CommandResultInfo.validate(tmpDirCommandResultInfo);

        } catch (Exception e) {
            throw new SourceException("Failed to move non-svn files from '" + srcDir + " ' to '" + destDir + "' Reason:" + e, e);
        }

    }

    /**
     * 
     * Executes a svn info command for a file system working directory and tries to create a {@link SvnInfo} bean from the answer.      
     * 
     * @param directory the working copy to ask svn info about.
     * @return a {@link SvnInfo} bean holding the svn response
     * @throws SourceException
     *             if there is trouble with the underlying process or response parsing.
     */
    public static SvnInfo getSvnInfoWorkingCopy(File directory) throws SourceException {
        return SvnUtil.getSvnInfo(".", null, null, directory);
    }

    /**
     * 
     * Executes a svn info command for a URL type request and tries to create a {@link SvnInfo} bean from the answer.
     * 
     * @param url the svn url to get info from 
     * @param revision optional revision, output depends on svn
     * @param uuid optional uuid, same as above
     * @return a {@link SvnInfo} bean holding the svn response
     * @throws SourceException for parsing or execution excitement
     */
    public static SvnInfo getSvnInfoForURL(String url, String revision, String uuid) throws SourceException {
        return getSvnInfo(url, revision, uuid, null);
    }

    /**
     * Executes a svn info command and creates a {@link SvnInfo} from the parsed response. This private method has code that is reused by
     * two wrapper methods {@link #getSvnInfoWorkingCopy(File)} and {@link #getSvnInfoForURL(String, String, String)}. It
     * handles the "tell me about this url" and "tell me about this working copy directory" versions of the svn
     * info command. Results are kept in memory because the response to svn info is typically short and contains info found useful
     * for exception detail messages. We are only capturing the response fields that we are interested in, svn info is pretty capable.  
     * 
     * TODO: what actually happens when you call it with params from both?
     * DEBATABLE we could integrate checks for fields involving locks but those are not expected (and where not seen during dev)
     * 
     * @param url
     *            the url to get info on 
     * @param revision
     *            the optional revision, can be null
     * @param uuid the optional uuid of the repo you think you are using
     * @param directory the working copy 
     * @return {@link SvnInfo} bean with the captured response
     * @throws SourceException
     *             if there is trouble with the underlying process or response parsing.
     */
    private static SvnInfo getSvnInfo(String url, String revision, String uuid, File directory) throws SourceException {
        // There must be a better way.... or not.
        String repositoryPathType = null;
        String repositoryURL = null;
        String repositoryRoot = null;
        String repositoryUUID = null;
        String repositoryRevision = null;
        String repositoryNodeKind = null;
        String repositorySchedule = null;
        String repositoryLastChangedAuthor = null;
        String repositoryLastChangedRev = null;
        String repositoryLastChangedDate = null;
        
        Reader results = null;
       
        try {
            List<String> command = new ArrayList<String>();
            command.add("svn");
            command.add("--non-interactive");
            command.add("info");
            command.add(url);

            if (revision != null) {
                command.add("-r");
                command.add(revision);
            }
            CommandResultInfo inMemoryCommandResultInfo = new CommandResultInfo();
            
            ProcessUtil.runCommand(inMemoryCommandResultInfo, command, directory);
            /**
             * Was //CommandResultInfo.validate(inMemoryCommandResultInfo); Now gets Special Handling. We want helpful
             * message from SVN output like the 'that is not a good URL for svn' to be in the exception detail message.
             * Normal processing would read that in the log files alone. Here we add what we think is a short message to
             * exception.
             */
            //CommandResultInfo.validate(inMemoryCommandResultInfo);
            if (!inMemoryCommandResultInfo.getSuccessStatus()) {
                // well we seem to have an exception already, rethrow that.
                if (inMemoryCommandResultInfo.getLastException() != null) {
                    throw new SourceException(inMemoryCommandResultInfo.getLastException());
                }
                /*
                 *  to get here we have a non zero exit code, no exception and perhaps a helpful message captured from
                 *  last svn process. CommandResultInfo.validate(inMemoryCommandResultInfo); would have thrown an exception
                 *  due to the exit code, we simulate that behavior but create a better detail message.
                 */
                throw new SourceException("Command " + inMemoryCommandResultInfo.getCommandAsString() + " returned exit code:" 
                        + inMemoryCommandResultInfo.getExitCode() + " with process output '" + readResultsToString(inMemoryCommandResultInfo)
                        + "'");
            }
            
            results = inMemoryCommandResultInfo.getResultsReader();

            Scanner in = new Scanner(results);
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split(":");

                if (fields.length == 1 && fields[0].isEmpty()) {
                    // actually end of stream.
                    continue;
                }

                if (fields.length != 2) {
                    if (fields.length == 3) {
                        if (fields[0].equals("URL")) {
                            repositoryURL = fields[1].trim() + ":" + fields[2].trim();
                            continue;
                        } else if (fields[0].equals("Repository Root")) {
                            repositoryRoot = fields[1].trim() + ":" + fields[2].trim();
                            continue;
                        }
                    }

                    if (fields.length == 4 && fields[0].equals("Last Changed Date")) {
                        repositoryLastChangedDate = fields[1].trim() + ":" + fields[2].trim() + ":" + fields[3].trim();
                        continue;
                    }

                    throw new SourceException("Unexpected number of fields while reading svn info output. Line '" 
                    + line + "' Number of fields" + fields.length);

                }

                if (fields[0].equals("Working Copy Root Path") ||
                            fields[0].equals("Relative URL")) {
                    continue;
                }

                if (fields[0].equals("Path")) {
                    repositoryPathType = fields[1].trim();
                } else if (fields[0].equals("Repository Root")) {
                    repositoryRoot = fields[1].trim();
                } else if (fields[0].equals("Repository UUID")) {
                    repositoryUUID = fields[1].trim();
                } else if (fields[0].equals("Revision")) {
                    repositoryRevision = fields[1].trim();
                } else if (fields[0].equals("Schedule")) {
                    repositorySchedule = fields[1].trim();
                } else if (fields[0].equals("Node Kind")) {
                    repositoryNodeKind = fields[1].trim();
                } else if (fields[0].equals("Last Changed Author")) {
                    repositoryLastChangedAuthor = fields[1].trim();
                } else if (fields[0].equals("Last Changed Rev")) {
                    repositoryLastChangedRev = fields[1].trim();
                } else {
                    throw new SourceException(
                            "Unexpected content while reading svn info output. Unable to parse line '"
                                    + line
                                    + "' Number of fields"
                                    + fields.length
                                    + " commandResultInfo:"
                                    + ((inMemoryCommandResultInfo != null) ? inMemoryCommandResultInfo.toString()
                                            : "null"));
                }
           }

        } catch (Exception e) {
            if (results != null) {
                try {
                    results.close();
                    results = null;
                } catch (IOException ioe) {
                    LOGGER.error("Error closing results reader. Reason:" + ioe, ioe);
                }
            }
            throw new SourceException("SVN info command FAILED. Reason:" + e, e);
        }

        if ((repositoryPathType == null) || (repositoryURL == null) || (repositoryRoot == null)
                || (repositoryUUID == null) || (repositoryRevision == null) || (repositoryNodeKind == null)
                /* repositorySchedule can be null if you svn info a URL instead of a working copy */
                || (repositoryLastChangedAuthor == null) || (repositoryLastChangedRev == null)
                || (repositoryLastChangedDate == null)) {
            throw new SourceException("SVN info returned a null field.\n" + "repositoryURL:" + repositoryURL
                    + " repositoryRoot:" + repositoryRoot + " repositoryUUID:" + repositoryUUID
                    + " repositoryRevision:" + repositoryRevision + " repositoryNodeKind:" + repositoryNodeKind

                    + " repositoryLastChangedAuthor:" + repositoryLastChangedAuthor + " repositoryLastChangedRev:"
                    + repositoryLastChangedRev + " repositoryNodeKind:" + repositoryNodeKind
                    + " repositoryLastChangedDate:" + repositoryLastChangedDate + " commandResultInfo:");
        }

        if ((uuid != null) && !repositoryUUID.equals(uuid)) {
            throw new SourceException("Repository UUID '" + repositoryUUID + "' does not match expectations '" + uuid + "'");
        }

        return new SvnInfo(repositoryPathType, repositoryURL, repositoryRoot, repositoryUUID, repositoryRevision, repositoryNodeKind, repositorySchedule,
                repositoryLastChangedAuthor, repositoryLastChangedRev, repositoryLastChangedDate);
    }

    /**
     * Checks to see if the given File is recognized as a SVN "working copy" by issuing a svn info command and
     * shortening the response in to a simple boolean YES or NO.
     * 
     * @param dir
     *            the directory to investigate
     * @return <code>true</code> if the directory exists is readable and is a svn working copy.
     * @throws SourceException
     *             if we go insane trying to find out.
     */
    public static boolean isWorkingDirectory(File dir) throws SourceException {
        SvnInfo svnInfo = null;
        try {

            FileUtil.checkDirExistsReadable(dir);
            svnInfo = getSvnInfoWorkingCopy(dir);

        } catch (SourceException sse) {
            if (!sse.getMessage().contains(SvnUtil.CURRENT_DIR_NOT_WORING_COPY)) {
                throw new SourceException("Unexpected Exception while CHECKING SVN INFO in directory: " + dir + " reason: " + sse, sse);
            }
        } catch (IOException ioe) {
             throw new SourceException("Working directory FAILED validation check. Reason:" + ioe, ioe);
        }

        return (svnInfo != null);
    }

    /** 
     *  Check out via svn (as opposed to switch). Used when there is no svn working copy.
     * 
     * @param checkOutDirectory where to put it
     * @param revision which revision to ask for
     * @param url the entity that will become an 'extract'
     * @return the results in the form of a {@link CommandResultInfo}
     * @throws SourceException 
     */
    public static CommandResultInfo svnCheckout(File checkOutDirectory, String revision, String url) throws SourceException {

        String[] command = {"svn", "--non-interactive", "checkout", "-r", revision, url };

        SvnInfo svnInfo = null;
        
        /*
         *  Hold results in a default named temp file. Ironically you will not read them in the case of
         *  success and only dump them to log in error rather than see it in a build artifact (even an error.log).
         *  This is a fun waste of time to rediscover so remember.
         */
        CommandResultInfo defaultTmpCommandResultInfo = new CommandResultInfo(null);
        defaultTmpCommandResultInfo = ProcessUtil.runCommand(defaultTmpCommandResultInfo, Arrays.asList(command), checkOutDirectory);
        File workingBaseDir = new File(checkOutDirectory + url.substring(url.lastIndexOf("/")));
        try {
            svnInfo = getSvnInfoWorkingCopy(workingBaseDir);
            verifiySvnResults(svnInfo, url, revision, command, workingBaseDir);
        } catch (Exception e) {
            defaultTmpCommandResultInfo.setSuccessStatus(false);
            defaultTmpCommandResultInfo.setLastException(e);
            defaultTmpCommandResultInfo.setExitCode(-1);
        }

        return defaultTmpCommandResultInfo;
    }

    /**
     * Perform a svn switch and verify the results are what we asked for. Used when we already have a svn working copy 
     * initialized. If errors are seen during this multi-step process the {@link CommandResultInfo} is updated and returned. 
     * 
     * @param directory the location to leave the source files. 
     * @param revision to retrieve
     * @param url svn url to retrieve
     * @return {@link CommandResultInfo} with the results.
     */
    public static CommandResultInfo svnSwitch(File directory, String revision, String url) {
        SvnInfo svnInfo = null;
        
        //Store results using CommmandResultInfo.defaultTempDirectory 
        CommandResultInfo defaultTmpCommandResultInfo = new CommandResultInfo(null);
        String[] command = {"svn", "--non-interactive", "--ignore-ancestry", "switch", "-r", revision, url };

        /*  Same as Checkout ....
         *  Hold results in a default named temp file. Ironically you will not read them in the case of
         *  success and only dump them to log in error rather than see it in a build artifact (even an error.log).
         *  
         *  This is a fun waste of time to rediscover so remember.
         */
        defaultTmpCommandResultInfo = ProcessUtil.runCommand(defaultTmpCommandResultInfo, Arrays.asList(command), directory);
        try {
            if (defaultTmpCommandResultInfo.getSuccessStatus()) {
                svnInfo = getSvnInfoWorkingCopy(directory);
                verifiySvnResults(svnInfo, url, revision, command, directory);
            }
        } catch (Exception e) {
            defaultTmpCommandResultInfo.setSuccessStatus(false);
            defaultTmpCommandResultInfo.setLastException(e);
            defaultTmpCommandResultInfo.setExitCode(-1);
        }
        return defaultTmpCommandResultInfo;
    }

    
    /**
     * Used as a sanity check after other operations. We expect the output from a svn status command to be null since there are 
     * no reasons to expect local changes to exist after a switch or check out.
     * 
     * @param directory the svn working copy directory to check.
     * @throws SourceException if the results are not null or an error happens while trying.
     */
    public static void verifySvnStatusIsNull(File directory) throws SourceException {
       
        CommandResultInfo inMemoryCommandResultInfo = new CommandResultInfo();
        
        //TODO if this proves useful, should/can it be -u with revision and such?
        String[] command = {"svn", "--non-interactive", "status" /*,"-r", revision, url*/ };

        inMemoryCommandResultInfo = ProcessUtil.runCommand(inMemoryCommandResultInfo, Arrays.asList(command), directory);
        try {
            if (inMemoryCommandResultInfo.getSuccessStatus()) {
                String statusOutput = readResultsToString(inMemoryCommandResultInfo);                    
                 if (!statusOutput.equals(null)) {
                    throw new SourceException("Unexpected svn status response: '" + statusOutput + "' was expecting 'null'");
                }
            }
        } catch (Exception e) {
            throw new SourceException(e);
        }

    }
    
    /**
     * Reads at most {@link SvnUtil #SVN_MAX_RESPONSE_SIZE} number of characters from the {@link CommandResultInfo #getResultsReader()} into a {@link String}. 
     * @param commandResultInfo the {@link CommandResultInfo} to read
     * @return a {@link String} copy of the results from the reader
     * @throws SourceException for errors
     */
    private static String readResultsToString(CommandResultInfo commandResultInfo) throws SourceException {
        StringBuilder resultsBuilder = new StringBuilder();
        BufferedReader resultsReader = null;
        try {
            resultsReader = commandResultInfo.getResultsReader();
            String line = resultsReader.readLine();
            int charsToRead = SVN_MAX_RESPONSE_SIZE;

            /*
             * Here we take a risk of holding an arbitrary length string in memory. We limit the length of the reporting
             * message. Hopefully it is not too long to degrade performance but is long enough to give a hint as to what
             * went wrong.
             */
            while (line != null) {
                if (charsToRead >= line.length()) {
                    resultsBuilder.append(line);
                    charsToRead -= line.length();                
                } else {
                    // enough characters.. quit now out of sense of self preservation
                    resultsBuilder.append(line.substring(0, charsToRead));
                    break;
                }
                
                line = resultsReader.readLine();

            }
            // read all results, ending normally
        } catch (Exception e) {
            throw new SourceException(e);
        } finally {
            if (resultsReader != null) {
                try {
                    resultsReader.close();
                } catch (IOException e) {
                    LOGGER.warn("Results reader reported failure on close attempt.");
                }
            }
        }
        
        return resultsBuilder.toString();
    }

    /**
     * SVN tries to accommodate 'bad' ideas like requesting a revision that does not exist on a branch. We can decline
     * this help by first noticing it happened. Did svn give us something equivalent to what it thinks we asked for, or
     * exactly what we asked for?
     * 
     * 
     * @param svnInfo the svn info of a directory as returned by svn presumably matching the other params about to be checked here
     * @param url the reference url you expect this directory to hold
     * @param revision the revision you asked for
     * @param command the command that is associated with the current working directory state. Only used in the error message.
     * @param directory the directory to look at
     * @throws SourceException if the inspected directory does not match expectations
     */
  public static void verifiySvnResults(SvnInfo svnInfo, String url, String revision, String[] command, File directory) throws SourceException {
        if (!svnInfo.getRevision().toUpperCase().equals("HEAD")) {
            if (!svnInfo.getUrl().equals(url) || !svnInfo.getRevision().equals(revision)) {
                throw new SourceException("Results of svn command do not match request." + "\n" + "Requested URL: "
                        + url + " Revision: " + revision + "\n" + "Received URL:  " + svnInfo.getUrl() + " Revision: "
                        + svnInfo.getRevision() + "\n" + " Command:" + command + " in Directory: " + directory);
            }
            //TODO this just looks broken suddenly......
        } else {
            if (!svnInfo.getUrl().equals(url)) {

                /**
                 * adding a \n at the end of a text string separately maximizes the chance you won't later be able to cut the message from a log and search for
                 * it in eclipse. Leave this.. its more.. 'fun' that way. Tell your friends to do it too. Because embedding formating in a stack trace isn't a
                 * good enough waste of time in the first place.
                 * --Author
                 * 
                 * // throw new SourceException("Results of svn command do not match request." + "\n"
                 */
                throw new SourceException("Results of svn command do not match request. " 
                        + "(You may be asking for a revision that does not exist on the branch specified).\n" 
                        + "Requested URL: " + url + " Revision: " + revision + " (not checking revision = HEAD) \n" + "Received URL:  " 
                        + svnInfo.getUrl() + " Revision: " + svnInfo.getRevision() + "\n"
                        + " Command:" + command + " in Directory: " + directory);
            }
        }
    }

    /**
     * Private utility constructor
     * 
     * @throws IllegalAccessException if used.
     */
    private SvnUtil() throws IllegalAccessException {
        throw new IllegalAccessException("Utility class not meant for instantiation.");
    }

    /**
     * Attempts to read the revision at which this branch was created using the "svn --stop-on-copy log" command and and
     * parsing the last line for the revision number.
     * 
     * 
     * @param url
     *            the url to investigate
     * @return a String with the revision number when the branch was created.
     * @throws SourceException
     *             if there is an error with SVN calls or parsing results
     */
    public static String getSvnBranchFirstRevison(String url) throws SourceException {

        // svn log revision example
        // "r154971 | chunt | 2011-06-10 09:47:04 -0700 (Fri, 10 Jun 2011) | 1 line"
        // REVISION_REG_EX = "^r(\\d+?)|(.*?)|(.*?)|(.*?)$";
        Matcher revisionMatcher = revisionPattern.matcher("");
        String revision = null;

        CommandResultInfo defaultTmpCommandResultInfo = new CommandResultInfo(null);
        String[] command = {"svn", "--stop-on-copy", "log", url };

        // This command doesn't need a specific working dir
        File directory = null;
        BufferedReader reader = null;

        defaultTmpCommandResultInfo = ProcessUtil.runCommand(defaultTmpCommandResultInfo, Arrays.asList(command),
                directory);

        try {
            CommandResultInfo.validate(defaultTmpCommandResultInfo);
            reader = defaultTmpCommandResultInfo.getResultsReader();

            /*
             * search to end of svn log output and remember last line that looked like it was a revision.
             */
            String in = reader.readLine();
            while (in != null) {
                revisionMatcher.reset(in);
                if (revisionMatcher.find()) {
                    revision = revisionMatcher.group(1);
                }
                in = reader.readLine();
            }

            /** remember the last revision number and return */
            LOGGER.debug("Log says branch started at revision {}", revision);
            
        } catch (Exception e) {
            throw new SourceException(e);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    LOGGER.warn("Results reader reported failure on close attempt.");
                }
            }
        }

        return revision;

    }

}
