package com.wsgc.ecommerce.buildsystem.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;

/**
 * 
 * A MD5 Hash digester with nowhere else to live.
 * 
 * @author chunt
 * @version $Id$ 
 */
public final class HashUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(HashUtil.class);

    /**
     * Utility class non-constructor. All methods are static, you don't need a class instance. Anyone attempting to do that will be corrected.
     * @throws IllegalAccessException if used. 
     */
    private HashUtil()
            throws IllegalAccessException {
        throw new IllegalAccessException("Utility class does not need instantiation");
    }

    /**
     * Reads the contents of a file and generates a MD5 hash string to represent the contents of that file.
     * 
     * @param file the file to digest.
     * @return a string containing the MD5 hash of the files contents.
     * @throws BuildServiceException for any IO errors or MD5 calculation accidents.
     */
    public static String md5Hash(File file) throws BuildServiceException {
        LOGGER.debug("Digesting file:{}", file.getAbsolutePath());
        
        DigestInputStream ds = null;
        
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
 
            ds = new DigestInputStream(new FileInputStream(file), md);
            byte[] buffer = new byte[8192];
            while (ds.read(buffer) != -1) {
                //don't do anything with the data, we are reading to update the digest only.
            }
            
            byte[] digest = md.digest();
            return digestToString(digest);

        } catch (Exception e) {
            throw new BuildServiceException("Unable to determine MD5 Hash Digest for '" + file.getAbsolutePath() 
                    + "' Reason:" + e, e);
        } finally {
            try {
                if (ds != null) {
                    ds.close();
                }
            } catch (IOException ioe) {
                throw new BuildServiceException("Unable to close hash digest input stream for file "
                        + file.getAbsolutePath() + " Reason:" + ioe, ioe);
            }
        }

    } 

    /**
     * Generate a MD5 hash String from a String. 
     * 
     * @param source the source of the data to digest, in String form.
     * @return A String with the MD5 hash derived from digesting the source string.
     * @throws BuildServiceException any errors due to IO or hash calculation.
     */
    public static String md5Hash(String source) throws BuildServiceException {

        byte[] bytesOfMessage;
        byte[] thedigest;

        try { 
            bytesOfMessage = source.getBytes("UTF-8");
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.reset();

            thedigest = md.digest(bytesOfMessage);
        } catch (Exception e) {
            throw new BuildServiceException("Unable to determine MD5 Hash Digest for '" + source 
                    + "' Reason:" + e, e);
        } 
        return digestToString(thedigest);
    }

    /**
     * Convert a byte[] digest in to a Hex string.
     * @param digest the digest to convert
     * @return a {@link String} with the digest expressed in hex 
     */
    private static String digestToString(byte[] digest) {
        StringBuilder stringBuilder = new StringBuilder();
        String tmp = null;

        /*
         *  TODO this could use a little scrutiny. Just because
         *  it was the least obnoxious looking solution doesn't 
         *  mean its good. Byte[] back to String has numerous 
         *  tribes devoted to various world views. Tests show it
         *  seems to be compatible with Unix md5hash util so we 
         *  let it slide....
         */
        for (byte b : digest) {
            tmp = (Integer.toHexString(0xFF & b));

            if (tmp.length() == 1) {
                stringBuilder.append("0");
            } 

            stringBuilder.append(tmp);
        }

        return stringBuilder.toString();
    }
}
