package com.wsgc.ecommerce.buildsystem.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.CommandResultInfo;

/**
 * A runnable class to populate a CommandResultInfo object with the results of the output from 
 * another process.  
 * 
 * @author chunt
 * @version $Id$ 
 */
public class CommandResultBuilder implements Runnable {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final InputStream is;
    private final CommandResultInfo commandResultInfo;

    /**
     * The constructor. Reads a {@link InputStream} and appends it as "results"
     * in a {@link CommandResultInfo}. 
     * 
     * @param commandResultInfo the 
     * @param is stream to read from.
     */
    public CommandResultBuilder(CommandResultInfo commandResultInfo, InputStream is) { 
        this.commandResultInfo = commandResultInfo;
        this.is = is; 
    }

    /** {@inheritDoc}  */
    @Override
    public void run() {
        logger.debug("Entering CommandResultBuilder run method with commandResultInfo {}", commandResultInfo);
        BufferedReader rdr = null;
        try {
            rdr = new BufferedReader(new InputStreamReader(is));
            String line = rdr.readLine();

            while (line != null) {
                logger.debug(line);                
                // we read a line and in doing so lost its new line character, in this one case, we put it back.
                commandResultInfo.appendResultsLine(line + "\n");
                line = rdr.readLine();
            }

        } catch (Exception e) {
            logger.error("Exception reading from input: " + e, e);
            commandResultInfo.setLastException("Exception reading from input: " + e, e);
            commandResultInfo.setSuccessStatus(false);
            commandResultInfo.setExitCode(-1);
        } finally {
            // not sufficient we may throw before this block (file not found process not run) and miss the lock call. 
            //commandResultInfo.lockResults();
            if (rdr != null) {
                try {
                    rdr.close();
                } catch (IOException ioe) {
                    logger.error("Exception closing reader, reason:" + ioe, ioe);

                }
            }
        }
        logger.debug("Leaving Run method. CommandResultInfo: {}",  commandResultInfo);
        return;
    }
}

