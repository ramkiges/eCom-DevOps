package com.wsgc.ecommerce.buildsystem.util;

/**
 * 
 * Immutable object to hold the state returned from a svn info request.
 * 
 * Example of svn info response:
 <pre>
    Path: .
    URL: https://repos.wsgc.com/svn/core/buildsystem/branches/2011-6-10-chunt-javaized-dedatabased
    Repository Root: https://repos.wsgc.com/svn/core
    Repository UUID: 4d9f3204-700e-0410-9f00-95bf6548d55c
    Revision: 159125
    Node Kind: directory
    Schedule: normal
    Last Changed Author: chunt  
    Last Changed Rev: 159080
    Last Changed Date: 2011-07-22 10:57:18 -0700 (Fri, 22 Jul 2011)
 </pre> 
 * 
 * @author chunt
 * @version $Id$ 
 */
public class SvnInfo {
    private final String path;
    private final String url;
    private final String repoRoot;
    private final String repoUuid;
    private final String revision;
    private final String nodeKind;
    private final String schedule;
    private final String lastChangedAuthor;
    private final String lastChangedRev;
    private final String lastChangedDate;

    /**
     * Only constructor. Directly sets all fields we are using. Each field has a svn defined meaning I can only reinterpret 
     * in this javadoc
     * 
     * @param path the file system location this info applies to
     * @param url the svn url that this working copy points to
     * @param repoRoot the svn "Repository Root"
     * @param repoUuid the "Repository UUID"
     * @param revision the revision
     * @param nodeKind the "Node Kind", "file" or "directory" are examples.
     * @param schedule the schedule, TODO: should be "normal' only for our purposes?
     * @param lastChangedAuthor last author
     * @param lastChangedRev last changed revision, used as effective revision in most cases
     * @param lastChangedDate last changed date of the extract
     */
    public SvnInfo(String path, String url, String repoRoot, String repoUuid,
            String revision, String nodeKind, String schedule,
            String lastChangedAuthor, String lastChangedRev,
            String lastChangedDate) {
        this.path = path;
        this.url = url;
        this.repoRoot = repoRoot;
        this.repoUuid = repoUuid;
        this.revision = revision;
        this.nodeKind = nodeKind;
        this.schedule = schedule;
        this.lastChangedAuthor = lastChangedAuthor;
        this.lastChangedRev = lastChangedRev;
        this.lastChangedDate = lastChangedDate;
    }

    /**
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }
    /**
     * @param url the url to set
     */
    /**
     * @return the repoRoot
     */
    public String getRepoRoot() {
        return repoRoot;
    }
    /**
     * @param repoRoot the repoRoot to set
     */
    /**
     * @return the repoUuid
     */
    public String getRepoUuid() {
        return repoUuid;
    }
    /**
     * @return the revision
     */
    public String getRevision() {
        return revision;
    }
    /**
     * @return the nodeKind
     */
    public String getNodeKind() {
        return nodeKind;
    }
    /**
     * @return the schedule
     */
    public String getSchedule() {
        return schedule;
    }
    /**
     * @return the lastChangedAuthor
     */
    public String getLastChangedAuthor() {
        return lastChangedAuthor;
    }
    /**
     * @return the lastChangedRev
     */
    public String getLastChangedRev() {
        return lastChangedRev;
    }
    /**
     * @return the lastChangedDate
     */
    public String getLastChangedDate() {
        return lastChangedDate;
    }
    
    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SvnInfo [path=").append(path).append(", url=")
                .append(url).append(", repoRoot=").append(repoRoot)
                .append(", repoUuid=").append(repoUuid).append(", revision=")
                .append(revision).append(", nodeKind=").append(nodeKind)
                .append(", schedule=").append(schedule)
                .append(", lastChangedAuthor=").append(lastChangedAuthor)
                .append(", lastChangedRev=").append(lastChangedRev)
                .append(", lastChangedDate=").append(lastChangedDate)
                .append("]");
        return builder.toString();
    }
}
