package com.wsgc.ecommerce.buildsystem.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Test;


/**
 * Holding pen for test cases with early development of {@link SvnUtil} package.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class SvnUtilitiesTests {

    /**
     * Test our ability to capture "effective revision" of a svn info via {@link SvnUtil#getSvnInfoForURL(String, String, String)}
     * @throws Exception if the test fails
     */
    @Test
    public void testGetEffectiveRevision() throws Exception   {
        String url = "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static/";
        String revision = "150000";
        String effectiveRevision = SvnUtil.getSvnInfoForURL(url, revision,  "4d9f3204-700e-0410-9f00-95bf6548d55c").getLastChangedRev();
        String expectedRevision = "149676";

        assertTrue("Unexpected effectiveRevision returned. Was expecting " + expectedRevision + " but found:" + effectiveRevision,
                effectiveRevision.equals(expectedRevision));
    }
    
    
    /**
     * very light weight test of the {@link SvnUtil #getSvnInfoWorkingCopy(File)} method.
     * @throws Exception if results are unexpected
     */
    @Test 
    public void testGetSvnInfoDirectoryWorkingDir() throws Exception {
        
        SvnInfo svnInfo = SvnUtil.getSvnInfoWorkingCopy(new File("."));
         
        /* should be svn info of this project but I am not going
         *  enforce anything here by asking for validation.
         */
        assertNotNull(svnInfo);
        
    }

    /**
     * Test of {@link SvnUtil#isWorkingDirectory(File)}
     * @throws Exception if test fails
     */
    @Test 
    public void testIsWorkingDir() throws Exception {
       
        File dir = new File(".");
        
        assertTrue("Directory should be a svn working directory. Directory:" + dir.getCanonicalPath(), 
                SvnUtil.isWorkingDirectory(dir));
        
        /*
         * target dirs are seldom under source control. 
         * We don't expect this to work. 
         * 
         */
        dir = new File("target");
        
        assertFalse("Directory should not be a svn working directory. Directory:" + dir.getCanonicalPath(), 
                SvnUtil.isWorkingDirectory(dir));
        
    }
    
}
