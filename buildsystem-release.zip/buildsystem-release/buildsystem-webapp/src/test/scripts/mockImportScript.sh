#!/bin/bash
set -u
set -e

#do nothing.

echo Current Working Directory: "${PWD}"

echo $0 done

