
insert into BUILD_USERS(USER_NAME,USER_DESC,USER_EMAIL,USER_INFO) values ('jpatel','Jigar Patel','jpatel@wsgc.com', 'Jigar Patel user info');
insert into BUILD_USER_ROLES(USER_NAME,ROLE_CONTEXT,ROLE_SET,ROLE_NAME) values ('jigar','*','BUILD', 'DEVELOPER');

