
insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('NONE','New release',0)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('RELEASED','Released by developers',1)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('VQAOK','Approved by Vendor QA',2)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('VQAFAIL','Rejected by Vendor QA',3)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('QAOK','Approved by QA',4)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('QAFAIL','Rejected by QA',5)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('PRDNOK','Approved for production use',6)
;

insert into BUILD_RELEASE_STATES (STATE_NAME, STATE_DESC, STATE_SEQ)
       values ('PRDNREJ','Rejected for production use',7)
;

insert into BUILD_ROLE_SETS (ROLE_SET, ROLE_SET_DESC, ROLE_SET_SEQ)
       values ('SYSTEM', 'Build management system', 1)
;

insert into BUILD_ROLE_SETS (ROLE_SET, ROLE_SET_DESC, ROLE_SET_SEQ)
       values ('BUILD', 'Build release management', 2)
;

insert into BUILD_ROLE_SETS (ROLE_SET, ROLE_SET_DESC, ROLE_SET_SEQ)
       values ('DEPLOY', 'Deployment pool management', 3)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('SYSTEM','ADMINISTRATOR','Build System Administrator',1)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','ADMINISTRATOR','Release Project Administrator',1)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','DEVELOPER','Application Developer',2)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','RELEASEMGR','Development Release Manager',3)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','VQAMGR','Development QA Manager',4)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','QAMGR','QA Manager',5)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','SITEMGR','Site Build Manager',6)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','VIEWONLY','View Only',100)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('BUILD','STATEMAINT','Release State Maintainer',7)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('DEPLOY','ADMINISTRATOR','Deployment Pool Administrator',1)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('DEPLOY','BUILDSELECT','Deployment Pool Build Selector',2)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('DEPLOY','INSTANCEMGR','Instance Manager', 3)
;

insert into BUILD_ROLES (ROLE_SET, ROLE_NAME, ROLE_DESC, ROLE_SEQ)
       values ('DEPLOY','VIEWONLY','View Only',100)
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('NONE','RELEASED','BUILD', 'RELEASEMGR')
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('RELEASED','VQAOK','BUILD', 'VQAMGR')
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('RELEASED','VQAFAIL','BUILD', 'VQAMGR')
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('VQAOK','QAOK','BUILD', 'QAMGR')
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('VQAOK','QAFAIL','BUILD', 'QAMGR')
;

insert into BUILD_RELEASE_STATE_CHANGES (OLD_STATE, NEW_STATE, ROLE_SET, ROLE_NAME)
       values('QAOK','PRDNOK','BUILD', 'SITEMGR')
;



insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('system/adduser','SYSTEM','Add a new user',1)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('system/setpassword','SYSTEM','Set a users password',2)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('system/setroles','SYSTEM','Set a users roles',3)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/view','BUILD','[Null activity - used to make VIEWONLY work]',0)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/makerelease','BUILD','Create a release',1)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/annotaterelease','BUILD','Annotate a release',2)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/labelrelease','BUILD','Label a release',3)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/unlabelrelease','BUILD','Un-label a release',4)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/makebuild','BUILD','Create a build',5)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/labelbuild','BUILD','Label a build',6)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/unlabelbuild','BUILD','Un-label a build',7)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/releasestate','BUILD','Modify the state of a release',8)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('build/setroles','BUILD','Set a users roles for a release',100)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/view','DEPLOY','[Null activity - used to make VIEWONLY work]',0)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/dropserver','DEPLOY','Remove a server (or part thereof) from a pool',20)
;

insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/addbuild','DEPLOY','Add build into a pool',1)
;


insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/removebuild','DEPLOY','Remove a build from a pool',2)
;
---------------------------------------------------------------------------------------------
insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/makeinstance','DEPLOY','Create/Refresh the instance for a pool',3)
;
--------------------------------------------------------------------------------------------
insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/addinstance','DEPLOY','Create new instances for a pool',3)
;
insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/modinstance','DEPLOY','Update the instances for a pool',4)
;
insert into BUILD_ACTIVITIES (ACTIVITY_NAME, ROLE_SET, ACTIVITY_DESC, ACTIVITY_SEQ)
       values('deploy/geninstance','DEPLOY','Generate the instances for a pool',5)
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makerelease','BUILD','DEVELOPER')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makerelease','BUILD','RELEASEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makebuild','BUILD','DEVELOPER')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makebuild','BUILD','RELEASEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makebuild','BUILD','VQAMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makebuild','BUILD','QAMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/makebuild','BUILD','SITEMGR')
;


insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/annotaterelease','BUILD','DEVELOPER')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/annotaterelease','BUILD','RELEASEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/annotaterelease','BUILD','VQAMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/annotaterelease','BUILD','QAMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/annotaterelease','BUILD','SITEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelrelease','BUILD','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelrelease','BUILD','DEVELOPER')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelrelease','BUILD','RELEASEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelrelease','BUILD','SITEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/unlabelrelease','BUILD','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/unlabelrelease','BUILD','SITEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelbuild','BUILD','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelbuild','BUILD','DEVELOPER')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelbuild','BUILD','RELEASEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/labelbuild','BUILD','SITEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/unlabelbuild','BUILD','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/unlabelbuild','BUILD','SITEMGR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/releasestate','BUILD','STATEMAINT')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/setroles','BUILD','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('build/view','BUILD','VIEWONLY')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('system/adduser','SYSTEM','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('system/setpassword','SYSTEM','ADMINISTRATOR')
;

insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
       values('system/setroles','SYSTEM','ADMINISTRATOR')
;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/view','DEPLOY','VIEWONLY')
--;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/dropserver','DEPLOY','ADMINISTRATOR')
--;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/addbuild','DEPLOY','BUILDSELECT')
--;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/removebuild','DEPLOY','BUILDSELECT')
--;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/modinstance','DEPLOY','BUILDSELECT')
--;

--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/makeinstance','DEPLOY','INSTANCEMGR')
--;


--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/newinstance','DEPLOY','INSTANCEMGR')
--;
-- failed


--insert into BUILD_ACTIVITY_ROLES (ACTIVITY_NAME, ROLE_SET, ROLE_NAME)
--       values('deploy/geninstance','DEPLOY','INSTANCEMGR')
--;

insert into BUILD_IDENTIFIERS (IDENTIFIER_TYPE,IDENTIFIER_DATE,IDENTIFIER_SEQ)
       values('cmx-extract',0,0)
;

insert into BUILD_IDENTIFIERS (IDENTIFIER_TYPE,IDENTIFIER_DATE,IDENTIFIER_SEQ)
       values('cmx-release',0,0)
;

insert into BUILD_IDENTIFIERS (IDENTIFIER_TYPE,IDENTIFIER_DATE,IDENTIFIER_SEQ)
       values('cmx-build',0,0)
;

insert into BUILD_IDENTIFIERS (IDENTIFIER_TYPE,IDENTIFIER_DATE,IDENTIFIER_SEQ)
       values('cmx-test',0,0)
;







-- diagnostics

-- select * from BUILD_ACTIVITY_ROLES where ACTIVITY_NAME='deploy/makeinstance';
-- select * from BUILD_ROLES where ROLE_NAME='INSTANCEMGR';
-- select * from ROLE_SET where ROLE_NAME='INSTANCEMGR';
-- select * from ROLE_SET where ROLE_NAME='INSTANCEMGR';

-- "Reset setup_types" script (order is important):
--delete from BUILD_ACTIVITY_ROLES;
--delete from BUILD_RELEASE_STATE_CHANGES;
--delete from BUILD_RELEASE_STATES;
--delete from BUILD_ROLES; 
--delete from BUILD_ACTIVITY_ROLES;
--delete from BUILD_ACTIVITIES;
--delete from BUILD_ROLE_SETS; 
--delete from BUILD_IDENTIFIERS;

-- Clean builds from database (order is important)
--delete from BUILD_RELEASE_EXTRACTS;
--delete from BUILD_RELEASE_STATE_HISTORY;
--delete from BUILD_RELEASE_LOOKUP;
--delete from BUILD_BUILD_ELEMENTS;
--delete from BUILD_BUILD_EXTRACTS;
--delete from BUILD_BUILD_RESULTS;
--delete from BUILD_BUILDS;
--delete from BUILD_RELEASES;


