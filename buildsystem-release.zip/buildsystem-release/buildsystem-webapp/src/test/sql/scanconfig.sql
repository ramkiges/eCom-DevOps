insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('thevault-core','Core repository on TheVault')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('thevault-cspecs','SVN content specs repository on TheVault')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('spectraprod','Spectra production objects')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('sheets','Spreadsheet Repository')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('productimages','Product Image Repository')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('p2productimages','P2 Product Image Repository')
;

insert into BUILD_REPOSITORIES (REPOSITORY_NAME,REPOSITORY_DESC) values ('dpproductimages','DP Product Image Repository')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corecmxtags','thevault-core','cftags/trunk/CORE','Core cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('contentcmxtags','thevault-core','contenttags/trunk','Content cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxtags','thevault-core','cftags/trunk/SITES/WH','Williams-Sonoma Home cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxtags','thevault-core','cftags/trunk/SITES/WS','Williams-Sonoma cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxtags','thevault-core','cftags/trunk/SITES/PB','Pottery Barn cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxtags','thevault-core','cftags/trunk/SITES/PK','Pottery Barn Kids cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxtags','thevault-core','cftags/trunk/SITES/PT','Pottery Barn Teen cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxtags','thevault-core','cftags/trunk/SITES/RI','Reference Implementation cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2tags','thevault-core','cftags/trunk/SITES/WH','Williams-Sonoma Home cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2tags','thevault-core','cftags/trunk/SITES/WS','Williams-Sonoma Home cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2tags','thevault-core','cftags/trunk/SITES/PB','Pottery Barn cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2tags','thevault-core','cftags/trunk/SITES/PK','Pottery Barn Kids cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2tags','thevault-core','cftags/trunk/SITES/PT','Pottery Barn Teen cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admincmxtags','thevault-core','cftags/trunk/SITES/Admin','Admin cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxapp','thevault-core','sites/WH/trunk/webbase','Williams-Sonoma Home application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxapp','thevault-core','sites/WS/trunk/webbase','Williams-Sonoma application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxapp','thevault-core','sites/PB/trunk/webbase','Pottery Barn application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxapp','thevault-core','sites/PK/trunk/webbase','Pottery Barn Kids application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxapp','thevault-core','sites/PT/trunk/webbase','Pottery Barn Teen application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxapp','thevault-core','sites/RI/trunk/webbase','Reference Implementation application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2app','thevault-core','sites/WH/trunk/webbase','Williams-Sonoma Home application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2app','thevault-core','sites/WS/trunk/webbase','Williams-Sonoma application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2app','thevault-core','sites/PB/trunk/webbase','Pottery Barn application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2app','thevault-core','sites/PK/trunk/webbase','Pottery Barn Kids application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2app','thevault-core','sites/PT/trunk/webbase','Pottery Barn Teen application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admincmxapp','thevault-core','sites/Admin/trunk/webbase','Admin application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('commoncmxmessages','thevault-core','common/trunk/messages','Cross-Concept message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('commoncmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxmessages','thevault-core','sites/WH/trunk/content','Williams-Sonoma Home message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whcmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxmisc','thevault-core','sites/WH/trunk/content','Williams-Sonoma Home miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whcmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxmessages','thevault-core','sites/WS/trunk/content','Williams-Sonoma message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wscmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxmisc','thevault-core','sites/WS/trunk/content','Williams-Sonoma miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wscmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxmessages','thevault-core','sites/PB/trunk/content','Pottery Barn message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbcmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxmisc','thevault-core','sites/PB/trunk/content','Pottery Barn miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbcmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxmessages','thevault-core','sites/PK/trunk/content','Pottery Barn Kids message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkcmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxmisc','thevault-core','sites/PK/trunk/content','Pottery Barn Kids miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkcmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxmessages','thevault-core','sites/PT/trunk/content','Pottery Barn Teen message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptcmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxmisc','thevault-core','sites/PT/trunk/content','Pottery Barn Teen miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptcmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxmessages','thevault-core','sites/RI/trunk/content','Reference Implementation message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ricmxmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxmisc','thevault-core','sites/RI/trunk/content','Reference Implementation miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ricmxmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2messages','thevault-core','sites/WH/trunk/content','Williams-Sonoma Home message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2misc','thevault-core','sites/WH/trunk/content','Williams-Sonoma Home miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2messages','thevault-core','sites/WS/trunk/content','Williams-Sonoma message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2misc','thevault-core','sites/WS/trunk/content','Williams-Sonoma miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2messages','thevault-core','sites/PB/trunk/content','Pottery Barn message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2misc','thevault-core','sites/PB/trunk/content','Pottery Barn miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2messages','thevault-core','sites/PK/trunk/content','Pottery Barn Kids message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2misc','thevault-core','sites/PK/trunk/content','Pottery Barn Kids miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2messages','thevault-core','sites/PT/trunk/content','Pottery Barn Teen message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2misc','thevault-core','sites/PT/trunk/content','Pottery Barn Teen miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp2messages','thevault-core','sites/Corpweb/trunk/content/','Corpweb message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corp2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp2misc','thevault-core','sites/Corpweb/trunk/content','Corpweb miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corp2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxprod','thevault-core','sites/WH/trunk/prod','Williams-Sonoma Home production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmxfixedimgs','thevault-core','sites/WH/trunk/images/fixed','Williams-Sonoma Home fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxprod','thevault-core','sites/WS/trunk/prod','Williams-Sonoma production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmxfixedimgs','thevault-core','sites/WS/trunk/images/fixed','Williams-Sonoma fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxprod','thevault-core','sites/PB/trunk/prod','Pottery Barn production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmxfixedimgs','thevault-core','sites/PB/trunk/images/fixed','Pottery Barn fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxprod','thevault-core','sites/PK/trunk/prod','Pottery Barn Kids production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmxfixedimgs','thevault-core','sites/PK/trunk/images/fixed','Pottery Barn Kids fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxprod','thevault-core','sites/PT/trunk/prod','Pottery Barn Teen production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmxfixedimgs','thevault-core','sites/PT/trunk/images/fixed','Pottery Barn Teen fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxprod','thevault-core','sites/RI/trunk/prod','Reference Implementation production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmxfixedimgs','thevault-core','sites/RI/trunk/images/fixed','Reference Implementation fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2prod','thevault-core','sites/WH/trunk/prod','Williams-Sonoma Home production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2fixedimgs','thevault-core','sites/WH/trunk/images/fixed','Williams-Sonoma Home fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2prod','thevault-core','sites/WS/trunk/prod','Williams-Sonoma production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2fixedimgs','thevault-core','sites/WS/trunk/images/fixed','Williams-Sonoma fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2prod','thevault-core','sites/PB/trunk/prod','Pottery Barn production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2fixedimgs','thevault-core','sites/PB/trunk/images/fixed','Pottery Barn fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2prod','thevault-core','sites/PK/trunk/prod','Pottery Barn Kids production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2fixedimgs','thevault-core','sites/PK/trunk/images/fixed','Pottery Barn Kids fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2prod','thevault-core','sites/PT/trunk/prod','Pottery Barn Teen production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2fixedimgs','thevault-core','sites/PT/trunk/images/fixed','Pottery Barn Teen fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp2prod','thevault-core','sites/Corpweb/creative/trunk/prod','Corpweb production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp2fixedimgs','thevault-core','sites/Corpweb/creative/trunk/images/fixed','Corpweb fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('recipes','spectraprod','recipe/','Spectra Recipes')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('tips','spectraprod','tip/','Spectra Tips/Techniques')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whprodloadsheets','sheets','sheets/WH','Williams-Sonoma Home Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whprodloadspecs','thevault-core','sites/WH/trunk/productload','Williams-Sonoma Home Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whprodloadspec2','thevault-cspecs','productload/trunk/WH','Williams-Sonoma Home Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whprodloadimages','productimages','images/WH','Williams-Sonoma Home Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2prodloadsheets','sheets','sheets/WHP2','Williams-Sonoma Home P2 Product Load Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp2prodloadimages','p2productimages','images/WH','Williams-Sonoma Home P2 Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsprodloadsheets','sheets','sheets/WS','Williams-Sonoma Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsprodloadspecs','thevault-core','sites/WS/trunk/productload','Williams-Sonoma Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsprodloadspec2','thevault-cspecs','productload/trunk/WS','Williams-Sonoma Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsprodloadimages','productimages','images/WS','Williams-Sonoma Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2prodloadsheets','sheets','sheets/WSP2','Williams-Sonoma P2 Product Load Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp2prodloadimages','p2productimages','images/WS','Williams-Sonoma P2 Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbprodloadsheets','sheets','sheets/PB','Pottery Barn Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbprodloadspecs','thevault-core','sites/PB/trunk/productload','Pottery Barn Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbprodloadspec2','thevault-cspecs','productload/trunk/PB','Pottery Barn Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbprodloadimages','productimages','images/PB','Pottery Barn Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2prodloadsheets','sheets','sheets/PBP2','Pottery Barn P2 Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp2prodloadimages','p2productimages','images/PB','Pottery Barn P2 Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkprodloadsheets','sheets','sheets/PK','Pottery Barn Kids Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkprodloadspecs','thevault-core','sites/PK/trunk/productload','Pottery Barn Kids Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkprodloadspec2','thevault-cspecs','productload/trunk/PK','Pottery Barn Kids Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkprodloadimages','productimages','images/PK','Pottery Barn Kids Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2prodloadsheets','sheets','sheets/PKP2','Pottery Barn Kids P2 Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp2prodloadimages','p2productimages','images/PK','Pottery Barn Kids P2 Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptprodloadsheets','sheets','sheets/PT','Pottery Barn Teen Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptprodloadspecs','thevault-core','sites/PT/trunk/productload','Pottery Barn Teen Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptprodloadspec2','thevault-cspecs','productload/trunk/PT','Pottery Barn Teen Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptprodloadimages','productimages','images/PT','Pottery Barn Teen Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2prodloadsheets','sheets','sheets/PTP2','Pottery Barn Teen P2 Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp2prodloadimages','p2productimages','images/PT','Pottery Barn Teen P2 Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('riprodloadsheets','sheets','sheets/RI','Reference Implementation Product Spreadsheets')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('riprodloadspecs','thevault-core','sites/RI/trunk/productload','Reference Implementation Product Load Configuration')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('riprodloadspec2','thevault-cspecs','productload/trunk/RI','Reference Implementation Product Load Configuration (CMX2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('riprodloadimages','productimages','images/RI','Reference Implementation Product Load Images')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corecmx2tags','thevault-core','common/cftags/trunk/CORE','Core cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('sharep2tags','thevault-core','common/cftags/trunk/SHARE','Share cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2tags','thevault-core','sites/WH/application/trunk/cftags/SITES/WH','Williams-Sonoma Home cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2tags','thevault-core','sites/WS/application/trunk/cftags/SITES/WS','Williams-Sonoma cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscontentcmx2tags','thevault-core','sites/WS/application/trunk/contenttags','Content cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2tags','thevault-core','sites/PB/application/trunk/cftags/SITES/PB','Pottery Barn cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2tags','thevault-core','sites/PK/application/trunk/cftags/SITES/PK','Pottery Barn Kids cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2tags','thevault-core','sites/PT/application/trunk/cftags/SITES/PT','Pottery Barn Teen cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2tags','thevault-core','sites/RI/application/trunk/cftags/SITES/RI','Reference Implementation cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22tags','thevault-core','sites/WH/application/trunk/cftags/SITES/WH','Williams-Sonoma Home cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22tags','thevault-core','sites/WS/application/trunk/cftags/SITES/WS','Williams-Sonoma cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscontentp22tags','thevault-core','sites/WS/application/trunk/contenttags','Content cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22tags','thevault-core','sites/PB/application/trunk/cftags/SITES/PB','Pottery Barn cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp22tags','thevault-core','sites/Corpweb/application/trunk/cftags/SITES/CORP','Corpweb cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22tags','thevault-core','sites/PK/application/trunk/cftags/SITES/PK','Pottery Barn Kids cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22tags','thevault-core','sites/PT/application/trunk/cftags/SITES/PT','Pottery Barn Teen cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admincmx2tags','thevault-core','sites/Admin/application/trunk/cftags/SITES/Admin','Admin cftags (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('adminp2tags','thevault-core','sites/Admin/application/trunk/cftags/SITES/Admin','Admin cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp2tags','thevault-core','sites/Corpweb/application/trunk/cftags/SITES/CORP','Corpweb cftags (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2app','thevault-core','sites/WH/application/trunk/webbase','Williams-Sonoma Home application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2app','thevault-core','sites/WS/application/trunk/webbase','Williams-Sonoma application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2app','thevault-core','sites/PB/application/trunk/webbase','Pottery Barn application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2app','thevault-core','sites/PK/application/trunk/webbase','Pottery Barn Kids application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2app','thevault-core','sites/PT/application/trunk/webbase','Pottery Barn Teen application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2app','thevault-core','sites/RI/application/trunk/webbase','Reference Implementation application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22app','thevault-core','sites/WH/application/trunk/webbase','Williams-Sonoma Home application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22app','thevault-core','sites/WS/application/trunk/webbase','Williams-Sonoma application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22app','thevault-core','sites/PB/application/trunk/webbase','Pottery Barn application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp22app','thevault-core','sites/Corpweb/application/trunk/webbase','Corpweb application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22app','thevault-core','sites/PK/application/trunk/webbase','Pottery Barn Kids application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22app','thevault-core','sites/PT/application/trunk/webbase','Pottery Barn Teen application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admincmx2app','thevault-core','sites/Admin/application/trunk/webbase','Admin application code (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('adminp2app','thevault-core','sites/Admin/application/trunk/webbase','Admin application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp2app','thevault-core','sites/Corpweb/application/trunk/webbase','Corpweb application code (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2prod','thevault-core','sites/WH/creative/trunk/prod','Williams-Sonoma Home production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2fixedimgs','thevault-core','sites/WH/creative/trunk/images/fixed','Williams-Sonoma Home fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2prod','thevault-core','sites/WS/creative/trunk/prod','Williams-Sonoma production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2fixedimgs','thevault-core','sites/WS/creative/trunk/images/fixed','Williams-Sonoma fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2prod','thevault-core','sites/PB/creative/trunk/prod','Pottery Barn production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2fixedimgs','thevault-core','sites/PB/creative/trunk/images/fixed','Pottery Barn fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2prod','thevault-core','sites/PK/creative/trunk/prod','Pottery Barn Kids production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2fixedimgs','thevault-core','sites/PK/creative/trunk/images/fixed','Pottery Barn Kids fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2prod','thevault-core','sites/PT/creative/trunk/prod','Pottery Barn Teen production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2fixedimgs','thevault-core','sites/PT/creative/trunk/images/fixed','Pottery Barn Teen fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2prod','thevault-core','sites/RI/creative/trunk/prod','Reference Implementation production files (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2fixedimgs','thevault-core','sites/RI/creative/trunk/images/fixed','Reference Implementation fixed images (CMX)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22prod','thevault-core','sites/WH/creative/trunk/prod','Williams-Sonoma Home production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22fixedimgs','thevault-core','sites/WH/creative/trunk/images/fixed','Williams-Sonoma Home fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22prod','thevault-core','sites/WS/creative/trunk/prod','Williams-Sonoma production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22fixedimgs','thevault-core','sites/WS/creative/trunk/images/fixed','Williams-Sonoma fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22prod','thevault-core','sites/PB/creative/trunk/prod','Pottery Barn production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22fixedimgs','thevault-core','sites/PB/creative/trunk/images/fixed','Pottery Barn fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22prod','thevault-core','sites/PK/creative/trunk/prod','Pottery Barn Kids production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22fixedimgs','thevault-core','sites/PK/creative/trunk/images/fixed','Pottery Barn Kids fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22prod','thevault-core','sites/PT/creative/trunk/prod','Pottery Barn Teen production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22fixedimgs','thevault-core','sites/PT/creative/trunk/images/fixed','Pottery Barn Teen fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp22prod','thevault-core','sites/Corpweb/creative/trunk/prod','Corpweb production files (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corp22fixedimgs','thevault-core','sites/Corpweb/creative/trunk/images/fixed','Corpweb fixed images (P2)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('commoncmx2messages','thevault-core','common/messages/trunk','Cross-Concept message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('commoncmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2messages','thevault-core','sites/WH/messages/trunk','Williams-Sonoma Home message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whcmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whcmx2misc','thevault-core','sites/WH/content/trunk','Williams-Sonoma Home miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whcmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2messages','thevault-core','sites/WS/messages/trunk','Williams-Sonoma message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wscmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wscmx2misc','thevault-core','sites/WS/content/trunk','Williams-Sonoma miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wscmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2messages','thevault-core','sites/PB/messages/trunk','Pottery Barn message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbcmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbcmx2misc','thevault-core','sites/PB/content/trunk','Pottery Barn miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbcmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2messages','thevault-core','sites/PK/messages/trunk','Pottery Barn Kids message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkcmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkcmx2misc','thevault-core','sites/PK/content/trunk','Pottery Barn Kids miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkcmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2messages','thevault-core','sites/PT/messages/trunk','Pottery Barn Teen message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptcmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptcmx2misc','thevault-core','sites/PT/content/trunk','Pottery Barn Teen miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptcmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2messages','thevault-core','sites/RI/messages/trunk','Reference Implementation message catalog (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ricmx2messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ricmx2misc','thevault-core','sites/RI/content/trunk','Reference Implementation miscellaneous supporting data (CMX)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ricmx2misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22messages','thevault-core','sites/WH/messages/trunk','Williams-Sonoma Home message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('whp22misc','thevault-core','sites/WH/content/trunk','Williams-Sonoma Home miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('whp22misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22messages','thevault-core','sites/WS/messages/trunk','Williams-Sonoma message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsp22misc','thevault-core','sites/WS/content/trunk','Williams-Sonoma miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsp22misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22messages','thevault-core','sites/PB/messages/trunk','Pottery Barn message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp22messages','thevault-core','sites/Corpweb/messages/trunk','Corpweb message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corpp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbp22misc','thevault-core','sites/PB/content/trunk','Pottery Barn miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbp22misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpp22misc','thevault-core','sites/Corpweb/content/trunk','Corpweb miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corpp22misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22messages','thevault-core','sites/PK/messages/trunk','Pottery Barn Kids message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pkp22misc','thevault-core','sites/PK/content/trunk','Pottery Barn Kids miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pkp22misc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22messages','thevault-core','sites/PT/messages/trunk','Pottery Barn Teen message catalog (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptp22messages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptp22misc','thevault-core','sites/PT/content/trunk','Pottery Barn Teen miscellaneous supporting data (P2)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptp22misc','misc.txt')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('whproductbuild2','Williams-Sonoma Home PRODUCT BUILD (New)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whproductbuild2','whproductbuild2/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whproductbuild2/products','whprodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whproductbuild2/products','whprodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whproductbuild2/products','whprodloadspec2','specs','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('whp2productbuild','Williams-Sonoma Home PRODUCT BUILD (P2)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2productbuild','whp2productbuild/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2productbuild/products','whp2prodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2productbuild/products','whp2prodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2productbuild/products','whprodloadspec2','specs','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('adminp2','Admin (P2)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('adminp2','adminp2/app','Application Code')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('adminp2/app','corecmx2tags','coretags','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('adminp2/app','sharep2tags','sharetags','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('adminp2/app','adminp2tags','apptags','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('adminp2/app','adminp2app','webbase','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('whp2','Williams-Sonoma Home (P2)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2','whp2/commonapp','Common Application Code')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/commonapp','corecmx2tags','coretags','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/commonapp','sharep2tags','sharetags','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2','whp2/siteapp','Site Application Code')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/siteapp','whp22tags','apptags','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/siteapp','whp22app','webbase','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2','whp2/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/prod','whp22prod','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/prod','whp22fixedimgs','fixedimgs','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2','whp2/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/messages','commoncmx2messages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/messages','whp22messages','messages','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('whp2','whp2/misc','Misc Data (Carriers/Shipmethods/Paytypes)')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('whp2/misc','whp22misc','misc','ignore')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admindpcontent','thevault-core','ecommerce/sites/admin/content/trunk/static','Admin Site content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admindpftl','thevault-core','ecommerce/sites/admin/content/trunk/templates','Admin Site Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpdpcontent','thevault-core','ecommerce/sites/corp/content/trunk/static','Corporate Site content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpdpftl','thevault-core','ecommerce/sites/corp/content/trunk/templates','Corporate Site Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpadmindpcontent','thevault-core','ecommerce/sites/corpadmin/content/trunk/static','Corporate Admin Site content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpadmindpftl','thevault-core','ecommerce/sites/corpadmin/content/trunk/templates','Corporate Admin Site Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpcontent','thevault-core','ecommerce/sites/pt/content/trunk/static','Pottery Barn Teen content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpftl','thevault-core','ecommerce/sites/pt/content/trunk/templates','Pottery Barn Teen Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpcontent','thevault-core','ecommerce/sites/pb/content/trunk/static','Pottery Barn content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpftl','thevault-core','ecommerce/sites/pb/content/trunk/templates','Pottery Barn Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpcontent','thevault-core','ecommerce/sites/we/content/trunk/static','West Elm content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpftl','thevault-core','ecommerce/sites/we/content/trunk/templates','West Elm Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpcontent','thevault-core','ecommerce/sites/ws/content/trunk/static','Williams Sonoma content files (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpftl','thevault-core','ecommerce/sites/ws/content/trunk/templates','Williams Sonoma Freemarker templates (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('commondpmessages','thevault-core','ecommerce/sites/common/messages/trunk','Cross-Concept message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('commondpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('admindpmessages','thevault-core','ecommerce/sites/admin/messages/trunk','Admin Site message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('admindpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpdpmessages','thevault-core','ecommerce/sites/corp/messages/trunk','Corporate Site message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corpdpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('corpadmindpmessages','thevault-core','ecommerce/sites/corpadmin/messages/trunk','Corporate Admin Site message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('corpadmindpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpmessages','thevault-core','ecommerce/sites/pt/messages/trunk','Pottery Barn Teen message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptdpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpmisc','thevault-core','ecommerce/sites/pt/misc/trunk','Pottery Barn Teen miscellaneous supporting data (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('ptdpmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpmessages','thevault-core','ecommerce/sites/pb/messages/trunk','Pottery Barn message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbdpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpmisc','thevault-core','ecommerce/sites/pb/misc/trunk','Pottery Barn miscellaneous supporting data (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('pbdpmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpmessages','thevault-core','ecommerce/sites/we/messages/trunk','West Elm message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wedpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpmisc','thevault-core','ecommerce/sites/we/misc/trunk','West Elm miscellaneous supporting data (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wedpmisc','misc.txt')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpmessages','thevault-core','ecommerce/sites/ws/messages/trunk','Williams Sonoma message catalog (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsdpmessages','messages.xml')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpmisc','thevault-core','ecommerce/sites/ws/misc/trunk','Williams Sonoma miscellaneous supporting data (DP)')
;

insert into BUILD_EXTRACT_FILES (EXTRACT_TYPE,EXTRACT_FILE) values ('wsdpmisc','misc.txt')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('admindp','Admin Site (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('admindp','admindp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('admindp/prod','admindpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('admindp/prod','admindpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('admindp','admindp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('admindp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('admindp/messages','admindpmessages','messages','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('corpdp','Corporate Site (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('corpdp','corpdp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpdp/prod','corpdpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpdp/prod','corpdpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('corpdp','corpdp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpdp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpdp/messages','corpdpmessages','messages','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('corpadmindp','Corporate Admin Site (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('corpadmindp','corpadmindp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpadmindp/prod','corpadmindpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpadmindp/prod','corpadmindpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('corpadmindp','corpadmindp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpadmindp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('corpadmindp/messages','corpadmindpmessages','messages','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('ptdp','Pottery Barn Teen (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('ptdp','ptdp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdp/prod','ptdpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdp/prod','ptdpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('ptdp','ptdp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdp/messages','ptdpmessages','messages','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('ptdp','ptdp/misc','Misc Data (Carriers/Shipmethods/Paytypes)')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdp/misc','ptdpmisc','misc','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('pbdp','Pottery Barn (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('pbdp','pbdp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdp/prod','pbdpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdp/prod','pbdpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('pbdp','pbdp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdp/messages','pbdpmessages','messages','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('pbdp','pbdp/misc','Misc Data (Carriers/Shipmethods/Paytypes)')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdp/misc','pbdpmisc','misc','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('wedp','West Elm (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wedp','wedp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedp/prod','wedpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedp/prod','wedpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wedp','wedp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedp/messages','wedpmessages','messages','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wedp','wedp/misc','Misc Data (Carriers/Shipmethods/Paytypes)')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedp/misc','wedpmisc','misc','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('wsdp','William Sonoma (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wsdp','wsdp/prod','Creative Production Content')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdp/prod','wsdpcontent','prod','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdp/prod','wsdpftl','template','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wsdp','wsdp/messages','Common and Site Message Catalog')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdp/messages','commondpmessages','commonmsgs','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdp/messages','wsdpmessages','messages','ignore')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wsdp','wsdp/misc','Misc Data (Carriers/Shipmethods/Paytypes)')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdp/misc','wsdpmisc','misc','ignore')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpprodloadsheets','sheets','sheets/PTDP','Pottery Barn Teen Product Spreadsheets (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpprodloadspec','thevault-cspecs','productload/trunk/PT','Pottery Barn Teen Product Load Configuration (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('ptdpprodloadimages','dpproductimages','images/PT','Pottery Barn Teen Product Load Images (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpprodloadsheets','sheets','sheets/PBDP','Pottery Barn Product Spreadsheets (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpprodloadspec','thevault-cspecs','productload/trunk/PB','Pottery Barn Product Load Configuration (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('pbdpprodloadimages','dpproductimages','images/PB','Pottery Barn Product Load Images (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpprodloadsheets','sheets','sheets/WEDP','West Elm Product Spreadsheets (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpprodloadspec','thevault-cspecs','productload/trunk/WE','West Elm Product Load Configuration (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wedpprodloadimages','dpproductimages','images/WE','West Elm Product Load Images (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpprodloadsheets','sheets','sheets/WSDP','Williams Sonoma Product Spreadsheets (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpprodloadspec','thevault-cspecs','productload/trunk/WS','Williams Sonoma Product Load Configuration (DP)')
;

insert into BUILD_EXTRACT_TYPES (EXTRACT_TYPE,REPOSITORY_NAME,EXTRACT_PATH,EXTRACT_TYPE_DESC) values ('wsdpprodloadimages','dpproductimages','images/WS','Williams Sonoma Product Load Images (DP)')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('ptdpproductbuild','Pottery Barn Teen PRODUCT BUILD (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('ptdpproductbuild','ptdpproductbuild/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdpproductbuild/products','ptdpprodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdpproductbuild/products','ptdpprodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('ptdpproductbuild/products','ptdpprodloadspec','specs','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('pbdpproductbuild','Pottery Barn PRODUCT BUILD (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('pbdpproductbuild','pbdpproductbuild/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdpproductbuild/products','pbdpprodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdpproductbuild/products','pbdpprodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('pbdpproductbuild/products','pbdpprodloadspec','specs','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('wsdpproductbuild','Williams Sonoma PRODUCT BUILD (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wsdpproductbuild','wsdpproductbuild/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdpproductbuild/products','wsdpprodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdpproductbuild/products','wsdpprodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wsdpproductbuild/products','wsdpprodloadspec','specs','ignore')
;

insert into BUILD_PROJECTS (PROJECT_NAME,PROJECT_DESC) values ('wedpproductbuild','West Elm PRODUCT BUILD (DP)')
;

insert into BUILD_BUILD_TYPES (PROJECT_NAME,BUILD_TYPE,BUILD_TYPE_DESC) values ('wedpproductbuild','wedpproductbuild/products','Product Information and Images')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedpproductbuild/products','wedpprodloadsheets','sheets','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedpproductbuild/products','wedpprodloadimages','images','ignore')
;

insert into BUILD_BUILD_TYPE_EXTRACTS (BUILD_TYPE,EXTRACT_TYPE,EXTRACT_ALIAS,RELATIVE_RULE) values ('wedpproductbuild/products','wedpprodloadspec','specs','ignore')
;


-- start over
--delete BUILD_EXTRACT_FILES;
--delete from BUILD_BUILD_TYPE_EXTRACTS;
--delete from BUILD_EXTRACT_TYPES;
--delete from BUILD_REPOSITORIES;
--delete from BUILD_BUILD_TYPES;
--delete from BUILD_PROJECTS;


