/**
 * Contains objects related to the build system webapp, thats one clase at the time of this writting. 
 */
package com.wsgc.ecommerce.buildsystem.webapp;

