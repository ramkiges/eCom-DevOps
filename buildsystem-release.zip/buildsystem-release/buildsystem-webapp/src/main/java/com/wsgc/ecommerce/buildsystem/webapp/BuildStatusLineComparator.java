/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.webapp;

import java.util.Comparator;

/**
 * @author chunt
 * @version $Id$ 
 */
enum BuildStatusLineComparator implements Comparator<BuildStatusLine> {
    BUILD {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return o1.getBuildId().compareTo(o2.getBuildId());
        }
    },
    BUILD_DEC {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return -(o1.getBuildId().compareTo(o2.getBuildId()));
        }
    },
    PROJECT {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return o1.getProjectLabel().compareTo(o2.getProjectLabel());
        }
    },
    PROJECT_DEC {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return -(o1.getProjectLabel().compareTo(o2.getProjectLabel()));
        }
    },    
    USER {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return (o1.getUser().compareTo(o2.getUser()));
        }
    },
    USER_DEC {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return -(o1.getUser().compareTo(o2.getUser()));
        }
    },
    TIME {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return o1.getCompletion().compareTo(o2.getCompletion());
        }
    },
    TIME_DEC {
        @Override
        public int compare(BuildStatusLine o1, BuildStatusLine o2) {
            return -(o1.getCompletion().compareTo(o2.getCompletion()));
        }
    };
    
    /**
     * Comparator inverter but affects multiple sorts as a group so ... not as useful as you might think at first.
     * @param other the {@link Comparator} to invert
     * 
     * @return your inverted {@link Comparator}
     */
    public static Comparator<BuildStatusLine> decending(final Comparator<BuildStatusLine> other) {
        return new Comparator<BuildStatusLine>() {
            public int compare(BuildStatusLine o1, BuildStatusLine o2) {
                return -1 * other.compare(o1, o2);
            }
        };
    }

    /**
     * Combines {@link Comparator}s by applying them in the order given.
     * @param multipleOptions a variable argument list of {@link Comparator}s. Can be an array or sequence of args.
     * @return a Single Comparator instance combining the features of the group.
     */
    public static Comparator<BuildStatusLine> getComparator(final BuildStatusLineComparator... multipleOptions) {
        return new Comparator<BuildStatusLine>() {
            public int compare(BuildStatusLine o1, BuildStatusLine o2) {
                for (BuildStatusLineComparator option : multipleOptions) {
                    int result = option.compare(o1, o2);
                    if (result != 0) {
                        return result;
                    }
                }
                return 0;
            }
        };
    }
}
