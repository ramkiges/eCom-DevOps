
package com.wsgc.ecommerce.buildsystem.webapp;

import com.wsgc.ecommerce.buildsystem.BuildOrder;

/**
 * Hybrid object that can be built from data found in the {@link BuildMonitor} and {@link ArtifactRepositoryView}. This 
 * was a late addition to support the idea of merging what had been the repo view page and the active builds in the build monitor page.
 * It implements Comparable<BuidStatusLine> for a default ordering by build id, but in practice that was replaced by use of a list of 
 * {@link BuildStatusLineComparator} instances for multiple field sorting.
 * 
 * Immutable.
 *
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildStatusLine implements Comparable<BuildStatusLine> {
    private String buildId;
    private String projectLabel;
    private String user;
    private String completion;
    private String status;
    private BuildOrder buildOrder;

    /**
     * @param buildId the build id of your build...duh.
     * @param projectLabel the project label, not to be confused with project id.
     * @param completion some time string
     * @param status the text indicating the state of the build
     * @param user the user on the hook for the build attempt
     * @param buildOrder the DNA of the build.
     */
    public BuildStatusLine(String buildId, String projectLabel, String user, String completion, String status, BuildOrder buildOrder) {
        this.buildId = buildId;
        this.projectLabel = projectLabel;
        this.user = user;
        this.completion = completion;
        this.status = status;
        this.buildOrder = buildOrder;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(BuildStatusLine o) {
        return buildId.compareTo(o.buildId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        BuildStatusLine other = (BuildStatusLine) obj;
        if (buildId == null) {
            if (other.buildId != null) {
                return false;
            }
        } else if (!buildId.equals(other.buildId)) {
            return false;
        }
        return true;
    }
    /**
     * @return the buildId
     */
    public String getBuildId() {
        return buildId;
    }
    /**
     * 
     * TODO bad name, change in rep_view too.
     * @return the completion
     */
    public String getCompletion() {
        return completion;
    }
    /**
     * @return the projectLabel
     */
    public String getProjectLabel() {
        return projectLabel;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @return the buildOrder
     */
    public BuildOrder getBuildOrder() {
        return buildOrder;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildId == null) ? 0 : buildId.hashCode());
        return result;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

}
