package com.wsgc.ecommerce.buildsystem.webapp;


import java.io.IOException;
import java.io.StringWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wsgc.ecommerce.buildsystem.BaseSvnExtract;
import com.wsgc.ecommerce.buildsystem.BuildInfo;
import com.wsgc.ecommerce.buildsystem.BuildMonitor;
import com.wsgc.ecommerce.buildsystem.BuildMonitor.BuildJobStatus;
import com.wsgc.ecommerce.buildsystem.BuildMonitor.JobStatus;
import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.BuildPlan;
import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.buildsystem.BuildService;
import com.wsgc.ecommerce.buildsystem.BuildSystemConfig;
import com.wsgc.ecommerce.buildsystem.ConcreteExtractDefinition;
import com.wsgc.ecommerce.buildsystem.ExtractDefinition;
import com.wsgc.ecommerce.buildsystem.Project;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtract;
import com.wsgc.ecommerce.buildsystem.ServerStatus;
import com.wsgc.ecommerce.buildsystem.SvnConcreteExtractDefinition;
import com.wsgc.ecommerce.buildsystem.SvnExtractDefinition;
import com.wsgc.ecommerce.buildsystem.User;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.exception.BuildStatusException;
import com.wsgc.ecommerce.buildsystem.exception.ExtractException;
import com.wsgc.ecommerce.buildsystem.json.BaseSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildOrderDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildPlanDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildRequestDeserializer;
import com.wsgc.ecommerce.buildsystem.json.ResolvedSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.json.SvnExtractDefinitionDeserializer;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepository;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryView;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryViewer;
import com.wsgc.ecommerce.buildsystem.repository.BuildReference;
import com.wsgc.ecommerce.utilities.json.DefaultJsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;
import com.wsgc.ecommerce.utilities.json.StandardJsonDeserializerConfig;
import com.wsgc.ecommerce.utilities.json.util.JsonJacksonUtilities;

/**
 * 
 * Controller for web app, mapping http requests of the build system to methods that process them.
 * 
 * @author chunt
 * @version $Id$ 
 */
@SuppressWarnings("deprecation")
@Controller
public class BuildController {
    private static final String BRANCH_INITITIALIZED    = "CONCRETE_BRANCH_UNITITIALIZED";
    private static final String REVSION_UNINITIALIZED   =  "CONCRETE_REVSION_UNITITIALIZED";
    private static final String UUID_UNITITIALIZED      =  "CONCRETE_UUID_UNITITIALIZED";

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private BuildService buildService;
    private ArtifactRepository artifactRepository;
    private ArtifactRepositoryViewer repoViewer;

    private BuildSystemConfig buildSystemConfig;
    private ServerStatus serverStatus;
    private BuildMonitor buildMonitor;

    /**
     * Constructor for dependency injection.
     * 
     * @param buildService the {@link BuildService} that does the builds
     * @param buildSystemConfig {@link BuildSystemConfig} that doesn't really do much and is on its way out
     * @param serverStatus {@link ServerStatus} also not used much
     * @param buildMonitor {@link BuildMonitor} used to watch builds in real time
     * @param artifactRepository {@link ArtifactRepository} where your builds end up
     * @throws BuildServiceException for just about everything that could go wrong
     */
    @Autowired
    public BuildController(BuildService buildService,
            BuildSystemConfig buildSystemConfig, ServerStatus serverStatus,
            BuildMonitor buildMonitor,
            ArtifactRepository artifactRepository) throws BuildServiceException {
        this.buildService = buildService;
        this.buildSystemConfig = buildSystemConfig;
        this.serverStatus = serverStatus;
        this.buildMonitor = buildMonitor;
        this.artifactRepository = artifactRepository;
        this.repoViewer = artifactRepository.getViewer();
    }

    /**
     * Services the Build Monitor page. Give a real time view of what is being built and what each of the requests
     * inside the build is up to.
     * 
     * @param purge
     *            if <code>true</code> then the builds that are not in progress are removed from the collection.
     * @return ModelAndView holding the {@link BuildMonitor}
     */
    @RequestMapping(value = "/secure/view/build_monitor")
    public ModelAndView buildMonitor(@RequestParam("purge") String purge) {

        if (purge.equals("true")) {
            buildMonitor.purge();
        }

        ModelAndView mav = new ModelAndView("build_monitor");
        mav.addObject("buildMonitor", buildMonitor);
        return mav;
    }

    /** Process form data and gleans enough information to resolve the extracts and create a build order from everything.
     * 
     * @param httpRequest with the reification data (extract, revision, branch)
     * @param principal the security Principal used for build owner identification
     * @throws BuildServiceException for general build issues
     * @throws IOException if the debugging info has a formatting issue
     * @return ModelAndView holding the {@link BuildOrder}
     */
    @RequestMapping(value = "/secure/build_order", method = RequestMethod.POST) 
    public ModelAndView  buildOrder(HttpServletRequest httpRequest, Principal principal) 
            throws BuildServiceException , IOException {
        String assumedUserEmailName = (principal == null) ? "" : principal.getName() + "@wsgc.com";
        ModelAndView mav = new ModelAndView("build_order"); 

        mav.addObject("userEmail", assumedUserEmailName);
        mav.addObject("notifyOnSuccessButtonState", "");
        mav.addObject("notifyOnFailureButtonState", "");

        //DEBATABLE remove? Seems loved by some.
        StringBuilder info = new StringBuilder("json objects:<br><br>");

        logger.info("In buildOrder");

        @SuppressWarnings("rawtypes")
        Map parameterMap =   httpRequest.getParameterMap();
        String[] projIdparams = (String[]) parameterMap.get("projectId");

        String projectId =  getSingleValue(projIdparams);
        if (projectId == null) {
            throw new BuildServiceException("Project Id not found in form parameters");
        }

        Project project = buildService.getProject(projectId);
        info.append(toJsonPrettyHtmlString(project));


        Map<BuildPlan, ? extends Map<String, ? extends ConcreteExtractDefinition>> concreteMap =
                generateConcreteMapFromForm(parameterMap, project);

        Set<String> buildPlanIds = new HashSet<String>();
        Map<String,  Map<String, ? extends ConcreteExtractDefinition>> concreteMaps =
                new HashMap<String,  Map<String, ? extends ConcreteExtractDefinition>>();

        for (BuildPlan buildPlan : concreteMap.keySet()) {
            concreteMaps.put(buildPlan.getId(), concreteMap.get(buildPlan));
            buildPlanIds.add(buildPlan.getId());
        }

        BuildOrder buildOrder =  buildService.generateBuildOrder(project, buildPlanIds, concreteMaps);

        // needed for direct processing in freemarker logic
        mav.addObject("buildOrder", buildOrder);
        // debugging info
        mav.addObject("prettyBuildOrder", toJsonPrettyHtmlString(buildOrder));        
        // ends up as hidden field in form for processing
        mav.addObject("encodedBuildOrder", encodeHtmlEntity(toJsonString(buildOrder)));
        mav.addObject("info", info);

        mav.addObject("projectId", projectId);
        mav.addObject("buildPlanIds", buildPlanIds);
        mav.addObject("buildMap", concreteMaps);
        return mav;
    }

    /**
     * 
     *  Returns the performance string from a archived build.
     *  Began to be useful, hasn't gone very far.
     * 
     * @deprecated not convinced it is needed at all anymore.
     * 
     * @param buildId the build id of the build you want the performance {@link String} from
     * @param response the performance {@link String}
     * @throws IOException if writer to {@link HttpServletResponse} wants to
     */
    @Deprecated
    @RequestMapping(value = "/secure/build_performance/build_id/{build_id}", 
            method = RequestMethod.GET)
    public void buildPerformance(
            @PathVariable("build_id") final String buildId,
            HttpServletResponse response
            ) throws /*BuildServiceException, ExtractException,*/ IOException {

        BuildReference buildReference =  artifactRepository.getBuildReference(buildId);

        String performanceString = (buildReference == null) ? "" : buildReference.getBuildPerformanceString();

        response.setContentType ("text/html;charset=UTF-8");
        response.getWriter().print(performanceString);

        return;

    }

    /**
     * 
     * Build status will show up in build monitor first. But may not live there long so we check repo too.
     * 
     * NOTE: You will have a bug here unless you keep the synch of the 'its in the monitor, someone purged, its in the
     * repo' state which is currently provided by {@link BuildMonitor #getBuildJobStatus} being synchronized 
     * 
     * 
     * @param buildId the build id you are getting status on
     * @param response {@link HttpServletResponse} to populate with the status
     * @throws IOException if there is trouble writing the response
     * @throws BuildStatusException if there is trouble finding the status
     */
    @RequestMapping(value = "/secure/build_status/build_id/{build_id}", 
            method = RequestMethod.GET)
    public void buildStatus(
            @PathVariable("build_id") final String buildId,
            HttpServletResponse response
            ) throws IOException, BuildStatusException {
        String responseMessage;
        BuildJobStatus status = buildMonitor.getBuildJobStatus(buildId);

        if (status == null) {
            //status = new StandardBuildJobStatus();
            BuildReference ref = artifactRepository.getBuildReference(buildId);

            if (ref != null) {                
                responseMessage = ref.getStatusString();
            } else {
                throw new BuildStatusException("Unable to find status for buildId:" + buildId);
            }
        } else {
            responseMessage = status.getStatus().toString();
        }
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().print(responseMessage);
        logger.debug("Responding to build status request. BuildId:{} status:{}", buildId, responseMessage);

        return;

    }

    /**
     * Helper method to get a json representation across the html barrier. 
     * Should be removed or given power to do a more complete job of converting.
     * 
     * @param string
     *            {@link String} to escape.
     * @return the same {@link String} with the "&quot;" replaced by "
     */
    private String decodeHtmlEntity(String string) {
        String returnString = string.replaceAll("&quot;", "\"");
        return returnString;
    }

    /**
     * Helper method to get a json representation across the html barrier. 
     * Should be removed or given power to do a more complete job of converting.
     * 
     * @param string
     *            {@link String} to escape.
     * @return the same {@link String} with the quotes replaced by &quot;
     */
    private String encodeHtmlEntity(String string) {
        String returnString = string.replaceAll("\"", "&quot;");
        return returnString;
    }


    /**
     * 
     * This is the handler that gets called after the user selects the revision and branch information for all the build plans
     * available for a build. It returns a map of BuildPlan keys to the map of {@link ConcreteExtractDefinition}s for each extract in that 
     * {@link BuildPlan}. 
     * 
     * Having little experience with form processing I found that getting the users choices from the fields in this form
     * took as long as writing the source retrieval code. The later I am not embarrassed by, this piece of code was expected to 
     * be corrected as soon as anyone saw it but no one wanted to mess with it since it 'works'.
     * 
     *   OK.
     *   But someday I would like to know how real front end developers actually would have solved this problem.
     * 
     * @param parameterMap the form fields with the users choices for revision and branch encoded in a hair brained scheme
     * @param project the {@link Project} the {@link BuildPlan} belongs to
     * @return the map of concrete extract definitions
     * @throws BuildServiceException if we lose our way
     */
    private Map<BuildPlan, Map<String, SvnConcreteExtractDefinition>> generateConcreteMapFromForm(
            @SuppressWarnings("rawtypes") Map parameterMap, Project project) throws BuildServiceException {


        Map<BuildPlan, Map<String, SvnConcreteExtractDefinition>> concreteDefinitions =
                new HashMap<BuildPlan, Map<String, SvnConcreteExtractDefinition>>();

        Map<BuildPlan, Map<String, String[]>> buildPlanConcreteConstructorParameters =
                new HashMap<BuildPlan, Map<String, String[]>>();


        /**
        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();
        reificationData.put(EXTRACT_DEF_PB_STATIC_CONTENT,
        new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT, "pb_primary", "154000",
                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
         */


        // For each text input field we encounter
        for (Object inputName : parameterMap.keySet()) {

            //TODO getting params from the revision form input is not done yet.
            if (((String) inputName).contains("/")) {

                String[] inputNameFields = ((String) inputName).split("/");
                //TODO check fields len? what else?
                if (inputNameFields.length != 3) {
                    throw new BuildServiceException("Unexpected number of fields parsing parameter name:"
                            + inputName + " value:" + parameterMap.get(inputName));
                }


                String buildPlanName = inputNameFields[0];
                String extractName = inputNameFields[1];
                String inputType =  inputNameFields[2];
                String extractBranch = null;
                String extractRevision = null;
                String extractUUID = null;

                String inputValue =  getSingleValue((String[]) parameterMap.get(inputName));
                if (inputType.equals("BRANCH")) {
                    extractBranch = (inputValue.isEmpty() ?  ExtractDefinition.TRUNK_MARKER : inputValue);
                } else if (inputType.equals("REVISION")) {
                    extractRevision = (inputValue.isEmpty() ?  ExtractDefinition.HEAD_REVISION_MARKER : inputValue);
                } else {
                    throw new BuildServiceException("Value was expected to be REVISION or BRANCH, value:" + inputType);
                }

                /* we now have part of a concrete definition, either a branch or revision, update collection */
                BuildPlan buildPlan = project.getBuildPlan(buildPlanName);
                if (!buildPlanConcreteConstructorParameters.containsKey(buildPlan)) {
                    Map<String, String[]> newExtractConcreteParameterMap = new HashMap<String, String[]>();
                    buildPlanConcreteConstructorParameters.put(buildPlan, newExtractConcreteParameterMap);
                }

                Map<String, String[]> extractConcreteParameterMap = buildPlanConcreteConstructorParameters.get(buildPlan);
                if (!extractConcreteParameterMap.containsKey(extractName)) {

                    extractUUID = project.getBuildPlan(buildPlan.getId()).getExtractDefinition(extractName).getUuid();

                    extractConcreteParameterMap.put(
                            extractName,
                            new String[] {extractName, BRANCH_INITITIALIZED, REVSION_UNINITIALIZED, extractUUID });
                }

                String[] extractConcreteParameterArray =  extractConcreteParameterMap.get(extractName);

                // Name should be set.
                if (!extractConcreteParameterArray[0].equals(extractName)) {
                    throw new BuildServiceException("Failed to build concrete parameter array, Unexpected name. expected value:" + extractName
                            + " parameter array:" + extractConcreteParameterArray);
                }

                //update other fields with what we see here being parsed.
                if (extractBranch != null) {
                    if (!extractConcreteParameterArray[1].equals(BRANCH_INITITIALIZED)) {
                        throw new BuildServiceException(
                                "Failed to build concrete parameter array. Branch already initialized. "
                                        + "Tried to set:" + extractBranch + " parameter array:"
                                        + extractConcreteParameterArray);
                    }
                    extractConcreteParameterArray[1] = extractBranch;
                } else if (extractRevision != null) {
                    if (!extractConcreteParameterArray[2].equals(REVSION_UNINITIALIZED)) {
                        throw new BuildServiceException(
                                "Failed to build concrete parameter array. Revision already initialized. "
                                        + "Tried to set:" + extractRevision + " parameter array:"
                                        + extractConcreteParameterArray);
                    }
                    extractConcreteParameterArray[2] = extractRevision;
                } else if (extractUUID != null) {
                    if (!extractConcreteParameterArray[3].equals(UUID_UNITITIALIZED)) {
                        throw new BuildServiceException(
                                "Failed to build concrete parameter array. UUID already initialized. "
                                        + "Tried to set:" + extractRevision + " parameter array:"
                                        + extractConcreteParameterArray);
                    }
                    extractConcreteParameterArray[3] = extractUUID;
                }

                // TODO really?
                buildPlanConcreteConstructorParameters.get(buildPlan).put(extractName, extractConcreteParameterArray);

            }
        }

        // We should have all parameter maps as complete as the are gon'na be
        for (BuildPlan buildplan : buildPlanConcreteConstructorParameters.keySet()) {

            Map<String, String[]> buildPlanConcreteConstructorParametersMap =  buildPlanConcreteConstructorParameters.get(buildplan);

            for (String extactName : buildPlanConcreteConstructorParametersMap.keySet()) {
                String[] extractConcreteConstructionParameters = buildPlanConcreteConstructorParametersMap.get(extactName);


                if (extractConcreteConstructionParameters.length != 4
                        || extractConcreteConstructionParameters[0] == null
                        || extractConcreteConstructionParameters[1] == null
                        || extractConcreteConstructionParameters[2] == null
                        || extractConcreteConstructionParameters[3] == null
                        || extractConcreteConstructionParameters[1].equals(BRANCH_INITITIALIZED)
                        || extractConcreteConstructionParameters[2].equals(REVSION_UNINITIALIZED)
                        || extractConcreteConstructionParameters[3].equals(UUID_UNITITIALIZED)
                        ) {
                    throw new BuildServiceException(
                            "Failed to capture construction params for SvnConcreteExtractDefinition. Params:"
                                    + extractConcreteConstructionParameters);
                }
                //TODO passing thought to not forget... follow all transfers of collections and see that everyone is making defensive copies.
                SvnConcreteExtractDefinition svnConcreteExtractDefinition =
                        new SvnConcreteExtractDefinition(extractConcreteConstructionParameters);

                if (!concreteDefinitions.containsKey(buildplan)) {
                    Map<String, SvnConcreteExtractDefinition> newBuildPlanExtractMap = new HashMap<String, SvnConcreteExtractDefinition>();
                    concreteDefinitions.put(buildplan, newBuildPlanExtractMap);
                }
                Map<String, SvnConcreteExtractDefinition> buildPlanExtractMap = concreteDefinitions.get(buildplan);
                if (buildPlanExtractMap.containsKey(extactName)) {
                    throw new BuildServiceException("Duplicate concrete extract definition found. buildplan:" + buildplan
                            + " extract:" + svnConcreteExtractDefinition);
                }

                buildPlanExtractMap.put(extactName, svnConcreteExtractDefinition);

            }
        }

        return concreteDefinitions;
    }

    /**
     * 
     *  Exposes contextPath to templates
     * 
     * @param httpRequest the  {@link HttpServletRequest}
     * @return {@link HttpServletRequest#getContextPath()}
     */
    @ModelAttribute("contextPath")
    public String getContextPath(HttpServletRequest httpRequest) {
        return httpRequest.getContextPath();
    }

    /**
     * Expose request params to templates
     * 
     * @param httpRequest the  {@link HttpServletRequest}
     * @return {@link HttpServletRequest#getParameterMap()}
     */
    @SuppressWarnings("unchecked")
    @ModelAttribute("params")
    public Map<String, String[]> getParams(HttpServletRequest httpRequest) {
        return httpRequest.getParameterMap();
    }

    /**
     * Expose the request to templates
     * 
     * @param httpRequest the  {@link HttpServletRequest}
     * @return {@link HttpServletRequest}
     */
    @ModelAttribute("request")
    public HttpServletRequest getRequest(HttpServletRequest httpRequest) {
        return httpRequest;
    }

    /*
     *    Example:
     *    http://localhost:1024/buildsystem-2.0/build/project/pb_id/plan/all_messages_build_plan/
     *    branch/pb_primary/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c
     */

    /**
     * expose server status to templates
     * 
     * @return {@link ServerStatus} object
     * @deprecated because no one cared
     */
    @Deprecated
    @ModelAttribute("serverStatus")
    public ServerStatus getServerStatus() {
        return serverStatus;
    }

    // 
    //    @RequestMapping(value = "/build/project/{project_id}/branch/{branch}/revision/{revision}/uuid/{uuid}", 
    //            method = RequestMethod.GET)
    //    @Deprecated
    //    public void restfulBuildFromProject(
    //            @PathVariable("project_id") final String projectId,
    //            @PathVariable("branch") String branch,
    //            @PathVariable("revision") String revision,
    //            @PathVariable("uuid") String uuid,
    //            HttpServletResponse response
    //            ) throws BuildServiceException, ExtractException, IOException {
    //
    //        Project project = null;
    //        //Map<String, BuildPlan> buildPlans = null;
    //
    //
    //        project = buildService.getProject(projectId);
    //        //buildPlans = project.getBuildPlans();
    //        
    //        
    //        Map<String, Map<String, ? extends ConcreteExtractDefinition>> allReificationData 
    //            = new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>();
    //        
    //        for (String key : project.getBuildPlans().keySet()) {
    //            allReificationData.putAll(reifyBuildPlanExtracts(project.getBuildPlans().get(key), branch, revision/*, uuid*/));
    //        }  
    //                
    //        
    ////        Map<String, ExtractDefinition> extracts = buildPlan.getExtractDefinitions();
    ////
    ////        
    ////        
    ////        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();         
    ////
    ////        for (String key : extracts.keySet()) {
    ////            ExtractDefinition extract = extracts.get(key);
    ////            reificationData.put(extract.getName(), new SvnConcreteExtractDefinition(extract.getName(), branch, revision, uuid));
    ////        }
    ////        
    ////        Set<String> buildPlans = new HashSet<String>();
    ////        buildPlans.add(planId);
    ////        //See above.
    ////        Map<String, Map<String, ? extends ConcreteExtractDefinition>> resolvedExtracts = 
    ////                new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>();
    ////        // reificationData is definite, but now referred to in a vague way. resolvedExtracts still doesn't know what the hell it is holding.
    ////        // but confusingly you can add to it...
    ////        resolvedExtracts.put(planId, reificationData);
    ////        
    //        // TODO is this a  reificationData or a ResolvedExtract now??? Take a nap and nail this down.
    //        BuildOrder buildOrder = buildService.generateBuildOrder(project, project.getBuildPlans().keySet(), allReificationData);
    //        User restfulUser = new User();
    //        restfulUser.setName("RestUI Builder");
    //
    //        String buildId = buildService.runBuildLater(buildOrder, restfulUser);
    //        response.setContentType ("text/html;charset=UTF-8");
    //        response.getWriter().print(buildId);
    //        
    //        return; 
    //    }

    /**
     * gets the single value from an array that is expected to have one value.
     * @param arrayIn array of {@link String} should actually hold a single value 
     * @return the {@link String} at index 0 
     * @throws BuildServiceException if the array has more than one element
     */
    private String getSingleValue(String[] arrayIn) throws BuildServiceException {

        String[] valueArray = arrayIn;
        if (valueArray.length != 1) {
            throw new BuildServiceException("Unexpected number of fields in array:" + arrayIn);
        }
        String value = valueArray[0];
        return value;
    }


    /**
     * @return the name of the login view.
     */
    @RequestMapping(value = "/login.html", method = RequestMethod.GET)
    public String login() {
        return "login";
    }


    /**
     * Exposes the {@link Project} to the presentation layer. Shows the user the build plans available. 
     * 
     * @param projectId the id of the project you are asking about.
     * @return ModelAndView with the {@link Project} requested.
     * @throws IOException if the debugging info can not be parsed, 
     */
    @RequestMapping(value =  "/secure/project")
    public ModelAndView  project(@RequestParam("projectId") String projectId) throws IOException {
        Project project = buildService.getProject(projectId);
        ModelAndView mav = new ModelAndView("build_plans");

        mav.addObject(project);

        //TODO remove, no one is using this anymore
        StringBuilder info = new StringBuilder("json objects:<br><br>");
        info.append(toJsonPrettyHtmlString(project));
        mav.addObject("info", info.toString());

        return mav;
    }

    /**
     * Shows the list of projects to the user.
     * 
     * @param principal the authenticated user
     * @return {@link ModelAndView} of the projects page
     */
    @RequestMapping(value = "/secure/projects")
    @ModelAttribute("projects")
    public ModelAndView projects(Principal principal) {

        ModelAndView mav = new ModelAndView("projects");

        mav.addObject("projects", buildService.getProjects());
        mav.addObject("userName", (principal == null) ? "null" : principal.getName());

        //TODO remove, its time has passed
        StringBuilder info = new StringBuilder("Debugging info:<br>");
        info.append("Loading project definition library from:");

        mav.addObject("startUpTimeString", serverStatus.getStartUpTime());
        mav.addObject("info", info.toString());

        return mav;
    }

    /**
     * Creates the same map of build plans to resolved extracts extract names to {@link ConcreteExtractDefinition}
     * as {@link BuildController#generateConcreteMapFromForm(Map, Project)} does but is given its reification data
     * from request params rather than form data. 
     * 
     * @see {@link BuildController#generateConcreteMapFromForm(Map, Project)}
     * @param buildPlan the build plan to build with.
     * @param branch the concrete branch to apply to the {@link BuildPlan}s extracts
     * @param revision the concrete revision to apply
     * @return the resolved extract map
     */
    private Map<String, Map<String, ? extends ConcreteExtractDefinition>> reifyBuildPlanExtracts(
            BuildPlan buildPlan, String branch, String revision) {

        Map<String, ExtractDefinition> extracts = buildPlan.getExtractDefinitions();

        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();         

        for (String key : extracts.keySet()) {
            ExtractDefinition extract = extracts.get(key);
            reificationData.put(extract.getName(), new SvnConcreteExtractDefinition(extract.getName(), branch, revision, extract.getUuid()));
        }
        Map<String, Map<String, ? extends ConcreteExtractDefinition>> resolvedExtracts = 
                new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>();
        resolvedExtracts.put(buildPlan.getId(), reificationData);
        return resolvedExtracts;
    }

    /**
     * 
     * We want a set of build status lines that is a fusion of static data from the repo and dynamic data from builds
     * currently underway.
     * 
     * First we query the BuildMonitor for its list of builds currently underway and save the results in a temp buffer
     * knowing they are old news by the time the method returns. Some of these builds may now be finished and will turn
     * up again when we check the repo. Others will be 'in work' for a while.
     * 
     * 
     * Second, we query the repository for builds that have made it through the build cycle now. This may now include
     * some builds we first saw in the build monitor what have now finished. In this case we have duplicates in the two
     * collections.
     * 
     * Now we create our final collection by first adding all the repo results to the final result set and only then we
     * attempt to add the other results we first got from the build monitor.
     * 
     * The way Sets work in java, attempts to add a duplicate entry will be ignored. This means any builds from the repo
     * collection (collected second but added to our return set first) will hold the latest result for that build and any other builds
     * found only found in the monitor collection will be added as well. This dire
     * 
     * Hopefully is better (less error prone) than trying to get 2 separate locks on the build monitor and repo for a
     * single list of builds.
     * 
     * 
     * @param request
     *            the users {@link HttpServletRequest} request, session info as set by your last build effort is used in
     *            this method
     * @param userFilter
     *            {@link String} to filers user results with
     * @param projectFilter
     *            {@link String} to filers project results with
     * @param buildIdFilter
     *            {@link String} to filers user results with
     * @param sortOptions a white space separated list of {@link BuildStatusLineComparator} names
     * @return {@link ModelAndView} of repo_view page
     * @throws ArtifiactRepostitoryException
     *             for problems retrieving repo information
     */
    @RequestMapping(value = "/secure/view/repo_view")
    public ModelAndView repoView(HttpServletRequest request,
            @RequestParam(value = "user_filter", required = false) String userFilter,
            @RequestParam(value = "project_filter", required = false) String projectFilter,
            @RequestParam(value = "build_id_filter", required = false) String buildIdFilter,
            @RequestParam(value = "sort_options", defaultValue = "BUILD_DEC") String sortOptions)
            throws ArtifiactRepostitoryException {
        ModelAndView mav = new ModelAndView("repo_view");
       
        if (request.getSession() != null) {
            HttpSession session = request.getSession(); 
            if (session.getAttribute("buildFailed") != null) {
                mav.addObject("buildFailed", session.getAttribute("buildFailed"));
                session.removeAttribute("buildFailed");
            } 
            if (session.getAttribute("buildStarted") != null) {
                mav.addObject("buildStarted", session.getAttribute("buildStarted"));
                session.removeAttribute("buildStarted");
            } 
        }
        
        //NavigableSet<ArtifactRepositoryView>  selectedViews = repoViewer.getAllViews(buildIdFilter, projectFilter, userFilter);
        
        NavigableSet<BuildStatusLine>  filteredStatusLines = new TreeSet<BuildStatusLine>(); 
        NavigableSet<BuildStatusLine>  filteredStatusLinesBM = new TreeSet<BuildStatusLine>(); 
        NavigableSet<BuildStatusLine>  filteredStatusLinesRepo = new TreeSet<BuildStatusLine>(); 
        

        // We first harvest the build monitor collection, and it is immediately out of date.
        filteredStatusLinesBM.addAll(BuildStatusLineFactory.createAll(buildMonitor.getFilteredBuildJobStatusMap(
                buildIdFilter, projectFilter, userFilter)));

        // Then we grab the info form the repo, this is most current, and either a build is still in the monitor collection or is now
        // in both collections (having moved to Repo since last check).
        filteredStatusLinesRepo.addAll(BuildStatusLineFactory.createAll(repoViewer.getAllViews(buildIdFilter,
                projectFilter, userFilter)));

        // Now we combine the two, in the opposite order they were collected. FIRST the Repo, THEN the monitor
        // collection. If it already is in the Repo group, the
        // attempt to add from the monitor collection will be ignored.
        filteredStatusLines.addAll(filteredStatusLinesRepo);
        filteredStatusLines.addAll(filteredStatusLinesBM);
        
        List<BuildStatusLine> sortedStatusList = new ArrayList<BuildStatusLine>(filteredStatusLines);
        
        if (sortOptions.isEmpty()) {
        
            /* somebody on the front end let a blank variable in.
             * Reset it to a safe value.
             */
            sortOptions = BuildStatusLineComparator.BUILD_DEC.name();
        }
        
        BuildStatusLineComparator[] comparators = parseComparatorList(sortOptions);
        Collections.sort(sortedStatusList, BuildStatusLineComparator.getComparator(comparators));
        mav.addObject("filteredStatusLines", sortedStatusList);
        
        mav.addObject("viewer", repoViewer);
        mav.addObject("allUsers", repoViewer.getAllUsers());
        mav.addObject("allProjectLabels", repoViewer.getAllProjectLabels());
        
          
        mav.addObject("buildMonitor", buildMonitor);

        /** not used
        Map<String, String> orders = new HashMap<String, String>();
        for (ArtifactRepositoryView view : selectedViews) {
            try {
                orders.put(view.getBuildId(), encodeHtmlEntity(toJsonString(view.getBuildOrder())));
            } catch (IOException ioe) {
                logger.error("Error serializing build order", ioe);
            }
        }
        mav.addObject("buildOrders", orders);
        */
        
        return mav;
    }

    /**
     * Helper method to parse and composite a {@link Comparator} from a text string collection of
     * {@link BuildStatusLineComparator} enum names.
     * 
     * @param comparators a whitespace delimited list of the comparators to sort by in order given.
     * @return
     */
    /**
     * Translates a white space delimited {@link String} of {@link BuildStatusLineComparator} names into
     * an array of {@link BuildStatusLineComparator}s
     * 
     * @param comparators the {@link String} to parse
     * @return an array of {@link BuildStatusLineComparator}s
     * 
     */
    private BuildStatusLineComparator[] parseComparatorList(String comparators) {
        
        //String decendingSuffix = "_DEC";
        List<BuildStatusLineComparator> comparatorList = new ArrayList<BuildStatusLineComparator>();
      
        for (String comparatorName : comparators.split("\\s")) {
//            boolean descending = false;
//            if(comparatorName.endsWith(decendingSuffix )){
//                descending = true;
//                comparatorName = comparatorName.substring(0, comparatorName.lastIndexOf(decendingSuffix));
//            }
//            
            BuildStatusLineComparator comparator = BuildStatusLineComparator.valueOf(comparatorName);
//            if(descending) {
//                BuildStatusLineComparator.decending(BuildStatusLineComparator.getComparator(comparator));
//                comparator = comparator.decending(comparator);
//            }
            comparatorList.add(comparator);
        }
        
        return comparatorList.toArray(new BuildStatusLineComparator[0]);
    }

    /** Returns the {@link ModelAndView} populated with the {@link ArtifactRepositoryView} of the requested build id.
     * @param buildId the build to get the view of
     * @return {@link ModelAndView} of the results page
     * @throws ArtifiactRepostitoryException general repo issues
     */
    @RequestMapping(value = "/secure/view/results")
    public ModelAndView  repoViewResults(@RequestParam("buildId") String buildId) throws ArtifiactRepostitoryException {
        //public ModelAndView  repoViewResults() throws ArtifiactRepostitoryException {
        ModelAndView mav = new ModelAndView("repo_view_build");
        mav.addObject("view", repoViewer.getView(buildId));
        return mav;
    }

    
    /**
     * 
     * Just don't use.
     * 
     * @param principal
     *            xx
     * @return xx
     * @throws Exception
     *             xx
     * 
     * @deprecated useful in development for a while, not for production
     * 
     * */
    @SuppressWarnings("unused")
    @Deprecated
    @RequestMapping(value = "/secure/restart")
    public String restart(Principal principal) throws Exception {
        logger.info("Server restart requested by:" + principal.getName());

        /*
         * TODO:
         * 1) create "server going down page" that uses XHTML to poll the server until its back,
         * 2) set up a delayed restart request strategy, queue the restart event and return the page before the server dies.
         */
        String[] command = {"src/test/scripts/restart.sh", buildSystemConfig.getSourcePath() };
        //ProcessUtil.waitForProcess(command);
        return "restart";
    }

    //    @RequestMapping(value = "/build/project/{project_id}/build/{build_id}/plan/{plan_id}/branch/{branch}/revision/{revision}/uuid/{uuid}", 
    //            method = RequestMethod.GET)
    /**
     * 
     * TODO: remove now that the real secure API is working
     * 
     * 
     * @deprecated   early attempt at service API
     * @param projectId xx
     * @param planId  xx
     * @param branch xx
     * @param revision xx
     * @param uuid xx
     * @param response xx
      * @throws BuildServiceException xx
     * @throws ExtractException xx
     * @throws IOException xx
     */
    @Deprecated
    @RequestMapping(value = "/build/project/{project_id}/plan/{plan_id}/branch/{branch}/revision/{revision}/uuid/{uuid}", 
    method = RequestMethod.GET)
    public void restfulBuildFromPlan(
            @PathVariable("project_id") final String projectId,
            //@PathVariable("build_id") String buildId,
            @PathVariable("plan_id") String planId,
            @PathVariable("branch") String branch,
            @PathVariable("revision") String revision,
            @PathVariable("uuid") String uuid,
            HttpServletResponse response
            ) throws BuildServiceException, ExtractException, IOException {

        Project project = null;
        BuildPlan buildPlan = null;


        project = buildService.getProject(projectId);
        buildPlan = project.getBuildPlan(planId);

        Set<String> buildPlanIds = new HashSet<String>();
        buildPlanIds.add(planId);

        // Map(buildPlanId, Map(ExtractId, concrete extract)
        Map<String, Map<String, ? extends ConcreteExtractDefinition>> buildPlanReificationData = 
                reifyBuildPlanExtracts(buildPlan, branch, revision/*, uuid*/);

        //        
        //        Map<String, ExtractDefinition> extracts = buildPlan.getExtractDefinitions();
        //        
        //        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();         
        //
        //        for (String key : extracts.keySet()) {
        //            ExtractDefinition extract = extracts.get(key);
        //            reificationData.put(extract.getName(), new SvnConcreteExtractDefinition(extract.getName(), branch, revision, uuid));
        //        }
        //        
        //        Set<String> buildPlans = new HashSet<String>();
        //        buildPlans.add(planId);
        //        //See above.
        //        Map<String, Map<String, ? extends ConcreteExtractDefinition>> resolvedExtracts = 
        //                new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>();
        //        // reificationData is definite, but now referred to in a vague way. resolvedExtracts still doesn't know what the hell it is holding.
        //        // but confusingly you can add to it...
        //        resolvedExtracts.put(planId, reificationData);
        //        

        BuildOrder buildOrder = buildService.generateBuildOrder(project, buildPlanIds, buildPlanReificationData);
        User restfulUser = new User();
        restfulUser.setName("RestUI Builder");

        String buildId = buildService.runBuildLater(buildOrder, restfulUser);
        response.setContentType ("text/html;charset=UTF-8");
        response.getWriter().print(buildId);

        return; 
    }

    /**
     * Returns the page used to specify the branch and revision for each build plan in a project.
     * 
     * TODO: remove debugging
     * 
     * @param projectId the project the build belongs to 
     * @param buildPlans an array of {@link String} holding build plan ids.
     * @return the {@link ModelAndView} populated with the {@link Project} and a List of {@link BuildPlan}s
     * 
     * @throws BuildServiceException trouble looking up info for the project
     * @throws IOException if optional debugging formatting goes badly
     */
    @RequestMapping(value = "/secure/revisions", method = RequestMethod.POST)
    public  ModelAndView  revisions(@RequestParam("projectId") String projectId,
            @RequestParam("buildPlans") String[] buildPlans) throws BuildServiceException, IOException {
        //logger.info("In revisions, projectId " + projectId + "  buildPlans = " + buildPlans);

        ModelAndView mav = new ModelAndView("revisions");

        Project project = buildService.getProject(projectId);
        List<BuildPlan> buildPlansList = new ArrayList<BuildPlan>();

        for (String buildPlan : buildPlans) {
            buildPlansList.add(project.getBuildPlan(buildPlan));
        }

        mav.addObject("project", project);
        mav.addObject("buildPlansList", buildPlansList);


        StringBuilder info = new StringBuilder("json objects:<br><br>");
        info.append(toJsonPrettyHtmlString(project));

        for (BuildPlan buildPlan : buildPlansList) {
            info.append(toJsonPrettyHtmlString(buildPlan));
        }

        mav.addObject("info", info.toString());

        return mav;
    }

    /**
     * Displays the index page.
     * 
     * TODO: is this even accessible anymore?
     * 
     * @return {@link ModelAndView} populated with a {@link BuildSystemConfig} object.
     */
    @RequestMapping(value = "/")
    public ModelAndView  root() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("buildSystemConfig", buildSystemConfig);
        return mav;
    }


    /**
     * Runs the build via info from the UI.
     * 
     * TODO: we accept a single email here, other places seem to allow a collection of names.
     * 
     * 
     * @param request {@link HttpServletRequest} the users request
     * @param mailTo email address to notify.
     * @param encodedBuildOrderFormInput the entire {@link BuildOrder} serialized as a {@link String}
     * @param notifyFail flag if user expects email notification in the event of a failure.
     * @param notifySuccess flag if user expects email notification in the event of success
     * @param force flag if user wants to force a new build even if an equivalent one exists
     * @param principal the {@link Principal} user who made the build
     * @param isUIRequest    TODO: unknown, Ray has added magic and we should attend to that lesson.
     * @return view of the result. Could be an error, and existing build or a new build.
     * @throws Exception for unexpected errors
     */ 
    @RequestMapping(value = "/secure/run_build", method = RequestMethod.POST)
    public ModelAndView  runBuild(
            HttpServletRequest request,
            @RequestParam("encodedBuildOrderFormInput") String encodedBuildOrderFormInput,
            @RequestParam(value = "mail_to",  required = false) String mailTo,
            @RequestParam(value = "notify_fail",  required = false) String notifyFail,
            @RequestParam(value = "notify_success", required = false) String notifySuccess,
            @RequestParam("force") String force,
            @RequestParam(value = "isUIRequest", required = false) boolean isUIRequest,
            Principal principal) throws Exception {
        StringBuilder info = new StringBuilder("json objects:<br><br>");

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();
        dConfig.registerDeserializer(BuildOrder.ENTITY_TYPE_ID, new BuildOrderDeserializer());
        dConfig.registerDeserializer(BuildPlan.ENTITY_TYPE_ID, new BuildPlanDeserializer());
        dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer());
        dConfig.registerDeserializer(BuildRequest.ENTITY_TYPE_ID, new BuildRequestDeserializer());
        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer());
        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer());

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);
        JsonFactory jsonFactory = new JsonFactory();

        // This is a debugging animal and everyone is afraid to get rid of it for some reason.
        String buildOrderJson = decodeHtmlEntity(encodedBuildOrderFormInput);
        JsonParser parser = null;
        BuildOrder buildOrder = null;

        parser = jsonFactory.createJsonParser(buildOrderJson);
        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        buildOrder = jsonIn.readObject(BuildOrder.class);
        jsonIn.close();
        info.append(toJsonPrettyHtmlString(buildOrder));
        User user = new User();

        //If security is disabled, principal is null. 
        user.setName((principal == null) ? "null" : principal.getName());
        ModelAndView mav = new ModelAndView();
        mav.addObject("userBuildOrder", buildOrder);
        mav.addObject("encodedBuildOrder", encodeHtmlEntity(toJsonString(buildOrder)));

        mav.addObject("userEmail", mailTo);
        mav.addObject("notifyOnSuccessButtonState", "");
        mav.addObject("notifyOnFailureButtonState", "");

        if (notifySuccess != null && notifySuccess.toLowerCase().equals("true")) {
            user.setNotifyOnSuccess(true);
            mav.addObject("notifyOnSuccessButtonState", "checked");
        }

        if (notifyFail != null && notifyFail.toLowerCase().equals("true")) {
            user.setNotifyOnFail(true);
            mav.addObject("notifyOnFailureButtonState", "checked");
        }
        if ((notifySuccess != null) || (notifyFail != null)) {
            user.addNotificationEmail(mailTo);

        }

        // from repoView...
        mav.addObject("viewer", repoViewer);
        mav.addObject("artifactRepositoryViews", repoViewer.getAllViews());
        mav.addObject("allUsers", repoViewer.getAllUsers());
        mav.addObject("allProjectLabels", repoViewer.getAllProjectLabels());
         
        mav.addObject("buildMonitor", buildMonitor);
        Map<String, String> orders = new HashMap<String, String>();
        for (ArtifactRepositoryView view : repoViewer.getAllViews()) {
            try {
                orders.put(view.getBuildId(), encodeHtmlEntity(toJsonString(view.getBuildOrder())));
            } catch (IOException ioe) {
                logger.error("Error serializing build order", ioe);
            }
        }
        mav.addObject("buildOrders", orders);

        if (artifactRepository.hasBuild(new BuildInfo(buildOrder, user)) && !force.equals("true")) {
            mav.setViewName("build_found");
            ArtifactRepositoryViewer viewer = artifactRepository.getViewer();
            mav.addObject("artifactRepoViews", viewer.getViews(buildOrder));
            mav.addObject("buildMessage", "Builds with this signature are already found in the repository.");

        } else {

            try {
               
                //BuildReference buildReference = buildService.runBuild(buildOrder, user);
                String buildId = buildService.runBuildLater(buildOrder, user);
                
                if (user.isNotifyOnSuccess()) {
                    mav.addObject("emailSentMessage", "Email notification of successful will build sent.");
                }

                //ArtifactRepositoryView  repoView = buildService.getRepositoryView(buildReference);
                //mav.setViewName("build_view");      

                //TODO this should not be set here in the end
                //                mav.addObject("buildMessage", "This build was found in artifact repository.");
                String buildMessage = "Your build '" + buildId + "' has been scheduled for processing."
                        // an optimistic deduction here... every other way to handle it was worse and time consuming to look at.
                        + (user.isNotifyOnSuccess() ? " Confirmation email was requested." : " Confirmation email was not requested.");
                Map<String, Object> buildStatus = new HashMap<String, Object>();
                buildStatus.put("buildMessage", buildMessage);
                buildStatus.put("buildId", buildId);
                
                // not used anyway
                //buildStatus.put("repoView", repoView);
                //mav.addObject("buildRequests", buildRequests);
               
                //maybe used
                //mav.addObject("repoBuildOrderJSON", repoView.getBuildOrderJSON());
                
                //buildStatus.put("user", repoView.getUser());
                //buildStatus.put("Buildend:", repoView.getEnd());
                //buildStatus.put("Buildstatus:", repoView.getBuildStatus());
                //buildStatus.put("buildLocation", repoView.getBuildLocation());
                //String manifestString = repoView.getManifestAsString();
                //buildStatus.put("manifestContents", manifestString);
                if (isUIRequest) {
                    request.getSession().setAttribute("buildStarted", buildStatus);
                    mav.clear();
                    mav.setViewName("redirect:/secure/view/repo_view");
                } else {
                    mav.addAllObjects(buildStatus);
                }
            } catch (BuildServiceException buildServiceException) {
                if (isUIRequest) {
                    mav.clear();
                    mav.setViewName("redirect:/secure/view/repo_view");
                    request.getSession().setAttribute("buildFailed", buildServiceException);

                } else {
                    // TODO someday..
                    //                mav.setViewName("build_view_failed");
                    //                /*
                    //                 *  TODO most likely if the name is the same as the object you can probably use mav.addObject(object) no?
                    //                 *  If so ... clean up with that in mind.
                    //                 */
                    //                mav.addObject(buildServiceException);
                    //                return mav;
                    // for now the 500 page is a better error dump, just rethrow
                    throw buildServiceException;
                }
            }
        }
        return mav;
    }


    /**
     * This is the URL the continuous build system uses to trigger builds. Currently don't have the ability to specify
     * arbitrary build plan collections with individual revision and branch specs. It will schedule a build on another
     * thread and return the build number that was generated by writing to the {@link HttpServletResponse} is to
     * directly as "text/html;charset=UTF-8" . It is up to the caller to determine status of the build, when it is
     * finished and if it was successful.
     * 
     * @param projectId
     *            the project id of your build
     * @param buildPlan
     *            a single build plan, optional, if missing, all build plans for your project will be built
     * @param branch
     *            the branch for this whole build
     * @param revision
     *            the revision for this whole build
     * @param force
     *            if <code>true</code> a new build will be made even if an existing one is equivalent
     * @param principal
     *            the user who triggered this build
     * @param response
     *            the {@link HttpServletResponse}
     * @throws BuildServiceException for things like 'bad project id' and over all orchestration errors
     * @throws IOException for trouble modifying the {@link HttpServletResponse}
     * @throws ArtifiactRepostitoryException for exceptions when looking up existing builds
     */
    @RequestMapping(value =  "/secure/build_project/{project_id}", method = RequestMethod.POST)
    public void runSecureBuildService(
            @PathVariable("project_id") final String projectId,
            //todo: defaults to 'build all"
            @RequestParam(value = "buildPlan", required = false, defaultValue = "") String buildPlan,
            @RequestParam(value = "branch", required = false, defaultValue = ExtractDefinition.TRUNK_MARKER) String branch,
            //defaults to 'head'
            @RequestParam(value = "revision", required = false, defaultValue = ExtractDefinition.HEAD_REVISION_MARKER) String revision,
            @RequestParam(value = "force", required = false, defaultValue = "false") String force,
            Principal principal,
            HttpServletResponse response
            ) throws BuildServiceException, ArtifiactRepostitoryException, IOException {

        User restfulUser = new User();
        restfulUser.setName((principal == null) ? "null" : principal.getName());
        String buildId = null;

        Project project = buildService.getProject(projectId);

        if (project == null) {
            throw new BuildServiceException("Unknown project requested. Project id: '" + projectId + "'");
        }

        Set<String> buildPlanIds = null;
        //different from the others, I got rid of the default string to specify 'build all".  
        if ((buildPlan == null) || buildPlan.isEmpty()) {
            buildPlanIds = project.getBuildPlans().keySet();
        } else {
            buildPlanIds = new HashSet<String>();
            buildPlanIds.add(buildPlan);
        }

        Map<String, Map<String, ? extends ConcreteExtractDefinition>> allBuildPlanReificationData = 
                new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>(); 

        for (String buildPlanId : buildPlanIds) {
            Map<String, Map<String, ? extends ConcreteExtractDefinition>> buildPlanReificationData = 
                    reifyBuildPlanExtracts(project.getBuildPlan(buildPlanId), branch, revision);
            allBuildPlanReificationData.putAll(buildPlanReificationData);
        }

        BuildOrder buildOrder = buildService.generateBuildOrder(project, buildPlanIds, allBuildPlanReificationData);

        if (!force.equals("true")) {
            Set<BuildReference> matchingBuilds = artifactRepository.getBuildReferences(buildOrder); 
            if (matchingBuilds.size() > 0) {
                long latestBuildTime = 0;
                for (BuildReference ref : matchingBuilds) {

                    if (!ref.getStatusString().equals(JobStatus.SUCCEEDED.toString())) {
                        continue;
                    }

                    if (latestBuildTime  < ref.getCompletionTimestamp()) {
                        latestBuildTime = ref.getCompletionTimestamp();
                        buildId = ref.getBuildId();
                        logger.debug("Found newer existing build to satisfy build request. BuildId:{} completionTimestamp:{}",
                                buildId, ref.getCompletionTimestamp());
                    }
                } 
            } 
        } 

        if (buildId == null) {
            logger.debug("No existing builds match, running new build order");
            buildId = buildService.runBuildLater(buildOrder, restfulUser);
        }

        response.setContentType ("text/html;charset=UTF-8");
        response.getWriter().print(buildId);

        return; 
    }
    //
    //    @RequestMapping(value =  "/build_project/{project_id}", method = RequestMethod.POST)
    //    public void runBuildService(
    //            @PathVariable("project_id") final String projectId,
    //            //defaults to 'build all"
    //            @RequestParam("buildPlan") String planId,
    //            // defaults to 'trunk'
    //            @RequestParam("branch") String branch,
    //            //defaults to 'head'
    //            @RequestParam("revision") String revision,
    //            // TODO take out?
    //           // @RequestParam("uuid") String uuid,
    //            @RequestParam("force") String force,
    //            HttpServletResponse response
    //            ) throws BuildServiceException, ExtractException, IOException, ArtifiactRepostitoryException {
    //
    //        //TODO, remove.
    //        User restfulUser = new User();
    //        restfulUser.setName("Build Service Anonymous User");
    //        String buildId = null;
    //        
    //        Project project = buildService.getProject(projectId);
    //
    //        if ((branch == null) || branch.isEmpty()) {
    //            branch = ExtractDefinition.TRUNK_MARKER;
    //        }
    //
    //        if ((revision == null) || revision.isEmpty()) {
    //            revision = ExtractDefinition.HEAD_REVISION_MARKER;
    //        }
    //        
    //        Set<String> buildPlanIds = null;
    //        //
    //        if ((planId == null) || planId.isEmpty()) {
    //            buildPlanIds = project.getBuildPlans().keySet();
    //        } else {
    //            buildPlanIds = new HashSet<String>();
    //            buildPlanIds.add(planId);
    //        }
    //
    //        Map<String, Map<String, ? extends ConcreteExtractDefinition>> allBuildPlanReificationData = 
    //                new HashMap<String, Map<String, ? extends ConcreteExtractDefinition>>(); 
    //
    //        for (String buildPlanId : buildPlanIds) {
    //            Map<String, Map<String, ? extends ConcreteExtractDefinition>> buildPlanReificationData = 
    //                    reifyBuildPlanExtracts(project.getBuildPlan(buildPlanId), branch, revision);
    //            allBuildPlanReificationData.putAll(buildPlanReificationData);
    //        }
    //
    //        BuildOrder buildOrder = buildService.generateBuildOrder(project, buildPlanIds, allBuildPlanReificationData);
    //        logger.debug("Force build flag:" + force);
    //        
    //        if (!force.equals("true")) {
    //            Set<BuildReference> matchingBuilds = artifactRepository.getBuildOrders(buildOrder); 
    //            if (matchingBuilds.size() > 0) {
    //                long latestBuildTime = 0;
    //                for (BuildReference ref : matchingBuilds) {
    //                    
    //                    if (!ref.getStatusString().equals(JobStatus.SUCCEEDED.toString())) {
    //                        continue;
    //                    }
    //                    
    //                    if (latestBuildTime  < ref.getCompletionTimestamp()) {
    //                        latestBuildTime = ref.getCompletionTimestamp();
    //                        buildId = ref.getBuildId();
    //                        if (logger.isDebugEnabled()) {
    //                            logger.debug("Found newer existing build to satisfy build request. BuildId:" + buildId 
    //                                    + " completionTimestamp:" + ref.getCompletionTimestamp());
    //                        }
    //                    }
    //                } 
    //            } 
    //            logger.debug("Existing build found, buildId" + buildId);
    //        }
    //        if (buildId == null) {
    //            logger.debug("Creating new build.");
    //            buildId = buildService.runBuildLater(buildOrder, restfulUser);
    //        }
    //
    //        response.setContentType ("text/html;charset=UTF-8");
    //        response.getWriter().print(buildId);
    //
    //        return; 
    //    }

    /*
     * Process test mail form.
     */
//    @RequestMapping(value = "/secure/send_test_mail")
//    @Deprecated
//    public ModelAndView sendMail(Principal principal) throws Exception {
//
//        String fromAddress = principal.getName() + "@wsgc.com";
//        Collection<String> toAddresses = new ArrayList<String>();
//        toAddresses.add(fromAddress);
//
//        String subject  =  "You have received a test message from the Build System.";
//        //String body     =  "This is the body of your message.";
//
//        //TODO for debugging only.
//        //        StringBuilder sb = new StringBuilder();
//        //        for (String address : toAddresses) {
//        //            sb.append(address).append(", ");
//        //        }
//        //
//        //        logger.info("NOT Sending email message from:" + fromAddress + " to: " + sb.toString()
//        //                +  " subject:" + subject);
//        //.sendMessage(fromAddress, toAddresses, subject, body);
//
//        // TODO message sent page
//        ModelAndView mav = new ModelAndView("index");
//        mav.addObject("buildSystemConfig", buildSystemConfig);
//        mav.addObject("serverStatus", serverStatus);
//        return mav;
//    }

    /**
     * @param buildMonitor the buildMonitor to set
     */
    public void setBuildMonitor(BuildMonitor buildMonitor) {
        this.buildMonitor = buildMonitor;
    }



    /**
     * @param buildService the buildService to set
     */
    public void setBuildService(BuildService buildService) {
        this.buildService = buildService;
    }

    /**
     * @param buildSystemConfig the buildSystemConfig to set
     */
    public void setBuildSystemConfig(BuildSystemConfig buildSystemConfig) {
        this.buildSystemConfig = buildSystemConfig;
    }


    /**
     * @param serverStatus the serverStatus to set
     * @deprecated never found to be useful
     */
    @Deprecated
    public void setServerStatus(ServerStatus serverStatus) {
        this.serverStatus = serverStatus;
    }

    /**
     * @deprecated uses obsolete methods, not intended for production
     * @param principal
     *            xx
     * @return xx
     * @throws Exception
     *             xx
     */
    @SuppressWarnings("unused")
    @Deprecated
    @RequestMapping(value = "/secure/syncwebapp")
    public String syncwebapp(Principal principal) throws Exception {
        logger.info("Server source code refresh, build and restart requested by:" + principal.getName());
        String[] command = {"src/test/scripts/syncwebapp.sh"};
        //ProcessUtil.waitForProcess(command);
        return "restartPage";
    }

//    //TODO clean up these mapping -> method names
//    @RequestMapping(value = "/todo")
//    public String  todo() {
//        return "todo";
//    }

    /**
     * Another helper used in debugging strings
     * 
     * @deprecated probably has outlived its usefulness
     * @param object a {@link JsonObjectEntity} to turn in to a pretty {@link String}
     * @return the formatted json representation of the object
     * @throws IOException if the json libraries are upset with the idea
     */
    @Deprecated
    private String toJsonPrettyHtmlString(JsonObjectEntity object) throws IOException {
        String returnString = "<b>" + object.getEntityTypeId() + ":</b><br><pre>" + toJsonString(object) + "</pre>";
        return returnString;
    }

    /**
     * Helper to serialize a {@link JsonObjectEntity} to a {@link String}
     * @param object the object to serialize
     * @return the json {@link String} representation of the object
     * @throws IOException if the json libraries get upset by something
     */
    private String toJsonString(JsonObjectEntity object) throws IOException {
        StringWriter stringWriterOut = new StringWriter();
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(stringWriterOut);
        jsonGen.useDefaultPrettyPrinter();

        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
        jsonOut.writeObject(object);

        jsonOut.close();
        stringWriterOut.close();
        return stringWriterOut.toString();
    }
}
