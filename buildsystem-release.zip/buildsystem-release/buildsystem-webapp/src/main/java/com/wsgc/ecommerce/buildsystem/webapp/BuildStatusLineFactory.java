package com.wsgc.ecommerce.buildsystem.webapp;

import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;


import com.wsgc.ecommerce.buildsystem.BuildMonitor.BuildJobStatus;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryView;

/**
 * 
 * Class factory to create a {@link BuildStatusLine} from wildly unrelated raw materials.
 * 
 * @author chunt
 * @version $Id$ 
 */
public final class BuildStatusLineFactory {

    /**
     * Private constructor.
     */
    private BuildStatusLineFactory() {
        throw new IllegalAccessError("Utility class does not need instantiation.");
    }

    /**
     * @param views
     *            a Set of {@link ArtifactRepositoryView} to convert in to an equal number of {@link BuildStatusLine}
     *            held in a {@link NavigableSet} that uses the {@link BuildStatusLine} internal comparator. This set is
     *            often converted further with sorting on multiple fields if you want other than build id sorting.
     * @return {@link NavigableSet} of {@link BuildStatusLine}
     * @throws ArtifiactRepostitoryException
     *             if the build order held by the ArtifactRepositoryView can not be deserialized...sigh
     */
    public static NavigableSet<BuildStatusLine> createAll(Set<ArtifactRepositoryView> views) throws ArtifiactRepostitoryException {
        NavigableSet<BuildStatusLine> buildStatusLines = new TreeSet<BuildStatusLine>();
  
        for (ArtifactRepositoryView view : views) {
            BuildStatusLine buildStatusLine = new BuildStatusLine(view.getBuildId(), 
                    view.getBuildOrder().getProjectLabel(), view.getUser(), view.getEnd(), view.getBuildStatus(), view.getBuildOrder());
            buildStatusLines.add(buildStatusLine);

        }
        
        return buildStatusLines;
    }

    /**
     * Factory method to create a {@link BuildStatusLine} from the elements obtainable from current builds reported by at {@link BuildMonitor} 
     * 
     * @param buildJobStatusMap the map of build ids and their status.
     * @return a {@link NavigableSet} sorted by ordering according to {@link BuildStatusLine} 
     */
    public static NavigableSet<BuildStatusLine> createAll(
            Map<String, ? extends  BuildJobStatus> buildJobStatusMap) {
        
        NavigableSet<BuildStatusLine> buildStatusLines = new TreeSet<BuildStatusLine>();
        
        for (Entry<String, ? extends BuildJobStatus> entry : buildJobStatusMap.entrySet()) {
            BuildStatusLine buildStatusLine = new BuildStatusLine(entry.getKey(), entry.getValue().getProjectLabel(), entry.getValue().getUser(),
                    /*entry.getValue().getTimestamp()*/ "", entry.getValue().getStatus().toString(), null);
            buildStatusLines.add(buildStatusLine);
            
        }
        
        return buildStatusLines;
    }

}
