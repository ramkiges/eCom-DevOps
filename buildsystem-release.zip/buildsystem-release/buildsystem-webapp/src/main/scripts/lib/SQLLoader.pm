package SQLLoader;

sub Create_SQLLDR_Line
{
    my (@data) = @_;
    my ($rec) = "";
    for $d (@data) {
	if ($d =~ /[^a-zA-Z0-9_]/) {
	    $d =~ s/\"/\"\"/gs;
	    $rec .= "\"$d\",";
	} else {
	    $rec .= "$d,";
	}
    }
    $rec .= "\n";
    my ($reclen) = length($rec);
    $reclen=substr("00000$reclen",-5);
    return $reclen . $rec;
}

1;











