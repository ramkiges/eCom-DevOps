package BuildUtils;

use Digest::MD5;

sub makePathAbsolute($)
{
    my ($p) = @_;
    if (!defined($p)) { return $p; }
    unless ($p =~ m:^/:) {$p = "/" . $p;}
    unless ($p =~ m:/$:) {$p = $p . "/";}
    return $p;
}

sub checkedSystem(@)
{
    my ($ret) = system(@_);
    if ($ret != 0) {
	die("Command '",join(" ",@_),"' returned $ret");
    }
}

sub uncheckedSystem(@)
{
    my ($ret) = system(@_);
}

sub checkedRemove($)
{
    my ($file) = @_;
    unless ($file =~ m:^/:) {die("checkedRemove called with relative path!");}
    return if (! -e $file);
    my ($ret) = checkedSystem('rm','-rf',$file);
    if (-e $file) {die("Attempt to remove '$file' failed.");}
}

sub makeDirectory($);

sub makeDirectory($)
{
    my ($path) = @_;
    return if (-d $path);
    return if ($path eq '');
    my ($parent) = $path;
    $parent =~ s:[^/]+/?$::;
    makeDirectory($parent);
    mkdir($path, 0755) || die("Failed to mkdir '$path': $!");
}

my (%TEMPDIRS)=();
my ($TEMPDIR) = $ENV{'TMPDIR'};
if (!defined($TEMPDIR)) {
    $TEMPDIR = "/tmp";
}
$TEMPDIR = makePathAbsolute($TEMPDIR);

sub createTempdir()
{
    my ($tdbase) = $TEMPDIR . "bsystmp-$$";
    my ($seq) = 0;
    my ($tdfile);

    for ($tdfile=$tdbase; ; ++$seq, $tdfile = $tdbase . "-" . $seq) {
	next if (-d $tdfile);
	
	if (!mkdir($tdfile,0700)) {
	    next if ($! eq 'File exists');
	    die("Failed to create temporary directory '$tdfile': $!");
	}
	last;
    }

    $TEMPDIRS{$tdfile} = 1;
    return $tdfile;
}

sub cleanupTempdir($)
{
    my ($td) = @_;
    if (!defined($TEMPDIRS{$td})) {
	die("Attempted to delete non-registered tempdir: $td");
    }
    chdir("/");
    system("rm","-rf",$td);
    delete($TEMPDIRS{$td});
}

sub cleanup()
{
    chdir("/");
    for $t (keys(%TEMPDIRS)) {
	system("rm","-rf",$t);
    }
}

sub getFileHash($)
{
    my ($path) = @_;
    open(HFIL, "<$path") || die("Failed to open '$path': $!");
    my ($ctx) = Digest::MD5->new;
    $ctx->addfile(*HFIL);
    close(HFIL) || die("Failed to close '$path': $!");
    return $ctx->hexdigest();
}

sub getStringHash($)
{
    my ($string) = @_;
    my ($ctx) = Digest::MD5->new;
    $ctx->add($string);
    return $ctx->hexdigest();
}

sub areSameFile($$)
{
    my ($a,$b) = @_;
    open(AFIL,"<$a") || die("Cannot open '$a': $!");
    open(BFIL,"<$b") || die("Cannot open '$b': $!");

    my ($ret) = 1;

    my ($bline);
    while (<AFIL>) {
	my ($aline) = $_;
	$bline = <BFIL>;
	if (!defined($bline)) { $ret = 0; last; }
	if ($aline ne $bline) { $ret = 0; last; }
    }
    if ($ret) {
	$bline = <BFIL>;
	if (defined($bline))  { $ret = 0; }
    }
    close(BFIL) || die("Failed to close '$b': $!");
    close(AFIL) || die("Failed to close '$a': $!");
    return $ret;
}

sub dieNicely(@)
{
    print STDERR "@_\n";
    cleanup();
    exit(2);
}

sub checkedChdir($)
{
    my ($f) = @_;
    chdir($f) || dieNicely("Failed to chdir to '$f': $!");
}

sub relocateFiles($$)
{
    my ($sd, $dd) = @_;

    unless ($sd =~ m:/$:) { $sd .= "/"; }
    unless ($dd =~ m:/$:) { $dd .= "/"; }
    
    if (! -d $sd) { dieNicely("Source to relocateFiles - '$sd' - is not directory");}
    if (! -d $dd) { dieNicely("Destination to relocateFiles - '$dd' - is not directory");}

    opendir(SDIR,"$sd") || dieNicely("Failed to open dir '$sd': $!");
    my (@tomove) = ();
    my ($f);
    for $f (readdir(SDIR)) {
	next if ($f =~ /^[.]/); 
	push(@tomove, $f);
    }
    closedir(SDIR) || dieNicely("Failed to close dir '$sd': $!");

    for $f (@tomove) { checkedSystem('mv',"$sd/$f","$dd/$f"); }
}

sub overlayTree($$);

sub overlayTree($$)
{
    my ($sd,$dd) = @_;
    
    unless ($sd =~ m:/$:) { $sd .= "/"; }
    unless ($dd =~ m:/$:) { $dd .= "/"; }

    if (! -d $sd) { dieNicely("Source to overlayTree - '$sd' - is not directory");}
    if (! -d $dd) { dieNicely("Destination to overlayTree - '$dd' - is not directory");}
    
    opendir(SDIR,"$sd") || dieNicely("Failed to open dir '$sd': $!");
    my (@flist) = readdir(SDIR);
    closedir(SDIR) || dieNicely("Failed to close dir '$sd': $!");

    my ($f);
    for $f (@flist) {
	next if ($f =~ /^[.]/); 
	if (-d "$sd$f") {
	    if (! -e "$dd$f") {
		checkedSystem('mv',"$sd$f","$dd$f");
		next;
	    }
	    if (! -d "$dd$f") {
		dieNicely("Overlay type mismatch directory '$sd$f' cannot overlay file '$dd$f'\n");
	    }
	    overlayTree("$sd$f/","$dd$f/");
	    next;
	}
	if (-e "$dd$f") {
	    dieNicely("Overlay type mismatch '$sd$f' cannot overlay existing '$dd$f'\n");
	}
	checkedSystem('mv',"$sd$f","$dd$f");
    }
}

sub unbundleExtract($$)
{
    my ($id,$s) = @_;
    BuildUtils::checkedSystem('unzip','-n','-q',$s);
    open(MFIL,"<MANIFEST") || BuildUtils::dieNicely("Failed to open MANIFEST: $!");
    my ($gotok) =0;
    my ($base) = '';
    while (<MFIL>) {
	chomp($_);
	if ($_ eq 'OK') {$gotok=1; last;}
	if ($_ =~ /^BASE (\S+)$/) {
	    $base = $1;
	    next;
	}
	if ($_ =~ /^FILE (\S+) (\S+)$/) {
	    if (! -f $1) {
		BuildUtils::dieNicely("File '$1' missing from bundle");
	    }
	    next;
	}
    }
    close(MFIL) || BuildUtils::dieNicely("Failed to close MANIFEST: $!");
    if (!$gotok) { BuildUtils::dieNicely("MANIFEST missing ending OK"); }
    open(IDFIL,">ID") || BuildUtils::dieNicely("Failed to open ID: $!");
    print IDFIL "EXTRACT $id\nOK\n" 
	|| BuildUtils::dieNicely("Write failed: $!");
    close(IDFIL) || BuildUtils::dieNicely("Failed to close ID: $!");
    open(BASEFIL,">BASE") || BuildUtils::dieNicely("Failed to open BASE: $!");
    print BASEFIL "BASE $base\nOK\n" 
	|| BuildUtils::dieNicely("Write failed: $!");
    close(BASEFIL) || BuildUtils::dieNicely("Failed to close BASE: $!");
}

sub getBuildIDGeneration($)
{
    my ($buildid) = @_;
    unless ($buildid =~ /^[a-z]+-build-(\d\d\d\d)(\d\d\d\d)-(\d+)$/) {
	BuildUtils::dieNicely("Build ID '$buildid' doesn't match expected format");
    }
    
    my ($y,$md,$s) = ($1,$2,$3);
    $y -= 1800 ;
    $s += 0;
    if ($s > 99) {
	BuildUtils::dieNicely("Sorry, cannot do a build w/ a sequence > 99");
    }
    if (length($s) < 2) {$s = "0$s";}
    return $y . $md . $s;
}

sub getExtractManifest($$)
{
    my ($id,$s) = @_;
    BuildUtils::checkedSystem('cp',$s,'MANIFEST');
    open(MFIL,"<MANIFEST") || BuildUtils::dieNicely("Failed to open MANIFEST: $!");
    my ($gotok) =0;
    my ($base) = '';
    while (<MFIL>) {
	chomp($_);
	if ($_ =~ /^BASE (\S+)$/) {
	    $base = $1;
	    next;
	}
	if ($_ eq 'OK') {$gotok=1; last;}
    }
    close(MFIL) || BuildUtils::dieNicely("Failed to close MANIFEST: $!");
    if (!$gotok) { BuildUtils::dieNicely("MANIFEST missing ending OK"); }
    open(IDFIL,">ID") || BuildUtils::dieNicely("Failed to open ID: $!");
    print IDFIL "EXTRACT $id\nOK\n" 
	|| BuildUtils::dieNicely("Write failed: $!");
    close(IDFIL) || BuildUtils::dieNicely("Failed to close ID: $!");
    open(BASEFIL,">BASE") || BuildUtils::dieNicely("Failed to open BASE: $!");
    print BASEFIL "BASE $base\nOK\n" 
	|| BuildUtils::dieNicely("Write failed: $!");
    close(BASEFIL) || BuildUtils::dieNicely("Failed to close BASE: $!");
}

sub getExtractID($)
{
    my ($f) = @_;
    open(IDFIL,"<$f") || BuildUtils::dieNicely("Failed to open '$f': $!");
    my ($lin);
    $lin = <IDFIL>;
    chomp($lin);
    unless ($lin =~ /^EXTRACT (\S+)$/) {
      BuildUtils::dieNicely("ID file does not have EXTRACT line");
    }
    my ($ret) = $1;
    $lin = <IDFIL>;
    if ($lin ne "OK\n") {
      BuildUtils::dieNicely("ID file does not have OK");
    }
    close(IDFIL) || BuildUtils::dieNicely("Failed to close ID file: $!");
    return $ret;
}

sub getInfoExtractDetails($$)
{
    my ($d,$alias) = @_;
    open(IDFIL,"<$d/info/MANIFEST") 
	|| BuildUtils::dieNicely("Failed to open '$d/info/MANIFEST': $!");
    while(<IDFIL>) {
	chomp($_);
	if ($_ =~ /^EXTRACT (\S+) (\S+) (\S+)$/) {
	    if ($1 eq $alias) {
		close(IDFIL);
		return $2,$3;
	    }
	}
    }
    close(IDFIL);
    BuildUtils::dieNicely("Info MANIFEST file does not have EXTRACT line for $alias");
}

sub getExtractBASE($)
{
    my ($f) = @_;
    open(IDFIL,"<$f") || BuildUtils::dieNicely("Failed to open '$f': $!");
    my ($lin);
    $lin = <IDFIL>;
    chomp($lin);
    unless ($lin =~ /^BASE (\S+)$/) {
      BuildUtils::dieNicely("BASE file does not have BASE line");
    }
    my ($ret) = $1;
    $lin = <IDFIL>;
    if ($lin ne "OK\n") {
      BuildUtils::dieNicely("BASE file does not have OK");
    }
    close(IDFIL) || BuildUtils::dieNicely("Failed to close BASE file: $!");
    return $ret;
}
sub unbundleBuildInfo($)
{
    my ($s) = @_;
    BuildUtils::checkedSystem('unzip','-n','-q',$s);
    open(MFIL,"<CONTENTS") || BuildUtils::dieNicely("Failed to open CONTENTS: $!");
    my ($gotok) =0;
    while (<MFIL>) {
	chomp($_);
	if ($_ eq 'OK') {$gotok=1; last;}
	if ($_ =~ /^INFO (\S+) $/) {
	    if (! -f "info/$1") {
		BuildUtils::dieNicely("File '$1' missing from bundle");
	    }
	    next;
	}
    }
    close(MFIL) || BuildUtils::dieNicely("Failed to close CONTENTS: $!");
    if (!$gotok) { BuildUtils::dieNicely("CONTENTS missing ending OK"); }
}

sub getFileOrURL($$)
{
    my ($source, $dest) = @_;
    print STDERR "Fetching [$dest] - $source\n";
    unlink($dest);
    if (-f $dest) {
	BuildUtils::dieNicely("Destination '$dest' cannot be removed before get");
    }
    if ($source =~ /^[a-z]+:/) {
	BuildUtils::checkedSystem("wget","-q","-nv","--output-document=$dest",$source);
	return;
    } else {
	BuildUtils::checkedSystem("cp","-f",$source, $dest);
    }
    if (! -f $dest) {
	BuildUtils::dieNicely("Failed to copy '$dest' from '$source'");
    }
}

sub getJavaCommand($)
{
    my ($rest) = @_;
    my ($cmd) = 'java';
    if (defined($ENV{'JAVA_BOOTCLASSPATH'})) {
	my ($bcp) = $ENV{'JAVA_BOOTCLASSPATH'};
	$cmd .= " -Xbootclasspath/p:'$bcp'";
    }
    return $cmd . " $rest";
}

sub getJavaCommandList(@)
{
    my (@ret) = ( 'java' );
    if (defined($ENV{'JAVA_BOOTCLASSPATH'})) {
	my ($bcp) = $ENV{'JAVA_BOOTCLASSPATH'};
	push(@ret, "-Xbootclasspath/p:'$bcp'");
    }
    push(@ret, @_);
    return @ret;
}
1;

