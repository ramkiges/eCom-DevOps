$(function() {
    // hide or show debug content based on cookie, and setup debug toggle in footer
    var isDebug = $.cookies.get('debug') || false,
        intervalMS = 30000;

    function displayDebug() {
        $('.debug').toggle(isDebug);
        if(isDebug) {
            $('.debugToggle').addClass('active');
        } else {
            $('.debugToggle').removeClass('active');
        }
    }
    displayDebug();

    $('body').delegate('.disclosable .disclosure', 'click', function(evt) {
        // setup disclosure control
        var disclosable = $(this).closest('.disclosable');

        var disclosed = disclosable.find('.disclosed');
        var undisclosed = disclosable.find('.undisclosed');

        undisclosed.slideDown(200).removeClass('undisclosed').addClass('disclosed');
        disclosed.slideUp(200).removeClass('disclosed').addClass('undisclosed');

        evt.preventDefault();
    }).delegate('.discloseRequests', 'click', function(evt) {
        var row = $(this).closest('tr'),
            requestsCell = row.next('tr.requests').find('td');

        requestsCell.slideToggle(200);

        evt.preventDefault();
    }).delegate('.editBuildPlansBtn', 'click', function(evt) {
        $('#editBuildPlans').submit();
        evt.preventDefault();
    }).delegate('.editBuildParamsBtn', 'click', function(evt) {
        $('#editBuildParams').submit();
        evt.preventDefault();
    }).delegate('.viewResultsModalTrigger', 'click', function(evt) {
        $('#viewResults').load($(this).attr('href'));
    }).delegate('.repeatBuildTrigger', 'click', function(evt) {
        $(this).closest('form').submit();
        evt.preventDefault();
    }).delegate('.alert-message .close', 'click', function(evt) {
        $(this).closest('.alert-message').remove();
    }).delegate('.repoView button[type=reset]', 'click', function(evt) {
        var href = location.href;
        $('.filterInput').each(function(_, elem) {
            href = href.replace(new RegExp('(?:(\\??)|&)' + elem.name + '=[^&]*'),'$1');
        });
        location.href = href.replace(/\?$/,'');
    }).delegate('.repoView .pagination .thisPage input', 'keypress', function(evt) {
        if(evt.keyCode == 10 || evt.keyCode == 13) {
            location.href = $(evt.target).data('href').replace('NNN', this.value);
        }
    }).delegate('.repoView .buildArtifacts th .sort a', 'click', function(evt) {
        // implement sort controls on the repo view table
        var control = $(evt.target),
            field = control.parent().data('sortfield'),
            order = control.data('sortorder') || '';

        location.href = location.href.replace(/&?sort_options=[^&]*|#.*/g,'') + (location.href.indexOf('?') == -1 ? '?' : '&') + 'sort_options=' + field + order;
    }).delegate('.revisions .branchInput', 'change', function(evt) {
        // propogate branch name changes down the revision form
        var input = $(evt.target),
            allInputs = $('.branchInput');

        allInputs.slice(allInputs.index(evt.target) + 1).val(input.val());
    });

    // placeholder plugin init for browsers that don't support html5 input placeholders
    $('[placeholder]').addPlaceholder();

    $('.repoView .filters').submit(function(evt) {
        // remove placeholder plugin vals
        $('.placeholder', evt.target).val('');
    });

    // twipsy plugin for tooltips
    $('[rel=twipsy]').twipsy({animate: false, delayIn: 300});

    // toggle debug mode (button removed from UI)
    $('.debugToggle').bind('click', function(evt) {
        isDebug ? $.cookies.del('debug') : $.cookies.set('debug', 'true', {path:'/', hoursToLive: 9999});
        isDebug = !isDebug;
        displayDebug();
        evt.preventDefault();
    });

    // periodically refresh table rows in repo view
    if($('body.repoView').length) {
        setInterval(function() {
            $.get(document.location.href, {async:true}, function (data) {
                $('.buildArtifacts tbody').replaceWith($('table', data).html());
                $('.buildStatus.modal:not(.in)').remove();
                $(document.body).append($('#modals', data).html());
                $('.pagination').replaceWith($('.pagination', data));
                $('.numBuilds').replaceWith($('.numBuilds', data));
            });
        }, intervalMS);
    }
});
