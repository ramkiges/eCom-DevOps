package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Type for errors related to extract creation and retrieval.
 * 
 * @author chunt
 * @version $Id$
 */
public class ExtractException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public ExtractException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public ExtractException(String message) {
        super(message);
    }

    /**
     * @param cause the original cause
     */
    public ExtractException(Throwable cause) {
        super(cause);
    }

}
