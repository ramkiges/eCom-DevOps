package com.wsgc.ecommerce.buildsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Holds inconveniently large result sets that we would rather keep in memory. It would have used FileUtil methods but
 * that brings a circular dependency.
 * 
 * @author chunt
 * @version $Id$
 */
public class FileBasedResultsHolder implements ResultsHolder {
    private Logger logger = LoggerFactory.getLogger(getClass());

    // Arbitrary, still looking for a good prefix, there must be a standard.
    private static final String RESULTS_FILE_PREFIX = "FileBasedResultsHolder_";
    /**
     * Suffix of all 'results files'
     */
    public static final String RESULTS_FILE_SUFFIX = "results";

    private File resultsFile;
    private FileWriter fileWriter;
    private BufferedWriter bufferedWriter;
    private PrintWriter printWriter;
    // private FileReader fileReader;

    private boolean initSuccess;
    private boolean locked;

    private List<BufferedReader> bufferedReaderList;

    /**
     * Constructor with optional File specification. If you have a nice place in mind, you can say where you want to
     * store your results, otherwise your data is going to live in the OS temp directory however that is locally
     * defined. See File.createTempFile  
     * 
     * @param aResultsFile
     *            File to hold results (doesn't have to exist yet), if null the OS will be asked to store it in default
     *            temporary file directory.
     * @param dir a directory to place the file in, if null the system default is trusted, otherwise you have control of the location.
     *  
     */
    public FileBasedResultsHolder(File aResultsFile, File dir) {
        /**
         * Errors may occur here but we need some object to hold exactly those kinds of errors. To allow this class to
         * be used in an enclosing classes constructor, we allow this constructor succeed and rely on further use of
         * this malformed object to raise an exception that will find its way to the general error handler.
         */
        if (aResultsFile == null) {
            try {
                resultsFile = File.createTempFile(
                        RESULTS_FILE_PREFIX, "." + FileBasedResultsHolder.RESULTS_FILE_SUFFIX, dir);
            } catch (IOException ioe) {
                //initSuccess is false already at this point
                logger.error("Unable to create temp file in '" + dir.getAbsolutePath() 
                        + "' for streaming results. Reason:" + ioe, ioe);
            }
        } else {
            resultsFile = aResultsFile;
        }

        if (resultsFile != null) {
            // FileUtil.checkFileExistsRWEmpty can't be used, you would have to make API depend on Util package
            logger.trace("{} Using results file: {}", toString(), resultsFile.getAbsolutePath());

            bufferedReaderList = new ArrayList<BufferedReader>();

            try {
                fileWriter = new FileWriter(resultsFile);
                bufferedWriter = new BufferedWriter(fileWriter);
                printWriter = new PrintWriter(bufferedWriter);
                logger.trace("Created Results holder {}", this);
                
                // This is the flag that matters when determining health of this object.
                initSuccess = true;
                
            } catch (IOException ioe) {
                logger.error("Unable to create print writer for streaming results. Reason:" + ioe, ioe);
                
                // should be redundant, leave for safety.
                initSuccess = false;
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void appendResultsString(String string) throws IOException {
        if (!initSuccess) {
            throw new IOException("Unable to write results to file system due to previous constructor failure");
        }
        if (locked) {
            throw new IOException("Attempt to write results after results are 'locked'");
        }
        logger.trace("Writing {} to results file {}", string, resultsFile.getAbsoluteFile());
        printWriter.print(string);
        // printWriter.println(string);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void finalize() throws Throwable {

        if (bufferedReaderList != null) {
            logger.trace("{} Closing all result readers", this);
            for (BufferedReader bufferedReader : bufferedReaderList) {
                logger.trace("{} Closing BufferedReader {}", this, bufferedReader);
                bufferedReader.close();
                bufferedReader = null;
            }
            logger.trace("{} All result readers closed", this);
        }

        if (resultsFile != null && resultsFile.exists()) {
            
            logger.trace("{} Deleting results file '{}'", this, resultsFile.getAbsoluteFile());

            if (!resultsFile.delete()) {
                // TODO are we willing to kill a build over this? Should it be an exception?
                throw new Exception("Error reported deleting '" + resultsFile.getAbsolutePath() + "' File"
                        + (resultsFile.exists() ? " still exists." : " seems to be gone anyway....sigh"));
                // logger.error(this + " Error reported deleting '" + resultsFile.getAbsolutePath() + "' File"
                // + (resultsFile.exists() ? " still exists." : " seems to be gone anyway."));
            }
        }

        super.finalize();

    }

    /**
     * {@inheritDoc}
     * 
     * 
     * TODO Did you just find a reason for a weak reference?
     * 
     * @throws IOException
     */
    @Override
    public synchronized BufferedReader getResultsReader() throws IOException {
        BufferedReader bufferedReader = null;

        if (!initSuccess) {
            throw new IOException("Unable to write results to file system due to previous constructor failure");
        }
        if (!locked) {
            throw new IOException("Attempt to read results before results are 'locked'");
        }
        // fileReader = new FileReader(resultsFile);
        bufferedReader = new BufferedReader(new FileReader(resultsFile));
        bufferedReaderList.add(bufferedReader);
        logger.trace("{} Created ResultsReader {}", this, bufferedReader);

        // else {
        // // TODO, no we are not done with this issue yet.
        // throw new IOException("ResultsReader " + bufferedReader
        // + " is not intended for multiple use and has already been returned once by " + this);
        // }
        //
        return bufferedReader;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void lockResults() /* throws IOException */ {

        /*
         * Even if stream close fails, we lock first so not to compound the problem by denying access to possible debug
         * info in the reader later.
         */
        locked = true;

        // These should not be null at this point. Readers are optional. Writers are not.
        printWriter.checkError();
        printWriter.close();
        printWriter = null;

        try {
            bufferedWriter.close();
        } catch (IOException ioe) {
            logger.error("Failed to close buffered writer. Reason:" + ioe, ioe);
        }
        bufferedWriter = null;

        try {
            fileWriter.close();
        } catch (IOException ioe) {
            logger.error("Failed to close file writer. Reason:" + ioe, ioe);
        }
        fileWriter = null;

    }

}
