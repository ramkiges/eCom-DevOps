package com.wsgc.ecommerce.buildsystem.exception;

/**
 * A class for unchecked BuildService exceptions.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildServiceRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public BuildServiceRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message 
     */
    public BuildServiceRuntimeException(String message) {
        super(message);
    }

    /**
     * @param cause the cause
     */
    public BuildServiceRuntimeException(Throwable cause) {
        super(cause);
    }

}
