/**
 * @author chunt
 * @version $Id$
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import com.wsgc.ecommerce.buildsystem.exception.BuildManagerException;
import com.wsgc.ecommerce.buildsystem.repository.BuildReference;

/**
 * The {@link BuildManager} is concerned with processing the build instructions in a {@link BuildInfo}. The difference
 * between {@link BuildService} and {@link BuildManager} is that {@link BuildService} talks to the user to create a
 * {@link BuildOrder}, where as {@link BuildManager} is a machine centric process that accepts a {@link BuildInfo} and
 * tells you only if the build completed and if it was successful.
 * 
 * @author chunt
 * @version $Id$
 */
public interface BuildManager {

    /**
     * Attempt to create a build from {@link BuildInfo}.
     * 
     * @param buildInfo
     *            the {@link BuildInfo} that describes your build and will be used to collect the results for logging
     *            and such along the way.
     * 
     * @return a {@link BuildReference} to your completed build in the repo. It may even have been a successful build
     *         but that isn't a requirement.
     * @throws BuildManagerException
     *             for a great many things that can go wrong.
     */
    BuildReference runBuild(BuildInfo buildInfo) throws BuildManagerException;

}
