package com.wsgc.ecommerce.buildsystem;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;

/**
 * Holds the definition of a specific extract, revision and branch.
 * 
 * @author chunt
 * @version $Id$
 */
public interface ConcreteExtractDefinition extends JsonObjectEntity {

    /**
     * @return the branch
     */
    String getBranch();

    /**
     * @return the revision
     */
    String getRevision();

    /**
     * 
     * DEBATABLE remove from all extract classes.
     * 
     * @return the type of the extract
     */
    String getType();

    /**
     * @return UUID of the svn repo this {@link ConcreteExtractDefinition} refers to
     */
    String getUuid();

}