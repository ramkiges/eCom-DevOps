/**
 * 
 */
package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Class for exceptions related to creating and managing separate system processes.
 * 
 * @author chunt
 * @version $Id$
 */
public class ProcessException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     */
    public ProcessException(String message) {
        super(message);
    }

    /**
     * @param cause the original cause
     */
    public ProcessException(Throwable cause) {
        super(cause);
    }

 
    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public ProcessException(String message, Throwable cause) {
        super(message, cause);
    }

}
