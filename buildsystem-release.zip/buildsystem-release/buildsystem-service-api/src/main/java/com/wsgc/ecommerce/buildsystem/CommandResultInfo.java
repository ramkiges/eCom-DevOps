package com.wsgc.ecommerce.buildsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.ProcessException;

/**
 * General collection object for all results from arbitrary things that go on in a separate processes launched by the
 * build system as it seeks to manipulate the external universe.
 * 
 * @author chunt
 * @version $Id$
 */
public class CommandResultInfo extends BaseInfo {

    private static final int ERROR_CODE_NOT_SET = -100;
    private int exitCode = ERROR_CODE_NOT_SET;

    private File directory;
    private List<String> commandList = new ArrayList<String>();
    private long startTime;
    private long endTime;
    /**
     * You generally get a static logger anyway, this one follows the trend to name such things.
     */
    private static Logger logger = LoggerFactory.getLogger(CommandResultInfo.class);
    private static File defaultTempDirectory;
    private final ResultsHolder resultsHolder;

    /**
     * Default constructor. This one buys you a <b>IN MEMORY</b> results holder with a maximum capacity of
     * {@link InMemoryResultsHolder #MAX_IN_MEMORY_SIZE}.
     */
    public CommandResultInfo() {
        resultsHolder = new InMemoryResultsHolder();
    }

    /**
     * Constructor to use a {@link FileBasedResultsHolder}. Your limits and performance are now file system dependant.
     * 
     * @param resultsFile
     *            where you expect your results to be kept. If null, a system dependent temp file will be requested.
     */
    public CommandResultInfo(File resultsFile) {
        resultsHolder = new FileBasedResultsHolder(resultsFile, defaultTempDirectory);
    }

    /**
     * Adds a list of command line strings to the internal collection.
     * 
     * @param newCommands
     *            the list of {@link String} to add.
     */
    public void addCommands(List<String> newCommands) {
        commandList.addAll(newCommands);
    }

    /**
     * 
     * 
     * TODO remove completely TODO complete entity map &apos; &quot;
     * 
     * @param string
     * @return
     * @deprecated
     */
    // @Deprecated
    // private String decodeHtmlEntity(String string) {
    // String returnString = string.replaceAll("&quot;", "\"");
    // return returnString;
    // }

    // private String encodeHtmlEntity(String string) {
    // String returnString = string.replaceAll("\"", "&quot;");
    // return returnString;
    // }

    /**
     * @return and unmodifiable copy of the command list
     */
    public List<String> getCommand() {
        return Collections.unmodifiableList(commandList);
    }

    /**
     * Gets command list as String.
     * 
     * @return a single String containing the command list arguments separated by an empty space.
     */
    public String getCommandAsString() {
        StringBuilder commandStringBuilder = new StringBuilder();
        for (String command : commandList) {
            commandStringBuilder.append(command).append(" ");
        }
        return commandStringBuilder.toString();
    }

    /**
     * @return the directory
     */
    public File getDirectory() {
        return directory;
    }

    /**
     * @param command
     *            the command to set
     */
    public void setCommand(List<String> command) {
        this.commandList = command;
    }

    /**
     * @param workingDir
     *            the directory that this process should consider as its working dir.
     */
    public void setDirectory(File workingDir) {
        directory = workingDir;
    }

    /**
     * Set the error code for the process being watched.
     * 
     * @param exitCode
     *            the exit code... 0 == success.
     */
    public void setExitCode(int exitCode) {
        this.exitCode = exitCode;
    }

    /**
     * @return the exit code of the process
     */
    public int getExitCode() {
        return exitCode;
    }

    // public String toHtmlEncodedString() {
    // return encodeHtmlEntity(toString());
    // }

    /**
     * Static method to check general success flag, exit code and any stored exceptions that happened. Simply returns if
     * the {@link CommandResultInfo} provided is free of errors. If {@link CommandResultInfo#getSuccessStatus()} returns
     * <code>false</code> then the results are read out to the logger at the ERROR level and an exception is thrown.
     * 
     * @param commandResultInfo
     *            the {@link CommandResultInfo} to validate
     * 
     * @throws ProcessException
     *             if the {@link CommandResultInfo} has errors
     */
    public static void validate(CommandResultInfo commandResultInfo) throws ProcessException {

        if (!commandResultInfo.getSuccessStatus()) {
            try {
                logger.error("CommandResultInfo error detected, dumping output of process responsible:");
                readResultsToErrorLog(logger, commandResultInfo);
            } catch (IOException ioe) {
                throw new ProcessException("Error reading previous error to logger. Reason: " + ioe, ioe);
            }
        }

        if (commandResultInfo.getLastException() != null) {
            throw new ProcessException("Command " + commandResultInfo.getCommandAsString() + " FAILED. Reason:"
                    + commandResultInfo.getLastException()
            /* + " Log:" + commandResultInfo.getLog() */, commandResultInfo.getLastException());
        }

        if (commandResultInfo.getExitCode() != 0) {
            throw new ProcessException("Command " + commandResultInfo.getCommandAsString() + " returned exit code:"
                    + commandResultInfo.getExitCode()
            /* + " Log: " + commandResultInfo.getLog() */);
        }
    }

    /**
     * Pulls information out of the {@link CommandResultInfo #getResultsReader()} and writes them to the logger provided
     * as an Error level message.
     * 
     * @param somelogger
     *            were to dump the results to
     * @param commandResultInfo
     *            the object with the secrets needing publication
     * @throws IOException
     *             if the underlying {@link Reader} is grumpy
     */
    public static void readResultsToErrorLog(Logger somelogger, CommandResultInfo commandResultInfo) throws IOException {
        if (somelogger.isErrorEnabled()) {
            somelogger.error("CommandResultInfo results:");
            BufferedReader resultsReader = commandResultInfo.getResultsReader();
            String line = resultsReader.readLine();
            while (line != null) {
                somelogger.error(line);
                line = resultsReader.readLine();
            }
            resultsReader.close();
        }
    }

    /**
     * Pulls information out of the {@link CommandResultInfo #getResultsReader()} and writes them to the logger provided
     * as an Debug level message.
     * 
     * @param somelogger
     *            were to dump the results to
     * @param commandResultInfo
     *            the object with the secrets needing publication
     * @throws IOException
     *             if the underlying {@link Reader} is grumpy
     */
    public static void readResultsToDebugLog(Logger somelogger, CommandResultInfo commandResultInfo) throws IOException {
        if (somelogger.isDebugEnabled()) {
            somelogger.debug("CommandResultInfo results:");
            BufferedReader resultsReader = commandResultInfo.getResultsReader();
            String line = resultsReader.readLine();
            while (line != null) {
                somelogger.debug(line);
                line = resultsReader.readLine();
            }
            resultsReader.close();
        }
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CommandResultInfo [exitCode=")
                .append((exitCode == ERROR_CODE_NOT_SET) ? "Not set yet" : exitCode).append(", directory=")
                .append(directory).append(", command as String ='").append(getCommandAsString()).append("'")
                /* .append(", getLog()=").append(getLog()) */.append("']");
        return builder.toString();
    }

    /**
     * @return the startTime
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * @param startTime
     *            the startTime to set
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * @param endTime
     *            the endTime to set
     */
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    /**
     * 
     * This is a big problem.... I will explain later.
     * 
     * @return your very own results reader.
     * @throws IOException
     *             because things sometimes don't work when dealing with outside agents.
     */
    public BufferedReader getResultsReader() throws IOException {
        return resultsHolder.getResultsReader();
    }

    /**
     * Add a line of 'results' to the collection.
     * 
     * @param string
     *            your new result to remember.
     * @throws IOException
     *             if it can not be stored by the underlying results holder.
     */
    public void appendResultsLine(String string) throws IOException {
        resultsHolder.appendResultsString(string);
        return;
    }

    /**
     * Call the underlying results holders lock results method.
     */
    public void lockResults() {
        logger.trace("{} locking results {}", this, resultsHolder);
        resultsHolder.lockResults();
    }

    /**
     * @param tempDir sets the location temp files should expect space to live in. This was a safety fix after I found out
     * the system locations are not always safe. I am not going to dwell on what happens if this static field is changed at runtime.
     * I will just prevent that for now.
     * 
     * :-)
     * 
     */
    public static void setDefaultTempDirectory(File tempDir) {
        if (defaultTempDirectory != null && (defaultTempDirectory != tempDir)) {
            throw new IllegalArgumentException("Default temp directory has already been set.");
        }
        defaultTempDirectory = tempDir;
    }

}
