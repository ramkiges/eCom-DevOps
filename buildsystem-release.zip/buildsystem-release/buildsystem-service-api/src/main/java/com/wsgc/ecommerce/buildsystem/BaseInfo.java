package com.wsgc.ecommerce.buildsystem;

/**
 * Serves as a top level state holder for objects that manage a collection of complaints from others but need a place of
 * their own to record the problems that occur managing the complaints of others. This class does not deal with
 * collections, only a single error is recorded.
 * 
 * @author chunt
 * @version $Id$
 */
public class BaseInfo {
    protected boolean status;
    protected String lastExceptionMessage;
    protected Throwable lastException;

    /**
     * @return the lastException
     */
    public Throwable getLastException() {
        return lastException;
    }

    /**
     * @param message
     *            the detail message of the throwable.
     * @param t
     *            the throwable
     */
    public void setLastException(String message, Throwable t) {
        setLastException(t);
        lastExceptionMessage = message;
    }

    /**
     * @param t
     *            the cause of the exception
     */
    public void setLastException(Throwable t) {
        lastException = t;
    }

    /**
     * Default constructor, currently just a placeholder for nothing.
     */
    public BaseInfo() {
        // nothing.
    }

    /**
     * @return the success status. <code>true</code> indicates no errors have ever been seen.
     */
    public boolean getSuccessStatus() {
        return status;
    }

    /**
     * Currently, this object does not automatically set its success state to false when an exception is set. Also
     * checks on making this a 'once failed, always broken' flag where considered but seemed over kill.
     * 
     * @param newstatus
     *            is this operation successful <code>true</code> means yes, no errors.
     */
    public void setSuccessStatus(boolean newstatus) {
        this.status = newstatus;
    }

}
