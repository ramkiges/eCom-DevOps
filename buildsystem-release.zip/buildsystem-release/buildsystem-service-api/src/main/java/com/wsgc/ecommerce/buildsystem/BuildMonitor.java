package com.wsgc.ecommerce.buildsystem;

import java.util.Map;
import java.util.Set;
import com.wsgc.ecommerce.buildsystem.exception.BuildStatusException;

/**
 * Provides information about currently running builds and variable collection of 'recent' builds. The number of builds
 * that are finished but still being monitored depends on the last time the purge method was used. All builds currently
 * underway are immune from being purged from this group.
 * 
 * DEBATABLE The getters allow retrieval of status based on build id held in {@link String}, but the setters requires
 * java objects. I actually like that (for now)
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public interface BuildMonitor {

    /**
     * 
     * <p>
     * TODO: Filter on USER for build monitor
     * <p>
     * TODO: Sort by build id?
     * <p>
     * 
     * "Inner interface since there is not intended for use outside of the enclosing interface". Every build has a
     * unique build id and a collection of one or more build requests. Each build request has a distinct build request
     * id within that build attempt. All build requests have different id's in a particular build but different builds
     * can have requests that share the same id. Whenever you look for the current status of a build request, you are
     * going to eventually also link that build request with a particular build id but I don't think that is obvious
     * from this API code. It is helpful to be clear about which you are dealing with at any time:
     * <p>
     * {@link BuildJobStatus} is an Inner interface of {@link BuildMonitor} with methods for getting details of the
     * requests that are going on in support of the build as a whole.
     * <p>
     * {@link JobStatus} is an Enum associated with overall build state
     * <p>
     * {@link BuildRequestStatus} is another Enum with a confusing name that is a request level status tied to extract
     * processing and build plan execution.
     * 
     * @author chunt
     * @version $Id$
     */
    interface BuildJobStatus {

        /**
         * Return the {@link BuildRequestStatus} of the build request with the given id.
         * 
         * @param buildRequestId
         *            the build request id to look up
         * @return the BuildRequestStatus.
         */
        BuildRequestStatus getBuildRequestStatus(String buildRequestId);

        /**
         * Returns the entire map of build request statuses (stati?) keys are the requestId, values are the last set
         * status.
         * 
         * @return the map
         */
        Map<String, BuildRequestStatus> getBuildRequestStatusMap();

        /**
         * @return message for this {@link BuildJobStatus}
         */
        String getMessage();

        /**
         * @return the project label of the build this status belongs to
         */
        String getProjectLabel();

        /**
         * @return overall success {@link JobStatus} of this build
         */
        JobStatus getStatus();

        /**
         * @return a formatted {@link String} of the last change in status
         */
        String getTimestamp();

        /**
         * @return the {@link User} associated with this build attempt
         */
        String getUser();

        /**
         * Setter for request level processing state. New status are checked against expected transitions to help insure
         * sanity.
         * 
         * @param buildRequestId
         *            the id of your request
         * @param buildRequestStatus
         *            the new status
         * @throws BuildStatusException
         *             if the transition between current status and next status is not allowed
         */
        void setBuildRequestStatus(String buildRequestId, BuildRequestStatus buildRequestStatus)
                throws BuildStatusException;

        /**
         * Sets this build request id as FAILED.
         * 
         * Things got very simple in certain catch blocks when I finally gave in and made a specific method to declare a
         * request over, done and finished rather than use a generic status setter to set "failed" and deal with
         * possible errors from the attempt.
         * 
         * @param buildRequestId
         *            the id of your victim.
         */
        void setBuildRequestStatusFailed(String buildRequestId);

        /**
         * Status setters accept optional detail messages like exceptions. This is the method that gets called to get
         * that done.
         * 
         * @param statusMessage
         *            the detail message
         */
        void setMessage(String statusMessage);

        /**
         * @param projectLabel
         *            the project label for this build job
         */
        void setProjectLabel(String projectLabel);

        /**
         * The new overall build status. Subject to transition rules.
         * 
         * @param jobStatus
         *            the new status
         * @throws BuildStatusException
         *             for errors including insane transition to wrong new status.
         */
        void setStatus(JobStatus jobStatus) throws BuildStatusException;

        /**
         * Convenience method to also add text message to status.
         * 
         * @param jobStatus
         *            the new status
         * @param statusMessage
         *            the message
         * @throws BuildStatusException
         *             for errors including insane transition to wrong new status.
         */
        void setStatus(JobStatus jobStatus, String statusMessage) throws BuildStatusException;

        /**
         * Mark over all build attempt as failed.
         */
        void setStatusFailed();

        /**
         * Mark over all build attempt as failed with a text message of the details.
         * 
         * @param message
         *            the detail message
         */
        void setStatusFailed(String message);
    };

    /**
     * Build request states expressed as enums.
     * 
     * @author chunt
     * @version $Id$
     */
    enum BuildRequestStatus {
        SUCCEEDED, FAILED, WAITING, EXTRACTING, BUILDING,
    };

    /**
     * Overall build status states
     * 
     * @author chunt
     * @version $Id$
     */
    enum JobStatus {
        WAITING, PROCESSING, ARCHIVING_SUCCESSFUL_BUILD, ARCHIVING_FAILED_BUILD, IMPORTING, SUCCEEDED, FAILED,
    }

    /**
     * Adds a new build job to be managed via internal maps or however the implementation deems fit. The build id of the
     * build info is used to reference this data later.
     * 
     * 
     * @param buildInfo
     *            the buildInfo to initialize with.
     * @throws BuildManagerException
     */
    void createBuildJobStatus(BuildInfo buildInfo);

    /**
     * Returns set of build id strings showing all builds being monitored. This is might be subject to change due to any
     * reason including possible user action or space limits of the implementation.
     * 
     * @return the set of buildIds being monitored.
     */
    Set<String> getBuildIds();
    
    /**
     * Returns a Map of Build id's keys with {@link BuildJobStatus} values filtered by a combination of optional params. Partial matches to
     * build id, project (label) and user will be returned (or their intersection of course, if using multiple filters).
     * 
     * @param buildIdFilter The build id you want to filter by.
     * @param projectFilter the project label filter.
     * @param userFilter the user...
     * @return your selected entries..
     */
    Map<String, ? extends BuildJobStatus>  getFilteredBuildJobStatusMap(String buildIdFilter, String projectFilter, String userFilter);

    /**
     * Return overall build job status. Almost certainly you will want this synchronized.
     * 
     * @param buildId
     *            the build id of job you want status of
     * @return the {@link BuildJobStatus} of the build id being monitored
     * @throws BuildStatusException
     *             for all checked exceptions thrown in the process
     */
    BuildJobStatus getBuildJobStatus(String buildId) throws BuildStatusException;

    /**
     * @param buildId
     *            the build id of the build you are asking about
     * @return a Map of {@link BuildRequestStatus} keyed by the name of the build request id
     */
    Map<String, BuildRequestStatus> getBuildRequestStatusMap(String buildId);

    /**
     * @return the number of builds currently in the monitor collection
     * @see #purge()
     */
    int getNumberOfMonitoredBuilds();

    /**
     * Alter the number of builds in the build monitor collection. Currently removes builds that have finished in one
     * way or another.
     */
    void purge();

    /**
     * Set a status on a build as a whole
     * 
     * @param buildId
     *            which build?
     * @param jobStatus
     *            what status?
     * @throws BuildStatusException
     *             for any problems
     */
    void setBuildJobStatus(String buildId, JobStatus jobStatus) throws BuildStatusException;

    /**
     * Set a status on a build as a whole with a message.
     * 
     * @param buildId
     *            which build?
     * @param jobStatus
     *            what status?
     * @param message
     *            the message associated with the status
     * @throws BuildStatusException
     *             for any problems
     */
    void setBuildJobStatus(String buildId, JobStatus jobStatus, String message) throws BuildStatusException;

    /**
     * Non-throwing method to safely set status to {@link BuildMonitor.JobStatus#FAILED}
     * 
     * @param buildId
     *            the sad build that is the victim of this non-success event
     */
    void setBuildJobStatusFailed(String buildId);

    /**
     * Non-throwing method to safely set status to {@link BuildMonitor.JobStatus#FAILED} with a message.
     * 
     * @param buildId
     *            the sad build that is the victim of this non-success event
     * @param message
     *            a message perhaps explaining why or some other relevant message
     */
    void setBuildJobStatusFailed(String buildId, String message);

    /**
     * Change the top build level message associated with this build id without changing the status.
     * 
     * @param buildId
     *            the build id
     * @param string
     *            the new status message
     */
    void setBuildJobStatusMessage(String buildId, String string);

    /**
     * Sets the status at the build request level.
     * 
     * @param buildRequest
     *            {@link BuildRequest} holding the build id and build request id to be used to organize the status maps.
     * @param buildJobStatus
     *            the new status
     * @throws BuildStatusException
     *             if the transition is not allowed or other errors
     */
    void setBuildRequestStatus(BuildRequest buildRequest, BuildRequestStatus buildJobStatus)
            throws BuildStatusException;

    /**
     * Unconditionally set a request level status to failed.
     * 
     * @param buildRequest
     *            the {@link BuildRequest} with
     */
    void setBuildRequestStatusFailed(BuildRequest buildRequest);

}
