/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.exception;

/**
 * @author chunt
 * @version $Id$ 
 */
public class BuildStatusException extends Exception {

    /**
     * for serialization no one ever uses.
     */
    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     */
    public BuildStatusException(String message) {
        super(message);
    }

    /**
     * @param cause the original cause
     */
    public BuildStatusException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public BuildStatusException(String message, Throwable cause) {
        super(message, cause);
    }

}
