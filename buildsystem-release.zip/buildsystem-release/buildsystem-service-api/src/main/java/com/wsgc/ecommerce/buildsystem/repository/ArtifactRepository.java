package com.wsgc.ecommerce.buildsystem.repository;

import java.util.Map;
import java.util.Set;

import com.wsgc.ecommerce.buildsystem.BuildInfo;
import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;

/**
 * Interface to the build artifact repository. This is where your builds live. We have methods to get {@link BuildReference}s
 * and {@link ArtifactRepositoryViewer}s as well as load and remove builds from the "repo".  
 * 
 * @author chunt
 * @version $Id$ 
 */
public interface ArtifactRepository {

    /**
     * A far too cute name for the method that inspects the repo and cleans it of unwanted files.
     * 
     * @throws ArtifiactRepostitoryException for the generally unexpected
     */
    void gc() throws ArtifiactRepostitoryException;


    /**
     * Returns a map sorted by Build completion time. Oldest to newest.
     * 
     * TODO: A little more time and we will find this doesn't belong in the interface at all. At this point its almost just a wrapper for
     * what should be happening under the covers anyway. This method is a waste of CPU currently.
     * 
     * @return the map of all {@link BuildReference}s in the repo, keyed by their completion time stamps
     */
    Map<Long, Set<? extends BuildReference>> getBuildHistoryMap();
    
    /**
     * 
     * Returns the build references of builds that where made with build orders that match the one given.
     * 
     * @param buildOrder the {@link BuildOrder} to match
     * @return the references in the repo that have matching build orders
     * @throws ArtifiactRepostitoryException any errors
     */
    Set<BuildReference> getBuildReferences(BuildOrder buildOrder)
            throws ArtifiactRepostitoryException;
    /**
     * Return the single build reference associated with a give build id String.
     * @param buildId the build id string.
     * @return the {@link BuildReference} that is associated with that build id or null if its not found.
     */
    BuildReference getBuildReference(String buildId);
    
    /**
     * Return the set of BuildReferences that match the BuildInfo provided.
     * @param buildInfo the buildInfo to match
     * @return the set of {@link BuildReference}s that match the BuildInfo 
     * @throws ArtifiactRepostitoryException for all exceptions
     */
    Set<BuildReference> getBuildReferences(BuildInfo buildInfo)
            throws ArtifiactRepostitoryException;
     
    /**
     * Return the entire collection of build references. One for each build held in the repo.
     * @return the complete set of build references
     */
    Set<BuildReference> getBuildReferenceSet();

    /**
     * Returns the size of the repo. 
     * 
     * @return the approximant size of the repo in bytes. 
     */
    long getSizeBytes();
   
    /**
     * Getter for a {@link ArtifactRepositoryViewer}
     * @return the {@link ArtifactRepositoryViewer}
     */
    ArtifactRepositoryViewer getViewer();
    
    /**
     * Boolean reporting if any build (successful or not) is in the repo that matches this build info.
     * 
     * <p>
     * TODO: Surprising to most people, this flag is not used in the logic that returns existing builds when a new
     * build is forced. This is why the success of the build references is not checked here. No one should be surprised
     * if it can be avoided, perhaps we can refactor with a HasSuccessfulBuild and use it in both places.
     * 
     * @param buildInfo
     *            the build info to match
     * @return <code>true</code> if a build reference was found
     * @throws ArtifiactRepostitoryException
     *             for any checked exceptions thrown along that journey
     */
    boolean hasBuild(BuildInfo buildInfo) throws ArtifiactRepostitoryException;
    
    /** Load build into repository, physical
     * @param buildInfo the {@link BuildInfo} used to create the build in the first place.
     * @return {@link BuildReference} to your build
     * @throws ArtifiactRepostitoryException implementations choice
     */
    BuildReference loadBuild(BuildInfo buildInfo) throws ArtifiactRepostitoryException;


    /**
     * Getter for number of builds held in repo.
     * 
     * @return the number of builds in repo.
     */
    int numberOfBuilds();


    /**
     * Removes a build from the repo. Implementation dependent.
     * @param buildReference the build to remove
     * @throws ArtifiactRepostitoryException implementation dependent.
     */
    void unloadBuild(BuildReference buildReference) throws ArtifiactRepostitoryException;
      
    /**
     * @return a {@link Set} of all users found in the builds in the repository. Useful for populating drop boxes 
     */
    Set<String> getAllUsers();
    /**
     * @return a {@link Set} of all project labels found in the builds in the repository. Useful for populating drop boxes 
     */
    Set<String> getAllProjectLabels();
    
    
}
