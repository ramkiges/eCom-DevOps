/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem;

/**
 * 
 * Move to build-service-impl if possible
 * 
 * Not used so far
 * 
 * @author chunt
 * @version $Id$
 */
public class ExtractHistory {

}
