package com.wsgc.ecommerce.buildsystem;

import static com.wsgc.ecommerce.buildsystem.BuildRequest.BUILD_ID;
import static com.wsgc.ecommerce.buildsystem.BuildRequest.GENERATION_ID;
import static com.wsgc.ecommerce.buildsystem.Project.BUILD_REQUESTS;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.PROJECT_ID;
import static com.wsgc.ecommerce.buildsystem.Project.PROJECT_LABEL;

import java.io.IOException;
import java.util.Collections;
import java.util.SortedSet;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceRuntimeException;
import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * 
 * Intended as a json serializable wrapper for List<BuildRequest> that holds the collection of BuildRequest objects
 * (BuildRequest = BuildPlan (previously 'BuildType') + reification/binding) selected for this 'build'.
 * 
 * 
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class BuildOrder implements JsonObjectEntity {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final String projectId;
    private final String projectLabel;

    // Required for JSON serialization framework but not used by BuildSystem.
    private final String id = "build_order_ID_not_used";
    private final String label = "build_order_label_not_used";
    /**
     * The json entity type.
     */
    public static final String ENTITY_TYPE_ID = "build_system/build_order";
    /**
     * Default marker that some ID has not be specifically set.
     */
    public static final String ID_NOT_INITIALIZED = "ID_NOT_INITIALIZED";

    private String buildId = ID_NOT_INITIALIZED;
    private String generationId = ID_NOT_INITIALIZED;

    private SortedSet<BuildRequest> buildRequestSet;

    private boolean writable = true;

    private int index;

    /**
     * Creates a new empty build order with the provided project identifiers. These {@link String}s are only really
     * eventually used for repo views at the presentation layer level.
     * 
     * @param projectId
     *            the project id of the build
     * @param projectLabel
     *            the project label of the build
     */
    public BuildOrder(final String projectId, String projectLabel) {
        buildRequestSet = new TreeSet<BuildRequest>();
        this.projectId = projectId;
        this.projectLabel = projectLabel;
    }

    /**
     * Alternate constructor used by the json deserializer. There are probably many ways we could have avoided creating
     * this but it was very helpful not to have to.
     * 
     * @param buildId
     *            the build Id
     * @param projectId
     *            the project Id
     * @param projectLabel
     *            the project label
     * @param buildRequests
     *            a collection of build requests
     */
    public BuildOrder(final String buildId, final String projectId, final String projectLabel,
            final SortedSet<BuildRequest> buildRequests) {
        this.projectId = projectId;
        this.projectLabel = projectLabel;
        this.buildRequestSet = Collections.unmodifiableSortedSet(new TreeSet<BuildRequest>(buildRequests));
        setBuildId(buildId);
        lock();
        logger.trace("Constructing new " + this.getClass().getName() + ": " + toString());
    }

    /** {@inheritDoc} */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

    /** {@inheritDoc} */
    @Override
    public Object getEntityInstanceId() {
        // not used.
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public void writeSelf(JsonObjectOutputStream json) throws IOException {
        json.writeStartObject();
        json.writeStringField(ID, id);
        json.writeStringField(LABEL, label);
        json.writeStringField(PROJECT_ID, projectId);
        json.writeStringField(PROJECT_LABEL, projectLabel);
        json.writeStringField(BUILD_ID, buildId);
        json.writeStringField(GENERATION_ID, generationId);

        json.writeArrayFieldStart(BUILD_REQUESTS);
        for (BuildRequest buildRequest : buildRequestSet) {
            json.writeObject(buildRequest);
        }
        json.writeEndArray();

        json.writeEndObject();
    }

    /**
     * Add a {@link BuildRequest} to the set of overall build tasks.
     * 
     * @param buildRequest
     *            the {@link BuildRequest} to add
     * @throws BuildServiceException
     *             if the build request has already been added
     */
    public void addBuildRequest(BuildRequest buildRequest) throws BuildServiceException {
        if (!getWritable()) {
            throw new BuildServiceException(getClass().getName() + " is not writable.");
        }
        // TODO go through collection process and add duplicate guards at all points like this? We have never seen an
        // issue...
        if (buildRequestSet.contains(buildRequest)) {
            throw new BuildServiceException("BuildRequest already found in list. BuildRequest:" + buildRequest + " "
                    + toString());
        }
        this.buildRequestSet.add(buildRequest);
        logger.debug("Adding buildRequest {}", buildRequest);
    }

    /**
     * @return if this BuildOrder has been locked or is still writable.
     */
    private boolean getWritable() {
        return writable;
    }

    /**
     * Attempts to 'lock' this build order. This signals that the build order is complete and the variables used to
     * calculate the index are stable. This means the index should be calculated and further attempts to alter it will
     * result in an exception.
     * 
     * 
     * @throws BuildServiceRuntimeException
     *             if this object has been locked before
     */
    public void lock() throws BuildServiceRuntimeException {
        checkWritable();
        index = generateIndex();
        writable = false;
    }

    /**
     * Assert the BuildOrder is still writable.
     * 
     * @throws BuildServiceRuntimeException
     *             if the writable flag is not true.
     */
    private void checkWritable() throws BuildServiceRuntimeException {
        if (!getWritable()) {
            throw new BuildServiceRuntimeException(getClass().getName() + " was already locked.");
        }
    }

    /**
     * Assert the BuildOrder is not writable.
     * 
     * @throws BuildServiceRuntimeException
     *             if the writable flag is still set.
     */
    private void checkNotWritable() throws BuildServiceRuntimeException {
        if (getWritable()) {
            throw new BuildServiceRuntimeException(getClass().getName() + " is not locked.");
        }
    }

    /**
     * @return an unmodifiable sorted set of build requests for this order.
     */
    public SortedSet<BuildRequest> getRequestSet() {
        return Collections.unmodifiableSortedSet(buildRequestSet);
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        /*
         * Here we are using index directly, don't use getIndex(), it checks that the index is done being calculated.
         * This means you will throw a runtime exception if it isn't and we need toString() to work all the time.
         */
        StringBuilder builder = new StringBuilder();
        builder.append("BuildRequests [id=").append(id).append(", label=").append(label).append(", writable=");
        builder.append(writable).append(", buildRequestSet=").append(buildRequestSet);
        builder.append(", index=").append(index).append("]");
        return builder.toString();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildRequestSet == null) ? 0 : buildRequestSet.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + ((projectId == null) ? 0 : projectId.hashCode());
        result = prime * result + ((projectLabel == null) ? 0 : projectLabel.hashCode());
        return result;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BuildOrder)) {
            return false;
        }
        BuildOrder other = (BuildOrder) obj;
        if (buildRequestSet == null) {
            if (other.buildRequestSet != null) {
                return false;
            }
        } else if (!buildRequestSet.equals(other.buildRequestSet)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (label == null) {
            if (other.label != null) {
                return false;
            }
        } else if (!label.equals(other.label)) {
            return false;
        }
        if (projectId == null) {
            if (other.projectId != null) {
                return false;
            }
        } else if (!projectId.equals(other.projectId)) {
            return false;
        }
        if (projectLabel == null) {
            if (other.projectLabel != null) {
                return false;
            }
        } else if (!projectLabel.equals(other.projectLabel)) {
            return false;
        }

        /**
         * Not part of what makes two BuildOrders 'equal' if (buildId == null) { if (other.buildId != null) { return
         * false; } } else if (!buildId.equals(other.buildId)) { return false; } if (generationId == null) { if
         * (other.generationId != null) { return false; } } else if (!generationId.equals(other.generationId)) { return
         * false; }
         */
        if (index != (other.index)) {
            return false;
        }
        return true;
    }

    /**
     * 
     * Sets the build id subject a to few rules like it has to be a build id and this has to be the first time you
     * tried.
     * 
     * TODO This should use lock() at some point. We seem to accomplish the same thing in a different way, decided to
     * create a lock flag and never got back to retrofitting its use everywhere it should go.
     * 
     * @param newBuildId
     *            the next build id
     */
    public void setBuildId(String newBuildId) {

        if (newBuildId == null || newBuildId.isEmpty()) {
            throw new IllegalArgumentException("New build id must not be " + ((newBuildId == null) ? "null" : "empty"));
        }

        // that was dumb and remained hidden a while
        // if (!buildId.equals(ID_NOT_INITIALIZED) && !newBuildId.equals(newBuildId)) {
        if (!buildId.equals(ID_NOT_INITIALIZED)) {
            throw new IllegalArgumentException("Build id is already set. Current build id:" + buildId
                    + " attempted new value:" + newBuildId);
        }

        /*
         * At the time of writing the generation id is almost a hash of the build id. Since we needed the build id as
         * input to decode and use to create the generation id a generationIdProvider would be a glorified macro that
         * still requires the build id to work. That logic to create a generation id is here if we ever have reason to
         * pull it out and make it part of dependency injection as a stand along object. Right now it seems better to
         * just explain why I didn't.
         * 
         * 
         * To get from this to the generation you use:
         * 
         * Generation = (DayCode – 18000000) * 100 + Sequence
         */
        if (!newBuildId.equals(ID_NOT_INITIALIZED)) {
            String[] fields = newBuildId.split("-");
            /*
             * We can't check type if the field is no longer static and we don't want to add a reference to the object
             * that holds it. This will 1) succeed or 2) throw for not trying to find a number or 3) throw for failing
             * to find a number.
             */
            if (fields.length == 4 /* && newBuildId.startsWith(TYPE) */) {
                generationId = String.valueOf((Integer.parseInt(fields[2]) - 18000000) * 100
                        + Integer.parseInt(fields[3]));
            } else {
                throw new IllegalArgumentException("Unable to determine generation number from '" + newBuildId + "'");
            }
        }

        this.buildId = newBuildId;

        /**
         * DEBATABLE Only at the very end did we add buildId to the requests.
         * 
         */
        for (BuildRequest buildRequest : buildRequestSet) {
            buildRequest.setBuildId(buildId);
            buildRequest.setGenerationId(generationId);
        }

    }

    /**
     * @return the buildId
     */
    public String getBuildId() {
        return buildId;
    }

    /**
     * Get the index after checking that this build order is non-writable and there for the index is now determined.
     * 
     * @return the index.
     */
    public int getIndex() {
        checkNotWritable();
        logger.trace("getIndex() returning: {}", index);
        return index;
    }

    /**
     * Index does not use buildId or generationId. We don't want to consider those when deciding if two
     * {@link BuildOrder}s are the same.
     * 
     * @return the index
     * @throws BuildServiceRuntimeException
     *             if object has not been locked.
     */
    private int generateIndex() throws BuildServiceRuntimeException {

        if (!writable) {
            throw new BuildServiceRuntimeException("Index calculation was attempted on a non-writable object" + this);
        }

        final int prime = 31;
        int result = 1;

        if (logger.isTraceEnabled()) {
            logger.trace(getClass().getName() + " has " + ((buildRequestSet == null) ? 0 : buildRequestSet.size())
                    + " BuildRequest entr" + ((buildRequestSet.size() == 1) ? "y" : "ies."));
        }
        if (buildRequestSet != null) {
            for (BuildRequest buildRequest : buildRequestSet) {
                result = prime * result + ((buildRequest == null) ? 0 : buildRequest.getIndex());
                logger.trace("Looking at buildrequest:{}", buildRequest.toString());
                logger.trace("This buildRequest.getIndex() is {} running result:{}", buildRequest.getIndex(), result);
            }
        }

        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + ((projectId == null) ? 0 : projectId.hashCode());
        result = prime * result + ((projectLabel == null) ? 0 : projectLabel.hashCode());
        logger.trace("id.hashCode():{} label.hashCode(){}", id.hashCode(), label.hashCode());

        return result;
    }

    /**
     * @return the projectId
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * @return the project label
     */
    public String getProjectLabel() {
        return projectLabel;
    }

    /**
     * @return the generationId
     */
    public String getGenerationId() {
        return generationId;
    }
}
