/**
 * Contains objects related to the build system exceptions.
 */
package com.wsgc.ecommerce.buildsystem.exception;

