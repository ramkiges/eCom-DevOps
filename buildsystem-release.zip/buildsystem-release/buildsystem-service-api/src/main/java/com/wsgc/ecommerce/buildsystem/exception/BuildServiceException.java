package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Class for BuildService level exceptions
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildServiceException extends Exception {

    private static final long serialVersionUID = 1L;


    /**
     * @param message the detail message
     * @param cause the cause
     */
    public BuildServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public BuildServiceException(String message) {
        super(message);
    }

    /**
     * @param cause the cause
     */
    public BuildServiceException(Throwable cause) {
        super(cause);
    }

}
