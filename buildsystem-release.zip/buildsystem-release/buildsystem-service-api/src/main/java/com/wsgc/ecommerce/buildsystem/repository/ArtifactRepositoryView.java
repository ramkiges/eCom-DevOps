package com.wsgc.ecommerce.buildsystem.repository;

import java.io.File;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;

/**
 * Provides presentation layer friendly access to the information about builds in a repository. Implementation must
 * allow for the fact BuildReferences may have been unloaded by the repo at anytime.
 * 
 * @author chunt
 * @version $Id$
 */
public interface ArtifactRepositoryView {

    /**
     * @return the build id of this build
     */
    String getBuildId();

    /**
     * 
     * Deserializes the build order back in to a {@link BuildOrder}.
     * 
     * @return the {@link BuildOrder} that made the build this view is associated with.
     * @throws ArtifiactRepostitoryException
     *             for errors
     */
    BuildOrder getBuildOrder() throws ArtifiactRepostitoryException;

    /**
     * Getter for the build order in the form of its JSON representation.
     * 
     * @return a {@link String} with the json definition of the build order this view points to.
     * @throws ArtifiactRepostitoryException
     *             for errors
     */
    String getBuildOrderJSON() throws ArtifiactRepostitoryException;

    /**
     * Meant to return a success or failure status of the build. Just because a build attempt completed, doesn't mean
     * you have a good build in the repo.
     * 
     * @return an implementation defined {@link String} like "SUCCESS" or "FAILURE"
     */
    String getBuildStatus();

    /**
     * 
     * The millisecond time stamp this build was completed.
     * 
     * @return the time stamp
     */
    Long getCompletionTimeStamp();

    /**
     * The completion time stamp formatted in to a string.
     * 
     * DEBATABLE share a single unified date format across whole build system.
     * 
     * @return a formated date string made from the completion time stamp
     * 
     */
    String getEnd();

    /**
     * @return a {@link File} associated with error log for this build
     */
    File getErrorLog();

    /**
     * @return error log as a single {@link String}
     * @throws ArtifiactRepostitoryException
     *             any errors
     */
    String getErrorLogAsString() throws ArtifiactRepostitoryException;

    /**
     * @return the file system location of this build
     */
    File getBuildLocation();

    /**
     * @return a {@link File} pointing to the build log for this build.
     */
    File getBuildLog();

    /**
     * @return build log as a single {@link String}
     * @throws ArtifiactRepostitoryException
     *             any errors
     */
    String getBuildLogAsString() throws ArtifiactRepostitoryException;

    /**
     * @return a {@link File} pointing to the manifest for this build.
     */
    File getManifest();

    /**
     * 
     * @return {@link String} holding the contents read from the manifest file
     * @throws ArtifiactRepostitoryException
     *             for general trouble
     */
    String getManifestAsString() throws ArtifiactRepostitoryException;

    /**
     * @return a String with the build originators name
     */
    String getUser();

}
