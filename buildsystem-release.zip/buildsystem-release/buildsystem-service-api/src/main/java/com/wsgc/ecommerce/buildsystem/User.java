package com.wsgc.ecommerce.buildsystem;

import java.util.HashSet;
import java.util.Set;

/**
 * Holds data specific to the original creator of a build request and the notification flags holding their notification
 * preferences for when the build finishes.
 * 
 * @author chunt
 * @version $Id$
 */
public class User {

    private String userName;
    private boolean notifyOnSuccess;
    private boolean notifyOnFail;
    private Set<String> userEmails;

    /**
     * @return the name associated with this user.
     */
    public String getName() {
        return userName;
    }

    /**
     * 
     * @param name
     *            the name you wish to associate with this user.
     */
    public void setName(String name) {
        userName = name;
    }

    /**
     * 
     * @return the notifyOnSuccess boolean <code>true</code> if the user has requested email notification in the event
     *         of a successful build attempt
     */
    public boolean isNotifyOnSuccess() {
        return notifyOnSuccess;
    }

    /**
     * @param notifyOnSuccess
     *            the notifyOnSuccess to set
     */
    public void setNotifyOnSuccess(boolean notifyOnSuccess) {
        this.notifyOnSuccess = notifyOnSuccess;
    }

    /**
     * @return the notifyOnFail boolean <code>true</code> if the user has requested email notification in the event of a
     *         unsuccessful build attempt
     */
    public boolean isNotifyOnFail() {
        return notifyOnFail;
    }

    /**
     * @param notifyOnFail
     *            the notifyOnFail to set
     */
    public void setNotifyOnFail(boolean notifyOnFail) {
        this.notifyOnFail = notifyOnFail;
    }

    /**
     * @return the userEmail
     */
    public Set<String> getUserEmails() {
        return userEmails;
    }

    /**
     * Add a string to the collection of addresses that will be sent notification messages at the end of the build.
     * 
     * @param userEmail
     *            the user email address to add to the collection.
     */
    public void addNotificationEmail(String userEmail) {
        if (userEmails == null) {
            userEmails = new HashSet<String>();
        }
        userEmails.add(userEmail);
    }

    /**
     * @return the set of email addresses related to the email notifications.
     */
    public Set<String> getNotificationEmails() {
        return userEmails;
    }
}
