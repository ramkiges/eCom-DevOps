package com.wsgc.ecommerce.buildsystem;

import java.util.Map;
import java.util.Set;

import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryView;
import com.wsgc.ecommerce.buildsystem.repository.BuildReference;

/**
 * Provides the interface to create artifact resources created from project files and user input. This exposes the
 * collection of projects, accepts custom build configuration data to generate a specific build order, generates build
 * artifacts from that request and offers a view of the repository where they should have ended up. The
 * {@link BuildService} negotiates with the user to create a {@link BuildOrder} from the users revision data choices.
 * The {@link BuildOrder} is used to create a {@link BuildInfo} which wraps the build order and has other object to hold
 * the results from the build process, which is passed to the {@link BuildManager} for build processing. <br>
 * {@link BuildOrder} is an immutable list of instructions for a build. <br>
 * {@link BuildInfo} holds an immutable {@link BuildOrder} and objects to hold the future results of the various build
 * steps.
 * 
 * @author chunt
 * @version $Id$
 */
public interface BuildService {

    /**
     * 
     * Creates a {@link BuildOrder} from stored construction rules in the form of a project definition combined with
     * real time user selections from the collection of possible build plans available from the project definition and
     * concrete choices about which revision for the various extracts defined by those build plans.
     * 
     * @param project
     *            the {@link Project} to build.
     * @param buildPlanIds
     *            the build plans to use in the build.
     * @param concreteMaps
     *            reification data for the extracts used in the build plans.
     * @return a {@link BuildOrder} representing a normalized version of all the requests that can be 'run' by the build
     *         system.
     * @throws BuildServiceException
     *             if that isn't completely successful.
     */
    BuildOrder generateBuildOrder(Project project, Set<String> buildPlanIds,
            Map<String, Map<String, ? extends ConcreteExtractDefinition>> concreteMaps) throws BuildServiceException;

    /**
     * Get a single {@link Project} from its projectId.
     * 
     * @param projectId
     *            the key
     * @return the {@link Project} that is mapped to the provided projectId key
     */
    Project getProject(String projectId);

    /**
     * Returns a map of all available Projects keyed by project id found in the project definition files that are
     * currently loaded.
     * 
     * @return a map of {@link Project} definitions available to build from.
     */
    Map<String, Project> getProjects();

    /**
     * View object created from a build reference.
     * 
     * @param buildReference
     *            the reference to generated the view for.
     * @return the view corresponding to the build reference.
     * @throws ArtifiactRepostitoryException the usual trouble dealing with files
     */
    ArtifactRepositoryView getRepositoryView(BuildReference buildReference) throws ArtifiactRepostitoryException;

    /**
     * Create a build from a BuildOrder and load it in to the repository. The fact the build completed and exists in the
     * repo does not imply it was successful as well.
     * 
     * 
     * @param buildOrder
     *            the build order defining the build request.
     * @param user
     *            the agent to identify as the initiator of this request.
     * @return a {@link BuildReference} showing where your build artifacts ended up.
     * @throws BuildServiceException
     *             for a GREAT MANY REASONS.
     */
    BuildReference runBuild(BuildOrder buildOrder, User user) throws BuildServiceException;

    /**
     * This one is different, is schedules the build on a separate thread and returns the build Id immediately. It is up
     * to the client to figure out when the build is finished and how successful it was. The only thing returned by this
     * method is the build id that has been reserved for this effort.
     * 
     * 
     * @param buildOrder
     *            the build order defining this build request.
     * @param user
     *            the person or agent that requested this build.
     * @return the buildId of this build request should it happen to complete (successfully or not).
     * @throws BuildServiceException
     *             any problem along the way.
     */
    String runBuildLater(BuildOrder buildOrder, User user) throws BuildServiceException;

}
