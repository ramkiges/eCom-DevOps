package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Exceptions for trouble when managing the extract source. 
 * 
 * @author chunt
 * @version $Id$ 
 */
public class SourceException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public SourceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public SourceException(String message) {
        super(message);
    }

    /**
     * @param cause the original cause
     */
    public SourceException(Throwable cause) {
        super(cause);
    }

}
