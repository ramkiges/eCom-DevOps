/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.repository;


/**
 * @author chunt
 * @version $Id$ 
 */
public class BuildPerformance {

    private final long buildStart;
    private final long totalExtractCPUTime;
    private final long totalExtractRealTime;
    private final long totalBuildProcessCPUTime;
    private final long totalBuildProcessRealTime;
    private final long completionTimestamp;
    private final String performanceString;
    private String id;

    /**
     * @return the buildStart
     */
    public long getBuildStart() {
        return buildStart;
    }

    /**
     * @return the totalExtractCPUTime
     */
    public long getTotalExtractCPUTime() {
        return totalExtractCPUTime;
    }

    /**
     * @return the totalExtractRealTime
     */
    public long getTotalExtractRealTime() {
        return totalExtractRealTime;
    }

    /**
     * @return the totalBuildProcessCPUTime
     */
    public long getTotalBuildProcessCPUTime() {
        return totalBuildProcessCPUTime;
    }

    /**
     * @return the totalBuildProcessRealTime
     */
    public long getTotalBuildProcessRealTime() {
        return totalBuildProcessRealTime;
    }

    /**
     * @return the completionTimestamp
     */
    public long getCompletionTimestamp() {
        return completionTimestamp;
    }

    /**
     * @return the performanceString
     */
    public String getPerformanceString() {
        return performanceString;
    }

    /**
     * Simple parsing of the performance string... experimental
     * @param s the {@link String} to parse
     */
    public BuildPerformance(String s) {
        
        String[] performanceFields = s.substring(s.indexOf(':') + 1).split(":");
        if (performanceFields.length != 6) {
            throw new IllegalArgumentException("Expecting 6 fields in performance data string but found " 
                    + performanceFields.length + " Parsing line '" + s + "'");
        }    
        
        performanceString = s;
        buildStart                     = Long.parseLong(performanceFields[0]);
        totalExtractCPUTime            = Long.parseLong(performanceFields[1]);
        totalExtractRealTime           = Long.parseLong(performanceFields[2]);
        totalBuildProcessCPUTime       = Long.parseLong(performanceFields[3]);
        totalBuildProcessRealTime      = Long.parseLong(performanceFields[4]);
        completionTimestamp            = Long.parseLong(performanceFields[5]);
    }

    /**
     * @param id the id to set..
     */
    public void setId(String id) {
        this.id = id;
    }
    
    /**
     * @return the meaning of life?
     */
    public String getId() {
        return id;
    }

}
