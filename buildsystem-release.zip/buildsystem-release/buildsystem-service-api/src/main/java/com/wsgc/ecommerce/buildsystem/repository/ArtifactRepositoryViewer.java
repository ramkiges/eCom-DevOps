/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.repository;

import java.util.NavigableSet;
import java.util.Set;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;

/**
 * 
 * TODO: update documentation to refect sorted set use. ...... Now update to NavigatableSet good thing you waited huh?
 * 
 * Interface for read only access to artifact repository information. The purpose of a implementing classes is to create
 * ArtifactRepositoryViews (in different ways from various clues generally available) that in turn could be used by a
 * front end UI to display artifact state to a user.
 * 
 * @author chunt
 * @version $Id$
 */
public interface ArtifactRepositoryViewer {

    /**
     * 
     * @return SortedSet of {@link ArtifactRepositoryView}, in fact, all views this repo has.
     * @throws ArtifiactRepostitoryException for general failure
     */
    NavigableSet<ArtifactRepositoryView> getAllViews() throws ArtifiactRepostitoryException;

    /**
     * Returns complete collection of all view records in repository.
     * @param userFilter 
     * @param projectFilter 
     * @param buildIdFilter 
     * 
     * @return Set of all repository builds.
     * @throws ArtifiactRepostitoryException
     *             for all trouble.
     */
    NavigableSet<ArtifactRepositoryView> getAllViews(String buildIdFilter, String projectFilter, String userFilter) throws ArtifiactRepostitoryException;

    /**
     * Returns current number of builds managed by the repository.
     * 
     * @return The number of builds in repository.
     */
    int getNumEntries();

    /**
     * Returns the total number of bytes allocated to build artifact files. The actual size on disk will likely be
     * larger, by how much depends on the host file system.
     * 
     * @return sum of the size of all files in the repository, in bytes.
     */
    long getSizeBytes();

    /**
     * 
     * getter for a ArtifactRepositoryView based on a BuildReference that was presumably obtained from some interaction
     * with a ArtifactRepository.
     * 
     * @param buildReference
     *            The buildreference to look up.
     * @return the ArtifactRepostitoryView that matches the BuildReference.
     * @throws ArtifiactRepostitoryException 
     */
    ArtifactRepositoryView getView(BuildReference buildReference) throws ArtifiactRepostitoryException;

    /**
     * 
     * getter for a ArtifactRepositoryView based on just a String build identifier.
     * 
     * @param buildId
     *            The build identifier to look up.
     * @return the ArtifactRepostitoryView that matches the string parameter.
     * @throws ArtifiactRepostitoryException 
     */
    ArtifactRepositoryView getView(String buildId) throws ArtifiactRepostitoryException;

    /**
     * Returns all views of build artifacts that where attempted using a specific BuildOrder definition. Each
     * ArtifactRepositoryView in the collection has an individual build success status. Presence in the repository does
     * not necessarily imply build success, only build completion.
     * 
     * 
     * @param buildOrder
     *            The BuildOrder to match
     * @return A set of matching ArtifactRepositoryViews that have BuildOrders that are equal() to this.
     * @throws ArtifiactRepostitoryException
     *             for any errors.
     */
    NavigableSet<ArtifactRepositoryView> getViews(BuildOrder buildOrder) throws ArtifiactRepostitoryException;

    /**
     * Returns a set of views related to a collection of supplied buildReferences.
     * @param buildRefs the set of build references you want views for.
     * @return a set of {@link ArtifactRepositoryView}s that have the views associated with the build references. 
     * @throws ArtifiactRepostitoryException 
     */
    NavigableSet<ArtifactRepositoryView> getViews(Set<BuildReference> buildRefs) throws ArtifiactRepostitoryException;

    /**
     * 
     * Returns a set of views related to a collection of supplied buildReferences, filtered by three string parameters.
     * Filter parameters can be null but if it is non empty then then result must have that filter string present in its
     * relevant state (user, project or buildId) for the {@link ArtifactRepositoryView} to be considered a match. We are
     * talking about an AND relationship here. A result will match all filters at the same time. 
     * 
     * Wildcards are not supported
     * 
     * @param buildRefs
     *            the set of {@link BuildReference}s to convert to {@link ArtifactRepositoryView}s
     * @param buildIdFilter
     *            this string must appear in the build id. Example "cmx-build-"
     * @param projectFilter
     *            the string must appear in the project name Example "PB"
     * @param userFilter
     *            the string must appear in the user name Example "cibuilder"
     * @return a set of {@link ArtifactRepositoryView}s that have the views associated with the build references,
     *         filtered by the parameters
     * @throws ArtifiactRepostitoryException wraps any low level trouble
     */
    NavigableSet<ArtifactRepositoryView> getViews(Set<BuildReference> buildRefs, String buildIdFilter,
            String projectFilter, String userFilter) throws ArtifiactRepostitoryException;

    /**
     * @return a {@link Set} of all users found in the builds in the repository. Useful for populating drop boxes 
     */
    Set<String> getAllUsers();

    /**
     * @return a {@link Set} of all project labels found in the builds in the repository. Useful for populating drop boxes 
     */
    Set<String> getAllProjectLabels();
    
}
