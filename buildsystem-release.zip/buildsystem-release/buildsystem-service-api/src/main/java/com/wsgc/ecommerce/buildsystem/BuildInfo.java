package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.BuildManagerException;

/**
 * 
 * This Class holds the largest collection of build information as it spans the build process all the way to repo load.
 * It is the one object that knows a lot about the build working directory and as such is able to physically move files
 * from their birthplace in the secret working directories to the public file system location in the repo. Most of this
 * info is used a thrown away by the time the build is safely resting in the repo. At that point you are back to having
 * a {@link BuildOrder} again. A {@link BuildInfo} is like a {@link BuildOrder} with user, start time and a top level
 * collection of {@link Throwable} to hold non-build-request specific failures.
 * 
 * <p>
 * TODO: rest a bit, then finish the explanation using the same number of words already expended above.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class BuildInfo extends BaseInfo implements Comparable<BuildInfo> {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private BuildOrder buildOrder;
    private File workingDir;
    private long creationTimestamp;
    private long completionTimestamp;
    private Set<Throwable> exceptions;

    private Set<BuildRequestResult> buildRequestResults;
    private User user;

    /**
     * The only constructor.
     * 
     * @param buildOrder
     *            the {@link BuildOrder} for the whole build attempt
     * @param user
     *            the user responsible for initiating this build.
     */
    public BuildInfo(BuildOrder buildOrder, User user) {
        this.buildOrder = buildOrder;
        this.user = user;
        buildRequestResults = new HashSet<BuildRequestResult>();

        exceptions = new HashSet<Throwable>(0);

        /*
         * this is another one we set as happy until it pick up a bad result. the children start off unhappy until
         * proven successful.
         */
        setSuccessStatus(true);
    }

    /**
     * Add another throwable to the top level collection of interesting events that happened during this build attempt.
     * 
     * @param t
     *            the throwable to add
     */
    public void addException(Throwable t) {
        logger.trace("Adding exception to build info. Exception:{}", t);
        setSuccessStatus(false);
        exceptions.add(t);
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(BuildInfo o) {
        return getIndex() - o.getIndex();
    }

    /**
     * Returns the internal {@link BuildOrder}s build id.
     * 
     * @return the build id of this BuildInfo
     */
    public String getBuildId() {
        return buildOrder.getBuildId();
    }

    /**
     * @return the buildOrder
     */
    public BuildOrder getBuildOrder() {
        return buildOrder;
    }

    /**
     * @return the buildReference
     */
    // public BuildReference getBuildReference() {
    // return buildReference;
    // }

    /**
     * @return the buildRequestResults
     */
    // public List<BuildRequestResult> getBuildRequestResults() {
    public Set<BuildRequestResult> getBuildRequestResults() {
        return buildRequestResults;
    }

    /**
     * @return the completionTimestamp
     */
    public long getCompletionTimestamp() {
        return completionTimestamp;
    }

    /**
     * @return the creationTimestamp
     */
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    /**
     * @return gets an unmodifiable copy of the collection of exceptions
     */
    public Set<Throwable> getExceptions() {
        return Collections.unmodifiableSet(exceptions);
    }

    /**
     * The index is different from the {@link Object#hashCode()} in that it only uses class fields that would make the
     * build artifacts created from this {@link BuildInfo} different from another BuildInfo.
     * 
     * @return the index
     */
    public int getIndex() {
        logger.trace("BuildInfo.buildOrder.getIndex():{}", buildOrder.getIndex());
        return buildOrder == null ? 0 : buildOrder.getIndex();
    }

    /**
     * @return the project id of the eventual build attempt.
     */
    public String getProjectId() {
        return buildOrder.getProjectId();
    }

    /**
     * @return the project label
     */
    public String getProjectLabel() {
        return buildOrder.getProjectLabel();
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * 
     * TODO Build or extract working dir?
     * 
     * @return the workingDir
     */
    public File getWorkingDir() {
        return workingDir;
    }

    /**
     * Add a {@link BuildRequestResult} to the collection of history about this build attempt.
     * 
     * @param buildRequestResult
     *            {@link BuildRequestResult} holding the details of success or failure of the build request
     * @throws BuildManagerException
     *             for detected data corruption or mundane trouble along the way
     */
    public void registerBuildRequestResult(BuildRequestResult buildRequestResult) throws BuildManagerException {

        if (getBuildId() == buildRequestResult.getBuildId()) {
            setSuccessStatus(getSuccessStatus() && buildRequestResult.getSuccessStatus());
            buildRequestResults.add(buildRequestResult);
        } else {
            throw new BuildManagerException("Build id miss-match BuildInfo buildId:" + getBuildId()
                    + " BuildRequestResult buildId:" + buildRequestResult.getBuildId());
        }
    }

    /**
     * Sets build id subject to the restrictions of {@link BuildInfo#setBuildId(String)}
     * 
     * @param newBuildId
     *            the build id to set
     * @see {@link BuildInfo#setBuildId(String)}
     */
    public void setBuildId(String newBuildId) {
        buildOrder.setBuildId(newBuildId);
    }

    //
    // public void setBuildReference(BuildReference buildReference) {
    // this.buildReference = buildReference;
    // }

    /**
     * Set the over all build working directory.
     * 
     * @param buildWorkingDir
     *            the build working directory
     */
    public void setBuildWorkingDir(File buildWorkingDir) {
        workingDir = buildWorkingDir;
    }

    /**
     * @param completionTimestamp
     *            the completionTimestamp to set
     */
    public void setCompletionTimestamp(long completionTimestamp) {
        this.completionTimestamp = completionTimestamp;
    }

    /**
     * @param creationTimestamp
     *            the creationTimestamp to set
     */
    public void setCreationTimestamp(long creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

}
