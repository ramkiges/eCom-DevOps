package com.wsgc.ecommerce.buildsystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * An implementation of ResultsHolder that holds data in memory rather than persist it to a file system. Since this has
 * the potential for performance degradation due to careless misuse, IOExceptions are thrown if expected limits are
 * exceeded. A default character limit of MAX_IN_MEMORY_SIZE exists but can be overridden via constructor. The actual
 * amount of memory consumed at any time is dependent on the on the implementation of StringBuilder which is created
 * with default size allocation and allowed to grow under its own management. We limit our checks to the number of
 * characters actually stored and hope there is a useful correlation.
 * 
 * @author chunt
 * @version $Id$
 */
public class InMemoryResultsHolder implements ResultsHolder {
    private Logger logger = LoggerFactory.getLogger(getClass());
    /**
     * The default character limit for holding otherwise completely arbitrary things in memory. Our only constraint is
     * you have a limited size. I can't really think of a good reason it needs to be a power of two other than ancient
     * respect for hardware page boundaries at some level.
     * 
     * SVN info command with nothing interesting to say is about 400 chars, so it rounded up.
     */
    public static final int MAX_IN_MEMORY_SIZE = 768;
    private final int characterLimitInUse;
    private StringBuilder sb;
    private boolean locked;

    /**
     * Default constructor that allocates a StringBuilder to hold results.
     */
    public InMemoryResultsHolder() {
        characterLimitInUse = MAX_IN_MEMORY_SIZE;
        sb = new StringBuilder();
    }

    /**
     * Constructor that allocates a StringBuilder to hold results and overrides the default character size limit.
     * 
     * @param characterLimit
     *            the number of characters to allow in the result string before throwing an IOException for trying.
     */
    public InMemoryResultsHolder(int characterLimit) {
        characterLimitInUse = characterLimit;
        logger.debug("Overriding default character size limit of {}, new limit is now {}", MAX_IN_MEMORY_SIZE,
                characterLimitInUse);
        sb = new StringBuilder();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BufferedReader getResultsReader() throws IOException {
        if (!locked) {
            throw new IOException("Attempt to read results before results are 'locked'");
        }
        return new BufferedReader(new StringReader(sb.toString()));
    }

    /**
     * {@inheritDoc}
     * 
     * If this action would cause the current character count of the results to exceed the limit set during
     * construction, an IOException is raised.
     * 
     */
    @Override
    public void appendResultsString(String line) throws IOException {
        if (locked) {
            throw new IOException("Attempt to write results after results are 'locked'");
        }
        checkCapacity(line.length());
        logger.trace("Writing {} to results file InmemoryResultsHolder {}", line, this);
        sb.append(line);
        // sb.append(line).append("\n");
    }

    /**
     * Compares current length of the results character string and throws IOException if the currently in use buffer
     * size would not hold the specified number of new characters.
     * 
     * @param spaceNeeded
     *            the number a characters you would like to store.
     * @throws IOException
     *             if that would break the buffer size.
     */
    private void checkCapacity(int spaceNeeded) throws IOException {
        if (sb.length() + spaceNeeded > characterLimitInUse) {
            throw new IOException("Additional results can not be stored due to in-memory size limit set at "
                    + characterLimitInUse + " Current results held: '" + sb.toString() + "'");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void lockResults() {
        locked = true;
    }

}
