/**
 * Contains objects related to the build system artifact repository.
 */package com.wsgc.ecommerce.buildsystem.repository;

