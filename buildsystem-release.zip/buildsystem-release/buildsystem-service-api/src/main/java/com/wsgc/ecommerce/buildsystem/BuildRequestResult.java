package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// TODO now BaseInfo duplicates the exceptions we ended up liking..and CommandResultInfo doesn't use it.
// Refactor CommandResultInfo and BuildRequestResult and switch the base class.
/**
 * Buildrequest level results holder. Holds a list of SourceRetrievalDetails for the history of the extract attempts and
 * a list of CommandResultInfo's to report on the various processes used during the build request. Both are used for
 * later output to repo forensic logs. This object is created with an optimistic outlook but monitors all result sets
 * added to it for their success status flag. Once a result from a monitored process (through ComandResultInfo) or
 * extract attempt (SourceRetrievalDetails) then the BuildRequestResult acquires an overall state of 'failed' as well.
 * 
 * @author chunt
 * @version $Id$
 */
public class BuildRequestResult {
    private String label;
    private String id;
    private String buildId;

    private long startTime;
    private long endTime;
    /*
     * this one we set as happy until it pick up a bad result. the children start off unhappy until proven successful,
     */
    private boolean successStatus = true;

    private List<SourceRetrievalDetails> sourceRetrievalDetails;
    private List<CommandResultInfo> commandResultInfos;

    protected String lastExceptionMessage;
    protected Throwable lastException;
    private File infoDir;
    private Set<File> outputFiles;

    /**
     * Default Constructor. Does not associate this set of results with any particular build request. Potentially
     * useful, in practice it is little more than a base init function and was made private out of a sense of modesty.
     * 
     * 
     */
    private BuildRequestResult() {
        sourceRetrievalDetails = new ArrayList<SourceRetrievalDetails>();
        commandResultInfos = new ArrayList<CommandResultInfo>();
        outputFiles = new HashSet<File>();
    }

    /**
     * The normal constructor based on an association with a particular build request belonging to a build underway with
     * an assigned build number.
     * 
     * @param buildRequest
     *            the BuildRequest to copy ids from.
     */
    public BuildRequestResult(BuildRequest buildRequest) {
        this();
        this.label = buildRequest.getLabel();
        this.id = buildRequest.getId();
        this.setBuildId(buildRequest.getBuildId());
    }

    /**
     * Add the contents of a directory to the list of files we consider to be the products of this build request.
     * 
     * TODO: Do we need a filename exclusion filter (like .DS_Store) here? TODO: if not, trace the exact reason your
     * repo is currently not getting junk files after using this......
     * 
     * @param dir
     *            the directory to search through.
     */
    public void addAllOutputFiles(File dir) {

        File[] files = dir.listFiles();
        for (File file : files) {
            if (outputFiles.contains(file)) {
                throw new IllegalArgumentException("File already exists in output set. File:" + file.getAbsolutePath());
            }
            outputFiles.add(file);
        }
    }

    /*
     * Never found a use for these, no one want it public BuildRequestResult(List<SourceRetrievalDetails>
     * sourceRetrievalDetails) { this.sourceRetrievalDetails = new
     * ArrayList<SourceRetrievalDetails>(sourceRetrievalDetails); }
     */
    /**
     * Add a commandResultInfo to the internal collection.
     * 
     * @param commandResultInfo
     *            the {@link CommandResultInfo} to add.
     */
    public void addCommandInfo(CommandResultInfo commandResultInfo) {
        commandResultInfos.add(commandResultInfo);
        setSuccessStatus(getSuccessStatus() && commandResultInfo.getSuccessStatus());
    }

    /**
     * Add a list of {@link CommandResultInfo}'s to the internal collection. This method has actually not been found
     * useful yet.
     * 
     * @param commandResultInfosList
     *            the list to add.
     */
    public void addCommandInfos(List<CommandResultInfo> commandResultInfosList) {
        for (CommandResultInfo commandResultInfo : commandResultInfosList) {
            addCommandInfo(commandResultInfo);
        }
    }

    /**
     * Add a list of {@link SourceRetrievalDetails} to the internal collection.
     * 
     * @param newSourceRetrievalDetailsList
     *            the list to add
     */
    public void addSourceDetails(List<SourceRetrievalDetails> newSourceRetrievalDetailsList) {
        for (SourceRetrievalDetails newSourceRetrievalDetails : newSourceRetrievalDetailsList) {
            addSourceRetrievalDetails(newSourceRetrievalDetails);
        }
    }

    /**
     * Add a single {@link SourceRetrievalDetails} to the internal collection. If the successStatus of the result is
     * indicates failure, then this is the point where the presumptive 'happy' flag of this object is also set to grumpy
     * and the build. If any
     * 
     * @param newSourceRetrievalDetails
     *            the details to add.
     */
    public void addSourceRetrievalDetails(SourceRetrievalDetails newSourceRetrievalDetails) {
        sourceRetrievalDetails.add(newSourceRetrievalDetails);
        setSuccessStatus(getSuccessStatus() && newSourceRetrievalDetails.getSuccessStatus());
    }

    /**
     * @return the buildId
     */
    public String getBuildId() {
        return buildId;
    }

    /**
     * @return the list of commandResultInfo objects.
     */
    public List<CommandResultInfo> getCommandResultInfos() {
        return commandResultInfos;
    }

    /**
     * @return the endTime
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Get the buildrequest working info directory.
     * 
     * @return the info directory
     */
    public File getInfoDir() {
        return infoDir;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @return the lastException
     */
    public Throwable getLastException() {
        return lastException;
    }

    /**
     * @return the lastExceptionMessage
     */
    public String getLastExceptionMessage() {
        return lastExceptionMessage;
    }

    /**
     * @return the directory designated to hold the build request level output.
     */
    public Set<File> getOutputFiles() {
        return outputFiles;
    }

    /**
     * @return the sourceRetrievalDetails
     */
    public List<SourceRetrievalDetails> getSourceRetrievalDetails() {
        return sourceRetrievalDetails;
    }

    /**
     * @return the startTime
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * @return the state of success, <code>true</code> means we have no errors in this collection of results.
     */
    public boolean getSuccessStatus() {
        return successStatus;
    }

    /**
     * @param buildId
     *            the buildId to set
     */
    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }

    /**
     * @param endTime
     *            the endTime to set
     */
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    /**
     * 
     * @param dir
     *            the working info directory for this build request.
     */
    public void setInfoDir(File dir) {
        this.infoDir = dir;
    }

    /**
     * Holder for a throwable with detail message related to the build request in general rather than an extraction
     * operation or monitored process. Setting an exception sets the overall success status to failure.
     * 
     * @param message
     *            the detail message
     * @param cause
     *            the cause.
     */
    public void setLastException(String message, Throwable cause) {
        setLastExceptionMessage(message);
        setLastException(cause);
        setSuccessStatus(false);
    }

    /**
     * Holder for a throwable related to the build request in general rather than an extraction operation or monitored
     * process. Setting an exception sets the overall success status to failure.
     * 
     * @param cause
     *            the cause.
     */
    public void setLastException(Throwable cause) {
        this.lastException = cause;
        setSuccessStatus(false);
    }

    /**
     * 
     * This is probably a bad idea. Lets let it live as a private method until someone is sure.
     * 
     * @param lastExceptionMessage
     *            the lastExceptionMessage to set
     */
    private void setLastExceptionMessage(String lastExceptionMessage) {
        this.lastExceptionMessage = lastExceptionMessage;
        setSuccessStatus(false);
    }

    /**
     * @param startTime
     *            the startTime to set
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setSuccessStatus(boolean status) {
        this.successStatus = status;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("BuildRequestResults [label=").append(label).append(", sourceRetrievalDetails=")
                .append(sourceRetrievalDetails).append(", commandResultInfos=").append(commandResultInfos)
                .append(", id=").append(id).append("]");
        return builder.toString();
    }

}
