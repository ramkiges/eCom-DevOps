package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * Project definition object that is serializable via JSON (immutable).
 * 
 * @author chunt
 * @version $Id$
 */
public class Project implements JsonObjectEntity {
    /**
     * DEBATABLE: This seems like a good place to also share any json labels that are shared, in the off chance we find
     * something {@link Project} doesn't use directly but is shared by others in the json ecosystem. But who would fit
     * in that category? We keep the ones used by project and shared by others too but none that are not actually used
     * by {@link Project} directly? TODO: Probably the honest thing is to scatter these to the components that use them.
     * I don't have enough experience with json to know if that is a time saver or not in the long run but it seems
     * reasonable if you have time to it.
     * 
     * 
     * ....
     */
    /**
     * json field, used to register a deserializer
     */
    public static final String ENTITY_TYPE_ID = "build_system/project";

    /*
     * TODO, track down the uses of both ID and PROJECT_ID and be sure no confusion as crept in it looks like you are
     * using id as project id for the project object , but then reusing it as project id later for others that reference
     * it.
     */

    /**
     * Marker for the ID field in the json representation.
     */
    public static final String ID = "id";
    /**
     * Marker for the unique project id in the json representation. There can only be no duplicates when loading
     * collections of project files.
     */
    public static final String PROJECT_ID = "project_id";

    /**
     * Marker for the project label field in the json representation.
     */
    public static final String LABEL = "label";
    /**
     * Marker for the extract definitions collections in the json representation.
     */
    public static final String EXTRACT_DEFINITIONS = "extract_definitions";
    /**
     * Marker for the resolved extract definitions collections in the json representation.
     */
    public static final String RESOLVED_EXTRACTS = "resolved_extracts";
    /**
     * Marker for a resolved URL definition in the json representation.
     */
    public static final String RESOLVED_URL = "resolvedUrl";
    /**
     * Marker for a branch specification in the json representation.
     */
    public static final String BRANCH = "branch";
    /**
     * Marker for a requested revision in the json representation.
     */
    public static final String REQUESTED_REVISION = "requestedRevision";
    /**
     * Marker for the build plan collection in the json representation.
     */
    public static final String BUILD_PLANS = "build_plans";
    /**
     * Marker for the build request collection in the json representation.
     */
    public static final String BUILD_REQUESTS = "build_requests";
    /**
     * Marker for the human friendly project label in the json representation.
     */
    public static final String PROJECT_LABEL = "project_label";
    /**
     * Marker for the name element sometimes found in the json representation.
     */
    public static final String NAME = "name";
    /**
     * Marker for the build command element found the json representation.
     */
    public static final String BUILD_COMMAND = "build_command";
    /**
     * Marker for the post build command element found the json representation.
     */
    public static final String POST_BUILD_COMMAND = "post_build_command";
    /**
     * Marker for the URL element found the json representation.
     */
    public static final String URL = "url";
    /**
     * Marker for the base URL element found the json representation.
     */
    public static final String BASE_URL = "baseUrl";
    /**
     * Marker for the repo UUID found the json representation.
     */
    public static final String UUID = "uuid";
    /**
     * Marker for the effective revision element found the json representation.
     */
    public static final String EFFECTIVE_REVISION = "effectiveRevision";
    private String id;
    private String label;

    // private SortedMap<String, ExtractDefinition> extractDefinitions;
    private SortedMap<String, BuildPlan> buildPlans;

    /**
     * The only constructor, creates a Project out of its build plans and map of extract definitions. I kept waiting for
     * the reason we keep a redundant map of extract definitions. They where in the original build system and perhaps
     * should not have been retained.
     * 
     * 
     * @param id
     *            this should be the project id
     * @param label
     *            the human readable label
     * @param buildPlans
     *            map of {@link BuildPlan}s
     */
    public Project(String id, String label, Map<String, BuildPlan> buildPlans) {
        this.id = id;
        this.label = label;

        /*
         * keys are buildPlan NAMES here, this is probably wrong, it has to do with json...*?
         */
        this.buildPlans = new TreeMap<String, BuildPlan>(buildPlans);
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Project)) {
            return false;
        }
        Project other = (Project) obj;
        if (buildPlans == null) {
            if (other.buildPlans != null) {
                return false;
            }
        } else if (!buildPlans.equals(other.buildPlans)) {
            return false;
        }
        // // if (extractDefinitions == null) {
        // // if (other.extractDefinitions != null) {
        // // return false;
        // // }
        // } else if (!extractDefinitions.equals(other.extractDefinitions)) {
        // return false;
        // }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (label == null) {
            if (other.label != null) {
                return false;
            }
        } else if (!label.equals(other.label)) {
            return false;
        }
        return true;
    }

    /**
     * Fetch a {@link BuildPlan} by its id from the collection of build plans known to this project.
     * 
     * @param buildPlanId
     *            the build plan id
     * @return the matching {@link BuildPlan}
     * @throws BuildServiceException
     *             for general evil being afoot.
     */
    public BuildPlan getBuildPlan(String buildPlanId) throws BuildServiceException {

        if (!buildPlans.containsKey(buildPlanId)) {
            throw new BuildServiceException("Unknown buildPlan requested:" + buildPlanId);
        }
        return buildPlans.get(buildPlanId);
    }

    /**
     * @return the buildPlans
     */
    public Map<String, BuildPlan> getBuildPlans() {
        return buildPlans;
    }

    /** {@inheritDoc} */
    @Override
    public Object getEntityInstanceId() {
        // Not used.
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

    /**
     * @return the extractDefinitions
     */
    // public Map<String, ExtractDefinition> getExtractDefinitions() {
    // return extractDefinitions;
    // }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildPlans == null) ? 0 : buildPlans.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        return result;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Project [id=").append(id).append(", label=").append(label).append(", buildPlans=")
                .append(buildPlans).append("]");
        return builder.toString();
    }

    /** {@inheritDoc} */
    @Override
    public void writeSelf(JsonObjectOutputStream jsonOut) throws IOException {
        jsonOut.writeStartObject();

        jsonOut.writeStringField(ID, id);
        jsonOut.writeStringField(LABEL, label);

        jsonOut.writeObjectFieldStart(BUILD_PLANS);
        if (buildPlans != null) {
            for (String buildPlanKey : buildPlans.keySet()) {
                BuildPlan buildPlan = buildPlans.get(buildPlanKey);
                jsonOut.writeObjectField(buildPlanKey, buildPlan);
            }
        }

        jsonOut.writeEndObject();

        jsonOut.writeEndObject();

    }

}
