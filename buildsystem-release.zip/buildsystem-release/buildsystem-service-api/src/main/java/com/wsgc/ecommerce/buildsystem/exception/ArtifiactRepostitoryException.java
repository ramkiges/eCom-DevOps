package com.wsgc.ecommerce.buildsystem.exception;


/**
 * Exception class for AritfiactRepository related errors.
 * 
 * 
 * @author chunt
 * @version $Id$ 
 */
public class ArtifiactRepostitoryException extends Exception { 

    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public ArtifiactRepostitoryException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public ArtifiactRepostitoryException(String message) {
        super(message);
    }

    /**
     * @param cause the cause
     */
    public ArtifiactRepostitoryException(Throwable cause) {
        super(cause);
    }

}
