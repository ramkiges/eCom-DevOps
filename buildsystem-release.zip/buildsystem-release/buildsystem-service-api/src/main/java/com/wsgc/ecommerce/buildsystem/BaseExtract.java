package com.wsgc.ecommerce.buildsystem;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;

/**
 * In the framework of the build system at some point the <i>things</i> you are building with are contained in some kind
 * of top level source control organizational unit. BaseExtract holds a URL to those <i>things</i>. <br>
 * At this level in the code hierarchy, we are not asking personal questions like how those <i>things</i> are further
 * resolved via properties or what those <i>things</i> even are, but we want to be sure exactly where they are. "Base"
 * in this sense is that of a base class at the beginning of the hierarchy or the root of a phylum in other fields.
 * 
 * 
 * DEBATABLE should a URI but the roots run deep into build system 1, pay off may be little.
 * 
 * @author chunt
 * @version $Id$
 * @param <T>
 */
public interface BaseExtract<T> extends JsonObjectEntity, Comparable<T> {

    /**
     * 
     * @return the location of the resource
     */
    String getURL();

}
