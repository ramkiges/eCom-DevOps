/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Runtime exception for BuildManager related errors you don't want to write a
 * throws clause for.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildManagerRuntimeException extends RuntimeException {

  
    private static final long serialVersionUID = 1L;
  
    /**
     * @param message the detail message
     * @param cause the cause
     */
    public BuildManagerRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public BuildManagerRuntimeException(String message) {
        super(message);
    }

    /**
     * @param cause the original cause
     */
    public BuildManagerRuntimeException(Throwable cause) {
        super(cause);
    }

}
