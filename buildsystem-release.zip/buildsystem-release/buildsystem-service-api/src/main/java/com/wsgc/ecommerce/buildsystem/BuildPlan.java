package com.wsgc.ecommerce.buildsystem;

import static com.wsgc.ecommerce.buildsystem.Project.BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.EXTRACT_DEFINITIONS;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.POST_BUILD_COMMAND;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * For Buildsystem 2 a build plan is the analog of 'build type' in build system 1. A {@link BuildPlan} is combined with
 * specific extract resolution information to create a {@link BuildRequest}. A complete "Build" is the results of a
 * collection of requested build plans turned in to a collection of {@link BuildRequest}'s and executed separately.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class BuildPlan implements Comparable<BuildPlan>, JsonObjectEntity {

    private final List<String> buildCommand;
    private final List<String> postBuildCommand;
    private final SortedMap<String, ExtractDefinition> extractDefinitions;
    private final String id;
    private final String label;
    /**
     * JSON likes this, no one else cares
     */
    public static final String ENTITY_TYPE_ID = "build_system/build_plan";

    /**
     * A build plan is a collection of extract definitions, a build command and a post build command.
     * 
     * @param id
     *            the build plan id
     * @param label
     *            a pretty {@link String} for humans to talk about this build plan
     * @param extractDefinitions
     *            a {@link Map} of {@link ExtractDefinition}s that comprise this build plan
     * @param command
     *            the command to execute against the extracts
     * @param postBuildCommand
     *            the post build command to run after the build command
     */
    public BuildPlan(String id, String label, Map<String, ? extends ExtractDefinition> extractDefinitions,
            List<String> command, List<String> postBuildCommand) {
        this.id = id;
        this.label = label;
        if (extractDefinitions.containsKey(null)) {
            throw new NullPointerException("Null keys are not allowed in extract definitions map");
        }
        this.extractDefinitions = new TreeMap<String, ExtractDefinition>(extractDefinitions);
        this.buildCommand = command;
        this.postBuildCommand = postBuildCommand;
    }

    /**
     * @return the command
     */
    public List<String> getBuildCommand() {
        return Collections.unmodifiableList(buildCommand);
    }

    /**
     * @return unmodifiable copy of the post build command {@link String}s
     */
    public List<String> getPostBuildCommand() {
        return Collections.unmodifiableList(postBuildCommand);
    }

    /**
     * @return unmodifiable copy of the Map of {@link ExtractDefinition}s
     */
    public Map<String, ExtractDefinition> getExtractDefinitions() {
        return Collections.unmodifiableMap(extractDefinitions);
    }

    /**
     * Getter for a specific extract definition.
     * 
     * @param key
     *            the extract name.
     * @return {@link ExtractDefinition} from the map
     */
    public ExtractDefinition getExtractDefinition(String key) {
        if (extractDefinitions.containsKey(key)) {
            return extractDefinitions.get(key);
        }
        throw new IllegalArgumentException("Key " + key + " not found in extract definitions. BuildPlan toString(): "
                + toString());

    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(getClass().getCanonicalName());
        builder.append("\n");
        builder.append(ID).append(":").append(id).append("\n");
        builder.append(LABEL).append(":").append(label).append("\n");
        builder.append(EXTRACT_DEFINITIONS).append(":").append(extractDefinitions.toString()).append("\n");
        builder.append(BUILD_COMMAND).append(":").append(buildCommand).append("\n");
        builder.append(POST_BUILD_COMMAND).append(":").append(postBuildCommand).append("\n");
        return builder.toString();
    }

    /** {@inheritDoc} */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

    /** {@inheritDoc} */
    @Override
    public Object getEntityInstanceId() {
        // Not used.
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public void writeSelf(JsonObjectOutputStream json) throws IOException {
        json.writeStartObject();
        json.writeStringField(ID, id);
        json.writeStringField(LABEL, label);

        json.writeArrayFieldStart(BUILD_COMMAND);
        for (String cmd : buildCommand) {
            json.writeString(cmd);
        }
        json.writeEndArray();

        json.writeArrayFieldStart(POST_BUILD_COMMAND);
        for (String cmd : postBuildCommand) {
            json.writeString(cmd);
        }
        json.writeEndArray();

        json.writeObjectFieldStart(EXTRACT_DEFINITIONS);

        for (String extractDefinitionKey : extractDefinitions.keySet()) {
            json.writeObjectField(extractDefinitionKey, extractDefinitions.get(extractDefinitionKey));
        }

        json.writeEndObject();

        json.writeEndObject();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildCommand == null) ? 0 : buildCommand.hashCode());
        result = prime * result + ((extractDefinitions == null) ? 0 : extractDefinitions.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        return result;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BuildPlan)) {
            return false;
        }
        BuildPlan other = (BuildPlan) obj;
        if (buildCommand == null) {
            if (other.buildCommand != null) {
                return false;
            }
        } else if (!buildCommand.equals(other.buildCommand)) {
            return false;
        }
        if (extractDefinitions == null) {
            if (other.extractDefinitions != null) {
                return false;
            }
        } else if (!extractDefinitions.equals(other.extractDefinitions)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (label == null) {
            if (other.label != null) {
                return false;
            }
        } else if (!label.equals(other.label)) {
            return false;
        }
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(BuildPlan anotherBuildPlan) throws ClassCastException {
        return this.getLabel().compareTo(((BuildPlan) anotherBuildPlan).getLabel());
    }

}
