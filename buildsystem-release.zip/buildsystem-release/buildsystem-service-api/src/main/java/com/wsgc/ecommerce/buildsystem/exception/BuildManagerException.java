package com.wsgc.ecommerce.buildsystem.exception;

/**
 * Exception class for BuildManager related errors.
 * 
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildManagerException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * @param message the detail message
     * @param cause the original cause
     */
    public BuildManagerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message the detail message
     */
    public BuildManagerException(String message) {
        super(message);
    }

 
    /**
     * @param cause the cause
     */
    public BuildManagerException(Throwable cause) {
        super(cause);
    }

}
