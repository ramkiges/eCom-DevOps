package com.wsgc.ecommerce.buildsystem;

import static com.wsgc.ecommerce.buildsystem.Project.BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.POST_BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.RESOLVED_EXTRACTS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * 
 * A build is what happens from servicing one or more {@link BuildRequest}'s Each {@link BuildRequest} is basically an
 * independent unit of work consisting of a collection of {@link ResolvedExtract}'s and a build command to run on them,
 * followed by a post build command that probably has something to do with deployment or other downstream process. A
 * {@link BuildPlan} is combined with revision and branch info to create a {@link BuildRequest}.
 * 
 * DEBATABLE Build id is in build request and all the json and repo artifacts along the way because of the build monitor
 * implementation.
 * 
 * @author chunt
 * @version $Id$
 */
public class BuildRequest implements JsonObjectEntity, Comparable<BuildRequest> {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    /**
     * required for json deserialization
     */
    public static final String ENTITY_TYPE_ID = "build_system/build_request";
    /**
     * required for shared json deserialization
     */
    public static final String BUILD_ID = "build_id";
    /**
     * required and shared for json deserialization
     */
    public static final String GENERATION_ID = "generation_id";

    private final String id;
    private final String label;
    private final List<String> buildCommand;
    private final List<String> postBuildCommand;

    // TODO why isn't this ? extends ResolvedExtract, its trying to be .. hang on.
    @SuppressWarnings("rawtypes")
    private final SortedMap<String, ResolvedExtract> resolvedExtracts;
    private String buildId = BuildOrder.ID_NOT_INITIALIZED;
    private String generationId = BuildOrder.ID_NOT_INITIALIZED;
    private final int index;

    /**
     * The constructor.
     * 
     * TODO remove the rawtypes suppression once you settle the generic wild cards
     * 
     * @param id
     *            the build request id
     * @param label
     *            the build request label, often erroneously referred to by its BuildSystem 1 analog "build type"
     * @param resolvedExtractList
     *            a {@link List} of {@link ResolvedExtract}s that
     * @param command
     *            the list of command {@link String}s to execute after the extracts are collected for such processing
     * @param postBuildCommand
     *            a post build command for importing the build plan level build artifacts.
     * 
     */
    @SuppressWarnings("rawtypes")
    public BuildRequest(final String id, final String label, final List<ResolvedExtract> resolvedExtractList,
            final List<String> command, final List<String> postBuildCommand) {
        this.id = id;
        this.label = label;
        this.buildCommand = Collections.unmodifiableList(new ArrayList<String>(command));
        this.postBuildCommand = Collections.unmodifiableList(new ArrayList<String>(postBuildCommand));
        this.resolvedExtracts = new TreeMap<String, ResolvedExtract>();
        for (ResolvedExtract resolvedExtract : resolvedExtractList) {
            resolvedExtracts.put(resolvedExtract.getName(), resolvedExtract);
        }
        index = generateIndex();
        logger.trace("{} Created {}", getClass().getName(), toString());
    }

    /** {@inheritDoc} */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public int compareTo(BuildRequest o) {
        if (equals(o)) {
            return 0;
        }

        // if these two are not completely identical. Check name.
        if (!getLabel().equals(o.getLabel())) {
            return getLabel().compareTo(o.getLabel());
        }

        if (!getId().equals(o.getId())) {
            return getId().compareTo(o.getId());
        }

        if (!getBuildId().equals(o.getBuildId())) {
            return getBuildId().compareTo(o.getBuildId());
        }

        if (!getGenerationId().equals(o.getGenerationId())) {
            return getGenerationId().compareTo(o.getGenerationId());
        }

        if (!getBuildCommand().equals(o.getBuildCommand())) {
            String[] commandString = getBuildCommand().toArray(new String[0]);
            String[] otherCommandString = o.getBuildCommand().toArray(new String[0]);
            for (int i = 0; i < commandString.length; i++) {
                if (!commandString[i].equals(otherCommandString[i])) {
                    return commandString[i].compareTo(otherCommandString[i]);
                }
            }
        }

        // If name is equal, The one with a shorter resolvedExtract list is first. TODO:(2nd?) check that sometime when
        // you actually care which.
        int sizeDiff = resolvedExtracts.size() - o.resolvedExtracts.size();
        if (sizeDiff != 0) {
            return ((Integer) resolvedExtracts.size()).compareTo(o.resolvedExtracts.size());
        }

        // if they are the same size, go through the resolvedExtracts until a difference is seen
        SortedMap<String, ResolvedExtract> mine = getResolvedExtracts();
        SortedMap<String, ResolvedExtract> other = o.getResolvedExtracts();

        // Find a difference in the keys
        String[] keySet = mine.keySet().toArray(new String[0]);
        String[] otherKeySet = other.keySet().toArray(new String[0]);

        for (int i = 0; i < keySet.length; i++) {
            if (!keySet[i].equals(otherKeySet[i])) {
                return keySet[i].compareTo(otherKeySet[i]);
            }
        }

        // Still here? Fine, go through the values now.

        // Find a difference in the values
        ResolvedExtract[] values = mine.values().toArray(new ResolvedExtract[0]);
        ResolvedExtract[] otherValues = other.values().toArray(new ResolvedExtract[0]);

        for (int i = 0; i < keySet.length; i++) {
            ResolvedExtract resolvedExtract = values[i];
            ResolvedExtract otherResolvedExtract = otherValues[i];

            // TODO need a generic comparator in ResolvedExtracts
            if (!resolvedExtract.equals(otherResolvedExtract)) {
                return resolvedExtract.compareTo(otherResolvedExtract);
            }
        }

        // How do we get here? Not all fields in equals accounted for in compare?
        // TODO do we need a Runtime version of BuildSystemException?
        throw new IllegalArgumentException("Unexpected state: Comparator failed to determine order. this:" + toString()
                + "/nOther:" + o.toString());

    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BuildRequest)) {
            return false;
        }
        BuildRequest other = (BuildRequest) obj;
        if (buildCommand == null) {
            if (other.buildCommand != null) {
                return false;
            }
        } else if (!buildCommand.equals(other.buildCommand)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (label == null) {
            if (other.label != null) {
                return false;
            }
        } else if (!label.equals(other.label)) {
            return false;
        }

        /**
         * BuildId and Generation are not part of what makes a BuildRequest different from another. if (buildId == null)
         * { if (other.buildId != null) { return false; } } else if (!buildId.equals(other.buildId)) { return false; }
         * if (generationId == null) { if (other.generationId != null) { return false; } } else if
         * (!generationId.equals(other.generationId)) { return false; }
         */

        if (resolvedExtracts == null) {
            if (other.resolvedExtracts != null) {
                return false;
            }
        } else if (!resolvedExtracts.equals(other.resolvedExtracts)) {
            return false;
        }

        if (index != (other.index)) {
            return false;
        }

        return true;
    }

    /**
     * This is hash based but not the hashCode(). Not sure if there is a remaining reason why.
     * 
     * @return the index calculated to reference this build request.
     */
    private int generateIndex() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildCommand == null) ? 0 : buildCommand.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());

        logger.trace(this.getClass().getName() + " This BuildRequest has "
                + ((resolvedExtracts == null) ? 0 : resolvedExtracts.size()) + " entries.");

        logger.trace(this.getClass().getName() + " about to index resolved extracts result:" + result);

        if (resolvedExtracts != null) {
            for (String resolvedExtractKey : resolvedExtracts.keySet()) {
                result = prime * result + resolvedExtracts.get(resolvedExtractKey).getIndex();
                if (logger.isTraceEnabled()) {
                    logger.trace(this.getClass().getName() + " adding resolved extract(" + resolvedExtractKey
                            + "), result now:" + result);
                }
            }
        }
        logger.trace("{} done calculating index:{}", this.getClass().getName(), result);
        return result;
    }

    /**
     * @return the command
     */
    // TODO look at every 'get' and 'set' and make sure you are returning unmodifiable collections and making defensive
    // copies of input.
    public List<String> getBuildCommand() {
        return Collections.unmodifiableList(buildCommand);
    }

    /**
     * 
     * And WHY OH WHY did we have to bring build id down in to the build request? Because
     * {@link BuildMonitor#createBuildJobStatus(BuildInfo)} wanted it at one point.
     * 
     * @see {@link BuildMonitor#createBuildJobStatus(BuildInfo)}
     * 
     * @return the build id
     */
    public String getBuildId() {
        return buildId;
    }

    /** {@inheritDoc} */
    @Override
    public Object getEntityInstanceId() {
        // unused
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * TODO BuildOrder has a lock method to make index real or not. Do you want to use that here too? If not, defend
     * your answer. Especially after adding "setBuildId".
     * 
     * 
     * @return the index.
     */
    public int getIndex() {
        if (logger.isTraceEnabled()) {
            logger.trace(getClass().getName() + " index:" + index);
        }
        return index;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @return an unmodifiable copy of the post build command {@link String}s
     */
    public List<String> getPostBuildCommand() {
        return Collections.unmodifiableList(postBuildCommand);
    }

    /**
     * @return the ResolvedExtracts
     */
    @SuppressWarnings("rawtypes")
    public SortedMap<String, ResolvedExtract> getResolvedExtracts() {
        return Collections.unmodifiableSortedMap(resolvedExtracts);
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildCommand == null) ? 0 : buildCommand.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + ((resolvedExtracts == null) ? 0 : resolvedExtracts.hashCode());
        return result;
    }

    /**
     * Sets the build id. The BuildRequest is set and its index stable when both this and ResovedExtracts are both set.
     * TODO, may need/want to enforce that with a lock() method.
     * 
     * DEBATABLE, putting the build id in the request was a late and often questioned action.
     * 
     * @param newBuildId
     *            the buildId to set
     */
    public void setBuildId(String newBuildId) {
        if (newBuildId == null) {
            throw new IllegalArgumentException("Build id can not be set to null");
        }

        /*
         * TODO we set build id at least twice to the same value in repo init. We first use a constructor that accepts
         * the build location (buildId) to create an BuildReference and then it goes on with lazy init to deserialize
         * the buildOrder (which sets it again). This offends the eye, confuses the debugger watcher and doesn't adhere
         * to the principle of least surprise... same with generationId
         */
        if (!buildId.equals(BuildOrder.ID_NOT_INITIALIZED) && !buildId.equals(newBuildId)) {
            throw new IllegalArgumentException("Build id is already set. Current build id:" + buildId
                    + " attempted new value:" + newBuildId);
        }
        this.buildId = newBuildId;
    }

    /**
     * Setter for generation id. Even though it can be derived from the build id, we let some other object do that so we
     * have a single source of truth. Like build Id this can only be set once.
     * 
     * TODO: Same as for setbuildId()
     * 
     * @param newGenerationId
     *            the next generation id to set. Can not be null
     */
    public void setGenerationId(String newGenerationId) {
        if (newGenerationId == null) {
            throw new IllegalArgumentException("Generation id can not be set to null");
        }
        if (!generationId.equals(BuildOrder.ID_NOT_INITIALIZED) && !generationId.equals(newGenerationId)) {
            throw new IllegalArgumentException("Generation id is already set. Current generation id:" + generationId
                    + " attempted new value:" + newGenerationId);
        }
        generationId = newGenerationId;
    }

    /**
     * @return the generationId
     */
    public String getGenerationId() {
        return generationId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(getClass().getCanonicalName());
        builder.append("\n");
        builder.append("id:").append(id).append("\n");
        builder.append("label:").append(label).append("\n");
        builder.append("buildId:").append(buildId).append("\n");
        builder.append("generationId:").append(generationId).append("\n");
        builder.append("build_command:").append(buildCommand).append("\n");
        builder.append("post_build_command:").append(postBuildCommand).append("\n");
        builder.append("Resolvedextracts:");
        for (String resolvedExtractKey : resolvedExtracts.keySet()) {
            builder.append(resolvedExtracts.get(resolvedExtractKey).toString());
        }
        return builder.toString();

    }

    /** {@inheritDoc} */
    @Override
    public void writeSelf(JsonObjectOutputStream jsonOut) throws IOException {
        jsonOut.writeStartObject();
        jsonOut.writeStringField(ID, id);
        jsonOut.writeStringField(LABEL, label);

        /*
         * First thought,its in the buildOrder, don't write it again. Second thought, its a sanity check, absolutely
         * write it.
         */
        jsonOut.writeStringField(BUILD_ID, buildId);
        jsonOut.writeStringField(GENERATION_ID, generationId);

        jsonOut.writeArrayFieldStart(BUILD_COMMAND);
        for (String commandElement : buildCommand) {
            jsonOut.writeString(commandElement);
        }
        jsonOut.writeEndArray();

        jsonOut.writeArrayFieldStart(POST_BUILD_COMMAND);
        for (String commandElement : postBuildCommand) {
            jsonOut.writeString(commandElement);
        }
        jsonOut.writeEndArray();

        jsonOut.writeObjectFieldStart(RESOLVED_EXTRACTS);

        for (String resolvedExtract : resolvedExtracts.keySet()) {
            jsonOut.writeObjectField(resolvedExtract, resolvedExtracts.get(resolvedExtract));
        }

        jsonOut.writeEndObject();

        jsonOut.writeEndObject();

    }

}
