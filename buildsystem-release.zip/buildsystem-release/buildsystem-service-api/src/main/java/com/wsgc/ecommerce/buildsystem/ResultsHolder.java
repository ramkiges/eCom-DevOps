package com.wsgc.ecommerce.buildsystem;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * 
 * 
 * Holder for results without promising if they are kept in quantum bits or on clay tablets. No promises about
 * synchronization are made except the object will be writable until someone formally indicates the result set has been
 * collected and calls the lock() method rendering the set read only for as long as the data exists. The data exists
 * until the java virtual machine decides it doesn't. Implementations should play well with their new best friend
 * 'finalize()'.
 * 
 * @author chunt
 * @version $Id$
 */
public interface ResultsHolder {

    /**
     * Create a new BufferedReader for accessing previously stored (and locked) results.
     * 
     * @return the BufferedReader to use.
     * @throws IOException
     *             if you forget to use lock() first to indicate the results are done or the java language gets grumpy
     *             along the way.
     */
    BufferedReader getResultsReader() throws IOException;

    /**
     * Add string to the growing collection of results.
     * 
     * @param string
     *            the new result you want to store.
     * @throws IOException
     *             On error to store data or if denied access because the 'locked' state was set.
     */
    void appendResultsString(String string) throws IOException;

    /**
     * Flush any buffers check for errors and make the result read only.
     * 
     */
    void lockResults();
}
