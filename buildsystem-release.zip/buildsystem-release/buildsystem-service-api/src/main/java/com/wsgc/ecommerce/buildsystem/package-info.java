/**
 * Contains objects related to the build system.
 */
package com.wsgc.ecommerce.buildsystem;

