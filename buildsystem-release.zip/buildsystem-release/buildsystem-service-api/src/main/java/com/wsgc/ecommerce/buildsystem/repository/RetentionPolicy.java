package com.wsgc.ecommerce.buildsystem.repository;

import java.util.Set;

/**
 * @author chunt
 * @version $Id$ 
 */
interface RetentionPolicy {
  
    
    /** Returns a set BuildReferences that are now expired according 
     * to the retention policy.
     * 
     * @param artifactRepository the {@link ArtifactRepository} being managed
     * @return a possibly unmodifiable Set<BuildReference>, if there are no references that qualify the 
     * returned set can be empty or null.
     */
    Set<BuildReference> getRemovalList(ArtifactRepository artifactRepository);
}
