/**
 * @author chunt
 * @version $Id$
 * 
 */
package com.wsgc.ecommerce.buildsystem.repository;

import java.io.File;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;

/**
 * 
 * Your handle on the build artifacts living in the repo. This says nothing about its import/deployment/activation state
 * as seen by the rest of the code delivery pipeline. These files are in the location with the logical mapping and we
 * have here class access points for reading about builds that have completed. Whether its successfully or not.
 * 
 * @author chunt
 * @version $Id$
 */
public interface BuildReference {

    /**
     * getter for a builds local file system directory.
     * 
     * @return the absolute file location of the build artifacts on the host system.
     */
    File getBuildLocation();

    /**
     * @return the buildId belonging to this reference.
     */
    String getBuildId();

    /**
     * @return the build manifest file
     */
    File getManifest();

    /**
     * @return the build log
     */
    File getLog();

    /**
     * @return a {@link File} pointing to the error log. On a good day, this will be NULL
     */
    File getErrorLog();

    /**
     * @return the Unix time in milliseconds the build finished.
     */
    long getCompletionTimestamp();

    /**
     * @return a single {@link String} that holds the json representation of the build order for this build
     * @throws ArtifiactRepostitoryException
     *             the usual reasons... unexpected chaos
     */
    String getBuildOrderJson() throws ArtifiactRepostitoryException;

    /**
     * Simple answer to 'was this build free of compile time errors'?
     * 
     * @return {@link String} with implementation defined representation of success or failure of <i>the build
     *         process</i>
     */
    String getStatusString();

    /**
     * @return who to blame for starting this build attempt
     */
    String getUser();

    /**
     * @return deserialized {@link BuildOrder} that was used to create the build
     * @throws ArtifiactRepostitoryException wraps all underlying trouble
     */
    BuildOrder getBuildOrder() throws ArtifiactRepostitoryException;

    /**
     * Index is different than hash code as it uses only build differentiating fields.
     * 
     * @return the index of this build
     * @throws ArtifiactRepostitoryException because lazy init may have to deserialize the build order and that can fail
     */
    int getIndex() throws ArtifiactRepostitoryException;

    /**
     * @return the t
     * @deprecated consolidating time getters
     */
    @Deprecated
    long getStartTimestamp();

    /**
     * 
     * TODO should document why this isn't used
     * @return build start we assume, not clear
     */
    long getBuildStart();

    /**
     * Performance metric intended for use with predictive source extract strategy.  
     * TODO still in dev, will have to be a per request map
     * @return the ms time spent actually running the extract process
     */
    long getTotalExtractCPUTime();

    /**
     * @return the time spent waiting for the extract to finish... including scheduling and queuing for source access 
     */
    long getTotalExtractRealTime();

    /**
     *  
     * @return Total time spent on extract and build steps
     */
    long getTotalBuildProcessCPUTime();

    /**
     * @return Total time spent waiting for build to finish,
     */
    long getTotalBuildProcessRealTime();

    /**
     * @return coded data {@link String} with condensed performance data in one place
     */
    String getBuildPerformanceString();

    /**
     * Import process needs a logical location holder
     * @return the logical location as defined by your local implementation
     */
    String getLogicalLocation();

}
