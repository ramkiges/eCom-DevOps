package com.wsgc.ecommerce.buildsystem;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;

/**
 * 
 * Basic interface in the extract hierarchy. Holds constants for branch and revision parsing even though the
 * {@link ExtractDefinition} implementors do not have those.
 * 
 * @author chunt
 * @version $Id$
 */
public interface ExtractDefinition extends JsonObjectEntity {
    // This has been a svn only object before, it didn't seem cleaner.
    /**
     * Marker for identifying a branch via the tag designation.
     */
    String TAGS_MARKER = "tags";
    /**
     * Marker for identifying a branch via the branch designation.
     */
    String BRANCHES_MARKER = "branches";

    /**
     * Marker for identifying a revision via the "head" designation.
     */
    String HEAD_REVISION_MARKER = "head";
    /**
     * Marker for identifying a trunk.
     */
    String TRUNK_MARKER = "trunk";
    /**
     * Marker used to scan user input for tag specification
     */
    String TAG_BANCH_PREFIX = "tag:";

    /**
     * @return the baseUrl
     */
    String getUrl();

    /**
     * @return the name
     */
    String getName();

    /**
     * @return the type of the extract (what kind of repo?)
     */
    String getExtractType();

    /**
     * @return the uuid
     */
    String getUuid();

}