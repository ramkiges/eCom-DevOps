/**
 * @author chunt
 * @version $Id$
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import com.wsgc.ecommerce.buildsystem.exception.ExtractException;

/**
 * As the idea of a predictive retrieval strategy was explored it seemed I was looking for an object that its self would
 * queued somehow and at the correct moment in the build schedule be handed to an actual java scheduler for concurrent
 * execution with a configuration specific in this delayed execution. This was painfully resolved in my mind with a
 * further abstraction around the idea of a future task or event handle that wasn't in the java language. Classes that
 * implement this may have the getter blocking for results while in a queue waiting to start or be waiting on a executor
 * service to finish something pull off a queue and started.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public interface SourceRetrievalAction {

    /**
     * This is a blocking call now.
     * 
     * @return the {@link SourceRetrievalDetails} once the extract is actually attempted.
     * @throws ExtractException
     *             if the extract fails.
     */
    SourceRetrievalDetails getSourceRetrievalDetails() throws ExtractException;

}