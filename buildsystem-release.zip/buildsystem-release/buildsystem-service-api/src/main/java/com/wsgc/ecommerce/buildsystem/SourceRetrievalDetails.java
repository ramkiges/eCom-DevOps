package com.wsgc.ecommerce.buildsystem;

import java.io.File;

/**
 * Place to hold the answers to 'what happened when we tried to extract'. The answer is in the form of a location of
 * your happy collection or a status of <code>false</code> and hopefully an exception explaining why.
 * 
 * @author chunt
 * @version $Id$
 */
public class SourceRetrievalDetails {
    private final File extractLocation;
    @SuppressWarnings("rawtypes")
    private final ResolvedExtract resolvedExtract;
    protected String lastExceptionMessage;

    protected Throwable lastException;

    private boolean status;
    private long startTime;
    private long endTime;

    /**
     * The constructor. This object is created with a success status of <code>false</code> and the last step in the
     * extract process is to set that to <code>true</code>.
     * 
     * @param resolvedExtract
     *            the {@link ResolvedExtract} that was requested.
     * @param extractLocation
     *            the file system location they should have ended up in.
     */
    @SuppressWarnings("rawtypes")
    public SourceRetrievalDetails(ResolvedExtract resolvedExtract, File extractLocation) {
        this.extractLocation = extractLocation;
        this.resolvedExtract = resolvedExtract;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SourceRetrievalDetails)) {
            return false;
        }
        SourceRetrievalDetails other = (SourceRetrievalDetails) obj;
        if (extractLocation == null) {
            if (other.extractLocation != null) {
                return false;
            }
        } else if (!extractLocation.equals(other.extractLocation)) {
            return false;
        }
        if (resolvedExtract == null) {
            if (other.resolvedExtract != null) {
                return false;
            }
        } else if (!resolvedExtract.equals(other.resolvedExtract)) {
            return false;
        }
        if (status != other.status) {
            return false;
        }
        return true;
    }

    /**
     * @return the canonicalPath
     */
    public File getExtractLocation() {
        return extractLocation;
    }

    /**
     * @return the lastException
     */
    public Throwable getLastException() {
        return lastException;
    }

    /**
     * @return the lastExceptionMessage
     */
    public String getLastExceptionMessage() {
        return lastExceptionMessage;
    }

    /**
     * @return the resolvedSvnExtract
     */
    @SuppressWarnings("rawtypes")
    public ResolvedExtract getResolvedSvnExtract() {
        return resolvedExtract;
    }

    /**
     * @return the status
     */
    public boolean getSuccessStatus() {
        return status;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((extractLocation == null) ? 0 : extractLocation.hashCode());
        result = prime * result + ((resolvedExtract == null) ? 0 : resolvedExtract.hashCode());
        result = prime * result + (status ? 1231 : 1237);
        return result;
    }

    /**
     * Setter for error condition (status = <code>false</code>)
     * 
     * @param message
     *            the detail message associated with the action that set the exception.
     * @param cause
     *            the original throwable.
     */
    public void setLastException(String message, Throwable cause) {
        this.lastExceptionMessage = message;
        this.lastException = cause;
        status = false;
    }

    /**
     * @param lastException
     *            the lastException to set
     */
    public void setLastException(Throwable lastException) {
        this.lastException = lastException;
        status = false;
    }

    /**
     * @param newstatus
     *            the status to set
     */
    public void setSuccessStatus(boolean newstatus) {
        this.status = newstatus;
    }

    /**
     * Used for performance metrics, plus I liked the name.
     * 
     * @return whatever someone set at the end time, should be the Unix time in ms when the extract was completed
     */
    public long getEndTime() {
        return endTime;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SourceRetrievalDetails [extractLocation=").append(extractLocation)
                .append(", resolvedSvnExtract=").append(resolvedExtract).append(", lastExceptionMessage=")
                .append(lastExceptionMessage).append(", lastException=").append(lastException).append(", status=")
                .append(status).append(", startTime=").append(startTime).append(", endTime=").append(endTime)
                .append("]");
        return builder.toString();
    }

    /**
     * @param timeMs
     *            should be the time (Unix ms) when the extract finished
     */
    public void setEndTime(long timeMs) {
        this.endTime = timeMs;
    }

    /**
     * @return the startTime
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * @param startTime
     *            the startTime to set
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * TODO we don't have an Id on the ResolvedExtract.. using name... maybe a bad idea. Make it a real id or a name but
     * don't quietly change it like this.
     * 
     * @return the NAME
     */
    public String getId() {
        return resolvedExtract.getName();
    }

}
