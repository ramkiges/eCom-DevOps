package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * 
 * Source control systems can hold multiple instances of the code set organized by time and space or as they call it
 * <b>branch</b> and/or <b>revision</b>. This interface represents the idea of a location like that defined by
 * {@link BaseExtract} with <b>concrete</b> definition of time and space (branch and revision) to define a unique set of
 * source files for the build. The implementations are free to use special knowledge of the underlying source control
 * system to start gaining efficiency. Since these end up as part of a forensic record of the build attempt, we are now
 * also a JsonObjectEntity.
 * 
 * 
 * TODO/DEBATABLE: This should derive from BaseExtract<T> but it was too hard to see that connection evolving in time to
 * enforce it through java. TODO nothing should be making collections out of ResolvedExtract, check someday. TODO public
 * interface ResolvedExtract<T> extends JsonObjectEntity, BaseExtract<T> { I don't know the syntax to make compare
 * generic (if possible).
 * 
 * @author chunt
 * @version $Id$
 * @param <T>
 */
public interface ResolvedExtract<T> extends JsonObjectEntity, Comparable<T> {

    /**
     * TODO do what it takes to remove the SuppresWarnings
     * 
     * @return the {@link BaseExtract}
     */
    @SuppressWarnings("rawtypes")
    BaseExtract getBaseExtract();

    /**
     * @return the pre-resolved branch identifier, could be trunk as that is just a special name for a branch
     */
    String getBranch();

    /**
     * The effective revision is the normalized version of the extract allows better caching of extracts How it is
     * determined is none of our business at this level.
     * 
     * @return the effectiveRevision
     */
    String getEffectiveRevision();

    /**
     * @return the index used to manage collections later
     */
    int getIndex();

    /**
     * @return the name
     */
    String getName();

    /**
     * @return the pre-resolved revision identifier
     */
    String getRequestedRevision();

    /**
     * @return the resolvedUrl
     */
    String getResolvedUrl();

    /**
     * @return the type
     */
    String getType();

    /**
     * @return the uuid
     */
    String getUuid();

    /** {@inheritDoc} */
    @Override
    void writeSelf(JsonObjectOutputStream jsonOut) throws IOException;

}
