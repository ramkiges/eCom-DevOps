package com.wsgc.ecommerce.buildsystem;

/**
 * Signature of someone that can provide a build id some how.
 * 
 * @author chunt
 * @version $Id$
 */
public interface BuildIdProvider {
    // String TYPE = "cmx-build";
    /**
     * Returns the sacred build id to chronical this particular saga against entropy know as 'our build'
     * 
     * @return the build id
     */
    String getBuildId();
}
