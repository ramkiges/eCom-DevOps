package com.wsgc.ecommerce.buildsystem;

import java.io.File;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/**
 * Abstracts the idea of 'how you manage retrieving source files' away from other things.
 * 
 * @author chunt
 * @version $Id$
 * 
 */
public interface SourceRetrievalStrategy {

    // TODO class types and interfaces need to be set correctly. This one seems close
    /**
     * Returns the action abstraction object {@link SourceRetrievalAction} associated with a desired extract and the need to see it on a specific file
     * system sometime soon.
     * 
     * 
     * @see {@link SourceRetrievalAction}
     * 
     * @param resolvedExtract what you want to extract
     * @param targetDirectory where you want to extract
     * @return {@link SourceRetrievalAction} with a special skills you can use to do that
     * 
     */
    SourceRetrievalAction getSourceRetrievalAction(@SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract, File targetDirectory);

    /**
     * This needs to be public to let extract managers choose when to init its Sources. We now have tried all possible
     * sequences and that seems the cleanest so far. Creating a source is not a light weight operation, we must control
     * its occurrence.
     * 
     * @throws SourceException if things go wrong like losing your connection to source control
     */
    void init() throws SourceException;

    /**
     * Again with the setters, it seems unavoidable now. I want the profiler to be able change this on any
     * SourceRetrievalStrategy
     * 
     * -later... So by 'unavoidable' that is to say fix it anyway. Just clean up your concrete class use.
     * 
     * @param numSourceChannels number of sources to manage.
     */
    void setNumSourceChannels(int numSourceChannels);

    /**
     * @return the number of sources in use
     */
    int getNumSourceChannels();

    /**
     * @throws SourceException
     */

}