
package com.wsgc.ecommerce.buildsystem.test;


import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.wsgc.ecommerce.buildsystem.BuildPlan;
import com.wsgc.ecommerce.buildsystem.ResolvedExtract;
import com.wsgc.ecommerce.buildsystem.SvnConcreteExtractDefinition;
import com.wsgc.ecommerce.buildsystem.SvnExtractDefinition;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;

/**
 * @author chunt
 * @version $Id$
 */
/**
 * @author chunt
 * @version $Id$ 
 */
public class StandardBuildServiceTests {
    
    /**
     * 
     * From the file called DPContentBuild. Here we have the build type "prod" inside a module called "content" building 
     * something called 'static content'. The meanings of 'content' and 'prod' are now uncertain. 
     * 
    # #######################################################################
    # DO PRODUCTION (PROD) BUILD
    # #######################################################################
    if (defined($BUILDMAP{'prod'})) {
        processStaticContent($tmpdir, $siteid, $generation, $sitepfx, $buildid);
    }
     * 
     * 
     * 
     * 
     */
    private static final String PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME   = "prod_build_plan";
    private static final String PB_ALL_MESSAGES_BUILD_PLAN_NAME         = "all_messages_build_plan";
    private static final String PB_MISC_BUILD_PLAN_NAME                 = "misc_build_plan";
    
    
    // These values are keys to both the extract definition and concrete extract definition maps.
    private static final String EXTRACT_DEF_PB_STATIC_CONTENT       = "static_content";
    private static final String EXTRACT_DEF_PB_TEMPLATE             = "template";
    private static final String EXTRACT_DEF_PB_COMMON_MESSAGES      = "commonmessages";
    private static final String EXTRACT_DEF_PB_MESSAGES             = "messages";    
    private static final String EXTRACT_DEF_PB_MISC                 = "misc";
    //private static final String EXTRACT_WORKING_DIR                 =  "target/extractWorkingDir";
    
    
    //private StandardBuildService buildService;
    private Map<String, BuildPlan> buildPlans;
    
    
    /**
     * @throws Exception  
     */
    @Before
    public void setUp() throws Exception {
        buildPlans = null;
        //buildService = null;
        
        //buildService = new StandardBuildService();   
        setupBuildPlans();
        
        File testOutputDir = new File("./target/test-output");
        if (!testOutputDir.isDirectory()) {
            testOutputDir.mkdirs();
        }
    }

    /**
     * Initialize some test cases
     */
    private void setupBuildPlans() {
            
        //String id = "pbdp";
        //String label = "Pottery Barn stub project (DP)";
        buildPlans = new HashMap<String, BuildPlan>();
 
        // Extract Definitions.
        Map<String, SvnExtractDefinition> projectExtractDefinitions  = new HashMap<String, SvnExtractDefinition>();
 
        projectExtractDefinitions.put(EXTRACT_DEF_PB_STATIC_CONTENT, new SvnExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT, 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_TEMPLATE, new SvnExtractDefinition(EXTRACT_DEF_PB_TEMPLATE, 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_COMMON_MESSAGES, new SvnExtractDefinition(EXTRACT_DEF_PB_COMMON_MESSAGES,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_MESSAGES, new SvnExtractDefinition(EXTRACT_DEF_PB_MESSAGES,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_MISC, new SvnExtractDefinition(EXTRACT_DEF_PB_MISC,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        
        /** Build plans are named collections of extract definitions + run command list */
        
        // Set up build plans.
        Map<String, SvnExtractDefinition> prodPlanExtractMap = new HashMap<String, SvnExtractDefinition>();
        prodPlanExtractMap.put(EXTRACT_DEF_PB_STATIC_CONTENT, projectExtractDefinitions.get(EXTRACT_DEF_PB_STATIC_CONTENT));             
        prodPlanExtractMap.put(EXTRACT_DEF_PB_TEMPLATE, projectExtractDefinitions.get(EXTRACT_DEF_PB_TEMPLATE)); 
        String[] rundpftlbuildCommand = {"rundpftlbuild",
                "site=${siteId}",
                "gen=${generation}",
                "content=static_content",
                "templates=template",
        };

        String[] noPostBuildCommand = {""};


        buildPlans.put(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME, 
                new BuildPlan(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME, "Production content (FTL)", prodPlanExtractMap, 
                        Arrays.asList(rundpftlbuildCommand), 
                        Arrays.asList(noPostBuildCommand)));

        Map<String, SvnExtractDefinition> messagesPlanExtractMap = new HashMap<String, SvnExtractDefinition>();

        messagesPlanExtractMap.put(EXTRACT_DEF_PB_COMMON_MESSAGES, projectExtractDefinitions.get(EXTRACT_DEF_PB_COMMON_MESSAGES)); 
        messagesPlanExtractMap.put(EXTRACT_DEF_PB_MESSAGES, projectExtractDefinitions.get(EXTRACT_DEF_PB_MESSAGES)); 

        String[] rundpmessagebuildCommand = {"rundpmessagebuild",
                "site=${siteId}",
                "gen=${generation}",
                "common=commonmessages",
                "messages=messages",
        };

        buildPlans.put(PB_ALL_MESSAGES_BUILD_PLAN_NAME, 
                new BuildPlan(PB_ALL_MESSAGES_BUILD_PLAN_NAME, "Message catalog", messagesPlanExtractMap, 
                Arrays.asList(rundpmessagebuildCommand),
                Arrays.asList(noPostBuildCommand)));

        Map<String, SvnExtractDefinition> miscPlanExtractMap = new HashMap<String, SvnExtractDefinition>();
        miscPlanExtractMap.put(EXTRACT_DEF_PB_MISC, projectExtractDefinitions.get(EXTRACT_DEF_PB_MISC));

        String[] rundpmiscbuildCommand = {"rundpmiscbuild",
                "site=${siteId}",
                "gen=${generation}",
                "extract=misc",
        };

        buildPlans.put(PB_MISC_BUILD_PLAN_NAME, new BuildPlan(PB_MISC_BUILD_PLAN_NAME, "Miscellaneous (shiptypes, cardtypes, etc)", miscPlanExtractMap, 
                Arrays.asList(rundpmiscbuildCommand),
                Arrays.asList(noPostBuildCommand)));

    }

    /**
     * Exercise the {@link BuildRequest} space
     * @throws BuildServiceException if the test does anything unexpected
     */
    @SuppressWarnings("rawtypes")
    @Test
    public void testCreateBuildRequest() throws BuildServiceException {
        //String buildId = "BOGUS_BUILD_ID_" + thisTestName();
        BuildPlan buildPlan = buildPlans.get(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME); 
        
        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
        reificationData.put(EXTRACT_DEF_PB_STATIC_CONTENT, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT, "pb_primary", "154000", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
        
        //BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
        Map<String, ResolvedExtract> resolvedExtractMap = new HashMap<String, ResolvedExtract>(); 
        
//        for (ResolvedExtract resolvedExtract : buildRequest.getResolvedExtracts()) {
//            assertTrue("Test disabled.. Refactoring", false);
//            //resolvedExtractMap.put(resolvedExtract.getName(), resolvedExtract);
//        }
//                
        for (String extractKey : buildPlan.getExtractDefinitions().keySet()) {
            assertTrue("Missing resolved extract '" + extractKey + "'", resolvedExtractMap.containsKey(extractKey));
        }

        assertTrue("Expecting url:" + buildPlan.getExtractDefinition(EXTRACT_DEF_PB_TEMPLATE).getUrl()
                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getResolvedUrl(), 
                resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getResolvedUrl().equals(buildPlan.getExtractDefinition(EXTRACT_DEF_PB_TEMPLATE).getUrl()));
//        assertTrue("Expecting requestedRevision:" + ResolvedSvnExtract.SVN_HEAD_REVISION_TAG 
//                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getRequestedRevision(),
//                resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getRequestedRevision().equals(ResolvedSvnExtract.SVN_HEAD_REVISION_TAG));
        assertTrue("Expecting effectiveRevision:" + "154470"
                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getEffectiveRevision() , 
                resolvedExtractMap.get(EXTRACT_DEF_PB_TEMPLATE).getEffectiveRevision().equals("154470"));

        assertTrue("Expecting url:" + "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/pb_primary/static/"
                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getResolvedUrl(), 
                resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getResolvedUrl().equals(
                        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/pb_primary/static/"));
//        assertTrue("Expecting requestedRevision:" + reificationData.get(EXTRACT_DEF_PB_STATIC_CONTENT).getRevision()
//                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getRequestedRevision(),
//                resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getRequestedRevision()
//                .equals(reificationData.get(EXTRACT_DEF_PB_STATIC_CONTENT).getRevision()));
        assertTrue("Expecting effectiveRevision:" + "153933"
                + " found:" + resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getEffectiveRevision() , 
                resolvedExtractMap.get(EXTRACT_DEF_PB_STATIC_CONTENT).getEffectiveRevision().equals("153933"));
    }
    
//    @Test
//    public void testGetExtracts() throws BuildServiceException {
//            BuildPlan buildPlan = buildPlans.get(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME); 
//        
//        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_STATIC_CONTENT, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT, "pb_primary", "154000", 
//                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//
//        // clean out previous output if present
//        //for (String key : buildRequest.getResolvedExtracts().keySet()) {
//        for (ResolvedExtract resolvedExtract : buildRequest.getResolvedExtracts()) {
//            
////            String extractCacheLocation = StandardBuildService.YOUR_FAKE_TEMP_DIRECTORY 
////            + buildRequest.getResolvedExtract(key).getResolvedUrl().replace("https://repos.wsgc.com/svn/core", "CACHED_EXTRACTS") 
////            + buildRequest.getResolvedExtract(key).getEffectiveRevision();
//
//            String extractCacheLocation = StandardBuildService.YOUR_FAKE_TEMP_DIRECTORY 
//            + resolvedExtract.getResolvedUrl().replace("https://repos.wsgc.com/svn/core", "CACHED_EXTRACTS") 
//            + resolvedExtract.getEffectiveRevision();
//
//            String[] command = {"rm", "-rf", extractCacheLocation + "/" };   
//            ProcessUtil.waitForProcess(command);    
//        }
//
//        //buildService.scriptRunner.prepareExtracts(buildRequest);
//        
//        //TODO validate extract revision and location via svn info?
//        for (ResolvedExtract resolvedExtract : buildRequest.getResolvedExtracts()) {
//            String extractCacheLocation = StandardBuildService.YOUR_FAKE_TEMP_DIRECTORY 
//                + resolvedExtract.getResolvedUrl().replace("https://repos.wsgc.com/svn/core", "CACHED_EXTRACTS") 
//                + resolvedExtract.getEffectiveRevision();
//
//            assertTrue("Expecting directory '" + extractCacheLocation + "' but it doesn't seem to exist."
//                    , (new File(extractCacheLocation)).exists());   
//              
//        }
//        
//
//        assertTrue("Being refactored", false);
//        
//
//    }
    
//    @Test
//    public void testPBDPMessagesBuild() throws Exception {
//        
//
//        assertTrue("not fully implemented yet", false);
//        
//        BuildPlan buildPlan = buildPlans.get(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME); 
//        
//        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_STATIC_CONTENT, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT,"pb_primary", "154000", 
//                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//
//        assertTrue("not fully implemented yet", false);
//        
//        buildService.runBuild(buildPlan, reificationData);
//
//        
//    }
    
//    @Test
//    public void testResolvedExtractWriteJson() throws Exception {
//
//        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        Map<String, ConcreteExtractDefinition> reificationData =  new HashMap<String, ConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_MISC, new ConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "svn", "pb_primary", "154000", 
//        "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//
//        for (ResolvedExtract resolvedExtract : buildRequest.getResolvedExtracts()) {
//
//            File infoFile = new File("./target/test-output/" + resolvedExtract.getName() +   ".json");
//            infoFile.createNewFile();
//
//            OutputStream os = new FileOutputStream(infoFile);
//            JsonFactory jsonFactory = new JsonFactory();
//            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
//            jsonGen.useDefaultPrettyPrinter();
//            JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
//            jsonOut.writeStartObject();
//
//            //resolvedExtract.writeJson(jsonOut);
//            jsonOut.writeObjectField(resolvedExtract.getName(), resolvedExtract);
//
//            jsonOut.writeEndObject();
//            jsonOut.close();
//            os.close();
//        }
//    }
//    
//    @Test
//    public void testBuildRequestWriteJson() throws Exception {
//
//        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        Map<String, ConcreteExtractDefinition> reificationData =  new HashMap<String, ConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_MISC, new ConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "svn", "pb_primary", "154000", 
//        "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//        File infoFile = new File("./target/test-output/" + "buildRequest-test" +   ".json");
//        infoFile.delete();
//        infoFile.createNewFile();
//
//        OutputStream os = new FileOutputStream(infoFile);
//        JsonFactory jsonFactory = new JsonFactory();
//        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
//        jsonGen.useDefaultPrettyPrinter();
//        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
//       
//        jsonOut.writeStartObject();
//
//        //resolvedExtract.writeJson(jsonOut);
//        jsonOut.writeObjectField(buildRequest.getLabel(), buildRequest);
//
//        jsonOut.writeEndObject();
//        jsonOut.close();
//        os.close();
//
//    }    @Test
//    public void testProjectWriteJson() throws Exception {
//
//        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        Map<String, ConcreteExtractDefinition> reificationData =  new HashMap<String, ConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_MISC, new ConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "svn", "pb_primary", "154000", 
//        "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//        File infoFile = new File("./target/test-output/" + "buildRequest-test" +   ".json");
//        infoFile.delete();
//        infoFile.createNewFile();
//
//        OutputStream os = new FileOutputStream(infoFile);
//        JsonFactory jsonFactory = new JsonFactory();
//        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
//        jsonGen.useDefaultPrettyPrinter();
//        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
//       
//        jsonOut.writeStartObject();
//
//        //resolvedExtract.writeJson(jsonOut);
//        jsonOut.writeObjectField(buildRequest.getLabel(), buildRequest);
//
//        jsonOut.writeEndObject();
//        jsonOut.close();
//        os.close();
//
//    }
    
//    @Test
//    public void testBuildRunnerMiscBuild() throws BuildServiceException, ExtractException {
//        String buildId = "BOGUS_BUILD_ID_" + thisTestName();
//        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_MISC, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "pb_primary", "154000", 
//                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//        
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//        //ExtractManager extractManager = new ExtractManager();
//        
//        //File extractWorkingDir  =  new File(EXTRACT_WORKING_DIR + File.pathSeparator + "MiscExtracts");
//        //extractWorkingDir.exists()
//        
//        //extractManager.getExtracts(buildRequest.getResolvedExtracts());
//                
//        
//        //BuildRunner buildRunner = new BuildRunner(buildRequest, null);
//        //buildRunner.run();
//        
//        
//        assertTrue("not fully implemented yet", false);
//        
//    }
    
    /**
     * Dubious time save to create test directories.
     * @return the name of your method if called in exactly the right way.
     */
    static String thisTestName() {
        return Thread.currentThread().getStackTrace()[2].getMethodName();
    }    
}
