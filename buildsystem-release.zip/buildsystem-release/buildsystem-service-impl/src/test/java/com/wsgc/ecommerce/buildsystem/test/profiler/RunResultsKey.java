
package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * Not my favorite name but doesn't break my build or head.
 * 
 * //public class OverAllTestRunResults {
 * Remove the Prefix "OverAll" from the name of this class and enjoy a day of hunting down runtime
 * "AbstractMethodError"s. Any class named 'TestRunResults' is a test according to maven and this one will fail (because
 * its not a test), so will your build (due to test failures) then if jetty runs anyway... you get the picture. Eclipse
 * will be silently laughing at you the whole time because it doesn't see a compilation error...
 * 
 * @author chunt
 * @version $Id$
 */
public class RunResultsKey {

    private int id;
    private long start;
    private long end;
    private SDResults sdResults;
    private Map<String, SDResults> dataSDResults = new HashMap<String, SDResults>();

    /**
     * @param index give this result key an id
     */
    public RunResultsKey(int index) {
        setId(index);
    }

    /**
     * @return the end
     */
    public long getEnd() {
        return end;
    }

    /**
     * @return the start
     */
    public long getStart() {
        return start;
    }

    /**
     * @param end the end to set
     */
    public void setEnd(long end) {
        this.end = end;
    }

    /**
     * @param start the start to set
     */
    public void setStart(long start) {
        this.start = start;
    }

    /**
     * @param results setter for {@link SDResults}
     */
    public void setSDResults(SDResults results) {
        sdResults = results;
        
    }

    /**
     * @return the testResults
     */
    public SDResults getTestResults() {
        return sdResults;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Setter for both key and {@link SDResults}
     * @param key the key
     * @param newSdResults the {@link SDResults}
     */
    public void setDataSdResults(String key,
            SDResults newSdResults) {
        dataSDResults.put(key, newSdResults);
        
    }

    /**
     * @return the dataSDResults
     */
    public Map<String, SDResults> getDataSDResults() {
        return dataSDResults;
    }

    /**
     * @param key your key to the results
     * @return your {@link SDResults}
     */
    public SDResults get(String key) {
        return dataSDResults.get(key);
    }
    /**
     * @param dataSDResults the dataSDResults to set
     */
    public void setDataSDResults(Map<String, SDResults> dataSDResults) {
        this.dataSDResults = dataSDResults;
    }
    
}