/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * Abstract class holds current state in private not protected fields for two reasons:
 * 1) You have to pick either protected or private scope. Protected is easier but private is more um...'correct'.
 * 2) This leaves the subclasses to hold only the 'next' state in its fields...seems cleaner slightly.  
 * 
 * 
 * 
 * 
 * @author chunt
 * @version $Id$ 
 */
public abstract class ProfilerConfig {
    /**
     * Anything after this character in a profile script is a comment
     */
    public static final String COMMENT_MARKER = "#";  
    private String notes;
    private int sampleSize;
    private int concurrentBuildRequests;
    private int testRuns;
    private String testSetKey;
    
    /*
     * TODO I assume I just committed generic suicide, but lets just get it running before focusing on me.
     * I think we are headed for ProfilerConfig<T>  
     */
    private Map<String, Object> testCollection;

    /**
     * @param reportFile
     */
    public ProfilerConfig(/*File scriptFile, File reportFile*/) {
        testCollection = new HashMap<String, Object>();
    }


    /**
     * 
     * This object is probably a Map but lets not judge....
     * 
     * @param key the key to assign this test set to
     * @param newTestSet the test set value
     */
    void defineTestSet(String key, Object newTestSet) {
        testCollection.put(key, newTestSet);
    }
    
    /**
     * @return the concurrentBuildRequests
     */
    public int getConcurrentBuildRequests() {
        return concurrentBuildRequests;
    }

    /**
     * @return the current test set
     */
    Object getCurrentTestSet() {
        return testCollection.get(testSetKey);
    }

    /**
     * @return current test set key
     */
    String getCurrentTestSetIndex() {
        return testSetKey;
    }

    /**
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * @return the sampleSize
     */
    public int getSampleSize() {
        return sampleSize;
    }

    /**
     * @return number of test runs
     */
    int getTestRuns() {
        return testRuns;
    }

    /**
     * TODO Am I in need of the 'generic method' here?
     * 
     * @param key the key
     * @return the test set object associated with that key
     */
    Object getTestSet(String key) {
        return testCollection.get(key);
    }

    /**
     * @return total number of samples per test run
     */
    int getTotalSamplesPerRun() {
        return sampleSize;
    }

    /**
     * Implementation defined answer to 'are we done yet"?
     * @return <code>true</code> if there are more tests in the test script
     * @throws IOException because it just might
     */
    abstract boolean hasMoreTests() throws IOException;

    /**
     * Output a standard footer to show test results.
     * 
     * @return report string
     */
    String reportSettings() {
        StringBuilder sb = new StringBuilder();
        sb.append("Time:").append(new Date(System.currentTimeMillis())).append(" Test notes: ").append(notes).append("\n");
        sb.append("TEST CONDITIONS: Samples per run: ").append(getTotalSamplesPerRun());
        sb.append(" Concurrent Requests: ").append(getConcurrentBuildRequests());
        sb.append(" Test Runs: ").append(getTestRuns());
        sb.append(" Test data index: ").append(getCurrentTestSetIndex()).append("\n");
        return sb.toString();
    }

    /**
     * @param concurrentBuildRequests the concurrentBuildRequests to set
     */
    public void setConcurrentBuildRequests(int concurrentBuildRequests) {
        this.concurrentBuildRequests = concurrentBuildRequests;
    }

    /**
     * @param nextKey verifies next key is part of the test script and sets it as the current test key
     */
    void setCurrentTestSet(String nextKey) {
        if (!testCollection.containsKey(nextKey)) {
            throw new IllegalArgumentException("Test key requested is not part of the configured test cases. Key: '" 
                    + nextKey + "' (Is your profile script asking for a test case that the build profiler doesn't understand)?");
        }
        testSetKey = nextKey;
    }

    /**
     * A method to call that will trigger the progression to the next test state, whatever that means to a particular implementation. 
     * @return a {@link ProfilerConfig} derived object that has the next test params set
     */
    abstract ProfilerConfig setNextTestParams();
    /**
     * @return the report file where all results are written to
     */
    abstract File getReportFile();

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * @param reportFile the reportFile to set
     */
//    public void setReportFile(File reportFile) {
//        this.reportFile = reportFile;
//    }

    /**
     * @param sampleSize the sampleSize to set
     */
    public void setSampleSize(int sampleSize) {
        this.sampleSize = sampleSize;
    }

    /**
     * @param testRuns the testRuns to set
     */
    public void setTestRuns(int testRuns) {
        this.testRuns = testRuns;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ProfilerConfig [sampleSize=").append(sampleSize)
                .append(", concurrentBuildRequests=")
                .append(concurrentBuildRequests).append(", testRuns=")
                .append(testRuns).append(", testSetIndex=")
                .append(testSetKey).append("]");
        return builder.toString();
    }  

}
