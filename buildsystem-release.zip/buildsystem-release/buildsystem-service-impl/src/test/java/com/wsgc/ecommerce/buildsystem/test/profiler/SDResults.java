package com.wsgc.ecommerce.buildsystem.test.profiler;

/**
 * Bean to hold standard deviation results
 * 
 * @author chunt
 * @version $Id$
 */
public class SDResults {
    private final double mean;
    private final double standardDeviation;
    private final double largestDeviation;
    
    /**
     * Constructor
     * @param mean the mean
     * @param standardDeviation the standard deviation
     * @param largestDeviation the outlier
     */
    public SDResults(double mean, double standardDeviation, double largestDeviation) {
        this.mean = mean;
        this.standardDeviation = standardDeviation;
        this.largestDeviation = largestDeviation;
    }
    /**
     * @return the largestDeviation
     */
    public double getLargestDeviation() {
        return largestDeviation;
    }
    /**
     * @return the mean
     */
    public double getMean() {
        return mean;
    }
    /**
     * @return the standardDeviation
     */
    public double getStandardDeviation() {
        return standardDeviation;
    }


}
