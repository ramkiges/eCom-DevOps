package com.wsgc.ecommerce.buildsystem.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtract;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtractFactory;
import com.wsgc.ecommerce.buildsystem.SourceRetrievalDetails;
import com.wsgc.ecommerce.buildsystem.SvnExtractSource;
import com.wsgc.ecommerce.buildsystem.SvnPredictiveSourceRetrievalStrategy;
import com.wsgc.ecommerce.buildsystem.SvnRunnableRetrievalAction;

/**
 * This file currently is just a convenient test bed to launch ad hoc experiments about retrieval strategies.
 * Unless it finds a better reason for living in our permanent collection, it should be deleted before it confuses 
 * some new guy.
 * 
 * 
 * @deprecated see above
 * @author chunt
 * @version $Id$ 
 */
@Deprecated
public class SvnSourceRetrievalStrategyTests {
    private final Logger logger = LoggerFactory.getLogger(getClass()); 

   // private static final String EXTRACT_DEF_PB_MISC = "misc";

    private static final boolean STATUS_GROOVEY = true;


    /**
     * Test method to investigate various initialization ideas during dev.
     * @throws Exception if clean directory fails
     */
    @Test
    public void testSvnSourceInit() throws Exception {

        //
        //        ResolvedSvnExtract extractRequest1 = ResolvedSvnExtractFactory.create(
        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
        //                "4d9f3204-700e-0410-9f00-95bf6548d55c",
        //                "153690", 
        //        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/");
        //        
        // Same branch different revision
        ResolvedSvnExtract source1InitialState = ResolvedSvnExtractFactory.init("misc",
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c",
                "156000", 
        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/",
        "trunk",
        "HEAD");

        File testDir =  new File("target/test-output/" + Thread.currentThread().getStackTrace()[1].getMethodName());
        cleanDirectory(testDir);
        File source1WorkingBase =  new File(testDir.getCanonicalPath() + "/source1WorkingBase");

        // we are just triggering the init, don't care about the returned object.
        @SuppressWarnings("unused")
        SvnExtractSource svnExtractSource1 = new SvnExtractSource(source1WorkingBase.getCanonicalPath(), source1InitialState/*, null*/);

        //        
        //        List<SvnExtractSource> sources = new ArrayList<SvnExtractSource>();
        //        sources.add(svnExtractSource1);
        //
        //        File targetDir = new File("./target/test-output/" + Thread.currentThread().getStackTrace()[1].getMethodName() 
        //                +   "/extractsTargetDirectory/extractRequest1");
        //        targetDir.mkdirs();
        //
        //        SvnSourceRetrievalStrategy svnSourceRetrievalStrategy = new SvnSourceRetrievalStrategy(); 
        //
        //        SvnRetrievalAction svnSourceRetrievalAction 
        //            = svnSourceRetrievalStrategy.scheduleRetrieval(sources, extractRequest1, targetDir);
        //        
        //        /*
        //         * TODO making svnSourceRetrievalAction.getSourceRetrievalDetails() blocking means a different synch strategy.
        //         * Until and unless, external waits
        //         */
        //        while (svnSourceRetrievalAction.getFutureSourceRetrievalDetails() == null) {
        //            try {
        //                logger.debug("Waiting 500 ms for svnSourceRetrievalTask.isDone()");
        //                               Thread.sleep(500);
        //            }  catch (InterruptedException ie) {
        //                logger.debug("Wait for svnSourceRetrievalTask.isDone() was interrupted" + ie, ie);
        //                Thread.currentThread().interrupt();
        //            }   
        //
        //        }
        //
        //        Future<SourceRetrievalDetails> result = svnSourceRetrievalAction.getFutureSourceRetrievalDetails();
        //        
        //        SourceRetrievalDetails extpectedResults = new SourceRetrievalDetails("Groovy", targetDir.getCanonicalPath(), extractRequest1);
        //        
        //        SourceRetrievalDetails results = result.get();
        //         assertTrue("Expected:" + extpectedResults + " found:" + results, results.equals(extpectedResults));

    }

    /**
     * Helper method, probably  turned in to or should have turned in to {@link FileUtil#removeDirectory(File)}
     * @param dir the directory to clean
     * @throws Exception if file system denies that the files are gone afterward.
     */
    private void cleanDirectory(File dir) throws Exception {
        //logger.debug("Looking in directory " + dir);

        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                //logger.debug("Looking at file: " + file); 
                if  (file.isDirectory()) {
                    //logger.debug(file + " is a directory");
                    cleanDirectory(file);
                } else {
                    //logger.debug("Attempting to delete file: " + file);
                    if (!file.delete()) {
                        logger.warn("the Attempt to delete file: " + file + " reported failure.");
                    }
                    //logger.debug(file + " was deleted");
                }
            }
        }
        //logger.debug("Attempting to delete directory " + dir);

        if (dir.delete()) {
            //logger.debug(dir + " was deleted");
        } else {
            if (dir.exists()) {
                logger.warn("The attempt to delete directory: " + dir + " reported failure."); 
                throw new IOException("Unable to delete directory:" + dir);
            }
        }
    }

    /**
     * Test bed for predictive retrieval strategy.
     * 
     * @throws Exception if the expected results turn out to be not valid
     */
    @Test
    public void testSvnSourceRetrievalStrategy () throws Exception {

        //File testDir =  new File("./target/test-output/" + Thread.currentThread().getStackTrace()[1].getMethodName());
        File testDir =  new File("target/test-output/" + Thread.currentThread().getStackTrace()[1].getMethodName());
        cleanDirectory(testDir);

        ResolvedSvnExtract extractRequest1 = ResolvedSvnExtractFactory.init("misc",
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c",
                "165211", 
        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/",
        "trunk",
        "HEAD");

        //        // Same branch different revision
        //        ResolvedSvnExtract source1InitialState = ResolvedSvnExtractFactory.create(
        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
        //                "4d9f3204-700e-0410-9f00-95bf6548d55c",
        //                "153000", 
        //        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/");
        //
        //        // different branch same revision
        //        ResolvedSvnExtract source2InitialState = ResolvedSvnExtractFactory.create(
        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_secondary/", 
        //                "4d9f3204-700e-0410-9f00-95bf6548d55c",
        //                "153690", 
        //        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/");
        //
        //        //  Same branch same revision different UUID
        //        ResolvedSvnExtract source3InitialState = ResolvedSvnExtractFactory.create(
        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_secondary/", 
        //                "BAD-UU-ID",
        //                "153690", 
        //        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/");
        //
        //        // Perfect match with request1
        //        ResolvedSvnExtract source4InitialState = ResolvedSvnExtractFactory.create(
        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
        //                "4d9f3204-700e-0410-9f00-95bf6548d55c",
        //                "153690", 
        //        "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/");
        //
        //
        //        SvnExtractSource svnExtractSource1 = new SvnExtractSource("./target/test-output/" 
        //                + Thread.currentThread().getStackTrace()[1].getMethodName() 
        //                +   "/workingBase1", source1InitialState, null);
        //
        //        SvnExtractSource svnExtractSource2 = new SvnExtractSource("./target/test-output/" 
        //                + Thread.currentThread().getStackTrace()[1].getMethodName() 
        //                +   "/workingBase2", source2InitialState, null);
        //
        //        SvnExtractSource svnExtractSource3 = new SvnExtractSource("./target/test-output/" 
        //                + Thread.currentThread().getStackTrace()[1].getMethodName() 
        //                +   "/workingBase3", source3InitialState, null); 
        //
        //        SvnExtractSource svnExtractSource4 = new SvnExtractSource("./target/test-output/" 
        //                + Thread.currentThread().getStackTrace()[1].getMethodName() 
        //                +   "/workingBase4", source4InitialState, null); 
        //        

        SvnPredictiveSourceRetrievalStrategy svnSourceRetrievalStrategy = new SvnPredictiveSourceRetrievalStrategy(); 
        svnSourceRetrievalStrategy.setSourcePath(testDir.getAbsolutePath());
        //svnSourceRetrievalStrategy.setSourceChannels("4");
        svnSourceRetrievalStrategy.init();

        //        List<SvnExtractSource> sources = new ArrayList<SvnExtractSource>();
        //        sources.add(svnExtractSource1);
        //        sources.add(svnExtractSource2);
        //        sources.add(svnExtractSource3);
        //        sources.add(svnExtractSource4);


        File targetDir = new File(testDir.getAbsolutePath() +   "/extractsTargetDirectory/extractRequest1");
        targetDir.mkdirs();

        SvnRunnableRetrievalAction svnSourceRetrievalAction 
        = svnSourceRetrievalStrategy.getSourceRetrievalAction(extractRequest1, targetDir);

        /*
         * TODO making svnSourceRetrievalAction.getSourceRetrievalDetails() blocking means a different synch strategy.
         * Until and unless, external waits are the rule
         */
//        while (svnSourceRetrievalAction.getFutureSourceRetrievalDetails() == null) {
//            try {
//                logger.debug("Waiting 500 ms for svnSourceRetrievalTask.isDone()");
//                Thread.sleep(500);
//            }  catch (InterruptedException ie) {
//                logger.debug("Wait for svnSourceRetrievalTask.isDone() was interrupted" + ie, ie);
//                Thread.currentThread().interrupt();
//            }   
//
//        }
//
        svnSourceRetrievalAction.join();
//        Future<SourceRetrievalDetails> result = svnSourceRetrievalAction.getFutureSourceRetrievalDetails();

        SourceRetrievalDetails extpectedResults = new SourceRetrievalDetails(extractRequest1, targetDir);
        extpectedResults.setSuccessStatus(STATUS_GROOVEY);
//        SourceRetrievalDetails results = result.get();
        SourceRetrievalDetails results = svnSourceRetrievalAction.getSourceRetrievalDetails();
        assertTrue("Expected:" + extpectedResults + " found:" + results, results.equals(extpectedResults));

    }



}
