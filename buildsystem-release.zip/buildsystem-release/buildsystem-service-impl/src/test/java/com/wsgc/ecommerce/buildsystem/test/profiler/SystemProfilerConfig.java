package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * 
 * For use with {@link BuildSystemProfiler}.
 * 
 * @author chunt
 * @version $Id$
 * 
 */
public class SystemProfilerConfig extends ProfilerConfig {
 
    private BufferedReader reader;
    private int nextSamples;
    private int nextConcurrentBuildRequests;
    private String nextTestSetIndex;
    private int nextTestRuns;
    private String nextNotes;
    
    private File reportFile;    
    private File scriptFile;
    
    //private String host;

    /**
     * 
     * The only constructor.
     * 
     * @param scriptFile the script with the profiler test commands.
     * @param reportFile the file to leave the results in
     * @throws Exception for unexpected errors
     */
    public SystemProfilerConfig(File scriptFile, File reportFile) throws Exception {
        this.reportFile = reportFile;
        this.scriptFile = scriptFile;
        reportFile.getParentFile().mkdirs();
        reader =  new BufferedReader(new FileReader(scriptFile));       
    }

//    public Set<String> getTestURLSet(int index) {
//        return testURLs[index];
//    }
//    /**
//     * @return the concurrentBuildRequests
//     */
//    public int getConcurrentBuildRequests() {
//        return concurrentBuildRequests;
//    }
//
//
//    public File getReportFile() {
//        return reportFile;
//    }
//    /**
//     * @return the testRuns
//     */
//    public int getTestRuns() {
//        return testRuns;
//    }
//    /**
//     * @return the totalBuildRequests
//     */
//    public int getTotalSamplesPerRun() {
//        return sampleSize;
//    }
//    /**
//     * @param i 
//     * @param buildRequest
//     */
//    @Override
//    public void defineTestSet(int i, Set<String> newTestSet){
//        testURLs[i] = newTestSet;
//    }

//    /**
//     * @param concurrentBuildRequests the concurrentBuildRequests to set
//     */
//    public void setConcurrentBuildRequests(int concurrentBuildRequests) {
//        this.concurrentBuildRequests = concurrentBuildRequests;
//    }
    /**
     * @param nSamples
     * @param nConcurrentBuildRequests
     * @param nSourceChannels
     * @param nTestRuns
     */
    //    public void setRunParams(int nSamples, int nConcurrentBuildRequests, int nExtracts,
    //            int nSourceChannels, int nTestRuns) {
    //        this.sampleSize = nSamples;
    //        this.concurrentBuildRequests = nConcurrentBuildRequests;
    //        this.testRuns = nTestRuns;        
    //    }
//    /**
//     * @param totalBuildRequests the totalBuildRequests to set
//     */
//    public void setSampleSize(int totalBuildRequests) {
//        this.sampleSize = totalBuildRequests;
//    }
//    /**
//     * @param testRuns the testRuns to set
//     */
//    public void setTestRuns(int testRuns) {
//        this.testRuns = testRuns;
//    }



    /**
     * @param testScript
     * @throws FileNotFoundException 
     */
//    public void openTestScript(File newTestScript) throws IOException {
//        testScript = newTestScript;
//        reader =  new BufferedReader(new FileReader(testScript));
//        host = reader.readLine().split("host=")[0];       
//    }

    /**
     * @return
     * @throws IOException 
     */
//    public boolean hasNextTest() throws IOException {
//        String lineIn = null;
//        boolean  hasNextTest = false; 
//
//        while ((lineIn = reader.readLine()) != null) {
//
//            if (lineIn.startsWith(COMMENT_MARKER) || lineIn.isEmpty()) {
//                continue;
//            }
//
//            String[] fields = lineIn.split(",");
//
//            if (fields.length != 6) {
//                throw new IOException("Parsing error reading profile script:" + testScript.getAbsolutePath()
//                        + " expecting 6 fields, found " + fields.length + " line '" + lineIn + "'");
//            }
//
//            nextSamples                    = Integer.parseInt(fields[0].trim());
//            nextConcurrentBuildRequests    = Integer.parseInt(fields[1].trim());
//            nextRequestType                = Integer.parseInt(fields[2].trim());
//            nextTestRuns                   = Integer.parseInt(fields[3].trim());
//            nextNotes                       = fields[4].trim();
//
//            
//            hasNextTest = true;
//
//        }
//
//        return hasNextTest;
//    }

    /**
     * @return
     */
//    public BuildSystemProfilerConfig useNextTest() {
//        sampleSize = nextSamples;
//        concurrentBuildRequests  =  nextConcurrentBuildRequests;
//        requestType = nextRequestType;
//        testRuns = nextTestRuns;
//        notes = nextNotes;
//        return this;
//    }

    /** {@inheritDoc} */
    @Override
    public boolean hasMoreTests() throws IOException {
        // boolean hasMoreTests = false;
         String lineIn = null;
         //String notes = null;

         while ((lineIn = reader.readLine()) != null) {

             if (lineIn.startsWith(COMMENT_MARKER) || lineIn.isEmpty()) {
                 continue;
             }

             String[] fields = lineIn.split(",");

             if (fields.length != 5) {
                 throw new IOException("Parsing error reading profiler test script:" + scriptFile.getAbsolutePath()
                         + " expecting 5 fields, found " + fields.length + " line '" + lineIn + "'");
             }

             // common
             nextSamples                    = Integer.parseInt(fields[0].trim());
             nextConcurrentBuildRequests    = Integer.parseInt(fields[1].trim());
             nextTestSetIndex               = fields[2].trim();
             nextTestRuns                   = Integer.parseInt(fields[3].trim());
             nextNotes                      = fields[4].trim();

             return true;

         }

         reader.close();
         return false;
     }
    /** {@inheritDoc} */
    @Override
    SystemProfilerConfig setNextTestParams() {
        setSampleSize(nextSamples);
        setConcurrentBuildRequests(nextConcurrentBuildRequests);
        setCurrentTestSet(nextTestSetIndex);
        setTestRuns(nextTestRuns);
        setNotes(nextNotes);
        return this;
    }

    /** {@inheritDoc} */
    @Override
    File getReportFile() {
        return reportFile;
    }

}
