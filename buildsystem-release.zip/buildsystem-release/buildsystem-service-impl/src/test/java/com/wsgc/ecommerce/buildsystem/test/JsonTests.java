
package com.wsgc.ecommerce.buildsystem.test;


import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParser;
import org.junit.Before;
import org.junit.Test;

import com.wsgc.ecommerce.buildsystem.BaseSvnExtract;
import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.BuildPlan;
import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.buildsystem.Project;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtract;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtractFactory;
import com.wsgc.ecommerce.buildsystem.StandardBuildService;
import com.wsgc.ecommerce.buildsystem.SvnConcreteExtractDefinition;
import com.wsgc.ecommerce.buildsystem.SvnExtractDefinition;
import com.wsgc.ecommerce.buildsystem.json.BaseSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildOrderDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildPlanDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildRequestDeserializer;
import com.wsgc.ecommerce.buildsystem.json.ProjectDeserializer;
import com.wsgc.ecommerce.buildsystem.json.ResolvedSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.json.SvnExtractDefinitionDeserializer;
import com.wsgc.ecommerce.utilities.json.DefaultJsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;
import com.wsgc.ecommerce.utilities.json.StandardJsonDeserializerConfig;
import com.wsgc.ecommerce.utilities.json.util.JsonJacksonUtilities;

/**
 * Tests the json serializers and deserializers for the JsonObjectEntity implementing children of the build system.
 * 
 * @author chunt
 * @version $Id$
 */
public class JsonTests {

    /**
     * 
     * From the file called DPContentBuild. Here we have the build type "prod" inside a module called "content" building 
     * something called 'static content'. The meanings of 'content' and 'prod' are now uncertain. 
     * 
    # #######################################################################
    # DO PRODUCTION (PROD) BUILD
    # #######################################################################
    if (defined($BUILDMAP{'prod'})) {
        processStaticContent($tmpdir, $siteid, $generation, $sitepfx, $buildid);
    }
     * 
     * 
     * 
     * 
     */
    private static final String PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME   = "prod_build_plan";
    private static final String PB_ALL_MESSAGES_BUILD_PLAN_NAME         = "all_messages_build_plan";
    private static final String PB_MISC_BUILD_PLAN_NAME                 = "misc_build_plan";


    // These values are keys to both the extract definition and concrete extract definition maps.
    private static final String EXTRACT_DEF_PB_STATIC_CONTENT       = "static_content";
    private static final String EXTRACT_DEF_PB_TEMPLATE             = "template";
    private static final String EXTRACT_DEF_PB_COMMON_MESSAGES      = "commonmessages";
    private static final String EXTRACT_DEF_PB_MESSAGES             = "messages";    
    private static final String EXTRACT_DEF_PB_MISC                 = "misc";
    //private static final String EXTRACT_WORKING_DIR                 =  "target/extractWorkingDir";


    private StandardBuildService buildService;
    private Map<String, BuildPlan> buildPlans;
    private Map<String, SvnExtractDefinition> projectExtractDefinitions; 

    /**
     * Stuff to to before every test
     */
    @Before
    public void setUp() /*throws Exception*/ {
        buildPlans = null;
        buildService = null;

        buildService = new StandardBuildService();   
        setupBuildPlans();

        File testOutputDir = new File("./target/test-output");
        if (!testOutputDir.isDirectory()) {
            testOutputDir.mkdirs();
        }
    }

    /**
     * Exercises the {@link ResolvedSvnExtract} json code. Tests the serialization/deserialization path, validates the
     * results are as expected.
     * 
     * @throws Exception
     *             if the test fails
     */
    @Test
    public void integrationTestResolvedSvnExtractJson() throws Exception {

        // Build a ResolvedSvnExtractDefinition
        SvnExtractDefinition svnExtractDefinition = 
                new SvnExtractDefinition(EXTRACT_DEF_PB_MISC,  "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/", 
                        "4d9f3204-700e-0410-9f00-95bf6548d55c");
        SvnConcreteExtractDefinition svnConcreteExtractDefinition = new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC,  "pb_primary", "154000", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c");

        ResolvedSvnExtract resolvedSvnExtract = ResolvedSvnExtractFactory.create(svnExtractDefinition, svnConcreteExtractDefinition);
        //ResolvedSvnExtract resolvedSvnExtract = new ResolvedSvnExtract(extractDefinition, null);

        // Write out json
        File jsonFile = new File("./target/test-output/" + Thread.currentThread().getStackTrace()[1].getMethodName() +   ".json");
        jsonFile.createNewFile();

        OutputStream os = new FileOutputStream(jsonFile);
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
        jsonGen.useDefaultPrettyPrinter();
        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);

        jsonOut.writeObject(resolvedSvnExtract);

        jsonOut.close();
        os.close();

        // Done writing. 

        // Try to read it back now.

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();

        // TODO looking for a better way to share TYPE. 
        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer()); 
        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);


        InputStream is = new FileInputStream(jsonFile);
        JsonParser parser = jsonFactory.createJsonParser(is);

        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        ResolvedSvnExtract extractJson = jsonIn.readObject(ResolvedSvnExtract.class);

        jsonIn.close();

        assertTrue("Deserialized resolvedSvnExtract does not match original. \n Original: " 
                + resolvedSvnExtract + "\nDeserialized object: " + extractJson, resolvedSvnExtract.equals(extractJson));
    }


    /**
     * Exercises the {@link BuildPlan} json code. Tests the serialization/deserialization path, validates the results
     * are as expected.
     * 
     * @throws Exception
     *             if the test fails
     */
    @Test
    public void integrationTestBuildPlanJson() throws Exception {
        BuildPlan buildPlanOut = buildPlans.get(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME);

        // Write out json
        File jsonFile = new File("./target/test-output/" + thisTestName() +   ".json");
        jsonFile.createNewFile();

        OutputStream os = new FileOutputStream(jsonFile);
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
        jsonGen.useDefaultPrettyPrinter();
        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);

        jsonOut.writeObject(buildPlanOut);

        jsonOut.close();
        os.close();

        // Done writing. 

        // Try to read it back now.
        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();

        dConfig.registerDeserializer(BuildPlan.ENTITY_TYPE_ID, new BuildPlanDeserializer()); 
        dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);


        InputStream is = new FileInputStream(jsonFile);
        JsonParser parser = jsonFactory.createJsonParser(is);

        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        BuildPlan buildPlanIn = jsonIn.readObject(BuildPlan.class);

        jsonIn.close();

        assertTrue("Deserialized object does not match original. Original: " 
                + buildPlanOut + "\n" + "Deserialized object: " + buildPlanIn, buildPlanIn.equals(buildPlanOut));

    }

    /**
     * Helper method to generate semi-understandable test file names.
     * @return a {@link String} based on the method call the this method.
     */
    static String thisTestName() {
        return Thread.currentThread().getStackTrace()[2].getMethodName();
    }
    
    /**
     * Exercises the {@link BuildRequest} json code. Tests the serialization/deserialization path, validates the results
     * are as expected.
     * 
     * @throws Exception
     *             if the test fails
     */
    @Test
    public void testBuildRequestJson() throws Exception {
        //String buildId = "BOGUS_BUILD_ID_" + thisTestName();
        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
        reificationData.put(EXTRACT_DEF_PB_MISC, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "pb_primary", "154000", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        BuildRequest buildRequestOut = buildService.generateBuildRequest(buildPlan, reificationData);
        File jsonFile = new File("./target/test-output/" + thisTestName() + ".json");

        jsonFile.delete();
        jsonFile.createNewFile();

        OutputStream os = new FileOutputStream(jsonFile);
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
        jsonGen.useDefaultPrettyPrinter();
        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);

        jsonOut.writeObject(buildRequestOut);

        jsonOut.close();
        os.close();


        // Try to read it back now.

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();
        dConfig.registerDeserializer(BuildRequest.ENTITY_TYPE_ID, new BuildRequestDeserializer()); 

        dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer()); 
        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer()); 
        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);


        InputStream is = new FileInputStream(jsonFile);
        JsonParser parser = jsonFactory.createJsonParser(is);

        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        BuildRequest buildRequestIn = jsonIn.readObject(BuildRequest.class);

        jsonIn.close();

        assertTrue("Deserialized object does not match original. Original: " 
                + buildRequestOut + "\n" + "Deserialized object: " + buildRequestIn, buildRequestIn.equals(buildRequestOut));

    }


//    @Test
//    @Deprecated
//    public void testBuildRequestMapJson() throws Exception {
//        String buildId = "BOGUS_BUILD_ID_" + thisTestName();
//
//        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
//        reificationData.put(EXTRACT_DEF_PB_MISC, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "pb_primary", "154000", 
//                "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//
//        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//        SortedMap<BuildPlan, BuildRequest> map = new TreeMap<BuildPlan, BuildRequest>();
//        map.put(buildPlan, buildRequest);
//
//        //TODO change name...no delete all together
//        BuildRequestMap buildRequestMapOut = new BuildRequestMap(map);
//
//        File jsonFile = new File("./target/test-output/" + thisTestName() + ".json");
//        jsonFile.delete();
//        jsonFile.createNewFile();
//
//        OutputStream os = new FileOutputStream(jsonFile);
//        JsonFactory jsonFactory = new JsonFactory();
//        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
//        jsonGen.useDefaultPrettyPrinter();
//        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
//
//        jsonOut.writeObject(buildRequestMapOut);
//
//        jsonOut.close();
//        os.close();
//
//
//        // Try to read it back now.
//
//        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();
//        dConfig.registerDeserializer(BuildRequestMap.ENTITY_TYPE_ID, new BuildRequestMapDeserializer());
//        dConfig.registerDeserializer(BuildPlan.ENTITY_TYPE_ID, new BuildPlanDeserializer()); 
//        dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer());         
//        dConfig.registerDeserializer(BuildRequest.ENTITY_TYPE_ID, new BuildRequestDeserializer());         
//        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer()); 
//        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer()); 
//
//        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);
//
//
//        InputStream is = new FileInputStream(jsonFile);
//        JsonParser parser = jsonFactory.createJsonParser(is);
//
//        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
//        BuildRequestMap buildRequestMapIn = jsonIn.readObject(BuildRequestMap.class);
//
//        jsonIn.close();
//
//        assertTrue("Deserialized object does not match original. Original: " 
//                + buildRequestMapOut + "\n" + "Deserialized object: " + buildRequestMapIn, buildRequestMapIn.equals(buildRequestMapOut));
//
//    }

    /**
     * Exercises the {@link BuildOrder} json code. Tests the serialization/deserialization path, validates the results
     * are as expected.
     * 
     * @throws Exception
     *             if the test fails
     */
    @Test
    public void testBuildOrderJson() throws Exception {
        String buildId = "BOGUS_BUILD_ID_" + thisTestName();
        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
        reificationData.put(EXTRACT_DEF_PB_MISC, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "pb_primary", "154000", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        BuildOrder buildOrder = new BuildOrder(buildPlan.getId(), "UNIT TEST PROJECT");
        buildOrder.setBuildId(buildId);
        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
        buildOrder.addBuildRequest(buildRequest);
        buildOrder.lock();

        File jsonFile = new File("./target/test-output/" + thisTestName() + ".json");
        jsonFile.delete();
        jsonFile.createNewFile();

        OutputStream os = new FileOutputStream(jsonFile);
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
        jsonGen.useDefaultPrettyPrinter();
        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);

        jsonOut.writeObject(buildOrder);

        jsonOut.close();
        os.close();


        // Try to read it back now.

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();
        dConfig.registerDeserializer(BuildOrder.ENTITY_TYPE_ID, new BuildOrderDeserializer());
        dConfig.registerDeserializer(BuildRequest.ENTITY_TYPE_ID, new BuildRequestDeserializer());         
        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer()); 
        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);


        InputStream is = new FileInputStream(jsonFile);
        JsonParser parser = jsonFactory.createJsonParser(is);

        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        BuildOrder buildOrderIn = jsonIn.readObject(BuildOrder.class);

        jsonIn.close();

        assertTrue("Deserialized object does not match original. Original: " 
                + buildOrder + "\n" + "Deserialized object: " + buildOrderIn, buildOrderIn.equals(buildOrder));

    }

// Not used anymore.    
//    @Test
//    public void whatIsWrongWithTreeSets() throws Exception {
//        //        BuildPlan buildPlan =  buildPlans.get(PB_MISC_BUILD_PLAN_NAME);
//        //        Map<String, SvnConcreteExtractDefinition> reificationData =  new HashMap<String, SvnConcreteExtractDefinition>();          
//        //        reificationData.put(EXTRACT_DEF_PB_MISC, new SvnConcreteExtractDefinition(EXTRACT_DEF_PB_MISC, "pb_primary", "154000", 
//        //        "4d9f3204-700e-0410-9f00-95bf6548d55c"));
//
//        //        BuildRequest buildRequest = buildService.generateBuildRequest(buildPlan, reificationData);
//        //        
//        //        SortedMap<String, ResolvedExtract> sortedMap = buildRequest.getResolvedExtracts();        
//        //        SortedSet<SortedMap<String, ResolvedExtract>> treeSet1 = new TreeSet<SortedMap<String, ResolvedExtract>>();
//        //        SortedSet<SortedMap<String, ResolvedExtract>> treeSet2 = new TreeSet<SortedMap<String, ResolvedExtract>>();       
//        //        treeSet1.add(sortedMap);
//        //        treeSet2.add(sortedMap);
//        //        Does not work
//
//        //      SortedMap<String, BaseSvnExtract> sortedMap = new TreeMap<String, BaseSvnExtract>();        
//        //      sortedMap.put("key", new BaseSvnExtract("url"));
//        //      SortedSet<SortedMap<String, BaseSvnExtract>> treeSet1 = new TreeSet<SortedMap<String, BaseSvnExtract>>();
//        //      SortedSet<SortedMap<String, BaseSvnExtract>> treeSet2 = new TreeSet<SortedMap<String, BaseSvnExtract>>();       
//        //      treeSet1.add(sortedMap);
//        //      treeSet2.add(sortedMap);
//        //      //Does not work
//
//        //        SortedMap<String, String> sortedMap = new TreeMap<String, String>();        
//        //        sortedMap.put("key", "value");
//        //        
//        //        
//        //        SortedSet<SortedMap<String, String>> treeSet1 = new TreeSet<SortedMap<String, String>>();
//        //        SortedSet<SortedMap<String, String>> treeSet2 = new TreeSet<SortedMap<String, String>>();       
//        //treeSet1.add(sortedMap);
//        //treeSet2.add(sortedMap);
//
//        //SortedMap<String, String> sortedMap = new TreeMap<String, String>();  
//
//        List<ResolvedExtract> resolvedExtracts = new ArrayList<ResolvedExtract>();
//        List<String> buildCommand = new ArrayList<String>();
//        List<String> postBuildCommand = new ArrayList<String>();
//
//        BuildRequest buildRequest = new BuildRequest("id", "label", resolvedExtracts, buildCommand, postBuildCommand);
//        BuildRequest buildRequest2 = new BuildRequest("id2", "label2", resolvedExtracts, buildCommand, postBuildCommand);
//
//
//        SortedSet<BuildRequest> treeSet1 = new TreeSet<BuildRequest>();
//        SortedSet<BuildRequest> treeSet2 = new TreeSet<BuildRequest>();
//
//        treeSet1.add(buildRequest);
//        treeSet2.add(buildRequest);
//
//        treeSet1.add(buildRequest2);
//        treeSet2.add(buildRequest2);
//
//        boolean same = treeSet1.equals(treeSet2);
//
//        assertTrue (same);
//
//    }

    /**
     * Exercises the {@link Project} json code. Tests the serialization/deserialization path, validates the results
     * are as expected.
     * 
     * @throws Exception
     *             if the test fails
     */
    @Test
    public void integrationTestProjectJson() throws Exception {

        // TODO not sure of meanings of id, or label yet.
        Project projectOut = new Project("id", "pb label"/*, projectExtractDefinitions*/, buildPlans);


        File jsonFile = new File("./target/test-output/" + thisTestName() + ".json");
        jsonFile.delete();
        jsonFile.createNewFile();

        OutputStream os = new FileOutputStream(jsonFile);
        JsonFactory jsonFactory = new JsonFactory();
        JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
        jsonGen.useDefaultPrettyPrinter();
        JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);
        jsonOut.writeObject(projectOut);

        jsonOut.close();
        os.close();

        // Done writing. 

        // Try to read it back now.

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();

        dConfig.registerDeserializer(BuildPlan.ENTITY_TYPE_ID, new BuildPlanDeserializer()); 
        dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer()); 
        dConfig.registerDeserializer(Project.ENTITY_TYPE_ID, new ProjectDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);


        InputStream is = new FileInputStream(jsonFile);
        JsonParser parser = jsonFactory.createJsonParser(is);

        JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
        Project projectIn = jsonIn.readObject(Project.class);

        jsonIn.close();

        assertTrue("Deserialized Project does not match original. Original: " 
                + projectOut + "\n" + "Deserialized object: " + projectIn, projectIn.equals(projectOut));

    }



    /**
     * Sets up some commonly useful {@link BuildPlan}s
     */
    private void setupBuildPlans() {
        buildPlans = new HashMap<String, BuildPlan>();

        // Extract Definitions.
        projectExtractDefinitions  = new HashMap<String, SvnExtractDefinition>();

        projectExtractDefinitions.put(EXTRACT_DEF_PB_STATIC_CONTENT, new SvnExtractDefinition(EXTRACT_DEF_PB_STATIC_CONTENT,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_TEMPLATE, new SvnExtractDefinition(EXTRACT_DEF_PB_TEMPLATE,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_COMMON_MESSAGES, new SvnExtractDefinition(EXTRACT_DEF_PB_COMMON_MESSAGES,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_MESSAGES, new SvnExtractDefinition(EXTRACT_DEF_PB_MESSAGES, 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));

        projectExtractDefinitions.put(EXTRACT_DEF_PB_MISC, new SvnExtractDefinition(EXTRACT_DEF_PB_MISC,
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/", "4d9f3204-700e-0410-9f00-95bf6548d55c"));


        /** Build plans are named collections of extract definitions + run command list */

        // Set up build plans.
        Map<String, SvnExtractDefinition> prodPlanExtractMap = new HashMap<String, SvnExtractDefinition>();
        prodPlanExtractMap.put(EXTRACT_DEF_PB_STATIC_CONTENT, projectExtractDefinitions.get(EXTRACT_DEF_PB_STATIC_CONTENT));             
        prodPlanExtractMap.put(EXTRACT_DEF_PB_TEMPLATE, projectExtractDefinitions.get(EXTRACT_DEF_PB_TEMPLATE)); 
        String[] rundpftlbuildCommand = {"rundpftlbuild",
                "site=${siteId}",
                "gen=${generation}",
                "content=static_content",
                "templates=template",
        };
        
        String[] noPostBuildCommand = {""};

        
        buildPlans.put(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME, 
                new BuildPlan(PB_PRODUCTION_CONTENT_BUILD_PLAN_NAME, "Production content (FTL)", prodPlanExtractMap, 
                        Arrays.asList(rundpftlbuildCommand), 
                        Arrays.asList(noPostBuildCommand)));

        Map<String, SvnExtractDefinition> messagesPlanExtractMap = new HashMap<String, SvnExtractDefinition>();

        messagesPlanExtractMap.put(EXTRACT_DEF_PB_COMMON_MESSAGES, projectExtractDefinitions.get(EXTRACT_DEF_PB_COMMON_MESSAGES)); 
        messagesPlanExtractMap.put(EXTRACT_DEF_PB_MESSAGES, projectExtractDefinitions.get(EXTRACT_DEF_PB_MESSAGES)); 

        String[] rundpmessagebuildCommand = {"rundpmessagebuild",
                "site=${siteId}",
                "gen=${generation}",
                "common=commonmessages",
                "messages=messages",
        };

        buildPlans.put(PB_ALL_MESSAGES_BUILD_PLAN_NAME, 
                new BuildPlan(PB_ALL_MESSAGES_BUILD_PLAN_NAME, "Message catalog", messagesPlanExtractMap, 
                        Arrays.asList(rundpmessagebuildCommand), 
                        Arrays.asList(noPostBuildCommand)));

        Map<String, SvnExtractDefinition> miscPlanExtractMap = new HashMap<String, SvnExtractDefinition>();
        miscPlanExtractMap.put(EXTRACT_DEF_PB_MISC, projectExtractDefinitions.get(EXTRACT_DEF_PB_MISC));

        String[] rundpmiscbuildCommand = {"rundpmiscbuild",
                "site=${siteId}",
                "gen=${generation}",
                "extract=misc",
        };

        buildPlans.put(PB_MISC_BUILD_PLAN_NAME, new BuildPlan(PB_MISC_BUILD_PLAN_NAME, "Miscellaneous (shiptypes, cardtypes, etc)", miscPlanExtractMap, 
                Arrays.asList(rundpmiscbuildCommand), 
                Arrays.asList(noPostBuildCommand)));
    }


}
