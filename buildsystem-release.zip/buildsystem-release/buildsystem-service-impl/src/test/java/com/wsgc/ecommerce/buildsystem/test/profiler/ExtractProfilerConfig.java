package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.wsgc.ecommerce.buildsystem.SourceRetrievalStrategy;

/**
 * @deprecated shares the same obsolete fate as {@link ExtractManagerProfiler}
 * @author chunt
 * @version $Id$ 
 */
@Deprecated
public class ExtractProfilerConfig extends ProfilerConfig  {
    private int sourceChannels;
    private SourceRetrievalStrategy retrievalStrategy;
    private BufferedReader reader;
    private int nextSamples;
    private int nextConcurrentBuildRequests;
    private String nextTestSetIndex;
    private int nextTestRuns;
    private String nextNotes;
    private int nextSourceChannels;

    private File reportFile;    
    private File scriptFile;

    /**
     * Only constructor. 
     * 
     * @param scriptIn test script to read test configuration from
     * @param reportOut where to write out the results of the tests
     * @param retrievalStrategy a {@link SourceRetrievalStrategy} to test
     * @throws FileNotFoundException possible if we can't read the test script
     */
    public ExtractProfilerConfig(File scriptIn, File reportOut, SourceRetrievalStrategy retrievalStrategy) throws FileNotFoundException {
        this.scriptFile = scriptIn;
        this.reportFile = reportOut;
        this.retrievalStrategy = retrievalStrategy;

        //TODO change array to a collection or add a limit check.
        //buildRequestArray = new BuildRequest[10];
        reader =  new BufferedReader(new FileReader(scriptFile));
    }

    /**
     * @return the current {@link SourceRetrievalStrategy} in use
     */
    public SourceRetrievalStrategy getRetrievalStratagy() {
        return retrievalStrategy;
    }
    
    /**
     * @return the number of source channels
     */
    public int getSourceChannels() {
        return sourceChannels;
    }
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasMoreTests() throws IOException {
        String lineIn = null;
        while ((lineIn = reader.readLine()) != null) {

            if (lineIn.startsWith(COMMENT_MARKER) || lineIn.isEmpty()) {
                continue;
            }

            String[] fields = lineIn.split(",");

            if (fields.length != 6) {
                throw new IOException("Parsing error reading profiler test script:" + scriptFile.getAbsolutePath()
                        + " expecting 6 fields, found " + fields.length + " line '" + lineIn + "'");
            }

            // common
            nextSamples                    = Integer.parseInt(fields[0].trim());
            nextConcurrentBuildRequests    = Integer.parseInt(fields[1].trim());
            //nextTestSetIndex               = Integer.parseInt(fields[2].trim());
            nextTestSetIndex               = fields[2].trim();
            nextTestRuns                   = Integer.parseInt(fields[4].trim());
            nextNotes                      = fields[5].trim();

            // not common
            nextSourceChannels             = Integer.parseInt(fields[3].trim());

            //            hasMoreTests = true;
            //            break;
            return true;

        }

        return false;
    }

    @Override
    public String reportSettings() {
        StringBuilder sb = new StringBuilder(super.reportSettings());
        sb.append(" Source Channels: ").append(getSourceChannels()).append("\n");
        return sb.toString();
    }
    @Override
    public ExtractProfilerConfig setNextTestParams() {
        setSampleSize(nextSamples);
        setConcurrentBuildRequests(nextConcurrentBuildRequests);
        setCurrentTestSet(nextTestSetIndex);
        setTestRuns(nextTestRuns);
        setNotes(nextNotes);
        setSourceChannels(nextSourceChannels);
        return this;
    }

    /**
     * @param retrievalStrategy the retrievalStrategy to set
     */
    public void setRetrievalStrategy(SourceRetrievalStrategy retrievalStrategy) {
        this.retrievalStrategy = retrievalStrategy;
    }

    /**
     * @param nChannels number of source channels
     */
    public void setSourceChannels(int nChannels) {
        sourceChannels = nChannels;
    }

    /**
     * 
     * TODO: This is just wrong still. Decide which object holds the file and why and then we will know 
     * who should have the accessor method.
     * 
     * {@inheritDoc}
     */
    @Override
    File getReportFile() {
        return reportFile;
    }
}

