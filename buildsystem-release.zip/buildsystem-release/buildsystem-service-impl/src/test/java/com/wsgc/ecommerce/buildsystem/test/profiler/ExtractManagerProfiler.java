package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.buildsystem.ExtractManager;
import com.wsgc.ecommerce.buildsystem.ExtractTargetMapping;
import com.wsgc.ecommerce.buildsystem.ResolvedExtract;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtractFactory;
import com.wsgc.ecommerce.buildsystem.SourceRetrievalDetails;
import com.wsgc.ecommerce.buildsystem.SvnBlindRetrievalStrategy;
import com.wsgc.ecommerce.buildsystem.SvnExtractManager;
import com.wsgc.ecommerce.buildsystem.exception.ExtractException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;

/**
 * 
 * 
 * @deprecated Prototype of what was later used to create {@link BuildSystemProfiler} and this was honorably abandoned
 *             seconds later where it now rests before you.
 * @author chunt
 * @version $Id$
 */
@Deprecated
public final class ExtractManagerProfiler {
    
    /**
     * Private default ctor
     */
    private ExtractManagerProfiler() {
        throw new IllegalAccessError("Utility class not meant for instantiation.");
    }

    @SuppressWarnings("unused")
    private static final Logger LOGGER = LoggerFactory.getLogger(ExtractManagerProfiler.class);
    private int reallyBogusBuildID;
    private static Accumulator<List<SourceRetrievalDetails>> testAccumulator;
    private CompletionService<List<SourceRetrievalDetails>> buildRequestCompletionService;
    private ExecutorService executorService;

    private static final String TEST_WORKING_DIR = "." + File.separatorChar + "target" + File.separatorChar + "test-output"
            + File.separatorChar + ExtractManagerProfiler.class.getName();

    private static final String SOURCE_WORKING_DIR = TEST_WORKING_DIR + File.separatorChar + "sourceWorkDir";   
    private static final File REPORT_FILE = new File(TEST_WORKING_DIR, "report.txt");
    private static final File TEST_SCRIPT = new File("src/test/resources/extract_manager_profiler_script.csv");  


    /**
     * 
     * Helper method to generate a useful {@link BuildRequest}.
     * 
     * Two extracts .. Commonmessages, and messages, light weight.
     * "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk",
     * "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk",
     * 
     * 
     * @return {@link BuildRequest} for a mock Message catalog build
     */
    @SuppressWarnings("rawtypes")
    private static BuildRequest getMessageCatalogBuildRequest() {
        List<ResolvedExtract> messageCatalogRevolvedExtracts = new ArrayList<ResolvedExtract>();         
        // CommonMessage Extract
        messageCatalogRevolvedExtracts.add(ResolvedSvnExtractFactory.init("commonmessages", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "171360", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk",
                "trunk",
                "HEAD"));
        // Message extract
        messageCatalogRevolvedExtracts.add(ResolvedSvnExtractFactory.init("messages", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174113", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk",
                "trunk",
                "HEAD"));

        return new BuildRequest("all_messages_build_plan", "Message catalog",
                messageCatalogRevolvedExtracts, 
                Arrays.asList(new String[] {"rundpmessagebuild", "63", "211100301", "common=commonmessages", "messages=messages"}),
                Arrays.asList(new String[] {"not_used"}));

    }
    /**
     * One extract light weight. This misc build plan.
     * "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk"
     * 
     * @return {@link BuildRequest} mocking a pb misc build plan
     */
    private static BuildRequest getMiscBuildRequest() {
        @SuppressWarnings("rawtypes")
        List<ResolvedExtract> miscRevolvedExtracts = new ArrayList<ResolvedExtract>();

        miscRevolvedExtracts.add(ResolvedSvnExtractFactory.init("misc", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "166855", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk",
                "trunk",
                "HEAD"));

        return new BuildRequest("misc_build_plan", "Miscellaneous (shiptypes, cardtypes, etc)"
                , miscRevolvedExtracts, 
                Arrays.asList(new String[] {"rundpmiscbuild", "63", "211100301", "misc" }),
                Arrays.asList(new String[] {"not_used"}));

    }

    /**
     * More representative content build type, two large extracts.
     * "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static",
     * "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates",
     * 
     * Not currently used.
     * 
     * @return {@link BuildRequest} mocking a pb "content build".
     */
    @SuppressWarnings("unused")
    private static BuildRequest getProdContentBuildRequest() {

        @SuppressWarnings("rawtypes")
        List<ResolvedExtract> prodContentExtracts = new ArrayList<ResolvedExtract>();

        prodContentExtracts.add(ResolvedSvnExtractFactory.init("static_content", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174843", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static",
                "trunk",
                "HEAD")); 

        prodContentExtracts.add(ResolvedSvnExtractFactory.init("template", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174957", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates",
                "trunk",
                "HEAD")); 

        return new BuildRequest("prod_build_plan", "Production content (FTL)", 
                prodContentExtracts, 
                Arrays.asList(new String[] {"rundpftlbuild", "63", "211100301", "content=static_content", "templates=template"}),
                Arrays.asList(new String[] {"not_used"}));

    }


    /**
     * One extract 5Gb. "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static",
     * 
     * @return {@link BuildRequest} for the largest single extract 
     */
    private static BuildRequest getStaticContentBuildRequest() {

        @SuppressWarnings("rawtypes")
        List<ResolvedExtract> prodContentExtracts = new ArrayList<ResolvedExtract>();

        prodContentExtracts.add(ResolvedSvnExtractFactory.init("static_content", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174843", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static",
                "trunk",
                "HEAD")); 

        return new BuildRequest("prod_build_plan", "Production content (FTL)", 
                prodContentExtracts, 
                Arrays.asList(new String[] {"rundpftlbuild", "63", "211100301", "content=static_content", "templates=template"}),
                Arrays.asList(new String[] {"not_used"}));

    }



    /**
     * Unused
     * 
     * @param args xx
     * @throws Exception xx
     */
    public static void main(String [ ] args) throws Exception {
        ExtractManagerProfiler profiler = new ExtractManagerProfiler();

        SvnBlindRetrievalStrategy blindStrategy = new SvnBlindRetrievalStrategy();
        //TODO should be in config object if you are serious about the config object
        blindStrategy.setSourcePath(SOURCE_WORKING_DIR + File.separatorChar  + blindStrategy.getClass().getSimpleName());
     
        /*
         *  The question of if and how we want to switch between retrieval strategies is not settled.
         *  For now we set it at ctor-time
         */       
        ExtractProfilerConfig config = new ExtractProfilerConfig(TEST_SCRIPT, REPORT_FILE, blindStrategy);        
        testAccumulator = new Accumulator<List<SourceRetrievalDetails>>(config);

        // clean up previous results
        config.getReportFile().delete();
        config.defineTestSet("1", getSingleSmallBuildRequest());
        config.defineTestSet("2", getTwoSmallBuildRequests());
        // single _big_ extract
        config.defineTestSet("3", getStaticContentBuildRequest());
        // multiple extracts, with a big content extract mixed it..
        config.defineTestSet("4", getAllBuildRequest());
        
        while (config.hasMoreTests()) {
            profiler.profile(config.setNextTestParams());
        }

    }    


    /**
     * Mimics a full pb build.
     * 
     * @return {@link BuildRequest} for a full pottery barn build
     */
    @SuppressWarnings("rawtypes")
    private static BuildRequest getAllBuildRequest() {


        List<ResolvedExtract> allExtracts = new ArrayList<ResolvedExtract>();

        allExtracts.add(ResolvedSvnExtractFactory.init("static_content", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174843", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static",
                "trunk",
                "HEAD")); 

        allExtracts.add(ResolvedSvnExtractFactory.init("misc", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "166855", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk",
                "trunk",
                "HEAD"));

        allExtracts.add(ResolvedSvnExtractFactory.init("commonmessages", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c", "171360", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk",
                "trunk",
                "HEAD"));

        return new BuildRequest("profiler_all_build_plan", "Profiler specific project", 
                allExtracts, 
                Arrays.asList(new String[] {"rundpftlbuild", "63", "211100301", "content=static_content", "templates=template"}),
                Arrays.asList(new String[] {"not_used"}));

    }

    /**
     * Wrapper with a Human friendly name.
     * 
     * @return {@link ExtractManagerProfiler#getMessageCatalogBuildRequest()}
     */
    private static BuildRequest getTwoSmallBuildRequests() {
        return getMessageCatalogBuildRequest();
    }

    /**
     * Wrapper with a Human friendly name.
     * 
     * @return {@link ExtractManagerProfiler#getMiscBuildRequest()}
     */
    private static BuildRequest getSingleSmallBuildRequest() {
        return getMiscBuildRequest();
    }

    // Not used but damn useful
//    private String formatTime(long timeInMillis) {
//        return String.format("%d min, %d sec", 
//                TimeUnit.MILLISECONDS.toMinutes(timeInMillis),
//                TimeUnit.MILLISECONDS.toSeconds(timeInMillis) 
//                - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(timeInMillis)));
//
//    }


    /**
     * Helper method to generate a semi-logically named test directory.
     * @param base the root of your temp test directory
     * @return a unique path to test directory
     */
    private synchronized String getNextBuildDir(String base) {
        return base + File.separatorChar + "profiler_extract_working_dir_" + System.currentTimeMillis() + "_" + reallyBogusBuildID++;
    }

    /**
     * Run the profiling script.
     * 
     * @param config {@link ExtractProfilerConfig} with the test definition
     * @throws Exception for anything from {@link ExtractManager} failures in init, to failures to report the results. 
     */
    private void profile(final ExtractProfilerConfig config) throws Exception {
        final SvnExtractManager extractManager = new SvnExtractManager();
        config.getRetrievalStratagy().setNumSourceChannels(config.getSourceChannels());
        extractManager.setSourceRetrievalStrategy(config.getRetrievalStratagy());
        
        testAccumulator.setConfiguration(config);
        
        List<SourceRetrievalDetails> sourceRetrievalDetails = new ArrayList<SourceRetrievalDetails>();

        //TODO clean this up. why is this here still?
        final String extractWorkingBaseDir = TEST_WORKING_DIR + File.separatorChar + "extractWorkingDir";
        FileUtil.removeDirectory(new File(extractWorkingBaseDir));

        //Creates CompletionService
        extractManager.init();

        Set<Future<List<SourceRetrievalDetails>>> futures = new HashSet<Future<List<SourceRetrievalDetails>>>();

        testAccumulator.clearData();
        testAccumulator.setTestStart(System.currentTimeMillis());

        //for each test run
        for (int run = 0; run < config.getTestRuns(); run++) {

            if (executorService != null) {
                executorService.shutdown();
            }

            executorService = Executors.newFixedThreadPool(config.getConcurrentBuildRequests());
            buildRequestCompletionService = new ExecutorCompletionService<List<SourceRetrievalDetails>>(executorService);

            RunResultsKey testRunResults = new RunResultsKey(run + 1);
            testAccumulator.createNewProfilerRun(testRunResults);
            testRunResults.setStart(System.currentTimeMillis());

            // for all requests (aka samples) in this test run
            for (int requestsIndex = 0; requestsIndex < config.getTotalSamplesPerRun(); requestsIndex++) {
                // This would record the time it was submitted, not when processing starts
                //testAccumulator.logRequestStart(testRun, requestsIndex, System.currentTimeMillis());
                Future<List<SourceRetrievalDetails>> requestFuture = buildRequestCompletionService.submit(new Callable<List<SourceRetrievalDetails>>() {
                    @Override
                    public List<SourceRetrievalDetails> call() throws Exception {
                        //TODO We assume its possible to remove this unsafe cast after a bit of generic deep thought
                        return   runBuildRequestExtractProcess((BuildRequest) config.getCurrentTestSet(), extractWorkingBaseDir, extractManager);
                    }
                });
                
                //testAccumulator.createNewRecord(testRunResults, requestsIndex, requestFuture);
                Record<List<SourceRetrievalDetails>> record = new Record<List<SourceRetrievalDetails>>();
                record.setFuture(requestFuture); 
                testAccumulator.addNewRecord(testRunResults, requestsIndex, record);
                
                
                futures.add(requestFuture);
            } // for all concurrent requests in this batch.

            Future<List<SourceRetrievalDetails>> completedFuture;
            List<SourceRetrievalDetails> newSourceRetrievalDetailsList;

            try {

                while (futures.size() > 0) {
                    // block until any callable completes
                    completedFuture = buildRequestCompletionService.take();
                    futures.remove(completedFuture);
                    // this will succeed now or throw an exception (but it should not ever wait).
                    newSourceRetrievalDetailsList = completedFuture.get();

                    /*
                     *  Here we are NOT looking at System.currentTimeMillis() to determine request duration.
                     *  I don't see any guarantees that the first to finish was the first to be returned by compService.take().
                     *  But for end time we inspect the timestamp of the results, not the current time when we first saw them.
                     *  Since a BuildRequest is potentially made of multiple extracts we take the time of the last one to
                     *  finish as the time of the time the BuildRequest as a whole... 'finished'. If the extracts where multithreaded
                     *  then the sum of the durations of the extracts will have only a loose relationship with the duration of the
                     *  BuildRequest. I think "Less" is all we are sure about at that point.
                     *  
                     */
                    long firstExtractStartTime = findStartTimeOfFirstExtract(newSourceRetrievalDetailsList);
                    testAccumulator.findMatchingTestRecord(testRunResults, completedFuture).setStartTime(firstExtractStartTime);
                    
                    long lastExtractEndTime = findEndTimeOfLastExtract(newSourceRetrievalDetailsList);
                    testAccumulator.findMatchingTestRecord(testRunResults, completedFuture).setEndTime(lastExtractEndTime);
                    // not used for anything as yet, but keep them anyway.
                    sourceRetrievalDetails.addAll(newSourceRetrievalDetailsList);

                } // while more futures left

            } catch (Exception e) {

                //Shutdown anyone we can as a convenience 
                for (Future<List<SourceRetrievalDetails>> f : futures) {
                    f.cancel(true);
                }

                throw new ExtractException(e);
            } finally {
                executorService.shutdown();
            }

            testRunResults.setEnd(System.currentTimeMillis());
            //TODO validate extract beyond "it didn't throw an exception"
            //testAccumulator.addTestRun(testRun);

        } // For all runs in the test runs.

        testAccumulator.setTestEnd(System.currentTimeMillis());
        testAccumulator.processTestRuns();
        testAccumulator.report();

    }

    /**
     * Helper method to find the time of the first extract started in a {@link List} of {@link SourceRetrievalDetails}
     * @param detailsList list of {@link SourceRetrievalDetails} to look through
     * @return the ms time of the first element
     */
    private long findStartTimeOfFirstExtract(
            List<SourceRetrievalDetails> detailsList) {
        long timeOfLastExtract = -1;
        for (SourceRetrievalDetails details : detailsList) {
            if (details.getStartTime() > timeOfLastExtract) {
                timeOfLastExtract = details.getStartTime(); 
            }
        }

        return timeOfLastExtract;       
    }
    
    /**
     * Helper method to find the time of the last extract started in a {@link List} of {@link SourceRetrievalDetails}
     * @param detailsList list of {@link SourceRetrievalDetails} to look through
     * @return the ms time of the last element
     */
    private long findEndTimeOfLastExtract(
            List<SourceRetrievalDetails> detailsList) {
        long timeOfLastExtract = -1;
        for (SourceRetrievalDetails details : detailsList) {
            if (details.getStartTime() > timeOfLastExtract) {
                timeOfLastExtract = details.getStartTime(); 
            }
        }

        return timeOfLastExtract;       
    }
  
    /**
     * Exercise the {@link ExtractManager#performExtracts(List)} method.
     * 
     * @param buildRequest a {@link BuildRequest} used for the extract definition
     * @param extractWorkingBaseDir the root of where you want your extracts to start piling up
     * @param extractManager the {@link ExtractManager} to exercise
     * @return {@link List} of {@link SourceRetrievalDetails} from your efforts
     * @throws ExtractException for all errors
     */
    private List<SourceRetrievalDetails> runBuildRequestExtractProcess(
            final BuildRequest buildRequest,
            final String extractWorkingBaseDir,
            final ExtractManager extractManager) throws ExtractException {

        // List<SourceRetrievalDetails> results = new ArrayList<SourceRetrievalDetails>();

        String buildDir = getNextBuildDir(extractWorkingBaseDir); 

        List<ExtractTargetMapping> extractTargetMappings = extractManager.getExtractTargets(
                new File(buildDir, buildRequest.getId()), buildRequest);

        return extractManager.performExtracts(extractTargetMappings);

        //        Set<Future<List<SourceRetrievalDetails>>> futures = new HashSet<Future<List<SourceRetrievalDetails>>>();
        //        CompletionService<List<SourceRetrievalDetails>> compService = new ExecutorCompletionService<List<SourceRetrievalDetails>>(
        //                Executors.newFixedThreadPool(1));        

        //        futures.add(compService.submit(new Callable<List<SourceRetrievalDetails>>() {
        //            @Override
        //            public List<SourceRetrievalDetails> call() throws Exception {
        //                return   extractManager.performExtracts(extractTargetMappings);
        //            }
        //        }));
        //
        //        Future<List<SourceRetrievalDetails>> completedFuture;
        //        List<SourceRetrievalDetails> newSourceRetrievalDetailsList;
        //
        //        while (futures.size() > 0) {
        //            try {
        //                // block until a callable completes
        //                completedFuture = compService.take();
        //                futures.remove(completedFuture);
        //                newSourceRetrievalDetailsList = completedFuture.get();
        //            } catch (Exception e) {
        //
        //                //Shutdown anyone we can.
        //                for (Future<List<SourceRetrievalDetails>> f : futures) {
        //                    f.cancel(true);
        //                }
        //
        //                throw new ExtractException(e);
        //            }
        //
        //            results.addAll(newSourceRetrievalDetailsList);
        //        }
        //
        //        return results;
    }

    //
    // private List<SourceRetrievalDetails> runProfilierBuildRequest(String extractWorkingBaseDir, final ExtractManager
    // extractManager) throws ExtractException {
    //
    //        List<SourceRetrievalDetails> results = new ArrayList<SourceRetrievalDetails>();
    //
    //
    //        List<ResolvedExtract> miscRevolvedExtracts = new ArrayList<ResolvedExtract>();
    //
    //        miscRevolvedExtracts.add(ResolvedSvnExtractFactory.create("misc", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
    //                "4d9f3204-700e-0410-9f00-95bf6548d55c", "166855", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk"));
    //
    //        BuildRequest miscBuildRequest = new BuildRequest("misc_build_plan", "Miscellaneous (shiptypes, cardtypes, etc)"
    //                , miscRevolvedExtracts, 
    //                Arrays.asList(new String[] {"rundpmiscbuild", "63", "211100301", "misc" }));
    //
    //
    //        List<ResolvedExtract> messageCatalogRevolvedExtracts = new ArrayList<ResolvedExtract>();         
    //        // CommonMessage Extract
    //        messageCatalogRevolvedExtracts.add(ResolvedSvnExtractFactory.create("commonmessages", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk", 
    //                "4d9f3204-700e-0410-9f00-95bf6548d55c", "171360", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/common/messages/trunk"));
    //        // Message extract
    //        messageCatalogRevolvedExtracts.add(ResolvedSvnExtractFactory.create("messages", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk", 
    //                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174113", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/messages/trunk"));
    //
    //        BuildRequest messageCatalogBuildRequest = new BuildRequest("all_messages_build_plan", "Message catalog",
    //                messageCatalogRevolvedExtracts, 
    //                Arrays.asList(new String[] {"rundpmessagebuild", "63", "211100301", "common=commonmessages", "messages=messages"}));
    //
    //
    //
    //
    //
    //        List<ResolvedExtract> prodContentExtracts = new ArrayList<ResolvedExtract>();
    //
    //        prodContentExtracts.add(ResolvedSvnExtractFactory.create("static_content", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static", 
    //                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174843", 
    //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static")); 
    //
    //        //        prodContentExtracts.add(ResolvedSvnExtractFactory.create("template", 
    //        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates", 
    //        //                "4d9f3204-700e-0410-9f00-95bf6548d55c", "174957", 
    //        //                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/templates")); 
    //
    //        BuildRequest prodContentBuildRequest = new BuildRequest("prod_build_plan", "Production content (FTL)", 
    //                prodContentExtracts, 
    //                Arrays.asList(new String[] {"rundpftlbuild", "63", "211100301", "content=static_content", "templates=template"}));
    //
    //        //One Prod content builds worth of extracts.       
    //        // Do what buildManager would do at this point... fire off all at once with a completion service call. 
    //
    //        String buildDir = getNextBuildDir(extractWorkingBaseDir); 
    //
    //        final List<ExtractTargetMapping> messageCatalogBuildTypeTargetMappings = extractManager.getExtractTargets(
    //                new File(buildDir, messageCatalogBuildRequest.getId()), messageCatalogBuildRequest);
    //
    //        final List<ExtractTargetMapping> miscBuildTypeTargetMappings = extractManager.getExtractTargets(
    //                new File(buildDir, miscBuildRequest.getId()), miscBuildRequest);
    //
    //        final List<ExtractTargetMapping> prodContentBuildTypeTargetMappings = extractManager.getExtractTargets(
    //                new File(buildDir, prodContentBuildRequest.getId()), prodContentBuildRequest);
    //
    //
    //        Set<Future<List<SourceRetrievalDetails>>> futures = new HashSet<Future<List<SourceRetrievalDetails>>>();
    //        CompletionService<List<SourceRetrievalDetails>> compService = new ExecutorCompletionService<List<SourceRetrievalDetails>>(
    //                Executors.newFixedThreadPool(3));        
    //
    //
    //        /////////////////////////// MISC BUILD TYPE
    //        //        futures.add(compService.submit(new Callable<List<SourceRetrievalDetails>>() {
    //        //            @Override
    //        //            public List<SourceRetrievalDetails> call() throws Exception {
    //        //                return   extractManager.performExtracts(miscBuildTypeTargetMappings);
    //        //            }
    //        //        }));
    //
    //        /////////////////////////// MESSAGE CATALOG BUILD TYPE
    //        //        futures.add(compService.submit(new Callable<List<SourceRetrievalDetails>>() {
    //        //            @Override
    //        //            public List<SourceRetrievalDetails> call() throws Exception {
    //        //                return   extractManager.performExtracts(messageCatalogBuildTypeTargetMappings);
    //        //            }
    //        //        }));
    //
    //
    //        ////////////////// CONTENT BUILD BUILD TYPE
    //        futures.add(compService.submit(new Callable<List<SourceRetrievalDetails>>() {
    //            @Override
    //            public List<SourceRetrievalDetails> call() throws Exception {
    //                return   extractManager.performExtracts(prodContentBuildTypeTargetMappings);
    //            }
    //        }));
    //        Future<List<SourceRetrievalDetails>> completedFuture;
    //        List<SourceRetrievalDetails> newSourceRetrievalDetailsList;
    //
    //        while (futures.size() > 0) {
    //            try {
    //                // block until a callable completes
    //                completedFuture = compService.take();
    //                futures.remove(completedFuture);
    //                newSourceRetrievalDetailsList = completedFuture.get();
    //            } catch (Exception e) {
    //
    //                //Shutdown anyone we can.
    //                for (Future<List<SourceRetrievalDetails>> f : futures) {
    //                    f.cancel(true);
    //                }
    //
    //                throw new ExtractException(e);
    //            }
    //
    //            results.addAll(newSourceRetrievalDetailsList);
    //        }
    //
    //        return results;
    //    }
    //
    //


}
