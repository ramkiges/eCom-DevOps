package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Experimental container to gather test data from the {@link BuildSystemProfiler}.
 * 
 * @see BuildSystemProfiler
 * @see ProfilerConfig
 * @see BuildPerformance
 * 
 * @author chunt
 * @version $Id$
 * @param <T>
 *            Current types in use, ... are exactly one {@link BuildPerformance}
 */
public class Accumulator<T> {
    private static final String DEFAULT_RESULT_KEY = "Mean Duration";
    private final Logger logger = LoggerFactory.getLogger(getClass());   
    private ProfilerConfig testConfig;
    //private SDResults overAllTestResult;
    private SortedMap<String, SDResults> overAllTestResults = new TreeMap<String, SDResults>();
    private long testStart;
    private long testEnd;
    private PrintWriter writer;
    
    //TODO when did we stop using this and are we sure that was a good thing?
    //@SuppressWarnings("unused")
    //private String testNotes;  
    
    
    private Map<RunResultsKey, Map<Integer, Record<T>>> testData;
    //private Map<Long, Map<Integer, Record<T>>> testData;

    /**
     * The only constructor I know about.
     * @param config  {@link ProfilerConfig} to read test scripts and come up with individual test conditions as needed
     */
    public Accumulator(ProfilerConfig config) /*throws IOException*/ {
        testConfig = config;
        testData = new HashMap<RunResultsKey, Map<Integer, Record<T>>>();
        //testData = new HashMap<Long, Map<Integer, Record<T>>>();
    }

    /**
     * @throws IllegalAccessException 
     * 
     */
    @SuppressWarnings("unused")
    private Accumulator() throws IllegalAccessException {
        throw new IllegalAccessException("Utility class not meant for instantiation.");
    }

    /**
     * Clear data... delete your collection and start a new one.
     */
    public void clearData() {
        testData = new HashMap<RunResultsKey, Map<Integer, Record<T>>>();    
    }


    //    public long findEndTimeOfLastExtract(List<SourceRetrievalDetails> detailList) {
    //        long timeOfLastExtract = -1;
    //        for (SourceRetrievalDetails details : detailList) {
    //            if (details.getEndTime() > timeOfLastExtract) {
    //                timeOfLastExtract = details.getEndTime(); 
    //            }
    //        }
    //
    //        return timeOfLastExtract;       
    //    }

    //    /**
    //     * @param newSourceRetrievalDetailsList
    //     * @return
    //     */
    //    public long findStartTimeOfFirstExtract(
    //            List<SourceRetrievalDetails> detailsList) {
    //        long timeOfLastExtract = -1;
    //        for (SourceRetrievalDetails details : detailsList) {
    //            if (details.getStartTime() > timeOfLastExtract) {
    //                timeOfLastExtract = details.getStartTime(); 
    //            }
    //        }
    //
    //        return timeOfLastExtract;       
    //    }


    /**
     * Returns the low level record for a single test event of a test run. 
     * DEBATABLE The confusing thing is that {@link Record}s have {@link Future}s and that the {@link Future}s are used as ids.
     * 
     * @see Record
     * @see RunResultsKey
     * @param testRunKey the group of tests your asking about that includes your event
     * @param future the {@link Future} of the process that was use to create this {@link Record} in the first place
     * @return your {@link Record}
     */
    public Record<T> findMatchingTestRecord(RunResultsKey testRunKey, Future<T> future) {      
        for (Record<T> testRecord : testData.get(testRunKey).values()) {
            if (future.equals(testRecord.getFuture())) {
                return testRecord;
            }
        }
        throw new RuntimeException("Did not find test record with matching future object in test run. Run:" 
                + testRunKey + " future:" + future);
    }

    /**
     * A more orthodox way of retrieving a record perhaps, but actually unused.
     * 
     * @param testRunKey the {@link RunResultsKey}
     * @param requestIndex the index of the {@link Record} you want
     * @return your {@link Record}
     */
    public Record<T> getTestRecord(RunResultsKey testRunKey, int requestIndex) {      
    //public Record<T> getTestRecord(Long testRun, int requestIndex) {      
        // if we don't have an entry for this request in this test run, we have made a mistake
        if (!testData.get(testRunKey).containsKey(requestIndex)) {
            throw new RuntimeException("test record not found. ProfilerRun: " + testRunKey + " index:" + requestIndex);
        }
        return testData.get(testRunKey).get(requestIndex); 
    }

    /**
     * @param run
     * @param completedFuture
     */
//    public void logTestEventEnd(ResultsBean testRunKey,
//    //public void logTestEventEnd(Long testRun,
//            Future<T> completedFuture, long endTime) {
//        findMatchingTestRecord(testRunKey, completedFuture).setEndTime(endTime);
//
//    }

    /**
     * @param run
     * @param requestsIndex
     * @param currentTimeMillis
     */
//    public void logRequestStart(ProfilerRun testRun, int requestsIndex, long requestStartTimeMillis) {
//        getTestRecord(testRun, requestsIndex).setStart(requestStartTimeMillis);
//    }

    /**
     * @param testRun
     * @param completedFuture
     * @param firstExtractStartTime
     */
//    public void logTestEventStart(ResultsBean testRun,
//    //public void logTestEventStart(Long testRun,
//            Future<T> completedFuture,
//            long firstExtractStartTime) {
//        findMatchingTestRecord(testRun, completedFuture).setStart(firstExtractStartTime);
//    }

    /**
     * setter for test start.
     * @param startMs the test start time im ms
     */
    public void setTestStart(long startMs) {
        testStart = startMs;

    }

    /**
     * @return the testStart
     */
    public long getTestStart() {
        return testStart;
    }

    /**
     * Crunch the data for the whole test run
     */
    public void processTestRuns() {
        List<Long> allDurations = new ArrayList<Long>();
        Map<String, List<Long>> allData = new HashMap<String, List<Long>>();
        

        // for each testRun
        for (RunResultsKey testRun : testData.keySet()) {
        //for (Long testRun : testData.keySet()) {
            List<Long> testRunDurations = new ArrayList<Long>();
            Map<String, List<Long>> testRunDatas = new HashMap<String, List<Long>>();
            //for each request in a test run            
            for (Record<T> record : testData.get(testRun).values()) {
                
                //find the duration of each request                
                testRunDurations.add(record.getEndTime() - record.getStartTime()); 
                for (String key : record.getDataKeySet()) {
                    if (!testRunDatas.containsKey(key)) {
                        testRunDatas.put(key, new ArrayList<Long>());
                    }
                    // each key in testRunDatas points to a list of data elements 
                    testRunDatas.get(key).add(record.getData(key));
                }
                
            }

            // crunch the collection in to standard deviation and what not for each 'test run' in a 'test' (probably not really useful).
            testRun.setSDResults(processTestResults(testRunDurations));
            for (String testRunDataKey : testRunDatas.keySet()) {
                testRun.setDataSdResults(testRunDataKey, processTestResults(testRunDatas.get(testRunDataKey)));
            }            

            allDurations.addAll(testRunDurations);
            for (String testRunDataKey : testRunDatas.keySet()) {
                if (!allData.containsKey(testRunDataKey)) {
                    /*  Statistical correctness warning:
                     *  Here you run in to all sorts of potentially insignificant statistical artifacts
                     *  should you not have the same number of data points for all data types.. (and we are not 
                     *  checking).  
                     */
                    allData.put(testRunDataKey, testRunDatas.get(testRunDataKey));
                } else {
                    allData.get(testRunDataKey).addAll(testRunDatas.get(testRunDataKey));
                }
            }
        }

        /*  Statistical correctness warning:
         *  Here we are not averaging a group of tests but recombining
         *  them in to one test sample, not convinced that is exactly the same thing, 
         *  and willing to bet small valued objects it very much isn't. 
         */
        overAllTestResults.put(DEFAULT_RESULT_KEY, processTestResults(allDurations));
        for (String dataKey : allData.keySet()) {
            overAllTestResults.put(dataKey, processTestResults(allData.get(dataKey)));
        }
    }

    /**
     * Crunch the data for a single test run
     * 
     * @param performanceResults a {@link List} of values, you would like the standard deviation computed for.
     * @return {@link SDResults} based on the population of values provided
     */
    private SDResults processTestResults(List<Long> performanceResults) {
        double mean = 0;
        double squaredDeviationTotal = 0;
        double standardDeviation = 0;
        double largestDeviation = 0;

        if (performanceResults.size() <= 1) {
            logger.info("Need more than one sample to calculate Standard Deviation, returning empty test result.");
            return new SDResults(0, 0, 0); 
        }

        for (long duration : performanceResults) {
            mean += duration;
        }

        mean = mean / performanceResults.size();

        for (long duration : performanceResults) {
            double deviation = (mean - (double) duration);
            if (Math.abs(deviation) > largestDeviation) {
                largestDeviation = Math.abs(deviation); 
            }
            squaredDeviationTotal +=  (deviation * deviation);
        }       

        standardDeviation = Math.sqrt(squaredDeviationTotal / (performanceResults.size() - 1));

        return  new SDResults(mean, standardDeviation, largestDeviation);
    }


    /**
     * Adds test record to collection organized by index and key
     * 
     * TODO this really needs a better name.
     * 
     * @param testRun {@link RunResultsKey} associated with all tests in this 'run'
     * @param requestIndex the index of the event being recorded
     * @param record the {@link Record} of the event
     */
    public void addNewRecord(RunResultsKey testRun, int requestIndex, Record<T> record) {
        if (!testData.containsKey(testRun)) {
            throw new RuntimeException("Key not found in data collection. Key: " + testRun 
                    + " index:" + requestIndex);
        }
        if (testData.get(testRun).containsKey(requestIndex)) {
            throw new RuntimeException("Record already in test data collection. Key: " + testRun 
                    + " index:" + requestIndex);
        }

        testData.get(testRun).put(requestIndex, record);
    }

    /**
     * Write out the results.
     * @throws IOException for file errors.
     */
    public void report() throws IOException {

        if (!testConfig.getReportFile().exists()) {
            testConfig.getReportFile().createNewFile();
        }
        
        //Open report file in append mode.
        writer = new PrintWriter(new BufferedWriter(new FileWriter(testConfig.getReportFile(), true)));
        StringBuilder sb = new StringBuilder();

        sb.append(testConfig.reportSettings());


        for (String dataKey : overAllTestResults.keySet()) {
            if (overAllTestResults.get(dataKey) == null) {
                sb.append("Overall test results are null for data type:" + dataKey);
            } else {
                sb.append(padRight(dataKey , 40) + ": ").append(
                        padRight(timeUnitFormat(overAllTestResults.get(dataKey).getMean()), 30));
                sb.append(padRight("sd: " + timeUnitFormat(overAllTestResults.get(dataKey).getStandardDeviation()), 30));
                sb.append(padRight("Max Dev: " + timeUnitFormat(overAllTestResults.get(dataKey).getLargestDeviation()), 30));
                sb.append("\n");
            }           
        }
    
        sb.append("Duration of overall test with ").append(testData.size());
        if (testData.size() > 1) {
            sb.append(" runs: ");
        } else {
            sb.append(" run: ");
        }
        sb.append(timeUnitFormat(getTestEnd() - getTestStart()));

        long overallDuration =  (getTestEnd() - getTestStart());
        int overallSamples = testConfig.getTotalSamplesPerRun() * testConfig.getTestRuns(); 
        double throughput =  (double) (overallDuration/* * 1000*/) / (double) overallSamples;  
   
        //TODO now we have a dependency again.
        if (overAllTestResults.containsKey(BuildSystemProfiler.EXTRACT_CPU_TIME)) {
            double extractBuildCPURatio = overAllTestResults.get(BuildSystemProfiler.EXTRACT_CPU_TIME).getMean() 
                    / overAllTestResults.get(BuildSystemProfiler.BUILD_CPU_TIME).getMean();
            double extractBuildRealRatio = overAllTestResults.get(BuildSystemProfiler.EXTRACT_REAL_TIME).getMean() 
                    / overAllTestResults.get(BuildSystemProfiler.BUILD_REAL_TIME).getMean();
            sb.append(String.format(" extract/build CPU: %.0f" , extractBuildCPURatio * 100) + "% "
                    + String.format("extract/build real: %.0f", extractBuildRealRatio * 100) + "%");
        }
        
        sb.append("\n" + overallSamples + " samples processed in " + timeUnitFormat(overallDuration) 
                + " " + String.format("%.0f", throughput) + " ms per sample\n");

        if (testData.size() > 1) {
            /////////////////////////////// INDIVIDUAL OUTPUT ///////////////////////////////////
            sb.append("Individual Test Run Results:\n");
            for (RunResultsKey testRun : testData.keySet()) {
                SDResults results = testRun.getTestResults();
                if (results == null) {
                    sb.append(" has no test results.");
                } else {
                    sb.append(padRight("Test run: ", 20)).append(testRun.getId()).append("\n");
                    sb.append(padRight("Mean ", 20)).append(": " + padRight(timeUnitFormat(results.getMean()), 30));
                    sb.append(padRight("sd: " + timeUnitFormat(results.getStandardDeviation()), 30));
                    sb.append(padRight("Max Dev: " + timeUnitFormat(results.getLargestDeviation()), 30));
                    sb.append("\n");

                    for (String dataKey : testRun.getDataSDResults().keySet()) {
                        if (testRun.get(dataKey) == null) {
                            sb.append("Overall test results are null for data type:" + dataKey);
                        } else {
                            sb.append(padRight(dataKey, 20)  + ": ").append(
                                    padRight(timeUnitFormat(testRun.get(dataKey).getMean()), 30));
                            sb.append(padRight("sd: " + timeUnitFormat(testRun.get(dataKey).getStandardDeviation()), 30));
                            sb.append(padRight("Max Dev: " + timeUnitFormat(testRun.get(dataKey).getLargestDeviation()), 30));
                            sb.append("\n");
                        }           
                    }
                }
            }
            /////////////////////////////// INDIVIDUAL OUTPUT ///////////////////////////////////
        }

        sb.append("//////////////////////////////////////////////////////////////////////////////////////\n");
        sb.append("Request: ").append(timeUnitFormat(overAllTestResults.get(DEFAULT_RESULT_KEY).getMean()));
        sb.append(" ").append((long) overAllTestResults.get(DEFAULT_RESULT_KEY).getMean()).append(" ms").append("\n");
        sb.append("Test run: ").append(timeUnitFormat(overallDuration)).append(" ").append(overallDuration).append(" ms").append("\n");
        sb.append("Throughput: ").append(String.format("%.0f", throughput)).append(" ms per sample\n");
        sb.append("Free memory: ").append(Runtime.getRuntime().freeMemory()).append(" bytes\n");
        sb.append("//////////////////////////////////////////////////////////////////////////////////////\n\n");
        logger.info(sb.toString());
        writer.print(sb.toString());
        writer.flush();
        logger.info("Test results written to " + testConfig.getReportFile().getAbsolutePath());
    }

    /**
     * Formatting helper method. Adds spaces to right of text.
     * 
     * @param text the text to pad right 
     * @param pad the number of spaces to pad
     * @return the padded string
     */
    private String padRight(String text, int pad) {
        
       StringBuilder sb = new StringBuilder();
       sb.append(text);
       for (int i = text.length(); i < pad; i++) {
           sb.append(" ");
       }
        return sb.toString();
    }

    /**
     * Convenience method to send doubles to {@link Accumulator#timeUnitFormat(long)} which normally accepts only longs. 
     * @param d your time in ms
     * @return {@link Accumulator#timeUnitFormat(long)}
     */
    private String timeUnitFormat(double d) {
        return timeUnitFormat((long) d);
    }

    /**
     * Pretty formatter for time units.
     * @param l your time in ms
     * @return a {@link String} formatted with minutes, seconds and ms.
     */
    private String timeUnitFormat(long l) {

        long wholeMins      =  TimeUnit.MILLISECONDS.toMinutes(l);
        long wholeSecs      =  TimeUnit.MILLISECONDS.toSeconds(l - TimeUnit.MINUTES.toMillis(wholeMins));
        long remainingMs    = l - TimeUnit.MINUTES.toMillis(wholeMins) - TimeUnit.SECONDS.toMillis(wholeSecs);

        return String.format("%d min, %d sec, %d ms", wholeMins, wholeSecs, remainingMs);  
    }

    /**
     * @return the testEnd
     */
    public long getTestEnd() {
        return testEnd;
    }

    /**
     * @param testEnd the testEnd to set
     */
    public void setTestEnd(long testEnd) {
        this.testEnd = testEnd;
    }

    /**
     * @param newConfig the next {@link ProfilerConfig} to use
     */
    public void setConfiguration(ProfilerConfig newConfig) {
        this.testConfig = newConfig;
    }

    /**
     * @param string
     */
//    public void logMessage(String string) {
//        // TODO Auto-generated method stub
//
//    }

    /**
     * @param string
     */
//    public void setTestTitle(String string) {
//        testNotes = string;
//    }

    /**
     * Initialize a new test run collection.
     * @param testRun {@link RunResultsKey} to associate with this test run
     */
    public void createNewProfilerRun(RunResultsKey testRun) {
        if (testData.containsKey(testRun)) { 
            throw new RuntimeException("ProfilerRun already in test data collection.");
        }
        testData.put(testRun, new HashMap<Integer, Record<T>>());
    }

    /**
     * @param newSourceRetrievalDetailsList
     * @return
     */
//    public long findEndTimeOfLastExtract(List<SourceRetrievalDetails> detailList) {
//        long timeOfLastExtract = -1;
//        for (SourceRetrievalDetails details : detailList) {
//            if (details.getEndTime() > timeOfLastExtract) {
//                timeOfLastExtract = details.getEndTime(); 
//            }
//        }
//
//        return timeOfLastExtract;       
//    }

}
