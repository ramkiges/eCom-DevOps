/**
 * @author chunt
 * @version $Id$
 * 
 */
package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;

/**
 * 
 * Attempt and a generally useful generic test record
 * 
 * @author chunt
 * @version $Id$ 
 * @param <T>
 */
class Record<T> {
    
    private long startTime;        
    private long endTime;

    private Map<String, Long> data;      

    private Future<T> future;

    /**
     * @return the end
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * @return the future
     */
    public Future<T> getFuture() {
        return future;
    }

    /**
     * @return the start
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * @param timeMs the end time
     */
    public void setEndTime(long timeMs) {
        endTime = timeMs;
    }

    /**
     * Assumes the test record holds some process specific info, this is the handle to that process.
     * 
     * @param requestFuture the {@link Future} that this record is associated with
     */
    public void setFuture(Future<T> requestFuture) {
        future = requestFuture;
    }

    /**
     * @param timeMs the start time
     */
    public void setStartTime(long timeMs) {
        startTime = timeMs;
    }
    
    /**
     * 
     * @param key the key you want the value of
     * @return the value set previously
     */
    public long getData(String key) {
        return data.get(key);
    }

    /**
     *
     * @return  {@link Map#keySet()}
     */
    public Set<String> getDataKeySet() {
        return data.keySet();
    }

    /**
     * Setter for a string key and data value.
     * @param key the key
     * @param value the value
     */
    public void setData(String key, long value) {
        data.put(key, value);
    }

    /**
     * 
     */
    public Record() {
        data = new HashMap<String, Long>();
    }

}
