package com.wsgc.ecommerce.buildsystem.test.profiler;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.wsgc.ecommerce.buildsystem.BuildMonitor.JobStatus;
import com.wsgc.ecommerce.buildsystem.exception.ExtractException;
import com.wsgc.ecommerce.buildsystem.repository.BuildPerformance;

/**
 * Experimental unsupported tool to get a flying guess at the throughput. The term of art is probably
 * "integration test harness". Worked damn well too until we secured the URL's of the web app. This code will now NOT
 * work with out some refactoring along the lines releaser.jar got to overcome the same problem.
 * 
 * 
 * HACK, I changed the simple index to a human readable string, that introduced a dependency where the config script now
 * needs the strings used here. The next step of defining the testSets IN the config script has not yet be undertaken,
 * You are responsible for them matching.
 * 
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public final class BuildSystemProfiler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BuildSystemProfiler.class);
    private static final String TEST_WORKING_DIR = "." + File.separatorChar + "target" + File.separatorChar + "test-output"
            + File.separatorChar + BuildSystemProfiler.class.getName();
    
    private static final File REPORT_FILE = new File(TEST_WORKING_DIR, "report.txt");
    private static final File TEST_SCRIPT = new File("src/test/resources/build_system_profiler_script.csv");

    //private static final String BUILD_SERVICE_FRAG = "/build_project/";
    private static final String BUILD_SERVICE_FRAG = "/secure/build_project/";

    private static Accumulator<BuildPerformance> testAccumulator;

    private CompletionService<BuildPerformance> buildRequestCompletionService;
    private ExecutorService executorService;
    private static String buildSystemHost;
    
    /**
     * Each build type generates an number of extract requests.
     */
    // Lightweight multi extract request.
//    private static Set<String> PB_ALL_MESSAGES_BUILD = new HashSet<String>();
//    static {
//        PB_ALL_MESSAGES_BUILD.add("/buildsystem-2.0/build/project/pb_id/plan/all_messages_build_plan/"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }
    
//    private static Set<String> WS_ALL_MESSAGES_BUILD = new HashSet<String>();
//    static {
//        WS_ALL_MESSAGES_BUILD.add("/buildsystem-2.0/build/project/ws_id/plan/all_messages_build_plan/"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }
//    
//    private static Set<String> PT_ALL_MESSAGES_BUILD = new HashSet<String>();
//    static {
//        PT_ALL_MESSAGES_BUILD.add("/buildsystem-2.0/build/project/pt_id/plan/all_messages_build_plan/"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }
    
    /**
     * These urls trigger full builds at a time rather than specify each build type with a separate http request.
     */
//    private static Set<String> PB_FULL_BUILD = new HashSet<String>();
//    static {
//        PB_FULL_BUILD.add("/buildsystem-2.0/build/project/pb_id"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }
//    private static String WS_ALL_MESSAGES_BUILD = "/buildsystem-2.0/build/project/ws_id/plan/all_messages_build_plan/"
//            + "branch/trunk/revision/170000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c";
//    private static String PT_ALL_MESSAGES_BUILD = "/buildsystem-2.0/build/project/pt_id/plan/all_messages_build_plan/"
//            + "branch/trunk/revision/170000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c";
 
    /**
     *  This will result in an effective revision of:
     *  
     *  sites/common/messages/trunk         166053 
     *  sites/pb/messages/trunk             169940
     *  sites/pb/misc/trunk                 166855
     *  sites/pb/content/trunk/static       169939
     *  sites/pb/content/trunk/templates    169939
     */
    //static String PB_FULL_BUILD_REVISION = "154000"; // will crash as revision does not exist on for an extract in prod_build build plan
    //static String PB_FULL_BUILD_REVISION = "HEAD"; // this only LOOKS like a constant.
    
    // This one seems safe and stable
    // private static final String PB_FULL_BUILD_REVISION = "187535";
    // private static final String PB_FULL_BUILD_BRANCH = "trunk";
    
//    private static String PB_FULL_BUILD = "/buildsystem-2.0/build/project/pb_id/"
//            + "branch/trunk/revision/" + PB_FULL_BUILD_REVISION + "/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c";

    // Change in format underway here do to refactoring of RESTUI to post. This is now a string with params separated by space.
    private static String pbFullBuildTestParams = BUILD_SERVICE_FRAG + " pbdp "
            /*+ "branch/trunk/revision/"*/ + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String pkFullBuildTestParams = BUILD_SERVICE_FRAG + " pkdp "
            /*+ "branch/trunk/revision/"*/ + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String ptFullBuildTestParams = BUILD_SERVICE_FRAG + " ptdp "
            /*+ "branch/trunk/revision/"*/ + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String weFullBuildTestParams = BUILD_SERVICE_FRAG + " wedp "
            /*+ "branch/trunk/revision/"*/ + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String wsFullBuildTestParams = BUILD_SERVICE_FRAG + " wsdp "
            /*+ "branch/trunk/revision/"*/ + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String weAllMessagesTestParams = BUILD_SERVICE_FRAG + " wedp " + "all_messages_build_plan "
            + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";

    private static String wsAllMessagesTestParams = BUILD_SERVICE_FRAG + " wsdp " + "all_messages_build_plan "
            + "trunk " + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c";
  
    private static String pbAllMessagesTestParams = BUILD_SERVICE_FRAG + " pbdp " + "all_messages_build_plan "
            + "trunk "  + "head " + "4d9f3204-700e-0410-9f00-95bf6548d55c"; 
 
//    
//    
//    private static Set<String> PT_FULL_BUILD = new HashSet<String>();
//    static {
//        PT_FULL_BUILD.add("/buildsystem-2.0/build/project/pt_id"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }

//    private static Set<String> WS_FULL_BUILD = new HashSet<String>();
//    static {
//        WS_FULL_BUILD.add("/buildsystem-2.0/build/project/ws_id"
//                + "branch/trunk/revision/154000/uuid/4d9f3204-700e-0410-9f00-95bf6548d55c");
//    }

    
//    private static Set<String> All_FULL_BUILD = new HashSet<String>();
//    static {
//        All_FULL_BUILD.addAll(PB_FULL_BUILD);
//        All_FULL_BUILD.addAll(PT_FULL_BUILD);
//        All_FULL_BUILD.addAll(WS_FULL_BUILD);
//   }

    /**
     * AKA, the 'strike package'. Probably need two flavors, one the one should shred the cache. The other to simulate
     * real auto build use from the continuous build client.
     */
    //  private static Set<String> PB_FULL_WSPT_ALL_MESSAGE_BUILD = new HashSet<String>();
//    static {
//        PB_FULL_WSPT_ALL_MESSAGE_BUILD.addAll(PB_FULL_BUILD);
//        PB_FULL_WSPT_ALL_MESSAGE_BUILD.addAll(WS_ALL_MESSAGES_BUILD);
//        PB_FULL_WSPT_ALL_MESSAGE_BUILD.addAll(PT_ALL_MESSAGES_BUILD);
//    }
//  private static Map<String, String> PB_FULL_WSPT_ALL_MESSAGE_BUILD = new HashMap<String, String>();
//  static {
//      PB_FULL_WSPT_ALL_MESSAGE_BUILD.put("PB_FULL_BUILD", PB_FULL_BUILD);
//      PB_FULL_WSPT_ALL_MESSAGE_BUILD.put("WS_ALL_MESSAGES_BUILD", WS_ALL_MESSAGES_BUILD);
//      PB_FULL_WSPT_ALL_MESSAGE_BUILD.put("PT_ALL_MESSAGES_BUILD", PT_ALL_MESSAGES_BUILD);
//  }

    private static Map<String, String> resetTestSet = new HashMap<String, String>();
    static {
        resetTestSet.put("we_all_messages_test_params", weAllMessagesTestParams);
    }

    private static Map<String, String> pbwsAllMessagesTestSet = new HashMap<String, String>();
    static {
        pbwsAllMessagesTestSet.put("pb_all_messages_test_params", pbAllMessagesTestParams);
        pbwsAllMessagesTestSet.put("ws_all_messages_test_params", wsAllMessagesTestParams);
    }

    private static Map<String, String> pbAllMessagesTestSet = new HashMap<String, String>();
    static {
        pbAllMessagesTestSet.put("pb_all_messages_test_params", pbAllMessagesTestParams);
    }
    
  private static Map<String, String> pbFullBuildTestSet = new HashMap<String, String>();
  static {
      pbFullBuildTestSet.put("pb_full_build", pbFullBuildTestParams);
  }

  private static Map<String, String> allFullBuildTestSet = new HashMap<String, String>();
  static {
      allFullBuildTestSet.put("pb_full_build", pbFullBuildTestParams);
      allFullBuildTestSet.put("pt_full_build", ptFullBuildTestParams);
      allFullBuildTestSet.put("pk_full_build", pkFullBuildTestParams);
      allFullBuildTestSet.put("ws_full_build", wsFullBuildTestParams);
      allFullBuildTestSet.put("we_full_build", weFullBuildTestParams);

      //      strike_package_test_set.put("ws_all_messages_build_plan", ws_all_messages_test_params);
      //      strike_package_test_set.put("we_all_messages_build_plan", we_all_messages_test_params);
  }
  
  
    //private RestTemplate restTemplate;
    private static List<HttpMessageConverter<?>> messageConverters;
    static {
        messageConverters = new ArrayList<HttpMessageConverter<?>>();
        messageConverters.add(new FormHttpMessageConverter());
        messageConverters.add(new StringHttpMessageConverter());
    }    
    
    private static String buildStatusURL = "/build_status/build_id/";
    private static String buildPerformanceRequest = "/build_performance/build_id/";
    private static final long DELAY_BETWEEN_RUNS = TimeUnit.MILLISECONDS.convert(45L, TimeUnit.MINUTES);
    
    // meaning of various fields in performance data string.

    //private static final int BUILD_START_TIME_INDEX = 0;
    /**
     * ms used working on the extract problem
     */
    public static final String EXTRACT_CPU_TIME = "EXTRACT_CPU_TIME";
    /**
     * ms used waiting for the extract problem to resolve
     */
    public static final String EXTRACT_REAL_TIME = "EXTRACT_REAL_TIME";
    /**
     * ms used working on the build problem
     */
    public static final String BUILD_CPU_TIME = "BUILD_CPU_TIME";
    /**
     * ms used waiting for the build problem to resolve
     */
    public static final String BUILD_REAL_TIME = "BUILD_REAL_TIME";

    
    /**
     * Private utility constructor
     * @throws IllegalAccessException every time
     */
    private BuildSystemProfiler() throws IllegalAccessException {
        throw new IllegalAccessException("Utility class not meant for instantiation.");
    }

    /**
     * The Main method. The only parameter used is the host string so we can point the profiler at different systems. Initializes the 
     * {@link SystemProfilerConfig} object and starts executing its little ideas.
     * 
     * @param args xx
     * @throws Exception oh, don't get me started
     */
    public static void main(String [ ] args) throws Exception {

        buildSystemHost  = "http://" + args[0];

        BuildSystemProfiler profiler = new BuildSystemProfiler();
       
        SystemProfilerConfig config = new SystemProfilerConfig(TEST_SCRIPT, REPORT_FILE);
        testAccumulator = new Accumulator<BuildPerformance>(config);
        
        // clean up previous results
        config.getReportFile().delete();
        
        /**
         * umm... nevermind.
         */
        //config.defineTestSet("PB_FULL_WSPT_ALL_MESSAGE_BUILD", PB_FULL_WSPT_ALL_MESSAGE_BUILD);     
        //config.defineTestSet("PB_FULL_BUILD_ONLY", PB_FULL_BUILD_ONLY);     
        
        config.defineTestSet("reset_test_set", resetTestSet); 
        config.defineTestSet("pb_all_messages_test_set", pbAllMessagesTestSet);     
        config.defineTestSet("pbws_all_messages_test_set", pbwsAllMessagesTestSet);     
        config.defineTestSet("pb_full_build_test_set", pbFullBuildTestSet);     
        config.defineTestSet("strike_package_test_set", allFullBuildTestSet);     
        //config.defineTestSet("ALL_FULL_BUILD", All_FULL_BUILD);     

        while (config.hasMoreTests()) {
            profiler.profile(config.setNextTestParams());
        }

    }    


    /**
     * 
     * Reads the profiling script file (who's secret language is not described here, or anywhere yet as far as I know). Sets up and runs 
     * the tests in the script.
     * 
     * @param buildSystemProfilerConfig the {@link BuildSystemConfig} object that controls the tests.
     * @throws Exception because you didn't love it enough
     */
    @SuppressWarnings("unchecked")
    private void profile(final SystemProfilerConfig buildSystemProfilerConfig) throws Exception {

        Map<String, String> testURLs = (Map<String, String>) buildSystemProfilerConfig.getCurrentTestSet();
        
        Iterator<Entry<String, String>> testURLIterator = getRandomizedListIterator(testURLs);

        testAccumulator.setConfiguration(buildSystemProfilerConfig);

        //List<SourceRetrievalDetails> sourceRetrievalDetails = new ArrayList<SourceRetrievalDetails>();

        //TODO clean this up.
        //final String extractWorkingBaseDir = TEST_WORKING_DIR + File.separatorChar + "extractWorkingDir";
        //FileUtil.removeDirectory(new File(extractWorkingBaseDir));


        //        final SvnExtractManager extractManager = new SvnExtractManager();
        //extractManager.setSourceRetrievalStrategy(config.getRetrievalStratagy());

        //Creates CompletionService
        //extractManager.init();

        Set<Future<BuildPerformance>> futures = new HashSet<Future<BuildPerformance>>();

        testAccumulator.clearData();
        testAccumulator.setTestStart(System.currentTimeMillis());

        //for each test run
        for (int run = 0; run < buildSystemProfilerConfig.getTestRuns(); run++) {

            if (executorService != null) {
                executorService.shutdown();
            }

            executorService = Executors.newFixedThreadPool(buildSystemProfilerConfig.getConcurrentBuildRequests());

            buildRequestCompletionService = new ExecutorCompletionService<BuildPerformance>(executorService);

            RunResultsKey testRunResults = new RunResultsKey(run + 1);
            testAccumulator.createNewProfilerRun(testRunResults);
            testRunResults.setStart(System.currentTimeMillis());

            //int requestsIndex = 0;

            //while (requestsIndex < config.getTotalBuildRequests()) {

            // for all requests in this test run
            //            for (int requestsIndex = 0; requestsIndex < config.getConcurrentBuildRequests(); 
            //                    /*&& (requestsIndex < config.getTotalBuildRequests()); i++,*/ requestsIndex++) {

            //TODO requestsIndex ~~> test-event
            for (int requestsIndex = 0; requestsIndex < buildSystemProfilerConfig.getTotalSamplesPerRun(); requestsIndex++) {
                
                //Rotate through the keyset, picking the next sample from the data set.
                if (!testURLIterator.hasNext()) {
                    testURLIterator =  getRandomizedListIterator(testURLs);
                }
                
                final String key = testURLIterator.next().getKey();
                
                //TODO need to change name now, they are not testUrls alone anymore.
                final String requestParamsString = testURLs.get(key); 
                final String[] requestParams = requestParamsString.split(" ");
                
                if ((requestParams.length < 5) ||  (requestParams.length > 6)) {
                    throw new Exception("Unable to parse test parameter string: '" 
                            + requestParamsString + "'");
                }
                
                int i = 0;
                final String url = requestParams[i++];
                final String project = requestParams[i++];
                final String buildPlan;
                final String branch;
                final String revision;
                final String uuid;
    
                //PlanId missing default to "all"
                if (requestParams.length == 5) {
                    //buildPlan = BUILD_PLAN_ALL;
                    buildPlan = "";
                    branch = requestParams[i++];
                    revision = requestParams[i++];
                    uuid = requestParams[i++];
                //buildPlanId present
                } else {
                    buildPlan = requestParams[i++];
                    branch = requestParams[i++];
                    revision = requestParams[i++];
                    uuid = requestParams[i++];                    
                }
                //        + " run " + (run + 1) + " of " + buildSystemProfilerConfig.getTestRuns()
                // This would record the time it was submitted, not when processing starts
                //testAccumulator.logRequestStart(testRun, requestsIndex, System.currentTimeMillis());
                //  Future<List<SourceRetrievalDetails>> requestFuture = buildRequestCompletionService.submit(new Callable<List<SourceRetrievalDetails>>() {
                final String sampleIdMessage = (requestsIndex + 1) + " of " + buildSystemProfilerConfig.getTotalSamplesPerRun() 
                        + " run " + (run + 1) + " of " + buildSystemProfilerConfig.getTestRuns();
                final String traceMessage = "Starting sample " + sampleIdMessage; 

                LOGGER.info("Submitting sample " + sampleIdMessage);
                Future<BuildPerformance> requestFuture = buildRequestCompletionService.submit(new Callable<BuildPerformance>() {
                    public BuildPerformance call() throws Exception {
                        return sendHTTPBuildRequest(key, url, project, buildPlan, branch, revision, uuid, traceMessage);
                    }
                });

                Record<BuildPerformance> record = new Record<BuildPerformance>();
                record.setFuture(requestFuture); 
                
                testAccumulator.addNewRecord(testRunResults, requestsIndex, record);

                futures.add(requestFuture);
            } // for all concurrent requests in this batch.

            Future<BuildPerformance> completedFuture;

            //TODO refactor name
            BuildPerformance buildPerformance;

            try {

                while (futures.size() > 0) {
                    // block until 'a' callable completes
                    completedFuture = buildRequestCompletionService.take();
                    futures.remove(completedFuture);
                    // this will succeed now or throw an exception (but it should not wait).
                    buildPerformance = completedFuture.get();
                    //String[] performanceData = buildReference.getPerformanceData().split(":");
                    
                    //TODO probably we now should move data into performance record? Ouch. Lets not... May have to 
                    testAccumulator.findMatchingTestRecord(
                            testRunResults, completedFuture).setData(
                                    EXTRACT_CPU_TIME + "_" + buildPerformance.getId(), buildPerformance.getTotalExtractCPUTime());
                    testAccumulator.findMatchingTestRecord(
                            testRunResults, completedFuture).setData(
                                    EXTRACT_REAL_TIME + "_" + buildPerformance.getId(), buildPerformance.getTotalExtractRealTime());
                    testAccumulator.findMatchingTestRecord(
                            testRunResults, completedFuture).setData(
                                    BUILD_CPU_TIME + "_" + buildPerformance.getId(), buildPerformance.getTotalBuildProcessCPUTime());
                    testAccumulator.findMatchingTestRecord(
                            testRunResults, completedFuture).setData(
                                    BUILD_REAL_TIME + "_" + buildPerformance.getId(), buildPerformance.getTotalBuildProcessRealTime());

                } // while more futures left

            } catch (Exception e) {

                //Shutdown anyone we can as a convenience 
                for (Future<BuildPerformance> f : futures) {
                    f.cancel(true);
                }

                throw new ExtractException(e);
            } finally {
                executorService.shutdown();
            }

            testRunResults.setEnd(System.currentTimeMillis());
            //TODO validate extract beyond "it didn't throw an exception"
            //testAccumulator.addTestRun(testRun);
           
            testAccumulator.report();
           Thread.sleep(DELAY_BETWEEN_RUNS);

        } // For all runs in the test runs.

        testAccumulator.setTestEnd(System.currentTimeMillis());
        testAccumulator.processTestRuns();
        testAccumulator.report();

        //TODO should not be necessary
        //executorService.shutdown();

    }

    /**
     * Randomizes the order of the test data to prevent unintended good results due to accidental cache hits that repeat. 
     * 
     * @param testURLs a {@link Map} with test URL population
     * @return an iterator to a shuffled copy of the original map
     */
    private Iterator<Entry<String, String>> getRandomizedListIterator(
            Map<String, String> testURLs) {
        List<Entry<String, String>> entries = new ArrayList<Map.Entry<String, String>>(testURLs.entrySet());
        Collections.shuffle(entries);
        return entries.iterator();
    }

    /**
     * This previously happy and productive little method now doesn't work with the new secured urls. Work with Releaser.jar showed you are not
     * going to solve that problem by sticking to RestTemplate. The answer required preemptive authorization and that
     * required directly messing with apache commons HTTPClient. Should you be reading these comments with a mind to
     * resurrect {@link BuildSystemProfiler}, then
      <pre>
      &lt;groupId&gt;com.wsgc.ecommerce.tools&lt;/groupId&gt; 
      &lt;artifactId&gt;build-system-releaser&lt;/artifactId&gt;
      &lt;version&gt;3.0-SNAPSHOT&lt;/version&gt;
      &lt;name&gt;build-system-releaser&lt;/name&gt; 
      </pre>
     * is the next place you should look.
     * 
     * 
     * @param id {@link String} the caller uses to mark this {@link BuildPerformance#setId(String)} in some way important to the client
     * @param buildRequestURL the base build service URL to request a build through
     * @param projectId the project you are building
     * @param buildPlan the build plan id you are asking for
     * @param branch the branch for the whole build
     * @param revision the revision for the whole build
     * @param uuid not used, should be removed
     * @param traceMessage a note to yourself
     * @return {@link BuildPerformance} the results
     * @throws Exception for really bad results
     */
    private static BuildPerformance sendHTTPBuildRequest(String id, 
            String buildRequestURL, 
            String projectId, 
            String buildPlan, 
            String branch, 
            String revision, 
            String uuid,
            String traceMessage) throws Exception {
        
        LOGGER.debug(traceMessage);
        
        //TODO move this to class field if possible once you understand the thread safety
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setMessageConverters(messageConverters);
        
        String requestURL = buildSystemHost + buildRequestURL + projectId;
        
        //String buildId = restTemplate.getForObject(requestURL, String.class);
        
        MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
        
        map.add("buildPlan", buildPlan);
        map.add("branch", branch);
        map.add("revision", revision);
        map.add("uuid", uuid);
        map.add("force", "true");
        
        /* 
         * DEBATABLE do we need to set an error handler? No but releaser.jar needs a better one. Starting with
         * a specification as to what return codes to expect.
         */
        String buildId = restTemplate.postForObject(requestURL, map, String.class);

        if (buildId == null) {
            throw new Exception("HTTP build request returned null build id , URL:" + requestURL);
        }

        boolean done = false;

        String status = null;
        
        String requestStatusURL = buildSystemHost + buildStatusURL + buildId;
       
        while (!done) {
            status = restTemplate.getForObject(requestStatusURL, String.class);
            if (status.equals(JobStatus.FAILED.toString()) 
                    || status.equals(JobStatus.SUCCEEDED.toString())) {
                done = true;
            } else {
                Thread.sleep(TimeUnit.MILLISECONDS.convert(5L, TimeUnit.SECONDS));
            }
        }

        String buildPerformanceRequestURL = buildSystemHost + buildPerformanceRequest + buildId;
       
        String performanceString = restTemplate.getForObject(buildPerformanceRequestURL, String.class);
        BuildPerformance buildPerformance = new BuildPerformance(performanceString);
        buildPerformance.setId(id);
        
        return buildPerformance;
    }

    /**
     * @deprecated not used...still... anymore.
     * @param restTemplate xx
     * @param requestURL xx
     * @param clazz xx
     * @param failLimit xx
     * @param retryMs xx
     * @param <T> xx
     * @return xx
     */
    @SuppressWarnings("unused")
    @Deprecated
    private static <T> T attemptToGetForObject(RestTemplate restTemplate, String requestURL, Class<T> clazz, 
            int failLimit, int retryMs) {
        int statusFails = 0;
        boolean done = false;
        T status = null;
        
        while (!done) {
            
            try {
                status = restTemplate.getForObject(requestURL, clazz);
                done =  true;
            } catch (HttpServerErrorException hsee) {
                statusFails++;
                HttpStatus httpStatus = hsee.getStatusCode();
                
                //When running both server and test locally about 10% of build status checks fail once, none have failed twice yet.
                if ((httpStatus == HttpStatus.INTERNAL_SERVER_ERROR) && (statusFails > failLimit)) {
                    LOGGER.error("HTTP request FAILED " + statusFails + " times. URL: " 
                            + requestURL + " Reason: " + hsee, hsee);
                    throw hsee;
                }
                
                try {
                    Thread.sleep(retryMs);
                } catch (InterruptedException e) {
                   LOGGER.warn("Sleep between http get attempts interrupted", e);
                   Thread.currentThread().interrupt();
                   continue;
                }
            }

        }
        return status;
    }


}
