package com.wsgc.ecommerce.buildsystem;

import java.io.File;

/**
 * An immutable link between a collection of source files on disk, and the {@link ResolvedExtract} that 
 * required it.
 * 
 * TODO: The problem is with ResolvedExtract<T> here too.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class ExtractTargetMapping {

    private final File directory;
    private final ResolvedExtract<?> resolvedExtract;
    
    /**
     * Standard Constructor.
     * 
     * @param resolvedExtract the extract definition in the form of {@link ResolvedExtract}
     * 
     * @param directory the target location to deliver the extracts to
     */
    public ExtractTargetMapping(ResolvedExtract<?> resolvedExtract, File directory) {
        this.directory = directory;
        this.resolvedExtract = resolvedExtract;
    }
    
    /**
     * @return the directory
     */
    public File getDirectory() {
        return directory;
    }
    /**
     * @return the resolvedExtract
     */
    public ResolvedExtract<?> getResolvedExtract() {
        return resolvedExtract;
    }

}
