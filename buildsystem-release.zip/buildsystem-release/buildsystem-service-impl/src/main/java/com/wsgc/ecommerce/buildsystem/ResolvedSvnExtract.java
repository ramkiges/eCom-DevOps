package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;

import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;


/**
 * Svn source control system version of a resolved extract. Immutable.
 * 
 * @author chunt
 * @version $Id$
 */
public class ResolvedSvnExtract implements ResolvedExtract<ResolvedSvnExtract> {
    /**
     * for json the deserializer 
     */
    public static final String ENTITY_TYPE_ID = "extract/resolved/svn";
    private final BaseSvnExtract baseExtract;
    private final String effectiveRevision;
    private final String resolvedUrl;
    private final String branch;
    private final String requestedRevision;
    private final String uuid;
    private final String name;
    private final int index;

    /**
     * The only constructor.
     * 
     * It seems odd to need both resolved url and branch but different components need those pieces of information separately
     * and its a time saver to record them here as constants instead of build logic to created them when asked.
     * 
     * @param name the name 
     * @param baseExtract the base extract, the canonical truck representation of the source files to extract
     * @param effectiveRevision the effective revision as determined by somebody else
     * @param resolvedUrl the actual url to request of the source control system, might point to a branch 
     * @param uuid the UUID of the repo you think this source matches
     * @param branch the branch this resolved url belongs to.
     * @param requestedRevision the requested revision
     */
    public ResolvedSvnExtract(final String name, final BaseSvnExtract baseExtract, final String effectiveRevision,
            final String resolvedUrl, final String uuid, final String branch, final String requestedRevision) {
        this.name = name;
        this.baseExtract = baseExtract;
        this.effectiveRevision = effectiveRevision;
        this.resolvedUrl = trimLastUrlSeparator(resolvedUrl);
        this.uuid = uuid;
        this.branch = branch;
        //DEBATABLE you could at least compare that the effective revision is before the requested but why stop there if you start at all?
        this.requestedRevision = requestedRevision;
        index = generateIndex();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(ResolvedSvnExtract o) {

        if (equals(o)) { 
            return 0;
        }

        if (!name.equals(o.name)) {
            return name.compareTo(o.name);
        }

        if (!resolvedUrl.equals(o.resolvedUrl)) {
            return resolvedUrl.compareTo(o.resolvedUrl);
        }

        if (!effectiveRevision.equals(o.effectiveRevision)) {
            return effectiveRevision.compareTo(o.effectiveRevision);
        }

        if (!uuid.equals(o.uuid)) {
            return uuid.compareTo(o.uuid);
        }

        if (!baseExtract.equals(o.baseExtract)) {
            return baseExtract.compareTo(o.baseExtract);
        }        

        //How do we get here? Not all fields in equals accounted for in compare?
        //TODO do we need a Runtime version of BuildSystemException?
        throw new RuntimeException("Unexpected state: Comparator failed to determine order. this:" + toString() + "/nOther:" + o.toString());

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ResolvedSvnExtract)) {
            return false;
        }
        ResolvedSvnExtract other = (ResolvedSvnExtract) obj;
        if (baseExtract == null) {
            if (other.baseExtract != null) {
                return false;
            }
        } else if (!baseExtract.equals(other.baseExtract)) {
            return false;
        }
        if (effectiveRevision == null) {
            if (other.effectiveRevision != null) {
                return false;
            }
        } else if (!effectiveRevision.equals(other.effectiveRevision)) {
            return false;
        }
        if (resolvedUrl == null) {
            if (other.resolvedUrl != null) {
                return false;
            }
        } else if (!resolvedUrl.equals(other.resolvedUrl)) {
            return false;
        }
        if (ENTITY_TYPE_ID == null) {
            if (ResolvedSvnExtract.ENTITY_TYPE_ID != null) {
                return false;
            }
        } else if (!ENTITY_TYPE_ID.equals(ResolvedSvnExtract.ENTITY_TYPE_ID)) {
            return false;
        }
        if (uuid == null) {
            if (other.uuid != null) {
                return false;
            }
        } else if (!uuid.equals(other.uuid)) {
            return false;
        }
        
        if (index != (other.index)) {
            return false;
        }
        
        return true;
    }

    /**
     * Helper to calculate the index from only the parts that would effect the build artifacts.
     * @return the index
     */
    private int generateIndex() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((baseExtract == null) ? 0 : baseExtract.hashCode());
        result = prime * result + ((effectiveRevision == null) ? 0 : effectiveRevision.hashCode());
        result = prime * result + ((resolvedUrl == null) ? 0 : resolvedUrl.hashCode());
        result = prime * result + ((ENTITY_TYPE_ID == null) ? 0 : ENTITY_TYPE_ID.hashCode());
        result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BaseSvnExtract getBaseExtract() {
        return baseExtract;
    }

    /**
     * @return the pre-resolved branch identifier
     */
    public String getBranch() {
        return branch;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public String getEffectiveRevision() {
        return effectiveRevision;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Object getEntityInstanceId() { return null; }

    @Override
    public String getEntityTypeId() { return "extract/resolved/svn"; }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int getIndex() {
        return index;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return name;
    }
    

    /**
     * @return the pre-resolved revision identifier
     */
    public String getRequestedRevision() {
        return requestedRevision;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getResolvedUrl() {
        return resolvedUrl;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getType() {
        return ENTITY_TYPE_ID;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getUuid() {
        return uuid;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((baseExtract == null) ? 0 : baseExtract.hashCode());
        result = prime * result + ((effectiveRevision == null) ? 0 : effectiveRevision.hashCode());
        result = prime * result + ((resolvedUrl == null) ? 0 : resolvedUrl.hashCode());
        result = prime * result + ((ENTITY_TYPE_ID == null) ? 0 : ENTITY_TYPE_ID.hashCode());
        result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
        return result;
    }
   
    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ResolvedSvnExtract [baseUrl=").append(baseExtract).append(", effectiveRevision=")
                .append(effectiveRevision).append(", resolvedUrl=").append(resolvedUrl).append(", branch=")
                .append(branch).append(", requestedRevision=").append(requestedRevision).append(", uuid=").append(uuid)
                .append(", name=").append(name).append(", index=").append(index).append("]");
        return builder.toString();
    }
    
    /**
     * 
     * TODO should be in a abstract base for all Extract classes.
     * 
     * Trims last '/' if its present.
     * @param url url with a possible trailing slash
     * @return url with out a trailing slash
     */
    private String trimLastUrlSeparator(String url) {
        return (url.endsWith("/")) ? url.substring(0, url.length() - 1) : url; 
    }

    /**
     * {@inheritDoc}
     */
    @Override public void writeSelf(JsonObjectOutputStream jsonOut) throws IOException {
        jsonOut.writeStartObject();
        jsonOut.writeStringField("name", name);
        jsonOut.writeStringField("resolvedUrl", resolvedUrl);
        jsonOut.writeStringField("requestedRevision", requestedRevision);
        jsonOut.writeStringField("branch", branch);
        jsonOut.writeStringField("uuid", uuid);
        jsonOut.writeStringField("effectiveRevision", effectiveRevision);
        jsonOut.writeObjectField("baseUrl", baseExtract);
        jsonOut.writeEndObject();
    }

}
