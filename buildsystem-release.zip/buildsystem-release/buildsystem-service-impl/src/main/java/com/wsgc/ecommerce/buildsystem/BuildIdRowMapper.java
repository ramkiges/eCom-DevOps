/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author chunt
 * @version $Id$ 
 */
public class BuildIdRowMapper implements RowMapper<String> {

    private static final String IDENTIFIER_DATE = "IDENTIFIER_DATE";
    private static final String IDENTIFIER_SEQ = "IDENTIFIER_SEQ";
    private static final int SEQUENCE_LIMIT = 99;
    
    /** {@inheritDoc} */
    @Override
    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
        String dateCode  = String.valueOf(rs.getInt(IDENTIFIER_DATE));
        String sequence = String.valueOf(rs.getInt(IDENTIFIER_SEQ));
        if (Integer.parseInt(sequence) > SEQUENCE_LIMIT) {
            throw new SQLException("Build id sequence field out of range. Limit=" + SEQUENCE_LIMIT + " Current value=" + sequence);
        }
        String id =  "-" + dateCode + "-" + "000".substring(0, 3 - sequence.length()) + sequence;
        return id;
    }

}
