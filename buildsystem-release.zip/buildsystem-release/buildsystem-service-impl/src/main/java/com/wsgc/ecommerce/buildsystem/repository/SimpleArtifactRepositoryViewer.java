package com.wsgc.ecommerce.buildsystem.repository;

import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;

/**
 * 
 * Factory for {@link SimpleArtifactRepositoryView}s
 * 
 * @author chunt
 * 
 * @version $Id$
 *
 */
public class SimpleArtifactRepositoryViewer implements ArtifactRepositoryViewer {
    private final SimpleArtifactRepository repo;
    
    /**
     * Constructor that sets the internal reference to the {@link SimpleArtifactRepository} that 
     * backs these views.
     * 
     * @param simpleArtifactRepository for general errors accessing the repo.
     */
    public SimpleArtifactRepositoryViewer(
            SimpleArtifactRepository simpleArtifactRepository) {
        repo = simpleArtifactRepository;
    }

    /** {@inheritDoc}  */
    @Override
    public NavigableSet<ArtifactRepositoryView> getAllViews() throws ArtifiactRepostitoryException {
        Set<BuildReference> allBuildRefs = repo.getBuildReferenceSet();
        return getViews(allBuildRefs);
    }

    /** {@inheritDoc}  
     * @throws ArtifiactRepostitoryException */
    @Override
    public NavigableSet<ArtifactRepositoryView> getAllViews(String buildIdFilter, String projectFilter,
            String userFilter) throws ArtifiactRepostitoryException {
        Set<BuildReference> allBuildRefs = repo.getBuildReferenceSet();
        return getViews(allBuildRefs, buildIdFilter, projectFilter, userFilter);
    }

    /** {@inheritDoc}  */
    @Override
    public int getNumEntries() {
        return repo.numberOfBuilds();
    }

    /** {@inheritDoc}  */
    @Override
    public long getSizeBytes() {
        return repo.getSizeBytes();
    }

    // TOODO NOT USED as of 5/9/12 Look at interface again    
    //    private Set<ArtifactRepositoryView> getViewsFromRequests(Set<BuildOrder> buildOrders) throws ArtifiactRepostitoryException {
    //        Set<BuildReference> buildRefs = new HashSet<BuildReference>();
    //
    //        for (BuildOrder buildOrder : buildOrders) {
    //            buildRefs.addAll(repo.getBuildOrders(buildOrder));
    //        }
    //
    //        return getViewsFromReference(buildRefs);
    //    }

    /** {@inheritDoc}  
     * @throws ArtifiactRepostitoryException */
    @Override
    public ArtifactRepositoryView getView(BuildReference buildReference) throws ArtifiactRepostitoryException {
        return new SimpleArtifactRepositoryView(buildReference);
    }    

    /**
     * {@inheritDoc}
     * @throws ArtifiactRepostitoryException 
     */
    @Override
    public ArtifactRepositoryView getView(String buildId) throws ArtifiactRepostitoryException {
        BuildReference buildReference = repo.getBuildReference(buildId);
        return getView(buildReference);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NavigableSet<ArtifactRepositoryView> getViews(BuildOrder buildOrder) throws ArtifiactRepostitoryException {
        Set<BuildReference> buildReferences = repo.getBuildReferences(buildOrder);
        return getViews(buildReferences);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NavigableSet<ArtifactRepositoryView> getViews(Set<BuildReference> buildRefs) throws ArtifiactRepostitoryException {
        return getViews(buildRefs, null, null, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NavigableSet<ArtifactRepositoryView> getViews(Set<BuildReference> buildRefs, String buildIdFilter,
            String projectFilter, String userFilter) throws ArtifiactRepostitoryException {
        NavigableSet<ArtifactRepositoryView> views = new TreeSet<ArtifactRepositoryView>();
        for (BuildReference buildReference : buildRefs) {

            if ((buildIdFilter != null) || (projectFilter != null) || (userFilter != null)) {

                boolean filterByBuildId = (buildIdFilter != null)   && !buildIdFilter.isEmpty();
                boolean filterByProject = (projectFilter != null)   && !projectFilter.isEmpty();
                boolean filterByUser    = (userFilter != null)      && !userFilter.isEmpty(); 

                boolean keep = true;

                /* partial match ok here */
                if (keep && filterByBuildId) {
                    keep = buildReference.getBuildId().contains(buildIdFilter);
                }
                
                /* these filters now come from a populated list and we want exact matches */
                if (keep && filterByProject) {
                    //keep = buildReference.getBuildOrder().getProjectLabel().contains(projectFilter);  
                    keep = buildReference.getBuildOrder().getProjectLabel().equals(projectFilter);  
                }

                /* these filters now come from a populated list and we want exact matches */
                if (keep && filterByUser) {
                    //keep = buildReference.getUser().contains(userFilter);
                    keep = buildReference.getUser().equals(userFilter);
                }   

                if (keep) {
                    views.add(getView(buildReference));
                }

            } else {
                views.add(getView(buildReference));
            }
        }
  
        return views;
    }

    /**
    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getAllUsers() {
        return repo.getAllUsers();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getAllProjectLabels() {
        return repo.getAllProjectLabels();
    }

}


