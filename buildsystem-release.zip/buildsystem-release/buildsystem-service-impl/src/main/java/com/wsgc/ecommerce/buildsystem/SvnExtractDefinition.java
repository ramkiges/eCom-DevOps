package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;

import com.wsgc.ecommerce.utilities.json.JsonObjectEntity;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;


/**
 * 
 * This form of the extract definition does not have revision or branch, only a name, url and uuid of the svn system it
 * points to.
 * 
 * Carefully note that the URL form is the normalize TRUNK URL for this location and the resolving
 * process depends on that to work.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class SvnExtractDefinition implements ExtractDefinition, JsonObjectEntity {
    private final String url;
    private final String name;
    private final String uuid;
    /**
     * json deserialization
     */
    public static final String ENTITY_TYPE_ID = "extract/definition/svn";
    
    /**
     * Only constructor
     * 
     * @param name the name
     * @param url the url (uri?) of the source extract
     * @param uuid the svn serves uuid
     */
    public SvnExtractDefinition(String name, String url, String uuid) {
        this.name = name;
        this.url = url;
        this.uuid = uuid;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public String getUrl() {
        return url;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public String getName() {
        return name;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public String getExtractType() {
        return ENTITY_TYPE_ID;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public String getUuid() {
        return uuid;
    }
        
    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(getClass().getCanonicalName());
        builder.append("\n");
        builder.append("baseUrl:").append(url).append("\n");
        builder.append("type:").append(ENTITY_TYPE_ID).append("\n");
        builder.append("uuid:").append(uuid);
        return builder.toString();
    }
    
    /** {@inheritDoc} */ 
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public Object getEntityInstanceId() {
        // Not used
        return null;
    }
        
    /** {@inheritDoc} */ 
    @Override
    public void writeSelf(JsonObjectOutputStream jsonOut) throws IOException {
        jsonOut.writeStartObject();
        
        jsonOut.writeStringField("url", url);
        jsonOut.writeStringField("name", name);
        jsonOut.writeStringField("uuid", uuid);
        
        jsonOut.writeEndObject();
    }
    
    /** {@inheritDoc} */ 
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((url == null) ? 0 : url.hashCode());
        result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
        return result;
    }
    
    /** {@inheritDoc} */ 
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SvnExtractDefinition)) {
            return false;
        }
        SvnExtractDefinition other = (SvnExtractDefinition) obj;
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        if (url == null) {
            if (other.url != null) {
                return false;
            }
        } else if (!url.equals(other.url)) {
            return false;
        }
        if (uuid == null) {
            if (other.uuid != null) {
                return false;
            }
        } else if (!uuid.equals(other.uuid)) {
            return false;
        }
        return true;
    }
    
}
