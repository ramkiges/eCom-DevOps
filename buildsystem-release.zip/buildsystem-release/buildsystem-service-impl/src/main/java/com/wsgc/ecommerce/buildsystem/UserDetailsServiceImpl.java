package com.wsgc.ecommerce.buildsystem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * 
 * Original file was from 
 * /wsgc-promotions-admin-access-impl-1.0-SNAPSHOT
 * /src/main/java/com/wsgc/promotion/admin/access/impl/service/UserDetailsServiceImpl.java
 * 
 * This file updates that one to Spring 3.
 * 
 * gets the user roles for given username. This class is the userservice argument for the 
 * authoritiesPopulator in security-config.xml
 * 
 * @author RVijayan
 * @version $Id$
 *
 */
@SuppressWarnings("deprecation")
public class UserDetailsServiceImpl implements UserDetailsService {

    private Log log = LogFactory.getLog(this.getClass());
    private static final String USER_SQL = "SELECT AUTHORITY_NAME FROM SECURITY_USER_AUTHORITY WHERE USER_NAME=?";
    private static final String GROUP_SQL = "SELECT AUTHORITY_NAME FROM SECURITY_GROUP_AUTHORITY, SECURITY_USER_GROUP "
            + "WHERE SECURITY_GROUP_AUTHORITY.GROUP_NAME=SECURITY_USER_GROUP.GROUP_NAME AND SECURITY_USER_GROUP.USER_NAME=?";   
    private static final String DEFAULT_ROLE = "ROLE_USER";    
    private JdbcTemplate jdbcTemplate;


    /**
     * legacy file, not subject to my checkstyle
     * 
     * @param username the username
     * @throws UsernameNotFoundException ??
     * @throws DataAccessException ??
     * @return UserDetails
     */
    public UserDetails loadUserByUsername(final String username)
            throws UsernameNotFoundException, DataAccessException {

        UserDetails userDetails = null;

        try {
            List<String> userAuth = jdbcTemplate.queryForList(USER_SQL, new String[]{username}, String.class);
            List<String> groupAuth = jdbcTemplate.queryForList(GROUP_SQL, new String[]{username}, String.class);

            final ArrayList<GrantedAuthority> gas = new ArrayList<GrantedAuthority>();
            gas.add(new GrantedAuthorityImpl(DEFAULT_ROLE));

            // iterate through user authorities and add to array
            Iterator<String> i = userAuth.iterator();
            while (i.hasNext()) {
                GrantedAuthority ga = new GrantedAuthorityImpl(/*(String)*/ i.next());
                gas.add((GrantedAuthorityImpl) ga);
            }

            // iterate through group authorities and add to array
            Iterator<String> j = groupAuth.iterator();
            while (j.hasNext()) {
                GrantedAuthority ga = new GrantedAuthorityImpl(/*(String)*/ j.next());
                gas.add((GrantedAuthorityImpl) ga);
            }           

            return new UserDetails() {

                private static final long serialVersionUID = 1L;
                //Spring 3
                public Collection<GrantedAuthority> getAuthorities() {
                    return  gas;
                }

                public String getPassword() {
                    return null;
                }

                public String getUsername() {
                    return username;
                }

                public boolean isAccountNonExpired() {
                    return true;
                }

                public boolean isAccountNonLocked() {
                    return true;
                }

                public boolean isCredentialsNonExpired() {
                    return true;
                }

                public boolean isEnabled() {
                    return true;
                }
            };

        } catch (Exception e) {
            // DEBATABLE, wrap and rethrow but the inherited signature restricts what you throw and this error is going
            // to halt the game anyway
            log.error("Error getting authorities from DB. Reason:" + e, e);
        }
        return userDetails;
    }

    /**
     * sets jdbcTemplate property
     * @param jdbcTemplate spring jdbc template object
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

}
