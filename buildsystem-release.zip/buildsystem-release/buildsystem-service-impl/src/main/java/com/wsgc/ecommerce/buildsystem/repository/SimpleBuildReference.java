package com.wsgc.ecommerce.buildsystem.repository;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BaseSvnExtract;
import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtract;
import com.wsgc.ecommerce.buildsystem.StandardBuildManager;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.json.BaseSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildOrderDeserializer;
import com.wsgc.ecommerce.buildsystem.json.BuildRequestDeserializer;
import com.wsgc.ecommerce.buildsystem.json.ResolvedSvnExtractDeserializer;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;
import com.wsgc.ecommerce.utilities.json.DefaultJsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;
import com.wsgc.ecommerce.utilities.json.StandardJsonDeserializerConfig;
import com.wsgc.ecommerce.utilities.json.util.JsonJacksonUtilities;


/**
 * 
 * Because weed some way to refer to a collection of build artifacts known as a build.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class SimpleBuildReference implements BuildReference, Comparable<SimpleBuildReference> {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private final String buildId;
    private final File buildLocation;
    //private int index;
    private File manifest;    
    private File log;
    private File errorLog;
    private BuildOrder buildOrder;
    private String status;

    private String user;
    private BuildPerformance buildPerformance;

    /*
     *  lazy init. At one time the repository was not likely to trigger this so
     *  the repo map size will benefit in the normal case but since this
     *  reference could refer to a build no longer loaded in the repo
     *  access needs a null guard.
     */
    private String buildOrderJson;
    private String logicalLocation;
    private File buildOrderJsonFile;


    /**
     * ....so at what point did you finally decide you should have just written a copy ctor?
     * ......now. Thought about using cloneable too but sobered up first.
     * 
     * @param buildReference s
     * @throws ArtifiactRepostitoryException 
     */
    public SimpleBuildReference(BuildReference buildReference) throws ArtifiactRepostitoryException {
        this(buildReference.getBuildId(), buildReference.getBuildLocation(), buildReference.getLogicalLocation());
    }


    /**
     * 
     * The 'real' constructor. We need to associate a file system location with build artifacts with a build id.
     * Later the need for logical locations in the import step was revealed and tacked on here. We 
     * 
     * DEBATABLE 
     * 
     * ---- to deserialize the build order and log files unbounded in size when in most cases all the client is 
     * asking for is a directory is a waste. Still working out the best access route to this for interested parties.
     * 
     * ---- Demanding the existence of such files as MANIFEST, BUILD.LOG and ERROR.LOG may be counter productive in a fault
     * tolerant system that on the other side is trying to preserve as many build artifacts as possible for forensic analysis
     * later. Life boat survivors shouldn't need id.
     * 
     * @param buildId a {@link String} uniquely identifying your build in the repository
     * @param location the file system location of your build products
     * @param logicalLocation a completely arbitrary {@link String} dependant on deployment systems down range
     * @throws ArtifiactRepostitoryException don't worry, nothing can go wrong, honest.
     */
    public SimpleBuildReference(String buildId, File location, String logicalLocation) throws ArtifiactRepostitoryException {
    
        this.buildId = buildId;
        buildLocation = location;
        this.logicalLocation = logicalLocation;
        // buildOrderJsonFile is almost useless in practice it seems unless you are the UI
        buildOrderJsonFile = new File (location, StandardBuildManager.BUILD_ORDER_JSON_FILE);
        manifest = new File(location, StandardBuildManager.MANIFEST_NAME);
        
        log = new File(location, StandardBuildManager.BUILD_LOG);
        errorLog = new File(location, StandardBuildManager.ERROR_LOG);
        //buildOrder = deserializeBuildOrder(new File (location, StandardBuildManager.BUILD_ORDER_JSON_FILE));
        //index = buildOrder.getIndex();
        readBuildResultsFromManifest();
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(SimpleBuildReference o) {
       return buildId.compareTo(o.buildId);
    }

    /**
     * Invoke the dark powers of json to resurrect the {@link BuildOrder} that created this pile of build artifacts. 
     * @return your forensic {@link BuildOrder}
     * @throws ArtifiactRepostitoryException every little Exception will be wrapped and rethrown
     */
    private BuildOrder deserializeBuildOrder() throws ArtifiactRepostitoryException {
        BuildOrder buildOrderIn = null;

        StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();
        dConfig.registerDeserializer(BuildOrder.ENTITY_TYPE_ID, new BuildOrderDeserializer());
        dConfig.registerDeserializer(BuildRequest.ENTITY_TYPE_ID, new BuildRequestDeserializer());         
        dConfig.registerDeserializer(ResolvedSvnExtract.ENTITY_TYPE_ID, new ResolvedSvnExtractDeserializer()); 
        dConfig.registerDeserializer(BaseSvnExtract.ENTITY_TYPE_ID, new BaseSvnExtractDeserializer()); 

        JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);
        InputStream is;
        try {

            is = new FileInputStream(buildOrderJsonFile);
            JsonFactory jsonFactory = new JsonFactory();
            JsonParser parser = jsonFactory.createJsonParser(is);
            JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
            buildOrderIn = jsonIn.readObject(BuildOrder.class);
            jsonIn.close();

        } catch (Exception e) {
            // wrap all exceptions in ArtifiactRepostitoryException
            throw new ArtifiactRepostitoryException("Unable to deserialize " + buildOrderJsonFile.getAbsolutePath() 
                    + " Reason:" + e, e);
        }
        return buildOrderIn;   
    }

    /** {@inheritDoc} */
    @Override
    public String getBuildId() {
        return buildId;
    }
    
    /** {@inheritDoc} */
    @Override
    public BuildOrder getBuildOrder() throws ArtifiactRepostitoryException {

        if (buildOrder == null) {
            buildOrder = deserializeBuildOrder();
        }
        return buildOrder;
    }

    /** {@inheritDoc} */
    @Override
    public synchronized String getBuildOrderJson() throws ArtifiactRepostitoryException {

        if (buildOrderJson == null) {
            if (getManifest().exists()) {
                try {
                    
                    //buildOrderJson = FileUtil.readAsString(getManifest());
                    buildOrderJson = FileUtil.readAsString(buildOrderJsonFile);
                } catch (IOException ioe) {
                    throw new ArtifiactRepostitoryException("Unable to read Manifest. Reason:" + ioe, ioe);
                }
            }
        }
        return buildOrderJson;
    }


    /** {@inheritDoc} */
    @Override
    public String getBuildPerformanceString() {
        return (buildPerformance != null) ? buildPerformance.getPerformanceString() : "";
    }

 
    /** {@inheritDoc} */
    @Override
    public long getBuildStart() {
        return  (buildPerformance != null) ? buildPerformance.getBuildStart() : -1;
    }

    /** {@inheritDoc} */
    @Override
    public long getCompletionTimestamp() {
        return  buildPerformance.getCompletionTimestamp();
    }

    /** {@inheritDoc} */
    @Override
    public File getErrorLog() {
        return errorLog;
    }

    /** {@inheritDoc} */
    @Override
    public int getIndex() throws ArtifiactRepostitoryException {
        return getBuildOrder().getIndex();
    }

    /** {@inheritDoc} */
    @Override
    public File getBuildLocation() {
        return buildLocation;
    }

    /** {@inheritDoc} */
    @Override
    public File getLog() {
        return log;
    }

    /** {@inheritDoc} */
    @Override
    public String getLogicalLocation() {
        return logicalLocation;
    }


    /** {@inheritDoc} */
    @Override
    public File getManifest() {
        return manifest;
    }

    /** {@inheritDoc} 
     * 
     * @deprecated need to consolidate time getters
     * */
    @Override
    @Deprecated
    public long getStartTimestamp() {
        // TODO Auto-generated method stub
        return 0;
    }

    /** {@inheritDoc} */
    @Override
    public String getStatusString() {
        return status;
    }

    /** {@inheritDoc} */
    @Override
    public long getTotalBuildProcessCPUTime() {
        return  (buildPerformance != null) ? buildPerformance.getTotalBuildProcessCPUTime() : -1;
    }

    /** {@inheritDoc} */
    @Override
    public long getTotalBuildProcessRealTime() {
        return  (buildPerformance != null) ? buildPerformance.getTotalBuildProcessRealTime() : -1;
    }

    /** {@inheritDoc} */
    @Override
    public long getTotalExtractCPUTime() {
        return  (buildPerformance != null) ? buildPerformance.getTotalExtractCPUTime() : -1;
    }

    /** {@inheritDoc} */
    @Override
    public long getTotalExtractRealTime() {
        return  (buildPerformance != null) ? buildPerformance.getTotalExtractRealTime() : -1;
    }

    /** {@inheritDoc} */
    @Override
    public String getUser() {
        return user;
    }

    /**
     * Helper method to glean the really important accounting data from the repo (as opposed to getting the files themselves).
     * TODO: also work in progress
     * 
     * @throws ArtifiactRepostitoryException anything caught will be wrapped and rethrown
     */
    private void  readBuildResultsFromManifest() throws ArtifiactRepostitoryException {

        // No reason to read whole file.        
        //        
        //        try {
        //            String s = FileUtil.readAsString(getManifest());
        //            s.substring(s.indexOf(StandardBuildManager.TIMESTAMP_PREFIX) + StandardBuildManager.TIMESTAMP_PREFIX.length());
        //            return Long.parseLong(s);
        //        } catch (IOException ioe) {
        //            throw new ArtifiactRepostitoryException("Unable to read Manifest. Reason:" + ioe, ioe);
        //        }
        //        

        // The hope was we would just need the first couple of lines not the whole file.
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(manifest)); 
            String s;
            s = br.readLine();
            //s = s.substring(s.indexOf(StandardBuildManager.BUILD_PERFORMANCE_PREFIX) 
            //        + StandardBuildManager.COMPLETION_TIMESTAMP_PREFIX.length());

            if (!s.startsWith(StandardBuildManager.BUILD_PERFORMANCE_PREFIX)) {
                throw new ArtifiactRepostitoryException("Did not find performance data string in manifest. Parsing line:" + s
                        + " of file:" + manifest.getAbsolutePath());
            }    

            buildPerformance = new BuildPerformance(s);
            //            s.substring(s.indexOf(':') + 1); 
            //            
            //            
            //            String[] performanceFields = buildPerformance.split(":");
            //            if (performanceFields.length != 6) {
            //                throw new ArtifiactRepostitoryException("Unexpected number of fields in performance data string. Parsing line:" + s
            //                        + " of file:" + manifest.getAbsolutePath());
            //            }    
            //                        
            //            buildStart                     = Long.parseLong(performanceFields[0]);
            //            totalExtractCPUTime            = Long.parseLong(performanceFields[1]);
            //            totalExtractRealTime           = Long.parseLong(performanceFields[2]);
            //            totalBuildProcessCPUTime       = Long.parseLong(performanceFields[3]);
            //            totalBuildProcessRealTime      = Long.parseLong(performanceFields[4]);
            //            //TODO or rename to buildEnd?
            //            completionTimestamp             = Long.parseLong(performanceFields[5]);
            //            


            s = br.readLine();
            status = s.substring(s.indexOf(StandardBuildManager.BUILD_SUCCESS_PREFIX) 
                    + StandardBuildManager.BUILD_SUCCESS_PREFIX.length());
            s = br.readLine();
            user = s.substring(s.indexOf(StandardBuildManager.USER_PREFIX) 
                    + StandardBuildManager.USER_PREFIX.length());    

        } catch (Exception e) {
            // wrap all exceptions in ArtifiactRepostitoryException
            throw new ArtifiactRepostitoryException("Failed to read manifest. Reason:" + e, e);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    logger.error("IOStream close failed in catch block, ignoring. Reason:" + e, e);
                } 
            }
        }
    }


    /**
     * Doesn't output things that require lazy init.
     * 
     * {@inheritDoc})
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SimpleBuildReference [buildId=").append(buildId)
        .append(", buildLocation=").append(buildLocation)
        //.append(", index=").append(index)
        .append(", completionTimestamp=").append(getCompletionTimestamp())
        //.append(", buildOrder=").append(buildOrder)
        .append(", status=")
        .append(status).append(", user=").append(user).append("]");
        return builder.toString();
    }

}
