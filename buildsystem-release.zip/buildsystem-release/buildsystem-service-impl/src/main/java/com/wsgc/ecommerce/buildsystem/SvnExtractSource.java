package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;
import com.wsgc.ecommerce.buildsystem.util.SvnInfo;
import com.wsgc.ecommerce.buildsystem.util.SvnUtil;

/**
 *   Prediction:
 *   
 *   The svn extract is only a percentage of the extract/copy cycle. If we eliminate it completely we only double our throughput 
 *   (maybe much less).
 *   If we multi-thread the build process we can get an order of magnitude of build production output.
 *   
 *   Its not about caching the extracts, its about concurrent processing.
 *   
 *   
 *   They are only related by the way resource contention prevents concurrent processing.
 *   We need a number of sources and use them all at once, not to be all that clever about reusing them every damn time.
 *   
 * @author chunt
 * @version $Id$ 
 */
public class SvnExtractSource implements ExtractSource, Runnable {
  
    /**
     * FilenameFiler that suppresses the .DS_Store files that seem to infect all dev OS X platforms.
     * 
     * @author chunt
     * @version $Id$ 
     */
    private static class DSFilter implements FilenameFilter {
        /**
         * {@inheritDoc}
         */
        @Override
        public boolean accept(File dir, String name) {
            if (!name.equals(".DS_Store")) {
                return true;
            }
            return false;
        }
    }

    /**
     * FilenameFilter that only returns the build system marker file used to safe guard the build system svn source work directory.
     * @author chunt
     * @version $Id$ 
     */
    private static class  OnlySafeMarkerFilter implements FilenameFilter {
        /**
         * {@inheritDoc}
         */
        @Override
        public boolean accept(File dir, String name) {
            if (name.equals(SAFE_MARKER_FILE_NAME)) {
                return true;
            }
            return false;
        }
    }

    
    /**
     * FilenameFilter that only returns the build system marker file used to safe guard the build system svn source work directory.
     * @author chunt
     * @version $Id$ 
     */
    private static class OtherThanSafeMarkerFilter extends DSFilter {
        /**{@inheritDoc}*/
        @Override
        public boolean accept(File dir, String name) {

            if (!name.equals(SAFE_MARKER_FILE_NAME)) {
                return super.accept(dir, name);
            }
            return false;
        }
    }

    /**
     * @return the lock
     */
    public static Object getAccessMutex() {
        return ACCESS_MUTEX;
    }

    /**
     * Getter for the mutex used to manage contention when asking about the number of tasks this source is scheduled to
     * do still.
     * 
     * @return the {@link DEPTH_MUTEX}
     */
    public static Object getDepthMutex() {
        return DEPTH_MUTEX;
    }

    /*
     *  So, if you Object MUTEX = "FOO".intern(); ...? 
     */
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private boolean logMutexUse;
    private static final String WARNING = "To use this directory it must be manually cleared first because "
            + "this program tends to rearrange things there "
            + "and we don't want any innocent files hurt.";

    /** Arbitrary limit... override as desired */
    private final int maxRequestDepth = 10;

    /**
     * @return the maxRequestDepth
     */
    public int getMaxRequestDepth() {
        return maxRequestDepth;
    }

    private static final Object DEPTH_MUTEX = new Object();
    private static final Object ACCESS_MUTEX = new Object();

    /**
     * Text string to leave in the directories we play in to warn they are subject to change.
     */
    public static final String SAFE_MARKER_FILE_NAME = "BUILD_SYSTEM_MANAGED_DIRECTORY_KEEP_OUT";
    private ResolvedSvnExtract currentState;

    private ResolvedSvnExtract endState;

    private Queue<SvnRunnableRetrievalAction> requestQueue;

    private int requestQueueIndex;

    private final String sourcePath;

    private File extractBaseDir;

    private boolean offLine = true;

    //TODO sanity checking for the selective retrieval only.
    private SvnRetrievalAction reservedAction;
    private long lastUsed;

    /**
     * Normal Constructor.
     * 
     * @param workingBase the path to the directory where svn is holding a working copy
     * @param initialState the initial check out to populate this source with
     * @throws SourceException if the source can not be initialized
     */
    public SvnExtractSource(String workingBase, ResolvedSvnExtract initialState) throws SourceException {
        this.sourcePath = workingBase;
        requestQueue = new ArrayDeque<SvnRunnableRetrievalAction>(maxRequestDepth);

        //lazy init not a good idea anymore.
        if (initialState != null) {
            init(initialState);
        } else {
            throw new SourceException("Must have initial value for svn source url.");
        }        
    }

    /**
     * @return the workingBase
     */
    public String getWorkingBase() {
        return sourcePath;
    }

    /**
     * 
     * TODO: maybe ya wanna 'think about it first'?
     * 
     * ....   nope not right now. we like delete.
     * When sure, remove this comment
     * 
     * @param foundDirInUse not used
     * @param initialState not used
     * @return always returns <code>true</code>
     */
    private boolean considerDelete(File foundDirInUse, ResolvedSvnExtract initialState) {
        return true;
    }

    /**
     * 
     * Checks to see if the directory exists and is safe to use or doesn't exist and needs to be created and marked as
     * safe to use. If the directory doesn't have the maker file we assume someone other than the build system lives there and 
     * would be overwritten by normal build system activities. This is bad enough to warrant an exception being raised. If the 
     * directory doesn't exist, it an attempt to create it an leave a marker file behind is made. If that fails, and exception is thrown
     * 
     * TODO: callers of this method still check for null response, doesn't seem possible anymore.
     * 
     * 
     * @param sourceWorkingDir the supposed place to start checking out files in to
     * @return the working directory either validated as in use or created and ready for initial check out
     * @throws SourceException if the directory provided exists and is unsuitable for use or doesn't exist and can not be created
     * 
     */
    private File findWorkingDirInUse(File sourceWorkingDir) throws SourceException {
        File workingDirFoundCheckout = null;
        try {

            if (sourceWorkingDir.exists()) {

                // do we own it?
                if (!hasSafeToUseMarker(sourceWorkingDir)) {
                    throw new SourceException("Directory exists but is not marked as safe to use by this process. " 
                            + WARNING + " Directory:" + sourceWorkingDir);   
                }

                // This is a managed directory, check for sanity
                // (check for existence of previously managed svn source buffers)
                File[] sources = sourceWorkingDir.listFiles(new OtherThanSafeMarkerFilter());
                if (sources.length > 1) {
                    throw new SourceException("Unexpected number of subdirectories found.  Directory:" + sourceWorkingDir);
                } else if (sources.length == 1) {
                    workingDirFoundCheckout = sources[0];           
                }

                //TODO This is over kill, not done correctly or both and should be looked at.
                // We expect... nothing, in fact, require it specifically, right here and now.
                //SvnUtil.verifySvnStatus(sourceWorkingDir, null);
                
                // Bug?
                //SvnUtil.verifySvnStatusIsNull(sourceWorkingDir);
                
                // Directory is under SVN control if not then who the hell is using it?
                if (sources.length == 1 && !SvnUtil.isWorkingDirectory(workingDirFoundCheckout)) {
                    throw new SourceException("Presumed source work directory is not a working directory. " 
                            + WARNING + " Directory:" + workingDirFoundCheckout);   
                }

                // Directory is under SVN control?
                //                    if (SvnUtil.isWorkingDirectory(sourceWorkingDir)) {
                //                        // but not used by us yet.
                //                        if (!hasSafeToUseMarker(sourceWorkingDir)) {
                //               throw new SourceException("Directory seems to be already in use by SVN but is not marked as safe to use by this process. " 
                //                                    + WARNING + " Directory:" + sourceWorkingDir);   
                //                        }
                //                        // Directory is not under SVN control.
                //                    } else {
                //                        // but is not empty
                //                        if (hasFiles(sourceWorkingDir)) {
                //                            throw new SourceException("Directory is not empty. " +
                //                                    WARNING + " Directory:" + sourceWorkingDir);   
                //                        }


            } else {  
                sourceWorkingDir.mkdirs();
                FileUtil.checkDirExistsRWEmpty(sourceWorkingDir);


                File marker = new File(sourceWorkingDir, SAFE_MARKER_FILE_NAME);
                if (!marker.createNewFile()) {
                    throw new SourceException("Unable to create marker file:" + marker.getAbsolutePath());  
                }
                FileUtil.checkFileExistsReadable(marker);
            }
        } catch (IOException ioe) {
            currentState = null;
            throw new SourceException("IOException while checking extract source working directory:" 
                    + sourceWorkingDir.getAbsolutePath() 
                    + " Reason:" + ioe, ioe);  
        }


        return workingDirFoundCheckout;
    }

    /** 
     * @return the currentState
     */
    public ResolvedSvnExtract getCurrentState() {
        return currentState;
    }

    /**
     * TODO not used, yet.
     * @return the future 'current state' for predictive strategy planing.
     */
    public String getFinalEffectiveRevision() {
        String localEffectiveRevision;

        logWaitingForMutex();
        synchronized (getAccessMutex()) {
            logGotMutex();
            localEffectiveRevision = (endState == null) ? "0" : endState.getEffectiveRevision();
            logReleasingMutex();
        } 
        return localEffectiveRevision;
    }

    /**
     * TODO not used, yet.
     * @return the future 'current state' for predictive strategy planing.
     */
    public String getFinalResolvedURL() {
        String localFinalResolvedURL;
        synchronized (getAccessMutex()) {
            logGotMutex();
            localFinalResolvedURL = (endState == null) ? "" : endState.getResolvedUrl();
        }
        return localFinalResolvedURL;
    }



    //    private void validateCurrentState() throws SourceException {
    //
    //        SvnInfo svnInfo = SvnUtil.getSvnInfoWorkingCopy(extractBaseDir);
    //        if (!svnInfo.getUrl().equals(currentState.getResolvedUrl())) {
    //            throw new SourceException("Unexpected SVN Info for working base directory. Expecting:\n" + currentState.getResolvedUrl() 
    //                    +  " but found:\n" + svnInfo.getUrl());
    //        }
    //
    //    }

    /**
     * TODO not used, yet.
     * @return the future 'current state' for predictive strategy planing.
     */
    public String getFinalUuid() {
        String localUuid;

        logWaitingForMutex();
        synchronized (getAccessMutex()) {
            logGotMutex();
            localUuid = (endState == null) ? "" : endState.getUuid();
            logReleasingMutex();
        } 
        return localUuid;
    }

    /** {@inheritDoc} */
    @Override
    public long getLastUsed() {
        return lastUsed;
    }

    /**
     * @return the number of extracts pending with this source
     */
    public int getRequestQueueDepth() {
        int localSize;

        logWaitingForMutex();
        synchronized (getDepthMutex()) {
            logGotMutex();
            //localSize = requestQueue.size();
            localSize = requestQueueIndex;
            logReleasingMutex();
        }

        return localSize;
    }

    /**
     * @param sourceWorkingDir
     * @return
     */
// TODO Why is this not used suddenly?
//    private boolean hasFiles(File sourceWorkingDir) {
//        String[] list = sourceWorkingDir.list(new OtherThanSafeMarkerFilter());
//        return (list != null && list.length > 0);
//    }

    /**
     * Returns <code>true</code> when the "safe to use" marker file (defined by SAFE_MARKER_FILE_NAME) is found in the specified directory.
     * 
     * @param sourceWorkingDir where to look for the maker.
     * @return if its there or not
     * @throws SourceException if more than one was found.
     */
    private boolean hasSafeToUseMarker(File sourceWorkingDir) throws SourceException {
        String[] list = sourceWorkingDir.list(new OnlySafeMarkerFilter());
        if (list.length > 1) {
            currentState = null;
            throw new SourceException("Multiple markers found in working directory. Directory:" + sourceWorkingDir.getAbsolutePath());
        }
        return (list.length == 1);
    }

    /**
     * Its nice to be able to spin up a source in a target directory for dev or unit tests. Because there is a theoretical potential to 
     * delete our own source code when pointing at our source tree, this initialization takes pains not to dance on unmarked territory.  
     * 
     * Requires that the working directory is either empty or has a marker file that 
     * hints we have been cleared to operate here before.  
     * 
     * @param initialState the {@link ResolvedSvnExtract} to check out as the initial source state
     * @throws SourceException if we are disappointed along the way
     */
    public void init(ResolvedSvnExtract initialState) throws SourceException {
        File svnSourceWorkingDir  = new File(sourcePath);
        /*
         *  odd hack needed here, svn creates a subdirectory for target when checking out. 
         *  We need to modify the extractBaseDirectory to match the path SVN added to our root. 
         *  
         *  Tricky too, you are dealing with URLs and file systems, which are only the same in Unix.
         *  This code is weak.
         */
        String extractWorkingBasePath = svnSourceWorkingDir 
                + initialState.getResolvedUrl().substring(initialState.getResolvedUrl().lastIndexOf("/"));
        extractBaseDir = new File(extractWorkingBasePath);

        // Does this working directory seem safe and is there a svn checkout already there?
        File foundDirInUse = findWorkingDirInUse(svnSourceWorkingDir);
        CommandResultInfo commandResultInfo = null;
        // seems safe or we would have had an exception by now ...
        if (foundDirInUse == null) {
            
            // no existing dir, do a full checkout.
            commandResultInfo = SvnUtil.svnCheckout(svnSourceWorkingDir, initialState.getEffectiveRevision(), initialState.getResolvedUrl());
        } else {

            // found an existing directory, do a delete and checkout or do a switch and not a checkout.
            if (considerDelete(foundDirInUse, initialState)) {
                FileUtil.removeDirectory(foundDirInUse);
                /**
                 * TODO svnCheckout and switch should do this commandResultInfo processing, return void and throw its own SourceException
                 * as the follow logic does. 
                 */
                commandResultInfo = SvnUtil.svnCheckout(svnSourceWorkingDir, initialState.getEffectiveRevision(), initialState.getResolvedUrl());
            } else {
                
                //THIS does not happen unless considerDelete returns other than true which it doesn't anymore.
                commandResultInfo = SvnUtil.svnSwitch(foundDirInUse, initialState.getEffectiveRevision(), initialState.getResolvedUrl());
            }
        }

        try {

            if (!commandResultInfo.getSuccessStatus()) {
                /**
                 *  commandResultInfo has a log record of the attempt but its over kill unless you are going
                 *  to use it in an error log. We are not going to write an ERROR.LOG for an init failure. Just dump the info...
                 */
                CommandResultInfo.readResultsToErrorLog(logger, commandResultInfo);
                throw new SourceException("Initial SVN source initialization FAILED. CommandResultInfo:" 
                        + commandResultInfo.toString());
            }

            if (!SvnUtil.isWorkingDirectory(extractBaseDir)) {
                throw new SourceException("Failed to create Svn 'working directory' at: "  
                        + extractBaseDir);   
            }

            currentState = initialState;
            endState = initialState;
            lastUsed = System.currentTimeMillis();
        } catch (Exception e) {
            // We assume all errors are due to the fact you are offline, if not rethrow as SourceException
            if (offLine) {
                logger.warn("Offline mode, svn source errors assumed, ignored. Distracting thread dump ignored." + e);
            } else {
                throw new SourceException(e.toString(), e);
            }
        }

        logger.info("Initialized an extract source in directory: " + extractBaseDir.getAbsolutePath());

    }

    /**
     * @return the logMutexUse
     */
    public boolean isLogMutexUse() {
        return logMutexUse;
    }

    /**
     * trace method to watch mutex use
     */
    private void logGotMutex() {
        if (isLogMutexUse()) {                
            logger.debug("{} got Mutex", Thread.currentThread().getStackTrace()[2].getMethodName()); 
        }
    }

    /**
     * trace method to watch mutex use
     */
    private void logReleasingMutex() {
        if  (isLogMutexUse()) {                
            logger.debug("{} releasing Mutex", Thread.currentThread().getStackTrace()[2].getMethodName());        
        }        
    }

    /**
     * trace method to watch mutex use
     */
    private void logWaitingForMutex() {
        if  (isLogMutexUse()) {                
            logger.debug("{} waiting for Mutex", Thread.currentThread().getStackTrace()[2].getMethodName());        
        }
    } 

    /** {@inheritDoc} */
    @Override
    public synchronized SourceRetrievalDetails performExtract(
            @SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract, File targetDirectory) throws SourceException {
        
        SourceRetrievalDetails sourceRetrievalDetails = null;
       
        // No one is leaving until we have an extract or have reset current state to "WTF?" == (null)
        try {
            
            lastUsed = System.currentTimeMillis();
            long extractStart = lastUsed;

            ResolvedSvnExtract  resolvedSvnExtract = (ResolvedSvnExtract) resolvedExtract;
            sourceRetrievalDetails = 
                    new SourceRetrievalDetails(resolvedSvnExtract, targetDirectory);
            sourceRetrievalDetails.setStartTime(extractStart);

            if (extractBaseDir == null) {
                throw new SourceException(getClass().getName() + " is not initialized.");
            }

            if (currentState != null && !resolvedSvnExtract.getUuid().equals(currentState.getUuid())) {
                throw new SourceException("'svn switch with relocate' between different repositories is not support yet.");
            }        
            
            /* Find or create and cached copy of the effective extract.
             * 
             * Extracts are defined by their concreteURL and revision number (and uuid).
             * 
             * Example:
             * "static_content", "svn",
             * baseURL = "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk/static/"
             * branchURL = https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/pb_primary/static/
             * 
             * do once (?) when encountering a missing base directory
             * 
             * Step #1
             * svn checkout baseURL (revision = head) to
             * $tmpdir/extracts/ecommerce/sites/pb/content/trunk/static/WORKING_BASE_REFFERENCE 
             *  
             *   Checked out revision 154752.
             *    
             *   real    8m35.102s
             *   user    1m7.582s
             *   sys     0m55.857s
             *
             * Step #2
             * cd $tmpdir/extracts/ecommerce/sites/pb/content/trunk/static/WORKING_BASE_REFFERENCE 
             * svn switch -r ${effective revision} branchURL 
             * svn switch -r 154000 https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/pb_primary/static/
             * Updated to revision 154000.
             *
             * real      0m28.799s
             * user      0m5.027s
             * sys       0m4.699s
             *
             * Step #3
             * svn status, remove any files not under version control
             * 
             * Step #4
             * copy to extract (cacheable?) 'holding directory'
             * tmpdir/extracts/ecommerce/sites/pb/content/branches/pb_primary/static/${effectiveRevision}
             *
             * mkdir -p /Users/chunt/work/local/newExtractsTmpDir/extracts/ecommerce/sites/pb/content/branches/pb_primary/static/154000 
             * time cp -R . /Users/chunt/work/local/newExtractsTmpDir/extracts/ecommerce/sites/pb/content/branches/pb_primary/static/154000 
             *
             * real  4m40.801s
             * user  0m1.451s
             * sys   0m22.570s
             *  
             *  
             *  
             *  From this point on we have an extract checked out of svn and ready for whatever 'build processing' the build command
             *  is associated with. The resolved extract lives in tmpdir/resolved_branch_URL/effective_revision.
             *  
             */

            // for (ResolvedExtract resolvedExtract : buildRequest.getResolvedExtracts()) {


            //ResolvedExtract resolvedExtract = buildRequest.getResolvedExtract(key); 

            //TODO simplistic parsing here
            /*
             *  TODO chance directory top from 'extracts' to something like extracts-base-working-directory-foo instead 
             *  of tagging the bottom of the dir tree
             */
            //            String extractWorkingBaseReffLocation = 
            //                StandardBuildService.YOUR_FAKE_TEMP_DIRECTORY 
            //                + resolvedSvnExtract.getBaseExtract().getURL().replace("https://repos.wsgc.com/svn/core", "extracts") 
            //                + StandardBuildService.EXTRACT_LOCATION_BASE_TAG;
            //            

            // Step #1 TODO Does checkout directory exist? ... lets say 'yes' for now.
            //checkOutExtract()

            //      validateCurrentState();
            SvnInfo svnInfo = SvnUtil.getSvnInfoWorkingCopy(extractBaseDir);

            if (currentState != null && !svnInfo.getUrl().equals(currentState.getResolvedUrl())) {
                String detailMesssage = "Unexpected SVN Info for working base directory. Expecting:\n" + currentState.getResolvedUrl() 
                        +  " but found:\n" + svnInfo.getUrl();
                throw new SourceException(detailMesssage);
            }

            /** 
             * Step #2
             * cd $tmpdir/extracts/ecommerce/sites/pb/content/trunk/static/WORKING_BASE_REFFERENCE 
             * svn switch -r ${effective revision} branchURL 
             * svn switch -r 154000 https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/pb_primary/static/
             * Updated to revision 154000.
             */

            /*
             *  Note: is there any good use for this return value? No. We check its status but don't care about the log.
             *  We use commandResultInfo but do not keep its logs for reporting SourceRetrievalDetails. SvnSwitch has 
             *  its own error processing and uses more than one SvnUtil to do its job. You are not the only one
             *  looking at this CommandResultInfo object. If the the process completes the log would be a list of files possibly very long.
             *  If it fails, the errors it generates should be captured before leaving svnSwitch and any exceptions are set on the 
             *  CommandResultInof object. CommandResultInfo.validate will rethrow those.
             */
            CommandResultInfo commandResultInfo = 
                    SvnUtil.svnSwitch(extractBaseDir, resolvedSvnExtract.getEffectiveRevision(), resolvedSvnExtract.getResolvedUrl());
//            try {
            CommandResultInfo.validate(commandResultInfo);
//        } catch (Throwable t) {
//            currentState = null;
//            throw new SourceException(t);
//        }

        //        
        //        //svnSwitch
        //        String[] command = {"svn", "switch", "-r", 
        //                resolvedSvnExtract.getEffectiveRevision(), resolvedSvnExtract.getResolvedUrl()};
        //
        //        ProcessBuilder processBuilder = new ProcessBuilder(command);
        //
        //        processBuilder.directory(extractBaseDir);
        //
        //        ProcessUtil.waitForProcess(processBuilder);

        /**
         * Step #3
         * svn status, remove any files not under version control
         * 
         * Now handled by svn -- ignore param
         */


        /**
         * Step #4
         * copy to extract (cacheable?) "holding directory for effective branch/extracts to be worked on by their 'build command'"
         * tmpdir/extracts/ecommerce/sites/pb/content/branches/pb_primary/static/${effectiveRevision}   
         */
        SvnUtil.copyNonSvnFiles(extractBaseDir, targetDirectory);

        currentState = resolvedSvnExtract;

        sourceRetrievalDetails.setSuccessStatus(true);
        sourceRetrievalDetails.setEndTime(System.currentTimeMillis());

        } catch (Throwable t) {
            currentState = null;
            throw new SourceException(t);
        }

        return sourceRetrievalDetails;
    }

    /**
     * predictive, experimental, not used by any other {@link SourceRetrievalStrategy}. The fact it could be via this
     * method is bad all by its self.
     * TODO...everything
     * @param svnRetrievalAction xx
     */
    public void queExtractRequest(SvnRunnableRetrievalAction svnRetrievalAction) {  
        logWaitingForMutex();
        synchronized (getAccessMutex()) {
            logGotMutex();
            //Action thread should immediately enter a wait for the next notification from the svn source queue put.
            svnRetrievalAction.start();        
            requestQueue.add(svnRetrievalAction);
            setEndState(svnRetrievalAction.getResolvedSvnExtract());
            logReleasingMutex();
        }
        // Notify ourselves that the our queue has been modified.
        synchronized (this) {
            notify();
        }
        return;
    }

    /**
       TODO likely remove after predictive is done and spend some time with a nice Islay of adequate lineage and think about why this class 
       KNOWS ANYTHING AT ALL ABOUT THAT FACT!!!!!!  
     * @param svnRetrievalAction all the wrong reasons apparently 
     */
    public void reserveOneExtractRequest(SvnRetrievalAction svnRetrievalAction) {  
        logWaitingForMutex();
        synchronized (getDepthMutex()) {
            logGotMutex();
            requestQueueIndex++;
            reservedAction = svnRetrievalAction;
            if (requestQueueIndex > 1) {
                throw new RuntimeException("Extract request limit out of range. current value:" + requestQueueIndex);
            }
            setEndState(svnRetrievalAction.getResolvedSvnExtract());
            logReleasingMutex();
        }
        // Notify ourselves that the our queue has been modified.
        //        synchronized (this) {
        //            notify();
        //        }
        return;
    }

    @Override
   // not used... yet
    public void run() {
        SvnRunnableRetrievalAction nextRetrievalAction;

        while (true) {

            try {

                synchronized (this) {                    
                    // tried originally with a BlockingQueue... surprisingly unhelpful.
                    while (requestQueue.peek() == null) {
                        //              try {
                        //Thread.sleep(500);
                        // we block until someone adds something to the queue and notifies us to look.
                        wait();
                    }
                    //                }  catch (InterruptedException ie) {
                    //                    logger.debug("Wait for add to request queue was interrupted:" + ie, ie);
                    //                    Thread.currentThread().interrupt();
                    //                }   
                }

                /* guard against changing queue depth while making
                 * decisions based on its value
                 */                    
                logWaitingForMutex();
                synchronized (getAccessMutex()) { 
                    logGotMutex();
                    nextRetrievalAction = requestQueue.poll();

                    /*
                     *  This line is either the whole idea or the whole problem depending if you are
                     *  Neo or the Architect when the flaw is expressed.
                     */
                    //////////////////////////////////////////////////////////////////////////////////////////////////////
                    //nextRetrievalAction.setFutureSourceRetrievalDetails(executor.submit(nextRetrievalAction));
                    //////////////////////////////////////////////////////////////////////////////////////////////////////
                    logReleasingMutex();
                }

                ////////////////////////////////////////////////////////////////////////////////////////////
                //            while (!nextRetrievalAction.getFutureSourceRetrievalDetails().isDone()) {
                //                // TODO remove this as too spammy Try to make this a wait?
                //                if (logger.isDebugEnabled()) {
                //                    logger.debug("Waiting for extract task to finish.");
                //                }
                //                try {
                //                    Thread.sleep(500);
                //                }  catch (InterruptedException ie) {
                //                    logger.debug("Wait for extract task to finish was interrupted:" + ie, ie);
                //                    Thread.currentThread().interrupt();
                //                }
                //            }
                /////////////////////////////////////////////////////////////////////////////////////////

                // Notify the action that it can start its extract operation now.
                logger.debug("Waiting for lock on {}", nextRetrievalAction);
                synchronized (nextRetrievalAction) {
                    logger.debug("Sending notify to action thread.");
                    nextRetrievalAction.notify();
                }
                /*
                 *  Action is now free to start performExtract at this point.
                 *  We wait for it to finish before starting next action.
                 */
                logger.debug("Waiting on join with action thread {}", nextRetrievalAction);
                nextRetrievalAction.join();
                logger.debug("After join with action thread {}", nextRetrievalAction);

            } catch (InterruptedException ie) {
                /*
                 *  There is nothing to do? 
                 *  Queued actions are in a wait state and will get their own interrupted signal but they are expecting a cancel in the case of
                 *  a bad build. 
                 *  Presumably nextRetrievalAction's run'ning thread will take care of its own state
                 *  THIS should not happen.
                 *  We would let this exception out if run could throw such animals.
                 *  
                 *  Why would this happen and what good is a dead svnSource afterward? A quiet shutdown seems equally useless..
                 *  
                 *  Lets just stop for now and figure out if a restart is a better idea.
                 */
                Thread.currentThread().interrupt();
                return;
            }            
        }
    }

    /**
     * @param currentState the currentState to set
     */
    public void setCurrentState(ResolvedSvnExtract currentState) {
        this.currentState = currentState;
    }

    /**
     * @param endState the endState to set
     */
    public void setEndState(ResolvedSvnExtract endState) {
        logWaitingForMutex();
        synchronized (getAccessMutex()) { 
            logGotMutex();
            this.endState = endState;
            logReleasingMutex();
        }
    }
    /**
     * @param logMutexUse whether to log mutex use or not
     */
    public void setLogMutexUse(boolean logMutexUse) {
        this.logMutexUse = logMutexUse;
    }

    /**
     * {@inheritDoc}     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SvnExtractSource [sourcePath=").append(sourcePath).append(", maxRequestDepth=")
        .append(maxRequestDepth).append(", currentState=")
        .append(currentState).append(", endState=").append(endState).append(", requestQueue=")
        .append(requestQueue).append(", requestQueueIndex=").append(requestQueueIndex)
        .append("]");
        return builder.toString();
    }

    /**
     * @param svnRetrievalAction remove the provided {@link SvnRetrievalAction} from the work queue
     */
    public void unreserveOneExtractRequest(SvnRetrievalAction svnRetrievalAction) {

        // Hack while I feel my way through this.
        // someone is not using reservations but unreserve is always being called due to experimental design.
        // ignore it.
        if (reservedAction == null) {
            return;
        }

        // sanity check only.
        if (reservedAction != svnRetrievalAction) {
            throw new RuntimeException("Mismatched reservations.. current reserved action:" + reservedAction 
                    + " action to unreserve:" + svnRetrievalAction);
        }

        logWaitingForMutex();
        synchronized (getDepthMutex()) {
            logGotMutex();
            requestQueueIndex--;
            if (requestQueueIndex != 0) {
                throw new RuntimeException("Extract request limit out of range. current value:" + requestQueueIndex);
            }
            logReleasingMutex();
            getDepthMutex().notifyAll();
        } 
    }

}