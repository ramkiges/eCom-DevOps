package com.wsgc.ecommerce.buildsystem.json;

import static com.wsgc.ecommerce.buildsystem.Project.BUILD_PLANS;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BuildPlan;
import com.wsgc.ecommerce.buildsystem.Project;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;

/**
 * JSON deserializer implementation for {@link Project}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class ProjectDeserializer implements JsonObjectDeserializer<Project> {
    
    private static final Class<Project> JSON_DESERIALIZATION_TARGET = Project.class;   
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(Project.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @Override
    public Project deserialize(String objectType, String instanceId,
            JsonObjectInputStream json) throws IOException {
        String id = null;
        String label = null;
        //String projectFileName  = null;
        //Map<String, ExtractDefinition> extractDefinitions = null;
        Map<String, BuildPlan> buildPlans = null;

        for (String fieldName : json.iterateObjectFieldNames()) {
            //if (log.isDebugEnabled()) {
                log.trace("Saw field: {}", fieldName);
            //}
//            if (fieldName.equals(PROJECT_FILE_NAME)) {
//                projectFileName = json.readString();
//            } else 
            if (fieldName.equals(ID)) {
                id = json.readString();
            } else if (fieldName.equals(LABEL)) {
                label = json.readString(); 
//            } else if (fieldName.equals(EXTRACT_DEFINITIONS)) {
//                extractDefinitions = new HashMap<String, ExtractDefinition>();
//                for (String extractName : json.iterateObjectFieldNames()) {
//                    ExtractDefinition extract = json.readObject(ExtractDefinition.class);
//                    extractDefinitions.put(extractName, extract);
//                }
                
                
////                for (String extractName : json.iterateObjectFieldNames()) {
////                    ExtractDefinition extract = json.readObject(ExtractDefinition.class);
////                    extractDefinitions.put(extractName, extract);
////                }
            } else if (fieldName.equals(BUILD_PLANS)) {
                buildPlans = new HashMap<String, BuildPlan>();
//                for (String buildPlanName : json.iterateObjectFieldNames()) {
//                    BuildPlan buildPlan = json.readObject(BuildPlan.class);
//                    buildPlans.put(buildPlanName, buildPlan);
//                }
/*
 *  TODO are you using NAMES or ID's for keys, Extracts have names , not ID's BuildPlans have ID.
 *  implement below and sync changes with build_plans.flt  
 */
                
                for (@SuppressWarnings("unused") String buildPlanName : json.iterateObjectFieldNames()) {
                    BuildPlan buildPlan = json.readObject(BuildPlan.class);
                    buildPlans.put(buildPlan.getId(), buildPlan);
                }
            } else {
                throw new JsonParseException("Unexpected field in json representation of " 
                        + JSON_DESERIALIZATION_TARGET.getName() + " '" + fieldName + "'",
                        json.getTokenLocation());
            }
        }

        if (id == null || label == null || /*extractDefinitions == null ||*/ buildPlans == null) {
            
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() 
                    + " Null field found:  "  
                    + ID + ":" + id + " " + LABEL + ":" + label
                    + " " /*+ EXTRACT_DEFINITIONS + ":" + extractDefinitions + " "*/ 
                    + BUILD_PLANS + ":" + buildPlans);
        }
        return new Project(id, label, /*extractDefinitions,*/ buildPlans);
        

    }

}
