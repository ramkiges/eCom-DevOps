package com.wsgc.ecommerce.buildsystem;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.ExtractException;
import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/**
 * 
 * SVN specific implementation of {@link SourceRetrievalAction}
 * 
 * @author chunt
 * @version $Id$
 * 
 */
public class SvnRetrievalAction implements SourceRetrievalAction {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private SvnExtractSource svnExtractSource;
    private ResolvedSvnExtract resolvedSvnExtract;
    private File targetDirectory;
    private SourceRetrievalDetails sourceRetrievalDetails;
    
    /**
     * Creates a {@link SvnRetrievalAction} from {@link SvnExtractSource} and {@link ResolvedSvnExtract}
     * 
     * @param svnExtractSource the source
     * @param resolvedSvnExtract the concrete extract to obtain
     * @param targetDirectory the directory where to put the extract
     */
    public SvnRetrievalAction(SvnExtractSource svnExtractSource, ResolvedSvnExtract resolvedSvnExtract,
            File targetDirectory) {
        this.svnExtractSource = svnExtractSource;
        this.resolvedSvnExtract = resolvedSvnExtract;
        this.targetDirectory = targetDirectory;
    }

    //    @Override
    //    public SourceRetrievalDetails call() throws Exception {
    //      public void run() {
    //        try {
    //            //block until someone sends a notify. Presumably this will the worker thread on svnExtractSource.
    //            logger.debug("Tying to enter sync(this) block to wait for notify from source worker thread.");
    //            synchronized (this) {
    //                logger.debug("Waiting for notify from Source worker thread.");
    //                wait();
    //                logger.debug("Got notify from Source worker thread.");
    //            }
    //            logger.debug("Beginning extract to " + targetDirectory.getAbsolutePath());
    //            sourceRetrievalDetails = svnExtractSource.performExtract(resolvedSvnExtract, targetDirectory);
    //        } catch (Exception e) {
    //            // Could be a failed build detected via InterruptException or something local.
    //            sourceRetrievalDetails = new SourceRetrievalDetails(resolvedSvnExtract, targetDirectory);
    //            sourceRetrievalDetails.setLastException(e);
    //        }
    //    }

    //    public synchronized Future<SourceRetrievalDetails> getFutureSourceRetrievalDetails() {
    //        return futureSourceRetrievalDetails;
    //    }
    //
    //    public synchronized void setFutureSourceRetrievalDetails(Future<SourceRetrievalDetails> sourceRetrievalDetails) {
    //        this.futureSourceRetrievalDetails = sourceRetrievalDetails;
    //    }

    /**
     * @return the resolvedSvnExtract
     */
    public ResolvedSvnExtract getResolvedSvnExtract() {
        return resolvedSvnExtract;
    }

    /** {@inheritDoc}} */
    @Override
    //lazy init or just a badly named method
    public SourceRetrievalDetails getSourceRetrievalDetails() throws ExtractException {
        try {
            sourceRetrievalDetails = svnExtractSource.performExtract(resolvedSvnExtract, targetDirectory);
        } catch (SourceException e) {
            throw new ExtractException(e);
        } finally {
            logger.trace("Finally block releasing reservation on {}", svnExtractSource);
            svnExtractSource.unreserveOneExtractRequest(this);
        }
        return sourceRetrievalDetails;
    }   

}
