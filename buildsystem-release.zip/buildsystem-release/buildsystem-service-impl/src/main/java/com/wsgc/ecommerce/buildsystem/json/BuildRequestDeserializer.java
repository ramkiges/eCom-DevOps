package com.wsgc.ecommerce.buildsystem.json;

import static com.wsgc.ecommerce.buildsystem.BuildRequest.BUILD_ID;
import static com.wsgc.ecommerce.buildsystem.BuildRequest.GENERATION_ID;
import static com.wsgc.ecommerce.buildsystem.Project.BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.POST_BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.RESOLVED_EXTRACTS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.buildsystem.ResolvedExtract;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;

/**
 * JSON deserializer implementation for {@link BuildRequest}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildRequestDeserializer implements JsonObjectDeserializer<BuildRequest> {
    private static final Class<BuildRequest> JSON_DESERIALIZATION_TARGET = BuildRequest.class;
    private final Logger log = LoggerFactory.getLogger(getClass());


    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(BuildRequest.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @SuppressWarnings("rawtypes")
    @Override
    public BuildRequest deserialize(String objectType, String instanceId,
            JsonObjectInputStream json) throws IOException {
        String id = null;
        String label = null;
        String  buildId = null;
        String  generationId = null;

        List<String> command = null;
        List<String> postBuildCommand = null;
        List<ResolvedExtract> resolvedExtracts = null;

        for (String fieldName : json.iterateObjectFieldNames()) {
            log.trace("Saw field: {}", fieldName);
            if (fieldName.equals(ID)) {
                id = json.readString();
            } else if (fieldName.equals(LABEL)) {
                label = json.readString(); 
            } else if (fieldName.equals(BUILD_ID)) {
                buildId = json.readString(); 
            } else if (fieldName.equals(GENERATION_ID)) {
                generationId = json.readString(); 
            }  else if (fieldName.equals(BUILD_COMMAND)) {
                command = new ArrayList<String>();
                for (@SuppressWarnings("unused") JsonToken tok : json.iterateArrayTokens()) {
                    //One might use: if (tok != JsonToken.VALUE_STRING) -- but its done by readString.  so we don't need tok. 
                    command.add(json.readString());
                }
            }  else if (fieldName.equals(POST_BUILD_COMMAND)) {
                postBuildCommand = new ArrayList<String>();
                for (@SuppressWarnings("unused") JsonToken tok : json.iterateArrayTokens()) {
                    //One might use: if (tok != JsonToken.VALUE_STRING) -- but its done by readString.  so we don't need tok. 
                    postBuildCommand.add(json.readString());
                }
            } else if (fieldName.equals(RESOLVED_EXTRACTS)) {
                resolvedExtracts = new ArrayList<ResolvedExtract>();
                for (@SuppressWarnings("unused") String extractName : json.iterateObjectFieldNames()) {
                    ResolvedExtract extract = json.readObject(ResolvedExtract.class);
                    resolvedExtracts.add(extract);
                }
            } else {
                throw new JsonParseException("Unexpected field in json representation of " 
                        + JSON_DESERIALIZATION_TARGET.getName() + " '" + fieldName + "'",
                        json.getTokenLocation());
            }
        }

        if (id == null || label == null || resolvedExtracts == null || command == null) {
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() 
                    + " Null field found:  " + ID + ":" + id + " " + LABEL + ":" + label
                    + " " + BUILD_COMMAND + ":" + command);
        }
        
        BuildRequest buildRequest = new BuildRequest(id, label, resolvedExtracts, command, postBuildCommand);
        buildRequest.setBuildId(buildId);
        buildRequest.setGenerationId(generationId);
        return buildRequest;
    }

}
