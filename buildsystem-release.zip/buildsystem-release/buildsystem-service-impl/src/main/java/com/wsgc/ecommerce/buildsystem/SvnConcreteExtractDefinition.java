package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;

import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;


/**
 * TODO still need to extract interface and create Svn version of all extract types that implement said interfaces.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class SvnConcreteExtractDefinition implements ConcreteExtractDefinition {

    private final String branch;
    private final String name;
    private final String revision;
    /**
     * We need some way other than java class hierarchy to tell what kind of extract we are using. 
     * This serializes nicely.
     * 
     */
    public static final String TYPE = "/extract/concrete/definition/svn";
    private final String uuid;
    private static final String ENTITY_TYPE_ID = "build_system/build_request";
    
    /**
     * Constructs a concrete extract definition for a SVN source server.
     * 
     * @param name the name of this extract definition
     * @param branch the branch or tag this source extract is from, TRUNK is a branch in this sense
     * @param revision the revision of source code
     * @param uuid the uuid of the server
     */
    public SvnConcreteExtractDefinition(String name, String branch, String revision, String uuid) {
        this.name = name;
        this.branch = branch;
        this.revision = revision;
        this.uuid = uuid;
    }

    /**
     * Convenience ctor used in early front end code. Completely unforgiving of miss-use or miss-understanding.
     * 
     * @param ctorParams the name, branch, revision and uuid objects in that order.
     */
    public SvnConcreteExtractDefinition(String[] ctorParams) {
        this.name = ctorParams[0];
        this.branch = ctorParams[1];
        this.revision = ctorParams[2];
        this.uuid = ctorParams[3];
    }

    /** {@inheritDoc} */
    @Override
    public String getBranch() {
        return branch;
    }

    /**
     * @return the id
     */
    public String getName() {
        return name;
    }

    /** {@inheritDoc} */
    @Override
    public String getRevision() {
        return revision;
    }

    /** {@inheritDoc} */
    @Override
    public String getType() {
        return TYPE;
    }

    /** {@inheritDoc} */
    @Override
    public String getUuid() {
        return uuid;
    }
    
    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SvnConcreteExtractDefinition [branch=").append(branch).append(", name=").append(name)
                .append(", revision=").append(revision).append(", uuid=").append(uuid).append("]");
        return builder.toString();
    }
    
    /** {@inheritDoc} */
    @Override
    public Object getEntityInstanceId() {
        // not used.
        return null;
    }
    
    /** {@inheritDoc} */
    @Override
    public void writeSelf(JsonObjectOutputStream json) throws IOException {
        // TODO Auto-generated method stub
        
    }

    /** {@inheritDoc} */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

}
