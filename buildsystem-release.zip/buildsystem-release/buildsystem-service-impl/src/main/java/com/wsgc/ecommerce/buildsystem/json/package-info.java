/**
 * Contains objects related to the build system json deserialization implementation.
 */package com.wsgc.ecommerce.buildsystem.json;

