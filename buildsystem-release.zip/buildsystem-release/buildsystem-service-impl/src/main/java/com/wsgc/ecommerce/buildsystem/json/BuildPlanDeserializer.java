package com.wsgc.ecommerce.buildsystem.json;

import static com.wsgc.ecommerce.buildsystem.Project.BUILD_COMMAND;
import static com.wsgc.ecommerce.buildsystem.Project.EXTRACT_DEFINITIONS;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.POST_BUILD_COMMAND;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BuildPlan;
import com.wsgc.ecommerce.buildsystem.ExtractDefinition;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;


/**
 * Json deserializer for {@link BuildPlan}.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildPlanDeserializer implements JsonObjectDeserializer<BuildPlan> {
    private static final Class<BuildPlan> JSON_DESERIALIZATION_TARGET = BuildPlan.class;
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(BuildPlan.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @Override
    public BuildPlan deserialize(String objectType, String instanceId,
            JsonObjectInputStream json) throws IOException {
        String id = null;
        String label = null;
        List<String> buildCommand = null;
        List<String> postBuildCommand = null;

        Map<String, ExtractDefinition> extractDefinitions = null;

        for (String fieldName : json.iterateObjectFieldNames()) {
                log.trace("Saw field: {}", fieldName);
            if (fieldName.equals(ID)) {
                id = json.readString();
            } else if (fieldName.equals(LABEL)) {
                label = json.readString(); 
            }  else if (fieldName.equals(BUILD_COMMAND)) {
                buildCommand = new ArrayList<String>();
                for (@SuppressWarnings("unused") JsonToken tok : json.iterateArrayTokens()) {
                    //One might use: if (tok != JsonToken.VALUE_STRING) -- but its done by readString.  so we don't need tok. 
                    buildCommand.add(json.readString());
                }
            }  else if (fieldName.equals(POST_BUILD_COMMAND)) {
                postBuildCommand = new ArrayList<String>();
                for (@SuppressWarnings("unused") JsonToken tok : json.iterateArrayTokens()) {
                    //One might use: if (tok != JsonToken.VALUE_STRING) -- but its done by readString.  so we don't need tok. 
                    postBuildCommand.add(json.readString());
                }
            } else if (fieldName.equals(EXTRACT_DEFINITIONS)) {
                extractDefinitions = new HashMap<String, ExtractDefinition>();
                for (String extractName : json.iterateObjectFieldNames()) {
                    ExtractDefinition extract = json.readObject(ExtractDefinition.class);
                    extractDefinitions.put(extractName, extract);
                }
            } else {
                throw new JsonParseException("Unexpected field in json representation of " 
                        + JSON_DESERIALIZATION_TARGET.getName() + " '" + fieldName + "'",
                        json.getTokenLocation());
            }
        }

        if (id == null || label == null || extractDefinitions == null || buildCommand == null) {
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() 
                    + " Null field found:  " + ID + ":" + id + " " + LABEL + ":" + label
                    + " " + BUILD_COMMAND + ":" + buildCommand);
        }
        return new BuildPlan(id, label, extractDefinitions, buildCommand, postBuildCommand);

    }

}
