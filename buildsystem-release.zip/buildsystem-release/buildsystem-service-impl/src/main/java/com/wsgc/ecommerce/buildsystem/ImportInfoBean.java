/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Data object to hold the logical sections of the importinfo.txt file used to import builds in to staging and deployment.
 * There is a header collection which can be set once, a provides list and requires map.
 * 
 * This class is not thread safe.
 * 
 * 
 * TODO: Need to watch the map construction under debugger and finish comments the email about the format
 * of the import info file is lost to disk quotas.
 * 
 * 
 

 
 * 
 * 
 * 
 * @author chunt
 * @version $Id$ 
 */
public class ImportInfoBean {

/** Example import info file:
      
    SITE 69
    BUILD cmx-test-20600411-063
    LABEL wedp cmx-test-20600411-063
    PROVIDES generation 69-MISC-260041163
    PROVIDES generation 69-MSG-260041163
    REQUIRES msgdata L-W802208PAGY/buildsystem2/wedp/cmx-test-20600411-063/wedpmsgs-cmx-test-20600411-063.zip
    REQUIRES miscdata L-W802208PAGY/buildsystem2/wedp/cmx-test-20600411-063/wedpmisc-cmx-test-20600411-063.zip
    OK
*/
    
    /**
     * A marker to identify the 'site id line' in a import info file e.g. "SITE 69"
     */
    public static final String SITE = "SITE";
    /**
     * A marker to identify the 'site id line' in a import info file. e.g. "BUILD cmx-test-20600411-063"
     */
    public static final String BUILD = "BUILD";
    /**
     * A marker to identify the 'label line' in a import info file. e.g. "LABEL wedp cmx-test-20600411-063"
     */    
    public static final String LABEL = "LABEL";
    /**
     * A marker to identify the 'provides line' in a import info file. e.g. "PROVIDES generation 69-MISC-260041163"
     */    
    public static final String PROVIDES = "PROVIDES";  
    /**
     * A marker to identify the 'requires line' in a import info file. e.g. 
     * "REQUIRES msgdata L-W802208PAGY/buildsystem2/wedp/cmx-test-20600411-063/wedpmsgs-cmx-test-20600411-063.zip"
     */        
    public static final String REQUIRES = "REQUIRES";
  
    
    private String header;
    private SortedSet<String> provides;

    private SortedMap<String, SortedSet<String>> requires;
    
    /**
     * Only constructor, initializes internal collections.
     */
    public ImportInfoBean() {
        provides = new TreeSet<String>();
        requires = new TreeMap<String, SortedSet<String>>();
    }
    
    /**
     * Add a 'provides line' to the virtual import info file we are creating.
     * @param value the "provides line"
     */
    public void addProvides(String value) {
        provides.add(value);
    }

    /**
     * @return the header
     */
    public String getHeader() {
        return header;
    }

    /**
     * @return the provides
     */
    public SortedSet<String> getProvides() {
        return provides;
    }

    /**
     * @return the requires
     */
    public SortedMap<String, SortedSet<String>> getRequires() {
        return requires;
    }

    /**
     * 
     * TODO: Explain this pls. We are not sure of the 'Key" here,
     * 
     * 
     * 
     * --signed author's other voices in head.
     * 
     * e.g.  '/BUILD_SYSTEM-2.0_WORK_AREA/EXTRACT_WORKING_DIR/cmx-test-20600412-016/all_messages_build_plan'
     * Does that help?
     * 
     * @param key  ?
     * @param value ?
     */
    public void putRequires(String key, String value) {

        if (!requires.containsKey(key)) {
            requires.put(key, new TreeSet<String>());
        }
        requires.get(key).add(value);      
    }

    /**
     * @param newHeader the header to set
     */
    public void setHeader(String newHeader) {
        if (header != null) {
            throw new IllegalArgumentException("Header can only be set once. Current value:" + this.header 
                    + " attempted new value:" + header);
        }
        this.header = newHeader;
    }

}
