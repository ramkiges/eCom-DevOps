package com.wsgc.ecommerce.buildsystem.json;

import static com.wsgc.ecommerce.buildsystem.BuildRequest.BUILD_ID;
import static com.wsgc.ecommerce.buildsystem.BuildRequest.GENERATION_ID;
import static com.wsgc.ecommerce.buildsystem.Project.BUILD_REQUESTS;
import static com.wsgc.ecommerce.buildsystem.Project.ID;
import static com.wsgc.ecommerce.buildsystem.Project.LABEL;
import static com.wsgc.ecommerce.buildsystem.Project.PROJECT_ID;
import static com.wsgc.ecommerce.buildsystem.Project.PROJECT_LABEL;

import java.io.IOException;
import java.util.SortedSet;
import java.util.TreeSet;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.BuildRequest;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;

/**
 * JSON deserializer implementation for {@link BuildOrder}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BuildOrderDeserializer implements JsonObjectDeserializer<BuildOrder> {
    private static final Class<BuildOrder> JSON_DESERIALIZATION_TARGET = BuildOrder.class;
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(BuildOrder.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @Override
    public BuildOrder deserialize(String objectType, String instanceId,
            JsonObjectInputStream json) throws IOException {
        String id = null;
        String label = null;
        String projectId = null;
        String projectLabel = null;
        String buildId = null;
        
        /**
         * Generation Id is in the json form but not part of the the constructor arguments as at the time of writing it
         * was calculated from the build id. We will read it now, perhaps check its value in the future but are ok with
         * not using it here.
         */
        @SuppressWarnings("unused")
        String generationId = null;
        
        SortedSet<BuildRequest> buildRequestSet = null;


        for (String fieldName : json.iterateObjectFieldNames()) {
            
            log.trace("Saw field: {}", fieldName);
            
            if (fieldName.equals(ID)) {
                id = json.readString();
            } else if (fieldName.equals(LABEL)) {
                label = json.readString();
            } else if (fieldName.equals(PROJECT_ID)) {
                projectId = json.readString();    
            } else if (fieldName.equals(PROJECT_LABEL)) {
                projectLabel = json.readString();
            } else if (fieldName.equals(BUILD_ID)) {
                buildId = json.readString();
            } else if (fieldName.equals(GENERATION_ID)) {
                generationId = json.readString();
            } else if (fieldName.equals(BUILD_REQUESTS)) {
                if (buildRequestSet == null) {
                    buildRequestSet = new TreeSet<BuildRequest>();
                }
  
                for (@SuppressWarnings("unused") JsonToken tok : json.iterateArrayTokens()) {
                    //One might use: if (tok != JsonToken.VALUE_STRING) -- but its done by readString.  so we don't need tok. 
                    buildRequestSet.add(json.readObject(BuildRequest.class));
                }

            } else {
                throw new JsonParseException("Unexpected field in json representation of " 
                        + JSON_DESERIALIZATION_TARGET.getName() + " '" + fieldName + "'",
                        json.getTokenLocation());
            }
        }

        if (id == null || label == null || buildRequestSet == null) {
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() 
                    + " Null field found:  " + ID + ":" + id + " " + LABEL + ":" + label 
                    + " buildRequestSet:" + buildRequestSet);
        }

        BuildOrder buildOrder =  new BuildOrder(buildId, projectId, projectLabel,  buildRequestSet);
        
        return buildOrder;

    }

}
