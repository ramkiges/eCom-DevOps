package com.wsgc.ecommerce.buildsystem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;
import com.wsgc.ecommerce.buildsystem.util.SvnInfo;
import com.wsgc.ecommerce.buildsystem.util.SvnUtil;

/**
 * Rather important class to the build system that combines the static definition of a source extract
 * with the users revision and branch specification for a <i><b>concrete extract definition</b></i>.<br> 
 * There are two very different methods to get a {@link ResolvedSvnExtract}. Definition
 * and reification data can be passed through {@link #create(SvnExtractDefinition, SvnConcreteExtractDefinition)}
 * and a {@link ResolvedSvnExtract} will be built after a lot of sanity checking and a normalization process 
 * to find the effective revision via svn commands. If the branch starts after the last real file change of the source collection, 
 * the effective revision is the first revision of your branch. This is slightly ineffective but plays well with other sanity
 * checking. The other way to get a {@link ResolvedSvnExtract} is with 
 * {@link #init(String, String, String, String, String, String, String)} which doesn't do anything but return a type with your trusted
 * state information. 
 * DEBATABLE If the {@link SvnExtractSource} code was designed differently, 
 * {@link #init(String, String, String, String, String, String, String)} could be removed.  
 * 
 * @author chunt
 * @version $Id$ 
 */
public final class ResolvedSvnExtractFactory {
    private static Logger logger = LoggerFactory.getLogger(ResolvedSvnExtractFactory.class);

    /**
     * Factory not meant for instantiation
     * @throws IllegalAccessException every time
     */
    private ResolvedSvnExtractFactory() throws IllegalAccessException {
        throw new IllegalAccessException("Utility class does not need instantiation");
    }

    /**
     * 
     * Use svn commands and the data in the arguments to create a new normalized {@link ResolvedSvnExtract}.
     * 
     * @param svnExtractDefinition the canonical static description of the source extract trunk location. 
     * @param svnConcreteExtractDefinition the reification data specifying actual branch and revision requested 
     * @return your {@link ResolvedSvnExtract}
     * @throws SourceException if our brilliant plan fails
     */
    public static ResolvedSvnExtract create(
            SvnExtractDefinition svnExtractDefinition,
            SvnConcreteExtractDefinition svnConcreteExtractDefinition) throws SourceException {

        String requestedRevision = null;
        String effectiveRevision = null;
        String branch = null;
        String uuid = null;
        BaseSvnExtract baseSvnExtract = null;
        String resolvedUrl = null;


        //TODO Unclear whether we should be checking for instanceof here or TYPE inspection.
        if (!(svnExtractDefinition.getExtractType().equals(SvnExtractDefinition.ENTITY_TYPE_ID))) {
            throw new IllegalArgumentException("SvnExtractDefinition must be of type: '" 
                    + SvnExtractDefinition.ENTITY_TYPE_ID + "'\nSvnExtractDefinition:" + svnExtractDefinition);
        }

        if (svnConcreteExtractDefinition != null 
                && !svnConcreteExtractDefinition.getType().equals(SvnConcreteExtractDefinition.TYPE)) {
            throw new IllegalArgumentException("ConcreteExtractDefinition must be of type: '" 
                    + SvnConcreteExtractDefinition.TYPE + "'\n"
                    + "ConcreteExtractDefinition:" + svnConcreteExtractDefinition);
        }

        uuid = svnExtractDefinition.getUuid();
        baseSvnExtract = new BaseSvnExtract(svnExtractDefinition.getUrl()); 

        if (svnConcreteExtractDefinition != null) { 
            branch = svnConcreteExtractDefinition.getBranch();

            requestedRevision = svnConcreteExtractDefinition.getRevision();

            if (!svnExtractDefinition.getName().equals(svnConcreteExtractDefinition.getName())) {
                throw new IllegalArgumentException("Can not resolve extracts with different names.");
            }

            if (!svnExtractDefinition.getUuid().equals(svnConcreteExtractDefinition.getUuid())) {
                //TODO better message
                throw new IllegalArgumentException("ExtractDefinition uuid:" + svnExtractDefinition.getUuid()
                        + " does not match ConcreteExtractDefinition uuid:" + svnConcreteExtractDefinition.getUuid());
            }

            if (baseSvnExtract.getURL().indexOf(ExtractDefinition.TRUNK_MARKER) 
                    != baseSvnExtract.getURL().lastIndexOf(ExtractDefinition.TRUNK_MARKER)) {
                throw new SourceException("Can't resolve branch url: Multiple instances of '" 
                        + ExtractDefinition.TRUNK_MARKER + "' in base url:" + baseSvnExtract); 
            }

            String trunkBranchOrTag = null;
            if (branch.equals(ExtractDefinition.TRUNK_MARKER)) {
                // Its positively on the trunk
                trunkBranchOrTag = branch;
            } else if (branch.toLowerCase().startsWith(ExtractDefinition.TAG_BANCH_PREFIX)) {
                // No, it clearly a tag!  (well,....case insensitive). 
                String[] fields = branch.toLowerCase().split(ExtractDefinition.TAG_BANCH_PREFIX);
                if (fields.length != 2) { 
                    throw new SourceException("Unexpected number of fields in presumed 'tags' specification. Expecting 2, found " 
                            + fields.length + " in '"
                            + branch + "' from concreteExtracetDefinition:" + svnConcreteExtractDefinition);  
                }
                trunkBranchOrTag =  (ExtractDefinition.TAGS_MARKER + "/" + fields[1]);                
            } else {
                // Whatever...., we _assume_ you are talking about a branch at this point.    
                trunkBranchOrTag =  ExtractDefinition.BRANCHES_MARKER + "/" + branch;
            }
            // replace the "trunk" string always found in the base url with either the correct branch or tag replacement from the request reification data.
            resolvedUrl = baseSvnExtract.getURL().replaceFirst(ExtractDefinition.TRUNK_MARKER, trunkBranchOrTag);

        } else {
            requestedRevision = ExtractDefinition.HEAD_REVISION_MARKER;
            resolvedUrl = baseSvnExtract.getURL();
        }

        /** TODO here is the first choice as to how to abstract SVN type 'effective revision' concept. */
        SvnInfo svnInfo = SvnUtil.getSvnInfoForURL(resolvedUrl, requestedRevision, uuid);

        /* svn info results for a URL should not have a schedule entry. */
        if (svnInfo.getSchedule() != null) {
            throw new SourceException("Unexpected 'schedule' value in svnInfo " + svnInfo);
        }

        effectiveRevision = svnInfo.getLastChangedRev();

        if (!branch.equals(ExtractDefinition.TRUNK_MARKER)) {
            
            long effectiveRevisionLong = Long.parseLong(effectiveRevision);
            
            /* If we are on a branch or tag */
            String branchStart = SvnUtil.getSvnBranchFirstRevison(resolvedUrl);

            long branchStartLong = Long.parseLong(branchStart);
            /* And the effective revision is before our branch creation */
            if (effectiveRevisionLong < branchStartLong) {
                /* then bump the effective revision to branch start 
                 * so when we later verify the results of the checkout/switch we don't also
                 * end up out of our desired branch
                 */
                logger.debug("Bumping effective revision from {}, to branch start at {}",
                        effectiveRevision, branchStart);
                effectiveRevision = branchStart;
            }

        }
        
        
        return new ResolvedSvnExtract(svnExtractDefinition.getName(), baseSvnExtract, effectiveRevision, resolvedUrl, uuid, branch, requestedRevision);
    }

    /**
     * Whip up a {@link ResolvedSvnExtract} based on this state information and the constructor
     * with out any sanity checking attempted. 
     * 
     * DEBATABLE This is really not a resolved extract then unless its been resolved before. 
     * 
     * @see {@link ResolvedSvnExtract#ResolvedSvnExtract(String, BaseSvnExtract, String, String, String, String, String)} ,
     * 
     * @param name the name 
     * @param resolvedUrl the resolved url which in this case will not be validated 
     * @param uuid the UUID of the repo the url comes from
     * @param effectiveRevision the effective revision, also not vetted
     * @param baseExtract the base extract (trunk version of this url)
     * @param branch the requested branch off the trunk (but could also just BE truck)
     * @param requestedRevision the requested revision ... oddly mock data here since its not used to determine effective revision this time.
     * @return your {@link ResolvedSvnExtract} with the provided characteristics
     */
    public static ResolvedSvnExtract init(String name, String resolvedUrl, String uuid ,
            String effectiveRevision, String baseExtract, String branch, String requestedRevision) {

        return new ResolvedSvnExtract(name, new BaseSvnExtract(baseExtract), effectiveRevision, resolvedUrl, uuid, branch, requestedRevision);
    }



}
