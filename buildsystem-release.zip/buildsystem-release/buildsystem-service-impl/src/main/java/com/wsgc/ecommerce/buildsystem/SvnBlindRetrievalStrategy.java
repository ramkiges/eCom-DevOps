package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/**
 * First useful retrieval strategy. Makes no attempt to reuse sources in any way. Used as a baseline in development to gauge the value of
 * other optimizations should they be found to be needed. 
 * 
 * 
 * @author chunt
 * @version $Id$
 * 
 */
public class SvnBlindRetrievalStrategy implements SourceRetrievalStrategy, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    protected  String sourcePath;
    
    /**
     * Copy constructor. Useful for derived classes to accept this as a base
     * @param svnBlindRetrievalStrategy the {@link SvnBlindRetrievalStrategy} to use as the source of the copy
     */
    public SvnBlindRetrievalStrategy(SvnBlindRetrievalStrategy svnBlindRetrievalStrategy) {
        setNumSourceChannels(svnBlindRetrievalStrategy.getNumSourceChannels());
        setSourcePath(svnBlindRetrievalStrategy.getSourcePath());
    }


    /**
     * Default constructor
     */
    public SvnBlindRetrievalStrategy() {
        // Nothing, but must be here.
    }


    /**
     * @return the sourcePath
     */
    public String getSourcePath() {
        return sourcePath;
    }


    /**
     * @param sourcePath the sourcePath to set
     */
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }


    protected int numSourceChannels;
    protected SvnExtractSource[] svnExtractSources;
    private static final String CHANNEL_MARKER =   "source_";
    protected static int sourceIndex;

    @Override
    public void afterPropertiesSet() throws Exception {
        checkFields();
    }

   
    /**
     * @throws SourceException 
     * 
     */
    private void checkFields() throws SourceException {
        if (sourcePath == null && numSourceChannels > 0) {
            throw new SourceException("Initialization not complete." + toString());
        }
    }

    /** {@inheritDoc} 
     * 
     * TODO: remove SuppressWarnings("rawtypes")
     * */
    @Override
    public SvnRetrievalAction getSourceRetrievalAction(
            @SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract, File targetDirectory) {
        SvnRetrievalAction svnRetrievalAction = null;
        synchronized (this) {
            svnRetrievalAction = 
                    new SvnRetrievalAction(svnExtractSources[sourceIndex], 
                            (ResolvedSvnExtract) resolvedExtract, targetDirectory);

            logger.debug("BLIND returning source at index:{}", sourceIndex);
            ++sourceIndex;
            if (sourceIndex == svnExtractSources.length) {
                sourceIndex = 0;
            }

        }
        return svnRetrievalAction;
    }
    
//    @Override
//    public void init() throws SourceException {
//        logger.info("Initializing " + getClass().getName());
//        checkFields();
//        svnExtractSources = new SvnExtractSource[numSourceChannels];
//        sourceIndex = 0;
//        
//        //TODO remove we need a null state denoting 'new' (lazy init)
//        ResolvedSvnExtract stubInitialState = ResolvedSvnExtractFactory.create("misc",
//                //"https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
//                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
//                "4d9f3204-700e-0410-9f00-95bf6548d55c",
//                "165211", //This is the head of that branch. 
//                /* "HEAD" that will fail validation later */
//                /*"156000", doesn't exist in branch  be careful asking for nonexistent revisions on branches, 
//                        it won't pass validation later */ 
//                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/",
//                "trunk",
//                "HEAD");
//
//        for (int i = 0; i < numSourceChannels; i++) {
//            svnExtractSources[i] = new SvnExtractSource(sourcePath + File.separatorChar + CHANNEL_MARKER + i, stubInitialState, null);
//
//        }
//
//    }
    
    /** {@inheritDoc} */
    @Override
    public void init() throws SourceException {
        /*
         * A) Nobody cares B) This line number appears in the logger message as coming from the derived class... which
         * if you are lucky, doesn't have code at that line number so you will notice when that happens.
         */
        //logger.info("Initializing " + getClass().getName());
        checkFields();
        svnExtractSources = new SvnExtractSource[numSourceChannels];
        sourceIndex = 0;

        //TODO remove we need a null state denoting 'new' (lazy init), put as parameter for init(defaultStateResolvedURL) call.
        final ResolvedSvnExtract stubInitialState = ResolvedSvnExtractFactory.init("misc",
                //"https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c",
                "165211", //This is the head of that branch. 
                /* "HEAD" that will fail validation later */
                /*"156000", doesn't exist in branch  be careful asking for nonexistent revisions on branches, 
                        it won't pass validation later */ 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/",
                "trunk",
                "HEAD");

        //        for (int i = 0; i < numSourceChannels; i++) {
        //            svnExtractSources[i] = new SvnExtractSource(sourcePath + File.separatorChar + CHANNEL_MARKER + i, stubInitialState, null);
        //
        //        }

        ExecutorService executorService = Executors.newFixedThreadPool(numSourceChannels);

        CompletionService<SvnExtractSource> sourceInitCompletionService = 
                new ExecutorCompletionService<SvnExtractSource>(executorService);
        Set<Future<SvnExtractSource>> futures = new HashSet<Future<SvnExtractSource>>();

        //        for (SourceRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
        for (int i = 0; i < numSourceChannels; i++) {
            final int fi = i;

            //            final SourceRetrievalAction finalSourceRetrievalAction = svnSourceRetrievalAction; 
            //            // keep track of the futures that get created so we can cancel them if necessary
            futures.add(sourceInitCompletionService.submit(new Callable<SvnExtractSource>() {
                @Override
                public SvnExtractSource call() throws Exception {
                    return new SvnExtractSource(sourcePath + File.separatorChar + CHANNEL_MARKER + fi, stubInitialState);
                }
            }));
        }
        Future<SvnExtractSource> completedFuture;
        List<SvnExtractSource> newSources = new ArrayList<SvnExtractSource>(numSourceChannels);
        SvnExtractSource newSource;
        try {

            while (futures.size() > 0) {
                // block until a callable completes
                completedFuture = sourceInitCompletionService.take();
                futures.remove(completedFuture);
                newSource = completedFuture.get();
                newSources.add(newSource);
            }
            //paranoid
            if (newSources.size() != numSourceChannels) {
                throw new SourceException("Number of results should match number of init attempts. results size:"
                        + newSources.size() + " source channels to init:" + numSourceChannels); 
            }
            // attempt to keep things in the expected order but its not really important, TODO use List<source> instead of source[]?
            for (SvnExtractSource source : newSources) {
                String indexString = source.getWorkingBase().split(CHANNEL_MARKER)[1];
                int index = Integer.parseInt(indexString);
                svnExtractSources[index] = source;  
            }
            
            // final sanity check
            for (int i = 0; i < numSourceChannels; i++) {
                if (svnExtractSources[i] == null) {
                    throw new SourceException("Source not initialized at index:" + i); 
                }
            }
                

        } catch (Exception e) {
            //Shutdown anyone we can. Bad idea.
            //            for (Future<SourceRetrievalDetails> f : futures) {
            //                f.cancel(true);
            //            }
            /* We catch and wrap all Exceptions with SourceException */
            throw new SourceException(e);
        } finally {
            executorService.shutdown();
            logger.trace("source init complete shutting down executor");
        }
    }
    
    /** {@inheritDoc} */
    @Override
    public void setNumSourceChannels(int numSourceChannels) {
        this.numSourceChannels = numSourceChannels;
    }



    /** {@inheritDoc} */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SvnBlindRetrievalStrategy [sourcePath=")
                .append(sourcePath).append(", numSourceChannels=")
                .append(numSourceChannels).append(", svnExtractSources=")
                .append(Arrays.toString(svnExtractSources)).append("]");
        return builder.toString();
    }

 
    /** {@inheritDoc} */
    @Override
    public int getNumSourceChannels() {
        return numSourceChannels;
    }
}
