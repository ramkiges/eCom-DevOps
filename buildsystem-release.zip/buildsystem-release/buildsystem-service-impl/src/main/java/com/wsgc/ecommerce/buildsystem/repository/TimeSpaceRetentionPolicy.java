package com.wsgc.ecommerce.buildsystem.repository;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;


/**
 * A artifact repository management strategy based on limits specified for both disk space and age of artifacts.
 * All builds of a certain age are removed first. When disk space is still needed, the oldest build is also removed.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class TimeSpaceRetentionPolicy implements RetentionPolicy, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final long BYTES_PER_MEGABYTE = 1048576;

    // Completely arbitrary limits so far.
    //Low limit is one minute 
    private static final long AGE_LIMIT_LOW_MS = TimeUnit.MILLISECONDS.convert(1L, TimeUnit.MINUTES);
    //Upper limit is one year (for vague definitions of a 'year').
    private static final long AGE_LIMIT_HIGH_MS = TimeUnit.MILLISECONDS.convert(365L, TimeUnit.DAYS);
    private long ageLimitMs;
    private long spaceLimitMb;

    /** {@inheritDoc}  */
    @Override
    public void afterPropertiesSet() throws Exception {
        if ((ageLimitMs == 0) && (spaceLimitMb == 0)) {
            throw new BuildServiceException("Properties not set." + toString());           
        }       
    }

    /** {@inheritDoc}  */
    @Override
    public Set<BuildReference> getRemovalList(ArtifactRepository repo) {
        long bytesToRemove = repo.getSizeBytes() - (spaceLimitMb * BYTES_PER_MEGABYTE);

        Set<BuildReference> removalList = new HashSet<BuildReference>();

        for (Long timeStamp : repo.getBuildHistoryMap().keySet()) {
            long now =  System.currentTimeMillis();
            if ((timeStamp + ageLimitMs) > now &&  (bytesToRemove <= 0)) {
                /*  If we are now starting to look at a builds too young to retire and we have already saved all the bytes needed,
                 *  then we have saved enough room. Stop checking over all the whole collection.
                 */
                break;
            }

            // If the build is too old to let stay around, or we need more space, add some builds to the retirement list.
            for (BuildReference buildReference : repo.getBuildHistoryMap().get(timeStamp)) {
                if (logger.isDebugEnabled()) {
                    String reason = null;
                    long age = now - timeStamp; 
                    reason =  (age > ageLimitMs) ? "The build reference is " + timeUnitFormat(age - ageLimitMs) + " beyond its age limit." 
                            : "The repository needs to free " + bytesToRemove + " more bytes";
                    logger.debug("Marking reference for removal. Reference:{} Reason:{}", buildReference, reason);
                }

                // if the builds in this set are old enough or we need room still, add them one at a time to the 'kick the bucket list'
                removalList.add(buildReference);
                bytesToRemove -= FileUtil.folderSize(buildReference.getBuildLocation());
                if (timeStamp + ageLimitMs > now &&  (bytesToRemove <= 0)) {
                    /*
                     *  if we have saved enough room, stop checking index sets, break out of this loop
                     *  and since the criteria is the same, we will next break out of the outer loop too.
                     */
                    break;
                }
            }
        }

        return Collections.unmodifiableSet(removalList);
    }

    /**
     * @param ageLimitMs the ageLimitMs to set
     */
    public void setAgeLimitMs(long ageLimitMs) {
        this.ageLimitMs = ageLimitMs;
    }

    /**
     * @param spaceLimitBytesMbs max size of repo in Megabytes.
     */
    public void setSpaceLimitBytes(long spaceLimitBytesMbs) {
        this.spaceLimitMb = spaceLimitBytesMbs;
    }

    /**
     * Set age limit via a String consisting of a number followed by a letter to denote units.
     * Valid Examples, 60D for sixty days, 12H for twelve hours or 12345M for a strange number of
     * minutes.
     *  
     * Surely there is a standard time format to use other than this?
     * 
     * @param ageLimitString the maximum age of a build to retain as expressed by a number of days hours or minutes 
     */
    public void setAgeLimitString(String ageLimitString) {

        long nextAgeLimitMs = 0;
        String newAgeLimitString = ageLimitString.toUpperCase(); 

        if (!newAgeLimitString.matches("\\d{1,3}[D|H|M]")) {
            throw new IllegalArgumentException(
                    "Unknown time format, expecting string to be 1-3 digits and 1 letter either: [D]ays, [H]ours [M]inutes."
                            + " String provided was: " + newAgeLimitString);
        }

        long scale = 0;

        if (newAgeLimitString.endsWith("M")) {
            scale = TimeUnit.MILLISECONDS.convert(1L, TimeUnit.MINUTES);
        } else if (newAgeLimitString.endsWith("H")) {
            scale = TimeUnit.MILLISECONDS.convert(1L, TimeUnit.HOURS);
        } else if (newAgeLimitString.endsWith("D")) {
            scale = TimeUnit.MILLISECONDS.convert(1L, TimeUnit.DAYS);
        } else {
            throw new RuntimeException("Unknown parsing error, time format string:" + ageLimitString);
        }

        nextAgeLimitMs = Long.parseLong(newAgeLimitString.substring(0, newAgeLimitString.length() - 1))
                * scale;


        if ((nextAgeLimitMs < AGE_LIMIT_LOW_MS) || (nextAgeLimitMs > AGE_LIMIT_HIGH_MS)) {
            throw new IllegalArgumentException(
                    "Parsed time value out of range. Value must be more than " + AGE_LIMIT_LOW_MS + " and less than " 
                            + AGE_LIMIT_HIGH_MS + " parsed value ended up as: " + nextAgeLimitMs);
        }

        ageLimitMs = nextAgeLimitMs;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TimeSpaceRetentionPolicy [ageLimitMs=")
        .append(ageLimitMs).append(", spaceLimitMB=")
        .append(spaceLimitMb).append("]");
        return builder.toString();
    }

    /**
     * Convenience method to turn a nasty time variable holding milliseconds
     * in to a pretty printing string converting that in to minutes and seconds..
     * 
     * @param l the long to convert
     * @return the formatted String
     */
    private String timeUnitFormat(long l) {

        logger.debug("Converting from {} ms to formatted time string.", l);
       
        long wholeMins      =  TimeUnit.MILLISECONDS.toMinutes(l);
        long wholeSecs      =  TimeUnit.MILLISECONDS.toSeconds(l - TimeUnit.MINUTES.toMillis(wholeMins));
        long remainingMs    = l - TimeUnit.MINUTES.toMillis(wholeMins) - TimeUnit.SECONDS.toMillis(wholeSecs);

        return String.format("%d min, %d sec, %d ms", wholeMins, wholeSecs, remainingMs);  
    }
};