package com.wsgc.ecommerce.buildsystem.repository;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.StandardBuildService;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;

/**
 * 
 * Immutable view on a build. 
 * 
 * @version $Id$ 
 */
public class SimpleArtifactRepositoryView implements ArtifactRepositoryView, Comparable<SimpleArtifactRepositoryView> { 
    private SimpleBuildReference simpleBuildReference;

    /**
     * StandardBuildService, SimpleBuildJobStatus and SimpleArtifactRepositoryView each have their own formatter that is
     * identical to this one and those DO write out formatted strings.
     * 
     * DEBATABLE: Rework classes/interfaces to share a single date formatter?
     */
    // If you are going to share it, all use must be synchronized
    private static DateFormat dateFormatter = StandardBuildService.getDateFormatter();
//    static {
//        dateFormatter.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US)); 
//    }
    
    /**
     * The only constructor, builds a view object from a {@link BuildReference}.
     * @param buildReference the thing being looked at 
     * @throws ArtifiactRepostitoryException if things go badly (IO, errors most likely, zombie attacks less likely)
     */
    public SimpleArtifactRepositoryView(BuildReference buildReference) throws ArtifiactRepostitoryException {
        if (buildReference == null) {
            throw new IllegalArgumentException("Can not construct " + getClass().getName() + " with null reference.");
        }
        simpleBuildReference = new SimpleBuildReference(buildReference);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(SimpleArtifactRepositoryView o) {
        return simpleBuildReference.compareTo(o.simpleBuildReference);
    }

    /** {@inheritDoc} */
    @Override
    public String getBuildId() {
        return simpleBuildReference.getBuildId();
    }

    /** {@inheritDoc} */
    @Override
    public BuildOrder getBuildOrder() throws ArtifiactRepostitoryException {
        return simpleBuildReference.getBuildOrder(); 

    }

    /**
     * Use sparingly, causes a lazy init.
     * {@inheritDoc}
     */
    @Override
    public String getBuildOrderJSON() throws ArtifiactRepostitoryException {
        return (simpleBuildReference.getBuildOrderJson() != null) ? simpleBuildReference.getBuildOrderJson() : "unloaded";
    }

    /** {@inheritDoc} */
    @Override
    public String getBuildStatus() {
        return simpleBuildReference.getStatusString();
    }

    @Override
    public Long getCompletionTimeStamp() {
        return simpleBuildReference.getCompletionTimestamp();
    }

    /** {@inheritDoc} */
    @Override
    public String getEnd() {
        String now = null;
        synchronized (dateFormatter) {
            now = dateFormatter.format(new Date(simpleBuildReference.getCompletionTimestamp()));
        }
        return now;
    }
    
    /** {@inheritDoc} */
    @Override
    public File getBuildLocation() {
        return simpleBuildReference.getBuildLocation();
    }
        
    /** {@inheritDoc} */
    @Override
    public File getBuildLog() {
        return simpleBuildReference.getLog();
    }
    
    /** {@inheritDoc} */
    @Override
    public File getManifest() {
        return simpleBuildReference.getManifest();
    }
    
    /** {@inheritDoc} */
    @Override
    public String getManifestAsString() throws ArtifiactRepostitoryException {
        return getFileAsString(getManifest());
    }
     
    /**
     * Perhaps misguided helper method to read presumable small files as a single {@link String}.
     *  
     * @param file the file to read.
     * @return a {@link String} built from the files contents, assuming you have enough memory.
     * @throws ArtifiactRepostitoryException for any caught errors
     */
    private String getFileAsString(File file) throws ArtifiactRepostitoryException {
        try {
            return (file.exists() ? FileUtil.readAsString(file) : "unloaded");
        } catch (IOException ioe) {
            throw new ArtifiactRepostitoryException("Unable to read Manifest. Reason:" + ioe, ioe);
        }       
    }

    /** {@inheritDoc} */
    @Override
    public String getUser() {
        return simpleBuildReference.getUser();
    }

    /** {@inheritDoc} */
    @Override
    public String getBuildLogAsString() throws ArtifiactRepostitoryException {
        return getFileAsString(getBuildLog());
    }

    /** {@inheritDoc} */
    @Override
    public String getErrorLogAsString() throws ArtifiactRepostitoryException {
        return getFileAsString(getErrorLog());
    }

    /** {@inheritDoc} */
    @Override
    public File getErrorLog() {
        return simpleBuildReference.getErrorLog();
    }

}


