package com.wsgc.ecommerce.buildsystem;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.BuildStatusException;


/**
 * Implements a lightweight {@link BuildMonitor}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class StandardBuildMonitor implements BuildMonitor {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private Map<String, StandardBuildJobStatus> buildJobStatusMap;

    /**
     * Default constructor, initializes the buildJobStatusMap.
     */
    public StandardBuildMonitor() {
        buildJobStatusMap = new HashMap<String, StandardBuildJobStatus>();
    }

    /**
     * {@inheritDoc}
     * 
     * Needs to be synchronized,
     * @see com.wsgc.ecommerce.buildsystem.webapp.BuildController.buildStatus(String, HttpServletResponse) for more
     */
    @Override
    public synchronized BuildJobStatus getBuildJobStatus(String buildId) throws BuildStatusException {
        BuildJobStatus buildJobStatus = null;
   
        if (!buildJobStatusMap.containsKey(buildId)) {
            return null;
        }

        buildJobStatus = buildJobStatusMap.get(buildId);
        return buildJobStatus;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void setBuildJobStatus(String buildId, JobStatus jobStatus) throws BuildStatusException {
        setBuildJobStatus(buildId, jobStatus, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void setBuildJobStatus(String buildId, JobStatus jobStatus, String message) throws BuildStatusException {
        if (!buildJobStatusMap.containsKey(buildId)) {
            throw new IllegalArgumentException("Build not found in build job status map. Build Id:" + buildId);
        } 
        buildJobStatusMap.get(buildId).setStatus(jobStatus);
        if (message != null) {
            buildJobStatusMap.get(buildId).setMessage(message);
        }
        logger.debug("Build job status set. buildId:{} BuildJobStatus: ", buildId, jobStatus);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized Set<String> getBuildIds() {
        return Collections.unmodifiableSet(new HashSet<String>(buildJobStatusMap.keySet()));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized int getNumberOfMonitoredBuilds() {
        return buildJobStatusMap.size();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void purge() {
    
        for (Iterator<Map.Entry<String, StandardBuildJobStatus>> i = buildJobStatusMap.entrySet().iterator(); i.hasNext(); )  
        {  
            Map.Entry<String, StandardBuildJobStatus> entry = i.next();  
            if (entry.getValue().getStatus().equals(JobStatus.SUCCEEDED) 
                    || entry.getValue().getStatus().equals(JobStatus.FAILED)) {
                logger.debug("Purging build id {} from build monitor status map.", entry.getKey());  
                i.remove();  
            }  
        }        
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void setBuildRequestStatus(BuildRequest buildRequest,
            BuildRequestStatus buildRequestStatus) throws BuildStatusException {  
        String buildId = buildRequest.getBuildId();
        String buildRequestId = buildRequest.getId();

        if (!buildJobStatusMap.containsKey(buildId)) {
            throw new IllegalArgumentException("Build id not found in build job status map. BuildId:" + buildId);
        }
        buildJobStatusMap.get(buildId).setBuildRequestStatus(buildRequestId, buildRequestStatus);
        if (logger.isDebugEnabled()) {
            logger.debug("BuildRequestStatus set.  BuildId:" + buildId + " buildRequestId:" + buildRequestId 
                    + " BuildRequestStatus:" + buildRequestStatus);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void setBuildRequestStatusFailed(BuildRequest buildRequest) {  
        String buildId = buildRequest.getBuildId();
        String buildRequestId = buildRequest.getId();

        if (!buildJobStatusMap.containsKey(buildId)) {
            throw new IllegalArgumentException("Build id not found in build job status map. BuildId:" + buildId);
        }
        buildJobStatusMap.get(buildId).setBuildRequestStatusFailed(buildRequestId);
        if (logger.isDebugEnabled()) {
            logger.debug("BuildRequestStatus set.  BuildId:" + buildId + " buildRequestId:" + buildRequestId 
                    + " BuildRequestStatus:" + BuildRequestStatus.FAILED);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
//    public void createBuildJobStatus(String buildId) {
//        logger.debug("Build added to status map. build id:{}", buildId);
//        buildJobStatusMap.put(buildId, new StandardBuildJobStatus());
//    }
//
    public void createBuildJobStatus(BuildInfo buildInfo) {
        logger.debug("Build added to status map. build id: {}", buildInfo.getBuildId());
        buildJobStatusMap.put(buildInfo.getBuildId(), new StandardBuildJobStatus(buildInfo));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setBuildJobStatusMessage(String buildId, String message) {
        if (!buildJobStatusMap.containsKey(buildId)) {
            throw new IllegalArgumentException("Build not found in build job status map. Build Id:" + buildId);
        }           
        buildJobStatusMap.get(buildId).setMessage(message);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setBuildJobStatusFailed(String buildId) {
        setBuildJobStatusFailed(buildId, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setBuildJobStatusFailed(String buildId, String message) {
        if (!buildJobStatusMap.containsKey(buildId)) {
            throw new IllegalArgumentException("Build not found in build job status map. Build Id:" + buildId);
        } 
        logger.debug("Setting status FAILED, build ID:{} message '{}'", buildId, message);
        buildJobStatusMap.get(buildId).setStatusFailed();
        if (message != null) {
            buildJobStatusMap.get(buildId).setMessage(message);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized Map<String, BuildRequestStatus> getBuildRequestStatusMap(String buildId) {
        return buildJobStatusMap.get(buildId).getBuildRequestStatusMap();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized Map<String, ? extends BuildJobStatus> getFilteredBuildJobStatusMap(String buildIdFilter, String projectFilter, String userFilter) {
                
        Map<String, StandardBuildJobStatus> filteredBuildJobStatusMap = new HashMap<String, StandardBuildJobStatus>();
        
        // For all build ids in the monitor collection
        for (String buildId : buildJobStatusMap.keySet()) {
            StandardBuildJobStatus buildJobStatus = buildJobStatusMap.get(buildId);
            
            // if the build is already finished, skip it.
            if (buildJobStatus.getStatus().equals(BuildRequestStatus.SUCCEEDED) 
                    || buildJobStatus.getStatus().equals(BuildRequestStatus.FAILED)) {
                continue;
            }
            
            // if the build is in the filter list keep it
            if ((buildIdFilter != null) || (projectFilter != null) || (userFilter != null)) {

                boolean filterByBuildId = (buildIdFilter != null)   && !buildIdFilter.isEmpty();
                boolean filterByProject = (projectFilter != null)   && !projectFilter.isEmpty();
                boolean filterByUser    = (userFilter != null)      && !userFilter.isEmpty(); 

                boolean keep = true;

                /* partial match ok here */
                if (keep && filterByBuildId) {
                    keep = buildId.contains(buildIdFilter);
                }
                
                /* these filters now come from a populated list and we want exact matches */
                if (keep && filterByProject) {
                    //keep = buildJobStatus.getProjectLabel().contains(projectFilter);  
                    keep = buildJobStatus.getProjectLabel().equals(projectFilter);  
                }

                /* these filters now come from a populated list and we want exact matches */
                if (keep && filterByUser) {
                    //keep = buildJobStatus.getUser().contains(userFilter);
                    keep = buildJobStatus.getUser().equals(userFilter);
                }   

                // If we should keep it, create 
                if (keep) {
                    filteredBuildJobStatusMap.put(buildId, buildJobStatus);
                }

            } else {
                filteredBuildJobStatusMap.put(buildId, buildJobStatus);
            }
        }
        
        return filteredBuildJobStatusMap;
    }
    
}
