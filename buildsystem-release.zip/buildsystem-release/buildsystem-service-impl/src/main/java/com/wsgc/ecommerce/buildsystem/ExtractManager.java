/**
 * @author chunt
 * @version $Id$
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.List;

import com.wsgc.ecommerce.buildsystem.exception.ExtractException;

/**
 * Responsible for interpreting a {@link BuildRequest} source requests and delivering those files
 * to a working directory. 
 * 
 * @author chunt
 * @version $Id$ 
 */
public interface ExtractManager {
    /**
     * Interprets the {@link BuildRequest}, looking for what source files are needed and where on the file system they
     * should be moved to, and returns the answer as a {@link ExtractTargetMapping}.
     * 
     * @param buildPlanWorkingExtractsDir your extract working directory
     * @param buildRequest a {@link BuildRequest} with presumably some concrete extract definitions
     * @return the list of generated {@link ExtractTargetMapping} useful for performing extracts later
     */
    List<ExtractTargetMapping> getExtractTargets(File buildPlanWorkingExtractsDir,  BuildRequest buildRequest);

    /**
     * Requests that the specified extract be performed, and then the result of the extract be placed into a target
     * directory (managed by the caller). The submitted task may fail with an ExtractException
     * in the event of difficulties performing the extract process.
     *
     * @param resolvedExtractTargets {@link ExtractTargetMapping} that define the sources needed and the locations they should be delivered to
     * @return a list of {@linkplain SourceRetrievalDetails} containing the saga of the journey 
     * @throws ExtractException for errors in the extraction process 
     */
    List<SourceRetrievalDetails> performExtracts(
            List<ExtractTargetMapping> resolvedExtractTargets) throws ExtractException;
    
}