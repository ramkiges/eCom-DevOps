package com.wsgc.ecommerce.buildsystem;

/**

 * @author chunt
 * @version $Id$
 * @deprecated was useful during early development but is almost completely forgotten now and 
 * unless some new reason for it arrives soon from something we learn after real use, it could be deleted.
 */
@Deprecated
public class BuildSystemConfig {

    private String projectLibraryPath;
    private String sourcePath;
    private String sourceChannels;
    private String workingRootDir;
    private String commandPath;
    private String artifactRepositoryHome;
    private String serverName;
    private String smtpHost;


    /**
     * @return the projectLibraryPath
     */
    public String getProjectLibraryPath() {
        return projectLibraryPath;
    }


    /**
     * @param projectLibraryPath the projectLibraryPath to set
     */
    public void setProjectLibraryPath(String projectLibraryPath) {
        this.projectLibraryPath = projectLibraryPath;
    }


    /**
     * @return the sourcePath
     */
    public String getSourcePath() {
        return sourcePath;
    }


    /**
     * @param sourcePath the sourcePath to set
     */
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }


    /**
     * @return the sourceChannels
     */
    public String getSourceChannels() {
        return sourceChannels;
    }


    /**
     * @param sourceChannels the sourceChannels to set
     */
    public void setSourceChannels(String sourceChannels) {
        this.sourceChannels = sourceChannels;
    }


    /**
     * @return the workingRootDir
     */
    public String getWorkingRootDir() {
        return workingRootDir;
    }


    /**
     * @param workingRootDir the workingRootDir to set
     */
    public void setWorkingRootDir(String workingRootDir) {
        this.workingRootDir = workingRootDir;
    }


    /**
     * @return the commandPath
     */
    public String getCommandPath() {
        return commandPath;
    }


    /**
     * @param commandPath the commandPath to set
     */
    public void setCommandPath(String commandPath) {
        this.commandPath = commandPath;
    }


    /**
     * @return the artifactRepositoryHome
     */
    public String getArtifactRepositoryHome() {
        return artifactRepositoryHome;
    }


    /**
     * @param artifactRepositoryHome the artifactRepositoryHome to set
     */
    public void setArtifactRepositoryHome(String artifactRepositoryHome) {
        this.artifactRepositoryHome = artifactRepositoryHome;
    }

    /**
     * @param serverName server name to set
     */
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }
    
    /**
     * @return server name
     */
    public String getServerName() {
        return serverName;
    }


    /**
     * @return the smtpHost
     */
    public String getSmtpHost() {
        return smtpHost;
    }


    /**
     * @param smtpHost the smtpHost to set
     */
    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }


}
