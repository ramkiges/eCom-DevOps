package com.wsgc.ecommerce.buildsystem;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.exception.ExtractException;

/**
 * 
 * This is a confused <now less> class that wants to act as if it implements FutureTask directly
 * Experimental, expected to be used with {@link SvnPredictiveSourceRetrievalStrategy}
 * 
 * TODO: not done
 * 
 * @author chunt
 * @version $Id$
 */
public class SvnRunnableRetrievalAction extends Thread implements SourceRetrievalAction { ///implements Callable<SourceRetrievalDetails> { 
    private final Logger logger = LoggerFactory.getLogger(getClass());
    
    private SvnExtractSource svnExtractSource;
    private ResolvedSvnExtract resolvedSvnExtract;
    private File targetDirectory;
    private SourceRetrievalDetails sourceRetrievalDetails;
    //private Future<SourceRetrievalDetails> futureSourceRetrievalDetails;

    private boolean started;
    
    /**
     * Creates a {@link SvnRunnableRetrievalAction} from {@link SvnExtractSource} and {@link ResolvedSvnExtract}
     * 
     * @param svnExtractSource the source
     * @param resolvedSvnExtract the concrete extract to obtain
     * @param targetDirectory the directory where to put the extract
     */
    public SvnRunnableRetrievalAction(SvnExtractSource svnExtractSource, ResolvedSvnExtract resolvedSvnExtract,
            File targetDirectory) {
        this.svnExtractSource = svnExtractSource;
        this.resolvedSvnExtract = resolvedSvnExtract;
        this.targetDirectory = targetDirectory;
    }

    @Override
//    public SourceRetrievalDetails call() throws Exception {
      public void run() {
        started = true;
        try {
            //block until someone sends a notify. Presumably this will the worker thread on svnExtractSource.
            logger.debug("Tying to enter sync(this) block to wait for notify from source worker thread.");
            synchronized (this) {
                logger.debug("Waiting for notify from Source worker thread.");
                wait();
                logger.debug("Got notify from Source worker thread.");
            }
            logger.debug("Beginning extract to " + targetDirectory.getAbsolutePath());
            sourceRetrievalDetails = svnExtractSource.performExtract(resolvedSvnExtract, targetDirectory);
        } catch (Exception e) {
            /* Could be a failed build detected via InterruptException or something local.
             * store the exception in the details.
             */
            sourceRetrievalDetails = new SourceRetrievalDetails(resolvedSvnExtract, targetDirectory);
            sourceRetrievalDetails.setLastException(e);
        }
    }

//    public synchronized Future<SourceRetrievalDetails> getFutureSourceRetrievalDetails() {
//        return futureSourceRetrievalDetails;
//    }
//
//    public synchronized void setFutureSourceRetrievalDetails(Future<SourceRetrievalDetails> sourceRetrievalDetails) {
//        this.futureSourceRetrievalDetails = sourceRetrievalDetails;
//    }

    /**
     * @return the resolvedSvnExtract
     */
    public ResolvedSvnExtract getResolvedSvnExtract() {
        return resolvedSvnExtract;
    }

    @Override
    public SourceRetrievalDetails getSourceRetrievalDetails() throws ExtractException {
        if (!started) {
            throw new ExtractException("Thread must be started for a call to get results to succeed");
                    
        }
        try {
//            for (SvnRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
                //We now wait for scheduled extract to finish
                logger.debug("waiting to join action thread. Action:" + this);
                // I don't think the this is necessary but it is illustrative.
                logger.debug("Current thread: " + Thread.currentThread() + " action thread " 
                + this + " isAlive():" + this.isAlive());
                this.join();
                logger.debug("leaving wait to join action thread. Action:" + this);
  //          }
        } catch (InterruptedException e) {
            logger.warn("Exception waiting for join with action thread", e);
            Thread.currentThread().interrupt();
            throw new ExtractException(e); 
        }
        return sourceRetrievalDetails;
    }   

}
