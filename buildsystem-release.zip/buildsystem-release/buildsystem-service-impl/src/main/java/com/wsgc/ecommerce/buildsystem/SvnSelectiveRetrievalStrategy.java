package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Source retrieval strategy that is one step above {@link SvnBlindRetrievalStrategy} and one step below 
 * {@link SvnPredictiveSourceRetrievalStrategy} in expected efficiency. This strategy tries to recognize and reuse 
 * sources that already have the requested extract.
 * 
 * @author chunt
 * @version $Id$ 
 */
public class SvnSelectiveRetrievalStrategy extends SvnBlindRetrievalStrategy {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    
    /**
     * Default constructor, the only use I can think of is that it allows spring config files without constructor
     * syntax.
     */
    public SvnSelectiveRetrievalStrategy() {
    }
   
    /**
     * Creates a selective retrieval from an existing base class object. This is used to facilitate a runtime change 
     * of retrieval strategies.
     * 
     * @param svnBlindRetrievalStrategy the SvnBlindRetrievalStrategy to base construction on.
     */
    public SvnSelectiveRetrievalStrategy(SvnBlindRetrievalStrategy svnBlindRetrievalStrategy) {
        super(svnBlindRetrievalStrategy);
    }

    @Override
    /*
     * TODO is it ResolvedExtract or ? extends something wild You have some casts to lose still here.
     * Then you can get rid of the rawtypes suppression here
     */
    public SvnRetrievalAction getSourceRetrievalAction(
            @SuppressWarnings("rawtypes") ResolvedExtract requestedExtract, File targetDirectory) {

        // TODO: This cast should go away once the hierarchy is done 
        BaseSvnExtract requestedBase = (BaseSvnExtract) requestedExtract.getBaseExtract();
        SvnRetrievalAction svnRetrievalAction = null;
        SvnExtractSource selectedSource = null;
        boolean cached = false;

        synchronized (this) {

            synchronized (SvnExtractSource.getDepthMutex()) {
                while (svnRetrievalAction == null) {
                    // look for perfect reuse, free and matches base.
                    logger.trace("SELECT CHECKING all sources. Request base: {}", requestedBase);
                    SvnExtractSource oldestFreeSource = null;
                    for (SvnExtractSource svnSource : svnExtractSources) {
                        if (svnSource.getRequestQueueDepth() == 0) {
                            logger.trace("SELECT FOUND FREE SOURCE:{} age:{}", svnSource, svnSource.getLastUsed());
                            if (oldestFreeSource == null || (svnSource.getLastUsed() < oldestFreeSource.getLastUsed())) {
                                oldestFreeSource = svnSource;
                                logger.trace("SELECT OLDEST free source updated. SOURCE:{}", oldestFreeSource);
                            }

                            //todo remove debugging messages
                            // plan A use the perfect match
                            if (svnSource.getCurrentState() != null) {
                                BaseSvnExtract sourceBase =  svnSource.getCurrentState().getBaseExtract();                                    
                               // logger.debug("SELECT considering sourceBase " + sourceBase + " requestBase " + requestedBase);
                                logger.trace("SELECT COMPARING source baseExtract:{}  request baseExtract:{}"
                                        , svnSource.getCurrentState().getBaseExtract(), requestedBase);
                                boolean perfectMatch = sourceBase.equals(requestedBase); 
                                
                                if (perfectMatch) {
                                    selectedSource = svnSource;
                                    logger.trace("SELECT FOUND MATCH, source base matches request. Ending search selected source:{}", selectedSource);
                                    cached = true;
                                    break;
                                } else {
                                    logger.trace("SELECT NO MATCH, source base does no match request.");
                                }
                            }
                        }
                    }
                    
                    // no perfect match found Ok...?
                    if (selectedSource == null) {
                        // plan B use the oldest free source                        
                        if (oldestFreeSource != null) {
                            selectedSource = oldestFreeSource;
                            logger.trace("SELECT FOUND OLDEST, no perfect match found, Using oldest free SOURCE:{} with current state:{}",
                                    selectedSource,  selectedSource.getCurrentState());
                        } else {
                            //if (selectedSource == null) {
                            //plan C, block until we can look again.
                            logger.trace("SELECT NONE FREE, no unused sources found at all.  Waiting.");
                            try {
                                SvnExtractSource.getDepthMutex().wait();
                            } catch (InterruptedException ie) {
                                // plan d, die and take as many with us as possible.
                      
                                //TODO may need to revisit that 'strategy'.
                                Thread.currentThread().interrupt();
                                throw new RuntimeException("Interrupted while waiting for free svn source. Cause:" + ie, ie);
                            }
                        }
                    } else {
                        // Somebody found a source to use.
                        svnRetrievalAction = new SvnRetrievalAction(selectedSource, (ResolvedSvnExtract) requestedExtract, targetDirectory);               
                        selectedSource.reserveOneExtractRequest(svnRetrievalAction);
                    }
                }
            }
            logger.debug("SELECT COMPLETE, Selected source:{} cached extract used={}",  selectedSource.toString(), cached);
            return svnRetrievalAction;
        }
    }


    /** 
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getClass().getName()).append(" [sourcePath=")
        .append(sourcePath).append(", numSourceChannels=")
        .append(numSourceChannels).append(", svnExtractSources=")
        .append(Arrays.toString(svnExtractSources)).append("]");
        return builder.toString();
    }
}
