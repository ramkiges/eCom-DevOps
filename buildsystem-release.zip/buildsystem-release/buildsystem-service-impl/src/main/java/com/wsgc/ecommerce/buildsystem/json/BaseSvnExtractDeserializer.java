package com.wsgc.ecommerce.buildsystem.json;
import static com.wsgc.ecommerce.buildsystem.Project.URL;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BaseSvnExtract;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;

/**
 * JSON deserializer implementation for {@link BaseSvnExtract}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class BaseSvnExtractDeserializer implements JsonObjectDeserializer<BaseSvnExtract> {
    private static final Class<BaseSvnExtract> JSON_DESERIALIZATION_TARGET = BaseSvnExtract.class;
    private final Logger log = LoggerFactory.getLogger(getClass());
    
    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(BaseSvnExtract.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @Override
    public BaseSvnExtract deserialize(String objectType, String instanceId, JsonObjectInputStream json) throws IOException {
        String url = null;

        for (String fieldName : json.iterateObjectFieldNames()) {
            log.trace("Saw field: {}", fieldName);

            if (fieldName.equals(URL)) {
                url = json.readString();
            } else {
                throw new JsonParseException("Unexpected field in reading json representation of " + JSON_DESERIALIZATION_TARGET.getName() 
                        + "'" + fieldName + "'", json.getTokenLocation());
            }
        }

        if (url == null) {
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() 
                    + ". Null field found:  " + URL + ":" + url);
        }
        return new BaseSvnExtract(url);
    }

}
