package com.wsgc.ecommerce.buildsystem;

import java.io.File;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/**
 * Had to start somewhere. The thing that keeps your source files needs to be able to give them to you.
 * 
 *  <p>
 *  Debatable: Later it was decided we needed to be able to know when was the last time it was used. More thought
 *  will remove that perceived need for that in this interface? 
 * 
 * 
 * @author chunt
 * @version $Id$ 
 */
public interface ExtractSource {
    /**
     * Given a concrete extract definition, deliver the collection to a target on the file system.
     * 
     * @param resolvedExtract the {@link ResolvedExtract} to extract from source control server
     * @param targetDirectory the file system location to place your goodies
     * @return {@link SourceRetrievalDetails} with logs and error coded generated during the attempt
     * @throws SourceException if things get surprising
     */
    SourceRetrievalDetails performExtract(
            ResolvedExtract<?> resolvedExtract, File targetDirectory) throws SourceException;

    /**
     * @return timestamp of last activity 
     */
    long getLastUsed();
}
