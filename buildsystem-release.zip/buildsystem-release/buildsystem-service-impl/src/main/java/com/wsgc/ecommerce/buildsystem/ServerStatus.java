package com.wsgc.ecommerce.buildsystem;

import java.util.Date;

/**
 * @author chunt
 * @version $Id$
 * @deprecated turns out, no one needs it.
 */
@Deprecated
public class ServerStatus {

    private final Date startup = new Date();

    /**
     * Default waiting to happen
     */
    public ServerStatus() {

    }

    /**
     * @return the server start string.
     */
    public String getStartUpTime() {
        return startup.toString();
    }

}
