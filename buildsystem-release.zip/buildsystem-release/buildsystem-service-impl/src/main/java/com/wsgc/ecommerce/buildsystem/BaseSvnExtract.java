package com.wsgc.ecommerce.buildsystem;

import java.io.IOException;

import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;

/**
 * 
 * SVN specific implementation of {@link BaseExtract}. Still referring to a group, with out a specific version defined.
 * 
 *  
 * @author chunt
 * @version $Id$ 
 */
public class BaseSvnExtract implements BaseExtract<BaseSvnExtract> {
    
    /**
     * Useful for json deserialization
     */
    public static final String ENTITY_TYPE_ID = "extract/base/svn";
    private final String url;

    /**
     * Constructor that accepts where the <i>thing -> {@link BaseExtract}</i> ... "<b>is</b>".
     * 
     * @param url location of resource
     */
    public BaseSvnExtract(String url) {
        //TODO: needs a check for trunk marker, that either raises or settles the question of where those marker definitions live
        this.url = trimLastUrlSeparator(url);
    }

    /**  {@inheritDoc}  */
    @Override
    public String getURL() {
        return url;
    }

    /**  {@inheritDoc}  */
    @Override
    public String getEntityTypeId() {
        return ENTITY_TYPE_ID;
    }

    /**  {@inheritDoc}  */
    @Override
    public Object getEntityInstanceId() {
        /** Not used. */
        return null;
    }

    /**  {@inheritDoc}  */
    @Override
    public void writeSelf(JsonObjectOutputStream jsonOut) throws IOException {
        jsonOut.writeStartObject();
        jsonOut.writeStringField("url", url);
        jsonOut.writeEndObject();       
    }

    /**  {@inheritDoc}  */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((url == null) ? 0 : url.hashCode());
        return result;
    }
    
    /**  {@inheritDoc}  */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BaseSvnExtract)) {
            return false;
        }
        BaseSvnExtract other = (BaseSvnExtract) obj;
        if (url == null) {
            if (other.url != null) {
                return false;
            }
        } else if (!url.equals(other.url)) {
            return false;
        }
        return true;
    }
    
    /**
     * Helper method to normalize representation by removing dangling connectors.
     * 
     * @param someUrl the url with a possible ending slash
     * @return a url that doesn't have a ending slash
     */
    private String trimLastUrlSeparator(String someUrl) {
        return (someUrl.endsWith("/")) ? someUrl.substring(0, someUrl.length() - 1) : someUrl; 
    }
 
    /**  {@inheritDoc}  */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("BaseSvnExtract [url=").append(url).append("]");
        return builder.toString();
    }

    /**  {@inheritDoc}  */
    @Override
    public int compareTo(BaseSvnExtract other) {
        return getURL().compareTo(other.getURL());
    }
    
}
