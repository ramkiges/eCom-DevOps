/**
 * @author chunt
 * 
 */
package com.wsgc.ecommerce.buildsystem;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.wsgc.ecommerce.buildsystem.exception.BuildManagerRuntimeException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;

/**
 * Implementation of {@link BuildIdProvider} that uses a {@link JdbcTemplate} and the usual date-code generation
 * the wsi ecom system used at the time of writing this. See {@link StandardBuildIdProvider #getBuildId()}
 * for a version of this common code duplicated in other projects. Meaning the format is a date code followed
 * by a sequence number. There can only be 99 builds a day and the next build will appear with tomorrows date code.
 * 
 * @author chunt
 * @version $Id$
 */
public class StandardBuildIdProvider implements BuildIdProvider, InitializingBean {
    private static  final Logger LOGGER = LoggerFactory.getLogger(StandardBuildIdProvider.class);
    
    protected static final String BUILD_IDENTIFIERS_TABLE = "BUILD_IDENTIFIERS";
    private JdbcTemplate jdbcTemplate;
    private TransactionTemplate transactionTemplate;
    private String buildTypePrefix;
    
    /**
     * {@link String} to tack on to the front of all the build id's. Its up to 
     * you to know if your choice works locally or strategically when it interacts 
     * with others downstream.
     * 
     * @param aBuildTypePrefix the prefix
     */
    public void setBuildTypePrefix(String aBuildTypePrefix) {
        this.buildTypePrefix = aBuildTypePrefix;
    }


    /** {@inheritDoc} */
    @Override
    public String getBuildId() {
        
        long time = 0;
            time = System.currentTimeMillis();
            LOGGER.debug("Looking up new build id.");

        String myBuildId = transactionTemplate.execute(new TransactionCallback<String>() {
            @Override
            public String doInTransaction(TransactionStatus ts) {
         
                try {

                    // Bump the seq
                    jdbcTemplate.update("update " + BUILD_IDENTIFIERS_TABLE + " set IDENTIFIER_SEQ = IDENTIFIER_SEQ + 1 where IDENTIFIER_TYPE = '" 
                    + buildTypePrefix + "'");

                    // Keep the sequence below 99
                    jdbcTemplate.update("update " + BUILD_IDENTIFIERS_TABLE 
                            + " set IDENTIFIER_DATE = IDENTIFIER_DATE + 1, IDENTIFIER_SEQ = 0 where IDENTIFIER_TYPE = '" 
                            + buildTypePrefix + "' and IDENTIFIER_SEQ > 99");

                    DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
                    formatter.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US));                    
                    String dateString = formatter.format(new Date()).replace("/", "");
                    int dateInt = Integer.parseInt(dateString);

                    // Wrap the date.
                    jdbcTemplate.update("update " + BUILD_IDENTIFIERS_TABLE
                            + " set IDENTIFIER_DATE=?,IDENTIFIER_SEQ=0 where IDENTIFIER_TYPE = ? and IDENTIFIER_DATE < ?", dateInt, buildTypePrefix, dateInt);
                    
                    // Get your id
                    String newBuildId = jdbcTemplate.queryForObject("select IDENTIFIER_DATE,IDENTIFIER_SEQ from " 
                            + BUILD_IDENTIFIERS_TABLE + " where IDENTIFIER_TYPE= '" + buildTypePrefix + "'", new BuildIdRowMapper()); //buildTypePrefix));

                    return buildTypePrefix  + newBuildId;
                } catch (Exception e) {
                    // wrap all exceptions in BuildManagerRuntimeException
                    ts.setRollbackOnly();
                    throw new BuildManagerRuntimeException("Build Id generation failed. Reason:" + e, e);
                }
            }
        });
        
            time = System.currentTimeMillis() - time;
            LOGGER.debug("Returning new build id:{} took {} ms", myBuildId, time);
        
            return myBuildId;
    }


    /**
     * Method to inject data source.
     * 
     * @param dataSource
     *            the data source
     */
    public void setDataSource(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
        transactionTemplate = new TransactionTemplate(transactionManager);
    }


    /**
     * {@inheritDoc}
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (buildTypePrefix == null) {
            throw new BuildServiceException("Not all required properties have been set." + toString());
        }
        
    }

}
