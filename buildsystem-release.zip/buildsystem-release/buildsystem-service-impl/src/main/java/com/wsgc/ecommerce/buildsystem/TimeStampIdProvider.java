package com.wsgc.ecommerce.buildsystem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

/**
 * @author chunt
 * @version $Id$ 
 * @deprecated replaced by StandardBuildIdProvider
 */
@Deprecated
public class TimeStampIdProvider implements InitializingBean, BuildIdProvider {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static String buildIdPrefix;
    private long lastId;
    
    /** {@inheritDoc} */
    @Override
    public String getBuildId() {
      return buildIdPrefix + getNextId();
    }


    /**
     * Sleep until next timestamp doesn't match current timestamp.
     * @return the next timestamp id String.
     */
    private synchronized String getNextId() {
        long nextId = System.currentTimeMillis();
        
        while (nextId == lastId) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
              logger.info("Sleep interrupted waiting for next id generation: " + e, e);
              
              // Normally we want to tell others we have been interrupted. In this loop
              // we just sleep again if that happens so lets not tell anyone (?).
              //Thread.currentThread().interrupt();
            }
            nextId = System.currentTimeMillis();
        }
        
        lastId = nextId;
        
        return "" + lastId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void afterPropertiesSet() throws Exception {
     if (buildIdPrefix == null) {
         throw new Exception("Properties not set. " + toString());
     }
    }

    /**
     * @return the prefix
     */
    public String getBuildIdPrefix() {
        return buildIdPrefix;
    }

    /**
     * @param prefix the prefix to set
     */
    public void setBuildIdPrefix(String prefix) {
        TimeStampIdProvider.buildIdPrefix = prefix;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TimeStampBuildIdProvider [prefix=").append(buildIdPrefix)
                .append("]");
        return builder.toString();
    }

}
