package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.exception.SourceException;

/** 
 * 
 * EXPERIMENTAL, expecting to record actual performance and manage queue scheduling base on real world performance.
 * <p>
 * 
 *     TODO private static final long FILE_NUMBER_CONSTANT = ?
 *     TODO private static final long FILE_CONTENT_SIZE_CONSTANT = ?
 *
 * Using "svn list command may be useful in finding this information. The overhead of doing so has yet to be 
 * justified in the real world case... There is a dramatic need for this in content type builds. Fevered dreams of
 * efficiency have an AI turning this weighting off and on at the right time. Practical use comments the idea away entirely. 
 *  
 * @author chunt
 * @version $Id$ 
 */
public class SvnPredictiveSourceRetrievalStrategy implements InitializingBean, SourceRetrievalStrategy { 
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private boolean logMutexUse;
    private String sourcePath;
    //private String sourceChannels;
    private int numSourceChannels;


    private List<SvnExtractSource> svnExtractSources;

    //private String extractCacheRoot;

    /** 
     * 
     *  time svn checkout  https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/trunk
     *  real    8m24.527s
     *  user    1m11.580s
     *  sys     1m2.607s
     *
     * Switch to OLD branch (Last Changed Rev: 123654)
     * 
     * 2 runs average ~ 3m
     * 
     * Switch back to trunk
     * 
     * 2 runs average ~ 6m
     *  
     * 
     * Update to recent branch
     * time svn switch  https://repos.wsgc.com/svn/core/ecommerce/sites/pb/content/branches/magnesium_sandbox
     *  
     * 2 runs average ~ 3m
     *
     * 
     * cp to working directory 4 minutes. 
     * 
     * 
     * Checkout  ~ 8   1000
     * Switch    ~ 4   500 
     * update    ~ 2   250
     * cp        ~ 4   500 * depth
     * 
     *      
     */

    private static final long REVISION_CONSTANT = 1;
    private static final long SWITCH_CONSTANT   = 2;
    private static final long CHECKOUT_CONSTANT = 3;
    private static final long TASK_DEPTH_CONSTANT = SWITCH_CONSTANT; // *(revisions)*depth
    private static final String CHANNEL_MARKER = SvnPredictiveSourceRetrievalStrategy.class.getName() + "_source_channel_";

    /*
     * TODO class types and interfaces  need to be set correctly. Then remove this suppressed raw type 
     */
    @Override
    public SvnRunnableRetrievalAction getSourceRetrievalAction(/*List<? extends ExtractSource> extractSources,*/
            @SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract, 
            File targetDirectory) {

        long bestWorkEstimate = Long.MAX_VALUE;
        long workEstimate = 0;
        SvnExtractSource bestExtractSource = null;
        SvnExtractSource potentialExtractSource = null;
        SvnRunnableRetrievalAction svnRetrievalAction = null;


        // Find best match and add our request to its queue in an atomic operation.
        if  (logMutexUse()) {                
            logger.debug("{} waiting for Mutex", Thread.currentThread().getStackTrace()[1].getMethodName());        
        }

        synchronized (SvnExtractSource.getAccessMutex()) {

            if  (logMutexUse()) {                
                logger.debug("{} got  Mutex", Thread.currentThread().getStackTrace()[1].getMethodName());        
            }

            //TODO these casts need to go away. Your interface types are not fully cooked here yet.
            for (ExtractSource extractSource : svnExtractSources) {

                potentialExtractSource = (SvnExtractSource) extractSource;

                workEstimate = predictWorkByHistory(potentialExtractSource, resolvedExtract);
                logger.debug("potentialExtractSource: {} workEstimate: {}", potentialExtractSource.getFinalResolvedURL(), workEstimate);
                if (workEstimate < bestWorkEstimate) {
                    bestWorkEstimate = workEstimate;
                    bestExtractSource = potentialExtractSource;
                    logger.debug("BestExtractSource: {} bestWorkEstimate: {}", bestExtractSource.getFinalResolvedURL(), bestWorkEstimate);
                }

            }

            svnRetrievalAction = new SvnRunnableRetrievalAction(bestExtractSource, (ResolvedSvnExtract) resolvedExtract, targetDirectory);

            bestExtractSource.queExtractRequest(svnRetrievalAction);

            if  (logMutexUse()) {                
                logger.debug(Thread.currentThread().getStackTrace()[1].getMethodName() + " releasing Mutex");        
            }
        }

        // 
        //return svnRetrievalTask.getSourceRetrievalDetails();
        return svnRetrievalAction;
    }





    /**
     * TODO: Experimental, for placement only. 
     * 
     * We know that a switch is damn near instantaneous 
     * @param potentialExtractSource xx
     * @param resolvedExtract xx
     * @return xx
     */
    private long predictWorkByHistory(SvnExtractSource potentialExtractSource,
            @SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract) {

        //        ExtractHistory extractHistory = SVNExtractSource.historicalRecord.get(resolvedExtract.getBaseExtract());
        //        


        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * @return whether to logMutexUse or not
     */
    private boolean logMutexUse() {
        return logMutexUse;
    }





    /**
     * Experimental, for placement only.
     * 
     * @param potentialExtractSource xx
     * @param resolvedExtract xx
     * @return xx
     */
    @SuppressWarnings("unused")
    private long estimateWorkTheoreical(SvnExtractSource potentialExtractSource,
            @SuppressWarnings("rawtypes") ResolvedExtract resolvedExtract) {


        //TODO, these are open calls.


        long workEstimate = 0;
        long revisionDelta =
                Math.abs((Long.parseLong(potentialExtractSource.getFinalEffectiveRevision()) 
                        - Long.parseLong(resolvedExtract.getEffectiveRevision())));     
        boolean sameRepo = resolvedExtract.getUuid().equals(potentialExtractSource.getFinalUuid());

        if  (logger.isDebugEnabled()) {  
            logger.debug(
                    "Estimating work\n" 
                            + "Source state:  " + potentialExtractSource.getFinalResolvedURL() + " revision:" 
                            + potentialExtractSource.getFinalEffectiveRevision() + " uuid: " + potentialExtractSource.getFinalUuid()
                            + "\n" 
                            + "Request state: " + resolvedExtract.getResolvedUrl()  + " revision:" 
                            + resolvedExtract.getEffectiveRevision() + " uuid: " + resolvedExtract.getUuid());
            logger.debug("revision delta:{}", revisionDelta);
        }


        // are URL's the same ?
        if (potentialExtractSource.getFinalResolvedURL().equals(resolvedExtract.getResolvedUrl()) && sameRepo) {
            // Yes the URL's are exactly the same
            // then no switch or checkout needed
            workEstimate = (revisionDelta + 1) * REVISION_CONSTANT;
            logger.debug("Source extract requires a update to correct revision.");
            
        } else if (isBranch(potentialExtractSource.getFinalResolvedURL(), resolvedExtract.getResolvedUrl()) && sameRepo) {
            // Yes the bases are the same
            // a switch is needed
            workEstimate = Math.abs(revisionDelta - 5000) * SWITCH_CONSTANT;
            logger.debug("Source extract requires a svn switch");
            
        } else {
            // a complete check out is needed
            workEstimate = Math.abs(revisionDelta - 5000) * CHECKOUT_CONSTANT;    
            logger.debug("Source extract will require a complete svn check out");
            
        }

        // how long will we have to wait for other tasks before getting to this state?
        long queueOverhead = Math.abs(revisionDelta - 5000) * TASK_DEPTH_CONSTANT * potentialExtractSource.getRequestQueueDepth();
        workEstimate += queueOverhead;

        if  (logger.isDebugEnabled()) { 
            if (queueOverhead > 0) {
                logger.debug("Queue depth: {} adding queue depth overhead:{}", potentialExtractSource.getRequestQueueDepth(), queueOverhead);
            }
            logger.debug("Work estimate:{}", workEstimate);
        }

        return workEstimate;
    }

    /**
    /**
     * Experimental, for placement only.
     * @param sourceURL xx
     * @param extractURL xx
     * @return xx
     */
    private boolean isBranch(String sourceURL, String extractURL) {

        /* If they share a url up to the WSI SVN marker "branches" or "trunk" then
         * one is a branch of the other.
         * 
         * TODO there must be some overly clever regex to do this better.
         */
        String sourceBase = null;
        String extractBase = null;

        if (sourceURL.contains(ExtractDefinition.BRANCHES_MARKER)) {
            sourceBase = sourceURL.substring(sourceURL.indexOf(ExtractDefinition.BRANCHES_MARKER));
        } else if (sourceURL.contains(ExtractDefinition.TRUNK_MARKER)) {
            sourceBase = sourceURL.substring(sourceURL.indexOf(ExtractDefinition.TRUNK_MARKER));
        }

        if (extractURL.contains(ExtractDefinition.BRANCHES_MARKER)) {
            extractBase = extractURL.substring(extractURL.indexOf(ExtractDefinition.BRANCHES_MARKER));
        } else if (extractURL.contains(ExtractDefinition.TRUNK_MARKER)) {
            extractBase = extractURL.substring(extractURL.indexOf(ExtractDefinition.TRUNK_MARKER));
        }

        boolean needsSwitch = ((extractBase == null) || (sourceBase == null) || !extractBase.equals(sourceBase));

        return needsSwitch;
    }

    /**
     * Experimental, for placement only.
     * @return xx
     */
    public String getsourcePath() {
        return sourcePath;
    }

    /**
     * Experimental, for placement only.
     * @param sourcePath xx
     */
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    /**
     * @return the logMutexUse
     */
    public boolean isLogMutexUse() {
        return logMutexUse;
    }





    /**
     * @param logMutexUse the logMutexUse to set
     */
    public void setLogMutexUse(boolean logMutexUse) {
        this.logMutexUse = logMutexUse;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (sourcePath == null  && numSourceChannels > 0) {
            throw new SourceException("Initialization not complete." + toString());
        }

    }

    @Override
    public void init() throws SourceException {
        svnExtractSources = new  ArrayList<SvnExtractSource>(numSourceChannels);

        //TODO remove we need a null state denoting 'new' (lazy init)
        ResolvedSvnExtract stubInitialState = ResolvedSvnExtractFactory.init("misc",
                //"https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/branches/pb_primary/", 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk", 
                "4d9f3204-700e-0410-9f00-95bf6548d55c",
                "165211", //This is the head of that branch. 
                /* "HEAD" that will fail validation later */
                /*"156000", doesn't exist in branch  be careful asking for nonexistent revisions on branches, 
                    it won't pass validation later */ 
                "https://repos.wsgc.com/svn/core/ecommerce/sites/pb/misc/trunk/",
                "trunk",
                "HEAD");

        for (int i = 0; i < numSourceChannels; i++) {


            /**
             * TODO this needs to be set by spring via an array/group bean inject trick that I don't
             * have time to look up right now.
             * <bean 
             * 
             */

            // replace stub default initial state with logic to recognize null as "new".
            svnExtractSources.add(
                    //                    new SvnExtractSource(sourcePath + File.separatorChar + CHANNEL_MARKER + i, null /*stubInitialState*/, null));
                    new SvnExtractSource(sourcePath + File.separatorChar + CHANNEL_MARKER + i, stubInitialState/*, null*/));

        }

    }

    /**
     * @param numSourceChannels the numSourceChannels to set
     */
    public void setNumSourceChannels(int numSourceChannels) {
        this.numSourceChannels = numSourceChannels;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SvnPredictiveSourceRetrievalStrategy [sourcePath=")
        .append(sourcePath).append(", numSourceChannels=")
        .append(numSourceChannels).append(", svnExtractSources=")
        .append(svnExtractSources).append("]");
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNumSourceChannels() {
        return numSourceChannels;
    }

}
