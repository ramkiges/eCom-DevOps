package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.exception.ExtractException;
import com.wsgc.ecommerce.buildsystem.exception.SourceException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;

/**
 * Responsible for providing all the requested extract collections. Uses
 * concurrent threads to service multiple extract requests from the extract
 * cache.
 * 
 * 
 * @author chunt
 * @version $Id$
 */
public class SvnExtractManager implements ExtractManager, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private SourceRetrievalStrategy sourceRetrievalStrategy;
    private int numberOfExtractThreads;
    private String debugSetting;

    private ExecutorService executorService;
     
    /** {@inheritDoc} */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (sourceRetrievalStrategy == null || numberOfExtractThreads == 0) {
            throw new BuildServiceException("Initialization not complete." + toString());
        }
        executorService = Executors.newFixedThreadPool(numberOfExtractThreads);
        
        logger.info("DEBUG SETTING: {}", debugSetting);
        
        if (debugSetting.equals("SELECTIVE")) {
            logger.info("DEBUG SETTING: sourceRetrievalStrategy is now SvnSelectiveRetrievalStrategy");
            sourceRetrievalStrategy = new SvnSelectiveRetrievalStrategy((SvnBlindRetrievalStrategy) sourceRetrievalStrategy);
        }
        init();
    }


    /** {@inheritDoc} */
    @Override
    public List<ExtractTargetMapping> getExtractTargets(
            File buildPlanWorkingExtractsDir, BuildRequest buildRequest) {
        
        if (buildPlanWorkingExtractsDir == null) {
            throw new IllegalArgumentException("Target directory can not be null");
        }

        if (buildRequest == null) {
            throw new IllegalArgumentException("BuildRequest can not be null");
        }
        
        /**
         * TODO This can be SortedSet<ResolvedExtract>, this is not good but has been looked at and should be a todo not just
         * a check style error.  
         */
        @SuppressWarnings("rawtypes")
        SortedMap<String, ResolvedExtract> resolvedExtracts = buildRequest.getResolvedExtracts();
        List<ExtractTargetMapping> extractTargets = new ArrayList<ExtractTargetMapping>();

        for (String resolvedExtractName : buildRequest.getResolvedExtracts().keySet()) {
            //TODO validate dirs with FileUtil
            File resolvedExtractWorkingExtractsDir = new File(buildPlanWorkingExtractsDir, resolvedExtractName);
          
            extractTargets.add(new ExtractTargetMapping(resolvedExtracts.get(resolvedExtractName), resolvedExtractWorkingExtractsDir));
        }
        return extractTargets;
    }


    /**
     * @return the currently set {@link SourceRetrievalStrategy}
     */
    public SourceRetrievalStrategy getSourceRetrievalStrategy() {
        return sourceRetrievalStrategy;
    }


    /**
     * A place to put init code, so far, it just calls the underlying {@link SourceRetrievalStrategy}
     * 
     * DEBATABLE this really seems to want to be in the interface....
     *  
     * @throws SourceException if something goes wrong.
     */
    public void init() throws SourceException {
        sourceRetrievalStrategy.init();        
    }

    /** {@inheritDoc} */
    @Override
    public  List<SourceRetrievalDetails> performExtracts(List<ExtractTargetMapping> resolvedExtractTargets) throws ExtractException {
        List<SourceRetrievalAction> sourceRetrievalActions = new ArrayList<SourceRetrievalAction>(resolvedExtractTargets.size());

        List<SourceRetrievalDetails> results = new ArrayList<SourceRetrievalDetails>();
        logger.debug("SourceRetrievalDetails:{}", results);

        logger.info("numberOfExtractThreads:{}", numberOfExtractThreads);

        // Let the strategy determine the action
        for (ExtractTargetMapping target : resolvedExtractTargets) {
            
            target.getDirectory().mkdirs();
            try {
                FileUtil.checkDirExistsRWEmpty(target.getDirectory());
            } catch (IOException ioe) {
                throw new ExtractException("Extract target directory validation check FAILED. Reason" + ioe, ioe);
            }
            
             SourceRetrievalAction action = sourceRetrievalStrategy.getSourceRetrievalAction(
                     target.getResolvedExtract(), target.getDirectory());
             logger.debug("Got SvnRetrievalAction:{}", action);
             sourceRetrievalActions.add(action);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        // Resolve actual paths before command setup and execution
        //for (Future<SourceRetrievalDetails> detailFuture : sourceRetrievalDetails) {
//        for (SvnRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
//
//            //TODO this must not stand, this needs to be turned in to a wait().
//            while (svnSourceRetrievalAction.getFutureSourceRetrievalDetails() == null) {
//                try {
//                    //logger.debug("Waiting 500 ms for svnSourceRetrievalTask.isDone()");
//                    Thread.sleep(500);
//                }  catch (InterruptedException ie) {
//                    logger.debug("Thread interrupted while sleeping, resetting interrupt. " + ie, ie);
//                    Thread.currentThread().interrupt();
//                }   
//            }
//            
//            Future<SourceRetrievalDetails> futureSourceRetrievalDetails = svnSourceRetrievalAction.getFutureSourceRetrievalDetails();
//            SourceRetrievalDetails sourceRetrievalDetails;
//         
//            try {
//                sourceRetrievalDetails = futureSourceRetrievalDetails.get();
//            } catch (InterruptedException e) {
//                //TODO place holder until final extraction refactoring, revisit and propagate more info than this.
//                sourceRetrievalDetails = new SourceRetrievalDetails(false, null, null);
//                sourceRetrievalDetails.setLastException(e);
//            } catch (ExecutionException e) {
//                //TODO place holder until final extraction refactoring
//                sourceRetrievalDetails = new SourceRetrievalDetails(false, null, null);
//                sourceRetrievalDetails.setLastException(e);
//            }
//            
//            results.add(sourceRetrievalDetails);
//
//        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////
// TODO no, when you get an action, its already started.
//        for (SvnRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
//            /*
//             * Action will begin with a wait for another notification by the svnSource worker thread.
//             */
//            svnSourceRetrievalAction.start();
//        }

//        try {
//            for (SvnRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
//                //We now wait for scheduled extract to finish
//                logger.debug("waiting to join action thread. Action:" + svnSourceRetrievalAction);
//                logger.debug("action thread isAlive():" + svnSourceRetrievalAction.isAlive());
//                svnSourceRetrievalAction.join();
//                logger.debug("leaving wait to join action thread. Action:" + svnSourceRetrievalAction);
//            }
//        } catch (InterruptedException e) {
//            logger.warn("Exception waiting for join with action thread", e);
//            throw new ExtractException(e); 
//        }

        
        
       // Single threading here (now that getSourceRetrievalDetails() blocks).
//OLD threading
//        for (SourceRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
//            SourceRetrievalDetails details = svnSourceRetrievalAction.getSourceRetrievalDetails();
//            logger.debug("Adding SourceRetrievalDetails to collection. " + details);
//            results.add(details);
//        }
        
// Hope for multithreading.
//////////////////////////////////////////////////////////////////////////////////////////////////////////
        //TODO this could be a static method Future<T> in ProcessUtil?
        Set<Future<SourceRetrievalDetails>> futures = new HashSet<Future<SourceRetrievalDetails>>();
        
        // TODO not sure why we need local executor?
        CompletionService<SourceRetrievalDetails> extractCompletionService = 
                new ExecutorCompletionService<SourceRetrievalDetails>(executorService);

        logger.info("sourceRetrievalActions size is {}", sourceRetrievalActions.size());
        for (SourceRetrievalAction svnSourceRetrievalAction : sourceRetrievalActions) {
            final SourceRetrievalAction finalSourceRetrievalAction = svnSourceRetrievalAction; 
            // keep track of the futures that get created so we can cancel them if necessary
            futures.add(extractCompletionService.submit(new Callable<SourceRetrievalDetails>() {
                @Override
                public SourceRetrievalDetails call() throws Exception {
                    return finalSourceRetrievalAction.getSourceRetrievalDetails();
                }
            }));
        }

        // TODO this code now is duplicated in StandardBuildManager as well.   
        Future<SourceRetrievalDetails> completedFuture;
        SourceRetrievalDetails returnedSourceRetrievalDetails;
        
        
// Lets make one try block entry, not one for every future.take() attempt.
        
//        while (futures.size() > 0) {
//            try {
//                // block until a callable completes
//                completedFuture = extractCompletionService.take();
//                futures.remove(completedFuture);
//                returnedSourceRetrievalDetails = completedFuture.get();
//            } catch (Exception e) {
//
//                //Shutdown anyone we can.
//                for (Future<SourceRetrievalDetails> f : futures) {
//                    f.cancel(true);
//                }
//                throw new ExtractException(e);
//            } finally {
//                executorService.shutdown();
//            }
//
//            results.add(returnedSourceRetrievalDetails);
//        }

        try {
            
            while (futures.size() > 0) {
                // block until a callable completes
                completedFuture = extractCompletionService.take();
                futures.remove(completedFuture);
                returnedSourceRetrievalDetails = completedFuture.get();

                results.add(returnedSourceRetrievalDetails);
            }

        } catch (Exception e) {

            //Shutdown anyone we can. Bad idea.
//            for (Future<SourceRetrievalDetails> f : futures) {
//                f.cancel(true);
//            }
            /* We catch and wrap all Exceptions with ExtractException */
            throw new ExtractException(e);
        } finally {
            executorService.shutdown();
            logger.trace("ExecutorService shutdown by finalizer");
        }

        logger.debug("SourceRetrievalDetails: {}", results);      
        return results;
    }
       
    /**
     * @param nExtractThreads the nExtractThreads to set.
     */
    public void setNumberOfExtractThreads(int nExtractThreads) {
        this.numberOfExtractThreads = nExtractThreads;
    }

    /**
     * @param sourceRetrievalStrategy the {@link SourceRetrievalStrategy} to use
     */
    public void setSourceRetrievalStrategy(SourceRetrievalStrategy sourceRetrievalStrategy) {
        this.sourceRetrievalStrategy = sourceRetrievalStrategy;
    }

    /**
     * @return the debugString
     */
    public String getDebugString() {
        return debugSetting;
    }

    /**
     * @param debugSetting a custom signal to inject at runtime
     */
    public void setDebugSetting(String debugSetting) {
        this.debugSetting = debugSetting;
    }

}
