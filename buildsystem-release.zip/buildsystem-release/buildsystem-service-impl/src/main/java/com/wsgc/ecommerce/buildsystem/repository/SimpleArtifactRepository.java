package com.wsgc.ecommerce.buildsystem.repository;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.BuildInfo;
import com.wsgc.ecommerce.buildsystem.BuildOrder;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;

/**
 * A ... 'simple' implementation of the artifact repository. Builds are 'loaded' into the repository and become subject
 * to management by the {@link RetentionPolicy} which will be used to determine which if any builds should be delete
 * from the repo when the maintenance timer triggers.
 * 
 * 
 * Probably could be renamed to StandardArtifactRepository if the size of the repo where managed more thoughtfully. One
 * issue is the repo will exceed max size when a new build is added and will stay that way until the retention policy
 * notices. Adding a full 'evaluate the repo and clean old build" check to before every single 'loadBuild()' operation
 * seems to slow and a waste of CPU. A quick check against a running total of the current repo size verses the space
 * needed for a new build used with a preemptive deletion of that many or more bytes before loading the next build would
 * prevent fix that. But the size of the repo is re-evaluated each time now. It seems too expensive to calculate that
 * again every time we load and the better idea hasn't been implemented yet.
 * 
 * The timer to trigger a repository cleaning inspection would then only be finding old builds that have quietly slipped
 * past the old age limit during periods when there where no builds being loaded. The repo would appear to slowly evaporate 
 * while time passed and builds where not replenished. The first new build would find a lot of room in a previously filled repo
 * at that point.
 * 
 * @author chunt
 * @version $Id$
 */
public class SimpleArtifactRepository implements ArtifactRepository, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String BUILD_SYSTEM_2_LABEL = "buildsystem2";

    private static final int MINUTES_BETWEEN_GC = 5;
    private Map<Integer, Set<SimpleBuildReference>> indexMap;
    private Map<String, SimpleBuildReference> idMap;
    
    /**
     *  These lists grows but do not shrink when the last example of a user or projectLabel is removed.
     *  It is re-read on init only so that is where deletions are finally noticed. 
     */
    private Set<String> allUsers;
    private Set<String> allProjectLabels;
    
    
    /*
     *  TODO change this to SortedMap ... see SortedMap<Long, Set<? extends BuildReference>> getBuildHistoryMap() {
     *  and start this off AS a sorted map, making getBuildHistoryMap just a getter for timeMap.
     *  This is a change I don't want to do just before release.
     */
    private Map<Long, Set<SimpleBuildReference>> timeMap;
    private String artifactRepositoryHome;
   
    private File repoRootDir;
    private RetentionPolicy retentionPolicy;

    /**
     * @param retentionPolicy the retentionPolicy to set
     */
    public void setRetentionPolicy(RetentionPolicy retentionPolicy) {
        this.retentionPolicy = retentionPolicy;
    }

    /**
     * Default constructor, starts maintenance timer to check repo against retention policy. The time setting is
     * compiled and is equal to {@linkplain #MINUTES_BETWEEN_GC}.
     */
    public SimpleArtifactRepository() {
        indexMap = new HashMap<Integer, Set<SimpleBuildReference>>();
        /*
         * TODO (see above too) SortedMap<Long, Set<? extends BuildReference>> getBuildHistoryMap() 
         */
        timeMap = new HashMap<Long, Set<SimpleBuildReference>>();
        idMap = new HashMap<String, SimpleBuildReference>();
        
        allProjectLabels = new HashSet<String>();
        allUsers = new HashSet<String>();
        
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                try {
                    gc();
                } catch (ArtifiactRepostitoryException e) {
                    throw new RuntimeException(e);
                }
            }
        }, MINUTES_BETWEEN_GC * 60 * 1000);

    }

    /**
     * @return top level path of the repository file system.
     */
    public synchronized String getArtifactRepositoryHome() {
        return artifactRepositoryHome;
    }

    /**
     * @param artifactRepositoryHome the root of the repo.
     */
    public synchronized void setArtifactRepositoryHome(String artifactRepositoryHome) {
        this.artifactRepositoryHome = artifactRepositoryHome;
    }

    /** {@inheritDoc} */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (artifactRepositoryHome == null || retentionPolicy == null) {
            throw new BuildServiceException("Properties not set." + toString());
        }
        init();
    }

    /**
     * Initialization method. At the moment it only reads the repo from disk and sets up the internal maps to manage it. 
     * 
     * @throws ArtifiactRepostitoryException for any Exception along the way
     */
    public void init() throws ArtifiactRepostitoryException {
        readRepository();
    }

    /**
     * Synchronized method that reads the file system starting at the top of the repo as defined by
     * {@link #artifactRepositoryHome} and attempts to register the build with this repo object by creating a
     * {@link SimpleBuildReference} for each build collection it finds and adds it to the internal maps used to manage
     * the repo. If a particular build can not be 'loaded()' an attempt to log that fact and continue will be made. At
     * the end of the process the total number of builds that failed to load will be reported, but no error condition
     * will be set in that case. So far a builds have only failed to load if the format has changed during development
     * without deleting the old builds from the repo.
     * 
     * 
     * @throws ArtifiactRepostitoryException
     *             for any number of bad things that could happen when talking to a file system that prevent further
     *             inspection of the collection.
     */
    private synchronized void readRepository() throws ArtifiactRepostitoryException {
        int dirtyRepo = 0;
        try {
            repoRootDir = new File(artifactRepositoryHome);
            FileUtil.checkDirExistsRW(repoRootDir);
            logger.info("Artifact repository root:" + repoRootDir.getAbsolutePath());

            for (File repoProjectDir : repoRootDir.listFiles(
                    // TODO use the one in FileUtil?
                    //TODO don't cut and paste filter
                    new FilenameFilter() {
                        public boolean accept(File dir, String name) {
                            if (!name.equals(".DS_Store")) {
                                return true;
                            }
                            return false;
                        }
                    }
                    )) {

                for (File repoBuildDir : repoProjectDir.listFiles(
                        //TODO just reuse this filter
                        new FilenameFilter() {
                            public boolean accept(File dir, String name) {
                                if (!name.equals(".DS_Store")) {
                                    return true;
                                }
                                return false;
                            }
                        }
                        )) {

                    FileUtil.checkDirExistsRW(repoBuildDir);
                    logger.debug("Reading build artifact from location:" + repoBuildDir.getAbsolutePath());

                    try {
                        addReference(new SimpleBuildReference(repoBuildDir.getName(), repoBuildDir, generateLogicalLocation(repoBuildDir)));
                    } catch (Exception e) {
                        // We are catching all exceptions here deliberately in an attempt to continue loading builds without errors.
                        ++dirtyRepo;
                        logger.error("Failed to Read build artifact from location:" + repoBuildDir.getAbsolutePath()
                                + " Reason:" + e, e);   
                    }
                }
            }
        } catch (Exception e) {
            // Catch all exceptions and wrap.
            throw new ArtifiactRepostitoryException(e);
        }

        if (dirtyRepo != 0) {
            logger.error("#############################################################");   
            logger.error("The repository contains " + dirtyRepo + " builds that could not be loaded");
            logger.error("#############################################################");   
        }
    }


    /**
     * A helper method to generate the logical location for a REQUIRES line in import information used by BigGreenButton
     * for deployment and staging.
     * 
     * @param repoBuildDir
     *            the directory on disk of the build.
     * @return a logical path string prepended with the {@link #BUILD_SYSTEM_2_LABEL}
     * 
     */
    private String generateLogicalLocation(File repoBuildDir) {      
        String absoluteRepoRoot = repoRootDir.getAbsolutePath();
        String absoluteBuildPath = repoBuildDir.getAbsolutePath();
        String logicalPath = absoluteBuildPath.substring(absoluteRepoRoot.length());
        String logicalLocation = BUILD_SYSTEM_2_LABEL + logicalPath;
        return logicalLocation;
    }

    /**
     * Synchronized method to add a {@link SimpleBuildReference} to the internal maps used to manage this repo.
     * 
     * @param simpleBuildReference the reference to add
     * @throws ArtifiactRepostitoryException if any error occurs including if this reference is already in the repo
     */
    private synchronized void addReference(SimpleBuildReference simpleBuildReference) throws ArtifiactRepostitoryException {

        /*
         *  there may be more than one build with the same index or timestamp but not build id.
         */
        if (!indexMap.containsKey(simpleBuildReference.getIndex())) {
            indexMap.put(simpleBuildReference.getIndex(), new HashSet<SimpleBuildReference>());
        }

        Set<SimpleBuildReference> indexSet = indexMap.get(simpleBuildReference.getIndex());

        if (indexSet.contains(simpleBuildReference)) {
            throw new ArtifiactRepostitoryException("build reference is already in repository index map.  BuildReference:" 
                    + simpleBuildReference);
        }

        indexSet.add(simpleBuildReference); 
        indexMap.put(simpleBuildReference.getIndex(), indexSet);

        if (!timeMap.containsKey(simpleBuildReference.getCompletionTimestamp())) {
            timeMap.put(simpleBuildReference.getCompletionTimestamp(), new HashSet<SimpleBuildReference>());
        }

        Set<SimpleBuildReference> timeSet = timeMap.get(simpleBuildReference.getCompletionTimestamp());

        if (timeSet.contains(simpleBuildReference)) {
            throw new ArtifiactRepostitoryException("build reference is already in history map.  BuildReference:" 
                    + simpleBuildReference);
        }

        timeSet.add(simpleBuildReference); 
        timeMap.put(simpleBuildReference.getCompletionTimestamp(), timeSet);


        if (idMap.containsKey(simpleBuildReference.getBuildId())) {
            throw new ArtifiactRepostitoryException("build reference is already in repository build id map. BuildReference:" 
                    + simpleBuildReference);
        }

        idMap.put(simpleBuildReference.getBuildId(), simpleBuildReference);
        
        allProjectLabels.add(simpleBuildReference.getBuildOrder().getProjectLabel());
        allUsers.add(simpleBuildReference.getUser());
        
        logger.trace("Registering artifacts at location:{} index:{}", 
                simpleBuildReference.getBuildLocation().getAbsolutePath(), simpleBuildReference.getIndex());
    }

    /**
     * Removes a {@link BuildReference} from the internal maps used to manage this repo.
     * 
     * @param reference the build reference to remove
     * @throws ArtifiactRepostitoryException if the build reference is not found to remove
     */
    private synchronized void deleteReference(BuildReference reference) throws ArtifiactRepostitoryException {

        if (!indexMap.get(reference.getIndex()).remove(reference)) {
            throw new ArtifiactRepostitoryException("Failed to remove build reference by repo index. Reference:" + reference);
        }

        if (idMap.remove(reference.getBuildId()) == null) {
            throw new ArtifiactRepostitoryException("Failed to remove build reference by build id. Reference:" + reference);
        }

        if (!timeMap.get(reference.getCompletionTimestamp()).remove(reference)) {
            throw new ArtifiactRepostitoryException("Failed to remove build reference by time index. Reference:" + reference);
        }

    }

    /** {@inheritDoc} */ 
    @Override
    public synchronized Set<BuildReference> getBuildReferences(BuildInfo buildInfo) throws ArtifiactRepostitoryException {
        return getBuildReferences(buildInfo.getBuildOrder());
    }
    
    /** {@inheritDoc} */ 
    @Override
    public synchronized Set<BuildReference> getBuildReferences(BuildOrder buildOrder) throws ArtifiactRepostitoryException {

        int index = buildOrder.getIndex();
        Set<BuildReference> returnSet = new HashSet<BuildReference>();

        logger.debug("Looking for builds in repo matching Index:{}", index);
        if (indexMap.containsKey(index)) {

            //These are only 'potential' matches.. the indexes are the same, but there will be hash collisions.  
            Set<SimpleBuildReference> indexSet = indexMap.get(index);
            if (indexSet.size() > 0) {
                logger.debug("Index has {} build ids associated with it. Index:{}", indexSet.size(), index);
            }

            for (SimpleBuildReference simplebuildReference : indexSet) {
                BuildOrder repoBuildOrder = simplebuildReference.getBuildOrder();

                if (repoBuildOrder.equals(buildOrder)) {
                    returnSet.add(simplebuildReference);
                    logger.debug("Matching BuildOrder added to return set. BuildOrder:{}", repoBuildOrder);        
                }
            }

        } 
        return returnSet;
    } 

    /** {@inheritDoc} */ 
    @Override
    public BuildReference loadBuild(BuildInfo buildInfo) throws ArtifiactRepostitoryException {
        logger.debug("Loading build in to repository. BuildInfo.getIndex():{}", buildInfo.getIndex());

        File repoProjectArtifactDir = new File(repoRootDir, buildInfo.getProjectId());
        File repoArtifactDir = new File(repoProjectArtifactDir, buildInfo.getBuildId());
        if (repoArtifactDir.exists()) {
            throw new ArtifiactRepostitoryException("New build directory already exists in repository. Path:" 
                    + repoArtifactDir.getAbsolutePath());
        }

        try {
            repoArtifactDir.mkdirs();
            FileUtil.checkDirExistsRW(repoArtifactDir);

            //TODO should it read build folder content or the manifest?
            /**
             * Its the Manifest, ... stupid.
             */
            File[] buildArtifacts = getBuildArtifactList(buildInfo);

            for (File buildArtifact : buildArtifacts) {

                // TODO need more checking here still
                // Why are we skipping directories again? Because they don't exist in the test set? ???
                if (!buildArtifact.isFile()) {
                    continue;
                }

                //    try {
                FileUtil.checkFileExistsReadable(buildArtifact);

                File repoArtifact = new File(repoArtifactDir, "" + buildArtifact.getName());
                /*
                 * Note, unless you use an anonymous File in this call, your original is not deleted
                 * by the rename operation. 
                 *  e.g. buildArtifact.renameTo(new File(repoBuildDir, "" + buildArtifact.getName());
                 *  also....ignore return code, we are going for a more severe check later.
                 */
                buildArtifact.renameTo(repoArtifact);
                FileUtil.checkFileExistsReadableNotEmpty(repoArtifact);        
            }

            SimpleBuildReference simpleBuildReference = 
                    new SimpleBuildReference(buildInfo.getBuildId(), 
                            repoArtifactDir, 
                            generateLogicalLocation(repoArtifactDir));
            addReference(simpleBuildReference);

            //TODO be making defensive copies, clones and immutable returns
            return simpleBuildReference;
        } catch (Exception e) {
            // Wrap all Exceptions as ArtifiactRepostitoryException 
            throw new ArtifiactRepostitoryException("Exception loading build in to artifact repository. Reason:" + e, e);
        }
    }

    /**{@inheritDoc} */
    @Override
    public synchronized void unloadBuild(BuildReference reference) throws ArtifiactRepostitoryException {

        File repoArtifactDir = reference.getBuildLocation();
           try {
            FileUtil.checkDirExistsRW(repoArtifactDir);
        } catch (IOException ioe) {
            throw new ArtifiactRepostitoryException("Failed to unload build. Reason:" + ioe, ioe);
        }

        //TODO should it read build folder content or the manifest?
        // TODO get it from the Manifest
        File[] buildArtifacts = repoArtifactDir.listFiles();

        for (File buildArtifact : buildArtifacts) {

            // TODO need more checking here still?, Checksum?
            if (!buildArtifact.isFile()) {
                throw new ArtifiactRepostitoryException(
                        "Expecting only files while deleting build artifacts but found a directory.... buildArtifact:" 
                                + buildArtifact.getAbsolutePath());
            }

            try {

                FileUtil.checkFileExistsReadable(buildArtifact);

                File repoArtifact = new File(repoArtifactDir, buildArtifact.getName());
                FileUtil.checkFileExistsReadableNotEmpty(repoArtifact);

                if (!repoArtifact.delete()) {
                    logger.warn("Failed to delete :" + repoArtifact.getAbsolutePath());
                }

            } catch (Exception e) {
                // wrap all exceptions in ArtifiactRepostitoryException
                throw new ArtifiactRepostitoryException("Exception unloading build artifact. BuildArtifact:" 
                        + buildArtifact.getAbsolutePath() +  " Reason:" + e 
                        + " reference: " + reference, e);
            }

        }
        
        if (!repoArtifactDir.delete()) {
            logger.warn("Failed to delete :" + repoArtifactDir.getAbsolutePath());
        }

        deleteReference(reference);
        
        return;
    }

    /**{@inheritDoc} */
    @Override
    public synchronized boolean hasBuild(BuildInfo buildInfo) throws ArtifiactRepostitoryException {
        return getBuildReferences(buildInfo).size() > 0;
    }

    /**
     * 
     * We are supposed to be using positive control to transfer files
     * but we didn't seem to need it at this level. There is a on going
     * struggle for reading the manifest ... not the file system for things like this.
     * 
     * TODO: And use the manifest checksum function?
     * 
     * 
     * @param buildInfo the build info of your build.
     * @return an array of build artifacts.
     */
    private File[] getBuildArtifactList(BuildInfo buildInfo) {

        /* 
         * TODO should it read build folder content or the manifest?
         * For now get folder contents. TODO verify with manifest.
         * 
         * Read from manifest and compare checksums.
         */
        File[] files = buildInfo.getWorkingDir().listFiles();

        return files;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ArtifactRepositoryViewer getViewer() { 
        return new SimpleArtifactRepositoryViewer(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized Set<BuildReference> getBuildReferenceSet() {

        //TODO maybe sorted.. Hmmm ?
        Set<BuildReference> allBuildRefs = new HashSet<BuildReference>();
        for (Integer indexKey : indexMap.keySet()) {
            allBuildRefs.addAll(indexMap.get(indexKey));
        }

        return allBuildRefs;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized SortedMap<Long, Set<? extends BuildReference>> getBuildHistoryMap() {
        SortedMap<Long, Set<? extends BuildReference>> allTimeMap = new TreeMap<Long, Set<? extends BuildReference>>();
        for (Long timestamp : timeMap.keySet()) {
            allTimeMap.put(timestamp, timeMap.get(timestamp));
        }
        return allTimeMap;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized BuildReference getBuildReference(String buildId) {
        return idMap.get(buildId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized int numberOfBuilds() {
        return idMap.size();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void gc() throws ArtifiactRepostitoryException {
        logger.debug("Checking repo for expired artifacts.");
        unloadBuilds(retentionPolicy.getRemovalList(this));
        logger.debug("Done checking repo for expired artifacts.");
    }

    /**
     * Synchronized helper method to remove the set of {@link BuildReference}s from the repo's internal maps and the file system.
     * @param removalList a set of {@link BuildReference}s to remove
     * @throws ArtifiactRepostitoryException for any exception thrown
     */
    private synchronized void unloadBuilds(Set<BuildReference> removalList) throws ArtifiactRepostitoryException {
        int count = 0;
        if (removalList != null) {
            for (BuildReference reference : removalList) {
                logger.info("Unloading build from repository. BuildId:" + reference.getBuildId());
                unloadBuild(reference);
                ++count;
            }       
        }
        
        FileUtil.removeEmptyDirectories(repoRootDir);
        if (count > 0) {
            logger.info("Unloaded " + count + " build" + ((count == 1) ? "" : "s") + " from repository.");
        } else {
            logger.trace("Repository check found no builds needed to be removed.");
        }
    }

    /**
     * {@inheritDoc}
     * <p>
     * TODO: This implementation is completely inefficient and should be replaced by a running total instead of calculated
     * from scratch each call.
     */
    @Override
    public long getSizeBytes() {
        return FileUtil.folderSize(repoRootDir);    
    }

    /**
     * {@inheritDoc}
     */ 
    @Override
    public Set<String> getAllUsers() {
        return Collections.unmodifiableSet(allUsers);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getAllProjectLabels() {
        return Collections.unmodifiableSet(allProjectLabels);
    }

}
