package com.wsgc.ecommerce.buildsystem.json;
import static com.wsgc.ecommerce.buildsystem.Project.BASE_URL;
import static com.wsgc.ecommerce.buildsystem.Project.BRANCH;
import static com.wsgc.ecommerce.buildsystem.Project.EFFECTIVE_REVISION;
import static com.wsgc.ecommerce.buildsystem.Project.NAME;
import static com.wsgc.ecommerce.buildsystem.Project.REQUESTED_REVISION;
import static com.wsgc.ecommerce.buildsystem.Project.RESOLVED_URL;
import static com.wsgc.ecommerce.buildsystem.Project.UUID;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wsgc.ecommerce.buildsystem.BaseSvnExtract;
import com.wsgc.ecommerce.buildsystem.ResolvedSvnExtract;
import com.wsgc.ecommerce.utilities.json.JsonObjectDeserializer;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;

/**
 * JSON deserializer implementation for {@link ResolvedSvnExtract}
 * 
 * @author chunt
 * @version $Id$ 
 */
public class ResolvedSvnExtractDeserializer implements JsonObjectDeserializer<ResolvedSvnExtract> {
    private static final Class<ResolvedSvnExtract> JSON_DESERIALIZATION_TARGET = ResolvedSvnExtract.class; 
    private final Logger log = LoggerFactory.getLogger(getClass());
    //TODO round up these constants you have more than one now.
//    private static final String BASE_URL = "baseUrl";
//    private static final String UUID = "uuid";
//    private static final String RESOLVED_URL = "resolvedUrl";
//    private static final String EFFECTIVE_REVISION = "effectiveRevision";

    /** {@inheritDoc} */
    @Override
    public boolean canDeserializeType(String objectType) {
        return objectType.equals(ResolvedSvnExtract.ENTITY_TYPE_ID);
    }

    /** {@inheritDoc} */
    @Override
    public ResolvedSvnExtract deserialize(String objectType, String instanceId, JsonObjectInputStream json) throws IOException {
        String uuid = null;
        BaseSvnExtract baseUrl = null;
        String resolvedUrl = null;
        String effectiveRevision = null;
        String name = null;

        // assume reasonable defaults in case older json (before requested params were saved) is deserialized
        String requestedRevision = "HEAD";
        String branch = "trunk";            
        
        for (String fieldName : json.iterateObjectFieldNames()) {
            log.trace("Saw field: {}", fieldName);
            if (fieldName.equals(NAME)) {
                name = json.readString();
            } else if (fieldName.equals(UUID)) {
                uuid = json.readString();
            } else if (fieldName.equals(BASE_URL)) {
                baseUrl = json.readObject(BaseSvnExtract.class);
            } else if (fieldName.equals(RESOLVED_URL)) {
                resolvedUrl = json.readString();
            } else if (fieldName.equals(BRANCH)) {
                branch = json.readString();
            } else if (fieldName.equals(REQUESTED_REVISION)) {
                requestedRevision = json.readString();
            } else if (fieldName.equals(EFFECTIVE_REVISION)) {
                effectiveRevision = json.readString();
            } else {
                throw new JsonParseException("Unexpected field in json representation of " 
                        + JSON_DESERIALIZATION_TARGET.getName() + " " + fieldName + "'",
                        json.getTokenLocation());
            }
        }

        if (uuid == null || resolvedUrl == null || effectiveRevision == null  || baseUrl == null) {
            throw new IOException("Can't deserialize " + JSON_DESERIALIZATION_TARGET.getName() + " Null field found:  "
                    + UUID + ":" + uuid + " " + RESOLVED_URL + ":" 
                    + resolvedUrl + " " + BASE_URL + ":" + baseUrl + " " 
                    + BRANCH + ":" + branch + " " + REQUESTED_REVISION + ":" + requestedRevision);
        }
        
        
        return new ResolvedSvnExtract(name, baseUrl, effectiveRevision, resolvedUrl, uuid, branch, requestedRevision);
    }

}
