package com.wsgc.ecommerce.buildsystem;
import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import com.wsgc.ecommerce.buildsystem.BuildMonitor.BuildJobStatus;
import com.wsgc.ecommerce.buildsystem.BuildMonitor.BuildRequestStatus;
import com.wsgc.ecommerce.buildsystem.BuildMonitor.JobStatus;
import com.wsgc.ecommerce.buildsystem.exception.BuildStatusException;


/**
 * The 'standard' implementation of the BuildJobStatus interface
 * @author chunt
 * @version $Id$ 
 */
public class StandardBuildJobStatus implements BuildJobStatus {
    /*
     * The exceptions thrown here are quick to make it to the logs,
     * the internal logger is currently unused, but ready for action. 
     * 
     *  import org.slf4j.Logger;
     *  import org.slf4j.LoggerFactory;
     *  private Logger logger = LoggerFactory.getLogger(getClass().getName());
     */

    // these can appear to not be used because java doesn't read them... Freemarker does and that is a runtime error
    // waiting to happen if you remove them with out being sure.
    private JobStatus status;
    private String message = "";
    private long timestamp;
    private String user;
    private String projectLabel;
    
    private Map<String, BuildRequestStatus> buildRequestStatusMap;
    /**
     * StandardBuildService, SimpleBuildJobStatus and SimpleArtifactRepositoryView each have their own formatter that is
     * identical to this one and those DO write out formatted strings.
     * 
     * DEBATABLE: Rework classes/interfaces to share a single date formatter?
     */
    // If you are going to share it, all use must be synchronized
    private static DateFormat dateFormatter =  StandardBuildService.getDateFormatter();
//    static {
//        dateFormatter.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US)); 
//    }

    /**
     * Only constructor. Associates a {@link BuildJobStatus} with a build id found in the {@link BuildInfo}.
     * Initial state is {@link JobStatus.WAITING} 
     * 
     * @param buildInfo the buildInfo holding build data such as project and user.
     */
    public StandardBuildJobStatus(BuildInfo buildInfo) {
        buildRequestStatusMap = new HashMap<String, BuildRequestStatus>();
        this.user = buildInfo.getUser().getName();
        this.projectLabel = buildInfo.getProjectLabel();
        status = JobStatus.WAITING;
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setStatus(JobStatus jobStatus) throws BuildStatusException {
        checkBuildJobTransition(jobStatus);
        status = jobStatus;
        timestamp = System.currentTimeMillis();
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setMessage(String statusMessage) {
        message = statusMessage;
        timestamp = System.currentTimeMillis();
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setStatus(JobStatus jobStatus, String statusMessage) throws BuildStatusException {
        setStatus(jobStatus);
        message = statusMessage;
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setStatusFailed() {
        status = JobStatus.FAILED;
        timestamp = System.currentTimeMillis();
    }

    /** {@inheritDoc} */
    @Override
    public void setStatusFailed(String statusMessage) {
        status = JobStatus.FAILED;
        timestamp = System.currentTimeMillis();
        /*
         *  Here is the point where you lose the ability to clear messages
         *  with null, but you can still use "";
         */
        if (statusMessage != null) {
            message = statusMessage;
        }
    }

    /**
     *
     * Ensures we are not insanely asking for events out of sequence in the overall build job.
     * 
     * Allowed overall job transitions:
     * 
     * null -> WAITING -> PROCESSING -> ARCHIVING -> IMPORTING -> SUCCESS
     * 
     * 
     * @param newJobStatus the next status to set
     * @throws BuildStatusException if the transition is forbidden
     */
    private void checkBuildJobTransition(JobStatus newJobStatus) throws BuildStatusException {

        /**
         *  BUILD JOB STATUS (not BuildRequestStatus)
         */

        //TODO you could combine these a bit?
        if (newJobStatus.equals(JobStatus.ARCHIVING_SUCCESSFUL_BUILD)) {
            for (String buildRequestId : buildRequestStatusMap.keySet()) {
                if (!(buildRequestStatusMap.get(buildRequestId).equals(BuildRequestStatus.SUCCEEDED))) {
                    throw new BuildStatusException("Can not set overall _JOB_ build status to " + JobStatus.ARCHIVING_SUCCESSFUL_BUILD 
                            + " unless all build requests subtasks have a build _REQUEST_ status of " 
                            + BuildRequestStatus.SUCCEEDED  + " buildRequestId:" + buildRequestId + " has status:" 
                            + buildRequestStatusMap.get(buildRequestId));                        
                }
            }
        } else if (newJobStatus.equals(JobStatus.ARCHIVING_FAILED_BUILD)) {
            for (String buildRequestId : buildRequestStatusMap.keySet()) {
                if (buildRequestStatusMap.get(buildRequestId).equals(BuildRequestStatus.FAILED)) {
                    return;
                }
            }
            throw new BuildStatusException("Can not set overall _JOB_ build status to " + JobStatus.ARCHIVING_FAILED_BUILD 
                    + " unless at least one build request subtask has a build _REQUEST_ status of " 
                    + BuildRequestStatus.FAILED  + " but none where found.");                        

        }


        if ((newJobStatus.equals(JobStatus.WAITING) && status == null) 
                || (newJobStatus.equals(JobStatus.PROCESSING) && status.equals(JobStatus.WAITING)) 
                || ((newJobStatus.equals(JobStatus.ARCHIVING_SUCCESSFUL_BUILD) || (newJobStatus.equals(JobStatus.ARCHIVING_FAILED_BUILD))
                        && (status.equals(JobStatus.PROCESSING))))
                        || (newJobStatus.equals(JobStatus.IMPORTING) && status.equals(JobStatus.ARCHIVING_SUCCESSFUL_BUILD))
                        || (newJobStatus.equals(JobStatus.SUCCEEDED) && status.equals(JobStatus.IMPORTING))) {
            return;
        }

        throw new BuildStatusException("Illegal build job status transition status:" 
                + ((status == null) ? "null" : status) 
                + " new status:" + newJobStatus 
                + ((newJobStatus.equals(JobStatus.FAILED)) ? " Use setStatusFailed() instead" : ""));
    }

    /**
     * Ensures we are not insanely asking for events out of sequence at the build REQUEST level.
     * 
     * Allowed build request specific transitions: When overall status is PROCESSING.
     * 
     * FAILED is always allowed null -> EXTRACTING -> BUILDING -> COMPLETED
     * 
     * 
     * 
     * @param buildRequestId the id of the request who's status you are changing
     * @param newBuildRequestStatus the next status to be set
     * @throws BuildStatusException if the transition is not allowed
     */
    private void checkBuildRequestStatusTransition(String buildRequestId, BuildRequestStatus newBuildRequestStatus)
            throws BuildStatusException {

        /**
         *  BUILD REQUEST STATUS (not BuildJobStatus)
         */

        /*
         * Allowed build request specific transitions:
         * When  overall status is PROCESSING.
         * 
         * FAILED is always allowed 
         *  null -> EXTRACTING -> BUILDING -> COMPLETED
         *                        
         */

        if (!status.equals(JobStatus.PROCESSING)) {
            throw new BuildStatusException(
                    "Illegal build request status transition, overall job status must be JobStatus." 
                            + "PROCESSING to set build request status to " + newBuildRequestStatus 
                            + " Current status is:" + status);                
        }

        if ((newBuildRequestStatus.equals(BuildRequestStatus.EXTRACTING) && getBuildRequestStatus(buildRequestId) == null) 
                || (newBuildRequestStatus.equals(BuildRequestStatus.BUILDING) 
                        && getBuildRequestStatus(buildRequestId).equals(BuildRequestStatus.EXTRACTING)) 
                        || (newBuildRequestStatus.equals(BuildRequestStatus.SUCCEEDED) 
                                &&  getBuildRequestStatus(buildRequestId).equals(BuildRequestStatus.BUILDING))
                                || newBuildRequestStatus.equals(BuildRequestStatus.FAILED)) {
            return;
        }

        throw new BuildStatusException("Illegal build request status transition, current build request status:" 
                + ((getBuildRequestStatus(buildRequestId) == null) ? "null" : getBuildRequestStatus(buildRequestId)) 
                +  " new build request status:" + newBuildRequestStatus);
    }

    /** {@inheritDoc} */
    @Override
    public synchronized JobStatus getStatus() {
        return status;
    }

    //TODO  what is going on here?
    /** {@inheritDoc} */
//    @Override
//    public synchronized String getMessage() {
//        return message;
//    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setBuildRequestStatus(String buildRequestId,
            BuildRequestStatus newBuildRequestStatus) throws BuildStatusException {
        checkBuildRequestStatusTransition(buildRequestId, newBuildRequestStatus);
        buildRequestStatusMap.put(buildRequestId, newBuildRequestStatus);
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void setBuildRequestStatusFailed(String buildRequestId) {
        buildRequestStatusMap.put(buildRequestId, BuildRequestStatus.FAILED);
    }

    /** {@inheritDoc} */
    @Override
    public synchronized BuildRequestStatus getBuildRequestStatus(String buildRequestId) {
        return buildRequestStatusMap.get(buildRequestId);
    }

    /** {@inheritDoc} */
    @Override
    public synchronized Map<String, BuildRequestStatus> getBuildRequestStatusMap() {
        return Collections.unmodifiableMap(buildRequestStatusMap);
    }

    /** {@inheritDoc} */
    @Override
    public String getTimestamp() {
        String now = null;
        synchronized (dateFormatter) {
            now = dateFormatter.format(new Date(timestamp));
        }
        return now;
    }

    /** {@inheritDoc} */
    @Override
    public String getMessage() {
        return message;
    }

    /** {@inheritDoc} */
    @Override
    public String getUser() {
        return user;
    }
    
    /** {@inheritDoc} */
    @Override
    public String getProjectLabel() {
        return projectLabel;
    }

    /** {@inheritDoc} */
    //DEBATABLE, this setter should not exist?
    @Override
    public void setProjectLabel(String projectLabel) {
        this.projectLabel = projectLabel;
    }
}