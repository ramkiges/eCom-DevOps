package com.wsgc.ecommerce.buildsystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.BuildMonitor.JobStatus;
import com.wsgc.ecommerce.buildsystem.exception.ArtifiactRepostitoryException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.json.BuildPlanDeserializer;
import com.wsgc.ecommerce.buildsystem.json.ProjectDeserializer;
import com.wsgc.ecommerce.buildsystem.json.SvnExtractDefinitionDeserializer;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepository;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryView;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepositoryViewer;
import com.wsgc.ecommerce.buildsystem.repository.BuildReference;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;
import com.wsgc.ecommerce.buildsystem.util.MailSender;
import com.wsgc.ecommerce.utilities.json.DefaultJsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonDeserializerContext;
import com.wsgc.ecommerce.utilities.json.JsonObjectInputStream;
import com.wsgc.ecommerce.utilities.json.StandardJsonDeserializerConfig;
import com.wsgc.ecommerce.utilities.json.util.JsonJacksonUtilities;

/**
 * The only real implementation of {@link BuildService} so far.
 * 
 * @author chunt
 * @version $Id$
 */
public class StandardBuildService implements BuildService, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * TODO remove these comments, if tests prove this was a good idea. 
     * 
     * StandardBuildService, SimpleBuildJobStatus and SimpleArtifactRepositoryView each have their own formatter that is
     * identical to this one and those DO write out formatted strings.
     * 
     * DEBATABLE: Rework classes/interfaces to share a single date formatter?
     */
    // This formatter is only used for a single log info message at the end and only effects the logger not stored dates
    // in build artifacts.
    // now that you are sharing it all use must be synchronized
    private static DateFormat dateFormatter = new SimpleDateFormat();
    /* 
     * Now we provide a default initialization, which will likely be overwritten by a call to setTimeZone(String) very soon. 
     */
    static {
        synchronized (dateFormatter) {
            dateFormatter.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US));
        }
    }

    private BuildIdProvider buildIdProvider;
    @SuppressWarnings("deprecation")
    private BuildSystemConfig buildSystemConfig;

    private BuildManager buildManager;
    private BuildMonitor buildMonitor;
    private ArtifactRepository artifactRepository;
    private String projectLibraryPath;
    private String smtpHost;
    private String smtpSender;
    
    // Calculated, never set...so no setter
    private File projectDir;

    private Map<String, Project> projects;
    private ArtifactRepositoryViewer artifactRepositoryViewer;

    private String timeZone;
    private static final String BUILDSYSTEM_EMAIL_SUBJECT_SUCCESS = "Build success notification";
    private static final String BUILDSYSTEM_EMAIL_SUBJECT_FAILURE = "Build failure notification";

    /**
     * Reads the project definition files and sets the {@link ArtifactRepositoryViewer}. Currently called
     * "after properties are set" because if its {@link InitializingBean} inheritance but needs to be called regardless
     * should we every use it outside a springframework.
     * 
     * DEBATABLE: Create a default constructor and call init() from it, also doesn't need to be public.
     * 
     * @throws BuildServiceException
     *             if errors are detected
     */
    public void init() throws BuildServiceException {
        loadProjects();
        artifactRepositoryViewer = artifactRepository.getViewer();
        logger.info("###########################################");
        logger.info("## BUILD SERVICE INITIALIZATION COMPLETE ##");
        logger.info("###########################################");
    }

    /**
     * Attempts to deserialize project files from their json representation. Projects must have unique project id's or
     * there will be an exception thrown. Unlike loading builds from the repo, loading projects is an unforgiving
     * endeavor. A failure to load and project will stop the fun for everyone.
     * 
     * @throws BuildServiceException
     *             for any checked exception generated along the way.
     */
    private void loadProjects() throws BuildServiceException {
        projects = new HashMap<String, Project>();
        logger.debug("Attempting to load projects from '{}'", projectLibraryPath);

        try {
            projectDir = new File(projectLibraryPath);
            FileUtil.checkDirExistsReadableNotEmpty(projectDir);

            // attempt to load all json files found here,
            File[] files = projectDir.listFiles(); // TODO listFiles(".json");

            // TODO leave this check in, its not the same as "is the directory empty" once you set a .json file filter
            // on listFiles
            if (files.length == 0) {
                throw new BuildServiceException("No project definition files found at:" + projectDir.getAbsolutePath());
            }

            StandardJsonDeserializerConfig dConfig = new StandardJsonDeserializerConfig();

            dConfig.registerDeserializer(BuildPlan.ENTITY_TYPE_ID, new BuildPlanDeserializer());
            dConfig.registerDeserializer(SvnExtractDefinition.ENTITY_TYPE_ID, new SvnExtractDefinitionDeserializer());
            dConfig.registerDeserializer(Project.ENTITY_TYPE_ID, new ProjectDeserializer());

            JsonDeserializerContext context = DefaultJsonDeserializerContext.createInstance(dConfig);

            JsonFactory jsonFactory = new JsonFactory();

            for (File jsonFile : files) {
                // TODO better FilenameFilter
                if (!jsonFile.getName().endsWith(".json")) {
                    continue;
                }

                InputStream is;
                is = new FileInputStream(jsonFile);

                JsonParser parser = jsonFactory.createJsonParser(is);

                JsonObjectInputStream jsonIn = JsonJacksonUtilities.createObjectInputStream(parser, context);
                Project projectIn = jsonIn.readObject(Project.class);
                jsonIn.close();

                logger.info("Read project file:{} label:{} id:{}",
                        new Object[] {jsonFile.getAbsolutePath(), projectIn.getLabel(), projectIn.getId() });

                if (projects.containsKey(projectIn.getId())) {
                    throw new IOException("Project load failure. Project id '" + projectIn.getId()
                            + "' is already defined. A second attempt to define it came from file:"
                            + jsonFile.getAbsolutePath());
                }
                projects.put(projectIn.getId(), projectIn);
            }
            logger.info("Loaded " + projects.size() + " projects from '" + projectLibraryPath + "'");

        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildServiceException */
            throw new BuildServiceException(e);
        }

    }

    /**
     * Create a {@link BuildRequest} from a {@link BuildPlan} and collection of {@link ConcreteExtractDefinition}s. Not
     * part of the {@link BuildService} API, this could be private if not for the early need to use it in unit tests.
     * 
     * DEBATABLE: Make it private and fix the unit tests if we are back this way again.
     * 
     * @param buildPlan
     *            the build plan containing the {@link ExtractDefinition} spec for this build type.
     * @param reificationData
     *            a map of {@link ConcreteExtractDefinition}'s holding the revision and branch selections for each
     *            extract
     * @return A {@link BuildRequest} defining a specific concrete build request.
     * @throws BuildServiceException
     *             for any failure
     */
    public BuildRequest generateBuildRequest(BuildPlan buildPlan,
            Map<String, ? extends ConcreteExtractDefinition> reificationData) throws BuildServiceException {

        @SuppressWarnings("rawtypes")
        List<ResolvedExtract> resolvedExtracts = resolveExtracts(buildPlan, reificationData);

        if (resolvedExtracts == null) {
            throw new BuildServiceException("Attempting to generate build request with null data. resolvedExtracts:"
                    + resolvedExtracts);
        }

        BuildRequest buildRequest = new BuildRequest(buildPlan.getId(), buildPlan.getLabel(), resolvedExtracts,
                buildPlan.getBuildCommand(), buildPlan.getPostBuildCommand());

        return buildRequest;
    }

    /** {@inheritDoc} */
    @Override
    public BuildOrder generateBuildOrder(Project project, Set<String> buildPlanIds,
            Map<String, Map<String, ? extends ConcreteExtractDefinition>> concreteMaps) throws BuildServiceException {

        BuildOrder buildOrder = new BuildOrder(project.getId(), project.getLabel());

        for (String buildPlanId : buildPlanIds) {
            BuildRequest buildRequest = generateBuildRequest(project.getBuildPlan(buildPlanId),
                    concreteMaps.get(buildPlanId));
            buildOrder.addBuildRequest(buildRequest);

        }

        buildOrder.lock();
        logger.debug("{} created.\n {}", buildOrder.getClass().getName(), buildOrder.toString());
        return buildOrder;
    }

    /**
     * The buildPlan is inspected for the list of extracts it uses and the concreteExtractDefinitions is searched to
     * find the revision and branch desired for that same extract. If there isn't one, obviously we throw an exception.
     * Otherwise {@link ResolvedSvnExtractFactory} is used with each pair to generate another {@link ResolvedExtract} to
     * add to the growing collection
     * 
     * @param buildPlan
     *            the {@link BuildPlan} holding the extract definitions.
     * @param concreteExtractDefinitions
     *            {@link ConcreteExtractDefinition} matching the extract definitions of the build plan.
     * @return List of {@link ResolvedExtract} created from both
     * @throws BuildServiceException
     *             for all checked exceptions
     */
    @SuppressWarnings("rawtypes")
    public List<ResolvedExtract> resolveExtracts(BuildPlan buildPlan,
            Map<String, ? extends ConcreteExtractDefinition> concreteExtractDefinitions) throws BuildServiceException {
        List<ResolvedExtract> resolvedExtracts = new ArrayList<ResolvedExtract>();

        if (buildPlan == null || concreteExtractDefinitions == null) {
            throw new BuildServiceException("Attempting to resolve extracts with null data. BuildPlan:" + buildPlan
                    + " concreteExtractDefinitions:" + concreteExtractDefinitions);
        }

        try {

            for (String extractDefinitionKey : buildPlan.getExtractDefinitions().keySet()) {
                ExtractDefinition buildPlanExtractDefinition = buildPlan.getExtractDefinition(extractDefinitionKey);
                ConcreteExtractDefinition concreteExtractDefinition = concreteExtractDefinitions
                        .get(extractDefinitionKey);

                if (!(buildPlanExtractDefinition.getExtractType().equals(SvnExtractDefinition.ENTITY_TYPE_ID) && concreteExtractDefinitions
                        .get(extractDefinitionKey).getType().equals(SvnConcreteExtractDefinition.TYPE))) {
                    throw new BuildServiceException(
                            "Presently we can only process SVN type extract definitions. BuildPlanExtractDefinition:"
                                    + buildPlanExtractDefinition + " ConcreteExtractDefinition:"
                                    + concreteExtractDefinition);
                }

                resolvedExtracts.add(ResolvedSvnExtractFactory.create(
                        (SvnExtractDefinition) buildPlanExtractDefinition,
                        (SvnConcreteExtractDefinition) concreteExtractDefinition));
            }
        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildServiceException */
            throw new BuildServiceException("Failed to resolve extracts for build plan.  Reason:" + e + " " + buildPlan
                    + " with concrete extract definitions: " + concreteExtractDefinitions, e);
        }

        return resolvedExtracts;
    }

    /** {@inheritDoc} */
    @Override
    public Map<String, Project> getProjects() {
        return projects;
    }

    /** {@inheritDoc} */
    @Override
    public Project getProject(String projectId) {
        return projects.get(projectId);
    }

    /**
     * @param projectLibraryPath
     *            the directory holding all the project files
     */
    public void setProjectLibraryPath(String projectLibraryPath) {
        this.projectLibraryPath = projectLibraryPath;
    }

    /** {@inheritDoc} */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (buildSystemConfig == null || buildManager == null || buildMonitor == null || artifactRepository == null
                || projectLibraryPath == null || smtpHost == null || smtpHost.isEmpty() || smtpSender == null
                || smtpSender.isEmpty() || timeZone == null) {
            throw new BuildServiceException("Properties not fully set. " + toString());
        }
        init();
    }

    /**
     * TODO remove all traces of this function.
     * 
     * @throws BuildServiceException
     *             xx
     * @deprecated once used to quickly restart a server after auto code sync. Needs to be taken out of the front end
     *             code.
     */
    @Deprecated
    public void restart() throws BuildServiceException {
        @SuppressWarnings("unused")
        String[] command = {"src/test/scripts/restart.sh"};
        // try {
        // disabled
        // ProcessUtil.waitForProcess(command);
        // } catch (ProcessException e) {
        // throw new BuildServiceException("Restart process seems unhappy. Reason:" + e, e);
        // }
    }

    /** {@inheritDoc} */
    @Override
    public BuildReference runBuild(BuildOrder buildOrder, User user) throws BuildServiceException {
        BuildInfo buildInfo = new BuildInfo(buildOrder, user);
        buildInfo.setBuildId(buildIdProvider.getBuildId());
        buildInfo.setCreationTimestamp(System.currentTimeMillis());
        buildMonitor.createBuildJobStatus(buildInfo);
        return runBuild(buildInfo);
    }

    /** {@inheritDoc} */
    @Override
    public String runBuildLater(BuildOrder buildOrder, User user) throws BuildServiceException {
        final BuildInfo buildInfo = new BuildInfo(buildOrder, user);
        String buildId = buildIdProvider.getBuildId();
        buildInfo.setBuildId(buildId);
        buildInfo.setCreationTimestamp(System.currentTimeMillis());
        buildMonitor.createBuildJobStatus(buildInfo);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    runBuild(buildInfo);
                } catch (BuildServiceException e) {
                    logger.warn("Build FAILED, reason:" + e, e);
                }
            }
        });

        t.start();

        return buildId;
    }

    /**
     * 
     * Surprisingly private method since it turned out {@link BuildInfo} was the real build object, but I don't feel
     * ownership of the API so I kept it to myself.
     * 
     * @param buildInfo
     *            the object with the build definition and the place we store the history of the build.
     * @return your {@link BuildReference} to the wonderful build you have no doubt created successfully
     * @throws BuildServiceException
     *             in case you don't get that lucky
     */
    private BuildReference runBuild(BuildInfo buildInfo) throws BuildServiceException {

        BuildReference buildReference = null;

        try {

            buildReference = buildManager.runBuild(buildInfo);
            if (buildInfo.getSuccessStatus()) {
                buildMonitor.setBuildJobStatus(buildReference.getBuildId(), JobStatus.SUCCEEDED);
            } else {
                buildMonitor.setBuildJobStatusFailed(buildReference.getBuildId());
            }

            if (buildInfo.getUser().isNotifyOnSuccess() && buildInfo.getSuccessStatus()) {
                sendSuccessMessage(buildInfo.getUser().getNotificationEmails(), buildReference);
            }

            if (buildInfo.getUser().isNotifyOnFail() && !buildInfo.getSuccessStatus()) {
                sendFailureMessage(buildInfo.getUser().getNotificationEmails(), /* buildInfo.getBuildId(), */
                        buildReference);
            }

        } catch (Exception e) {
            // buildMonitor.setBuildJobStatusFailed(buildInfo.getBuildId(), e.toString());
            // logger.error("Exception running buildId:" + buildInfo.getBuildId() + " Reason:" + e, e);
            // /*
            // * if we have a failure but have a buildRef, refresh the repo with this last error.
            // */
            // if (buildReference != null) {
            // buildInfo.addException(e);
            // try {
            // buildReference = artifactRepository.updateReference(buildReference.getBuildId());
            // } catch (ArtifiactRepostitoryException are) {
            // // Just give up. Dump to logging stream here makes the code path stupidly complicated for no real obvious
            // gain.
            // throw new BuildServiceException("Failed to update repo after previous failure was logged for buildID:"
            // + buildInfo.getBuildId() + " Reason:" + are, are);
            // }
            // } else {
            // // No repo reference either? Enjoy your 500 error. Down stream code needs that artifact reference.. too
            // hard to keep going now.
            // throw new
            // BuildServiceException("Exception generated and there is no artifact repo reference to update. Exception Reason:"
            // + e, e);
            // }

            /**
             * Runtime exceptions in the build and email failures end up here. After lots of consideration...in both
             * cases we leave whatever build products there are in the repo. We don't want to fail an otherwise good
             * build because the email server was down and BuildManager.runBuild has enough 'rewrite existing manifest'
             * code to correctly retrofit errors into the manifest after build. BuildService.runBuild is going to just
             * send 500 errors at this point (AFTER writing a logger message thank you very much).
             * 
             * And we don't update the build monitor status.
             */
            logger.error("Exception running buildId:" + ((buildInfo == null) ? "NULL" : buildInfo.getBuildId())
                    + " Reason:" + e, e);
            throw new BuildServiceException("Exception in build process. Reason:" + e, e);
        }

        /**
         * phew... At this point every attempt to kill this magic assembly of bytes called "a build" has been thwarted
         * or blamed on somebody. The wounded parts of failed attempts have been evacuated from the field of battle or
         * being managed in their repo awaiting deployment orders and the after-action reports have been filed in logs.
         * The process came to a _compeletion_ so the 'build system has succeeded'. Whether or not the
         * "build is a success" is a different question. (i.e a subset of all 'build system successes'). The repo
         * already knows, update the annoying build monitor and app log.
         */
        synchronized (dateFormatter) {
            logger.info("Build "
                    + buildInfo.getBuildId()
                    + " "
                    + ((buildInfo.getSuccessStatus() ? "SUCCEEDED" : "FAILED") + " at " + dateFormatter
                            .format(new Date(buildInfo.getCompletionTimestamp()))));
        }
        return buildReference;
    }

    /**
     * Generates a message notifying someone or somebodies of the build success.
     * 
     * @param notificationEmails
     *            Collection of email addresses to send the message to
     * @param buildRef
     *            the build reference, the results of your effort
     * @throws BuildServiceException
     *             if the underlying send attempt is unhappy somehow.
     */
    private void sendSuccessMessage(Collection<String> notificationEmails, BuildReference buildRef)
            throws BuildServiceException {

        StringBuilder sb = new StringBuilder("This is an automated message from the build system.\n");
        sb.append("Build ").append(buildRef.getBuildId())
                .append(" completed successfully and is resting comfortably at ");
        sb.append(buildRef.getBuildLocation());

        sendMessage(/*smtpSender,*/ notificationEmails,
                BUILDSYSTEM_EMAIL_SUBJECT_SUCCESS + " BuildId " + buildRef.getBuildId(), sb.toString());
    }

    /**
     * Generates a message notifying someone or group of people of the build failure.
     * 
     * @param notificationEmails
     *            Collection of email addresses to send the message to
     * @param buildRef
     *            the build reference, the results of your effort, can not be null
     * @throws BuildServiceException
     *             if the underlying send attempt is unhappy somehow.
     */
    private void sendFailureMessage(Collection<String> notificationEmails, /* String buildId, */BuildReference buildRef)
            throws BuildServiceException {
        StringBuilder sb = new StringBuilder("This is an automatic message from the build system.\n");
        sb.append("Build ").append(buildRef.getBuildId()).append(" was not successful.\n");

        if (buildRef != null && buildRef.getBuildLocation() != null) {
            sb.append("Additional debugging information may be available at '" + buildRef.getBuildLocation() + "'\n");
        } else {
            sb.append("The repository can not provide a reference to this build.\n");
            sb.append("Additional debugging information may be available in the build system server application logs.\n");
        }

        sendMessage(/*smtpSender, */notificationEmails,
                BUILDSYSTEM_EMAIL_SUBJECT_FAILURE + " BuildId " + buildRef.getBuildId(), sb.toString());
    }

    /**
     * @param buildManager
     *            the buildManager to set
     */
    public void setBuildManager(BuildManager buildManager) {
        this.buildManager = buildManager;
    }

    /**
     * @param projectDir
     *            the projectDir to set
     */
//    public void setProjectDir(File projectDir) {
//        this.projectDir = projectDir;
//    }

    /** {@inheritDoc} 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     *  (buildSystemConfig == null || buildManager == null || buildMonitor == null || artifactRepository == null
                || projectLibraryPath == null || smtpHost == null || smtpHost.isEmpty() || smtpSender == null
                || smtpSender.isEmpty() || timeZone == null)
     * 
     * 
     * 
     * */
//    @Override
//    public String toString() {
//        StringBuilder builder = new StringBuilder();
//        builder.append("StandardBuildService [projectLibraryPath=").append(projectLibraryPath)
//                .append(", buildManager=").append(buildManager).append(", projectDir=").append(projectDir)
//                .append(", projects=").append(projects).append("]");
//        return builder.toString();
//    }

    /**
     * @param smtpHost
     *            the smtpHost to set
     */
    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("StandardBuildService [buildSystemConfig=").append(buildSystemConfig).append(", buildManager=")
                .append(buildManager).append(", buildMonitor=").append(buildMonitor).append(", artifactRepository=")
                .append(artifactRepository).append(", projectLibraryPath=").append(projectLibraryPath)
                .append(", smtpHost=").append(smtpHost).append(", smtpSender=").append(smtpSender)
                .append(", timeZone=").append(timeZone).append("]");
        return builder.toString();
    }

    /**
     * @param smtpSender declare the originator of the notification message
     */
    public void setSmtpSender(String smtpSender) {
        this.smtpSender = smtpSender;
    }

    /**
     * Helper message to send either good or bad news out via email.
     * 
     * @param toAddresses recipient list for this email spam.
     * @param subject the email message subject
     * @param body the body of the email message
     * @throws BuildServiceException
     *             actually quite prone to failure in practice, due to net topography. The mail server can easily be unavailable.
     */
    private void sendMessage(/*String fromAddress, */Collection<String> toAddresses, String subject, String body)
            throws BuildServiceException {
        MailSender mailSender = new MailSender();
        try {
            mailSender.sendMessage(smtpHost, smtpSender, toAddresses, subject, body);
        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildServiceException */
            StringBuilder sb = new StringBuilder();
            sb.append("Failed to send email message.");
            sb.append(" host:").append(smtpHost).append(" from address:").append(smtpSender);
            sb.append(" to addresses: [");

            StringBuilder sb2 = new StringBuilder();
            for (String toAddress : toAddresses) {
                sb2.append(toAddress).append(" ");
            }
            sb.append(sb2.toString().trim()).append("]");

            throw new BuildServiceException(sb.toString(), e);
        }
        logger.debug("Sent email to:{}", toAddresses);
    }

    /**
     * @param artifactRepository
     *            the artifactRepository to set
     */
    public void setArtifactRepository(ArtifactRepository artifactRepository) {
        this.artifactRepository = artifactRepository;
    }

    @Override
    public ArtifactRepositoryView getRepositoryView(BuildReference buildReference) throws ArtifiactRepostitoryException {
        return artifactRepositoryViewer.getView(buildReference);
    }

    /**
     * @param buildMonitor
     *            the buildMonitor to set
     */
    public void setBuildMonitor(BuildMonitor buildMonitor) {
        this.buildMonitor = buildMonitor;
    }

    /**
     * @param buildIdProvider
     *            the buildIdProvider to set
     */
    public void setBuildIdProvider(BuildIdProvider buildIdProvider) {
        this.buildIdProvider = buildIdProvider;

    }

    /**
     * @param buildSystemConfig
     *            the buildSystemConfig to set
     */
    public void setBuildSystemConfig(@SuppressWarnings("deprecation") BuildSystemConfig buildSystemConfig) {
        this.buildSystemConfig = buildSystemConfig;
    }

    /**
     * We share this formatter across the whole build system.
     * Hopefully people notice it needs external synchronization.
     * 
     * @return the {@link DateFormat}
     */
    public static DateFormat getDateFormatter() {
        return dateFormatter;
    }
    
    /**
     * Set the time zone string for the global date formatter. 
     * See TimeZone.getTimeZone for behavior.
     * @param newTimeZone the String to set as new time zone
     */
    public void setTimeZone(String newTimeZone) {
        timeZone = newTimeZone;
        synchronized (dateFormatter) {
            dateFormatter.setCalendar(Calendar.getInstance(TimeZone.getTimeZone(timeZone), Locale.US));
        }
    }
    
}
