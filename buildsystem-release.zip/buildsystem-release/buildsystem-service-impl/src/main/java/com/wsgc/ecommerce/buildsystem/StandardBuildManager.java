package com.wsgc.ecommerce.buildsystem;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import com.wsgc.ecommerce.buildsystem.BuildMonitor.BuildRequestStatus;
import com.wsgc.ecommerce.buildsystem.BuildMonitor.JobStatus;
import com.wsgc.ecommerce.buildsystem.exception.BuildManagerException;
import com.wsgc.ecommerce.buildsystem.exception.BuildServiceException;
import com.wsgc.ecommerce.buildsystem.repository.ArtifactRepository;
import com.wsgc.ecommerce.buildsystem.repository.BuildReference;
import com.wsgc.ecommerce.buildsystem.util.FileUtil;
import com.wsgc.ecommerce.buildsystem.util.HashUtil;
import com.wsgc.ecommerce.buildsystem.util.ProcessUtil;
import com.wsgc.ecommerce.utilities.json.JsonObjectOutputStream;
import com.wsgc.ecommerce.utilities.json.util.JsonJacksonUtilities;

/**
 * 
 * Our first and so far only implementation of {@link BuildManager}
 * 
 * @author chunt
 * @version $Id$
 */
public class StandardBuildManager implements BuildManager, InitializingBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(StandardBuildManager.class);

    private ArtifactRepository artifactRepository;
    private ExtractManager extractManager;
    private BuildMonitor buildMonitor;
    private ExecutorService executorService;

    private String buildSystemHostName;
    private String siteAssetDir;
    private String workingRootDir;
    private String buildSystemHome;
    private int numBuildThreads;
    private File buildSystemHomeDir;
    private File tempDir;

    private String importScriptPath;
    private boolean cleanExtractWorkingDir = true;

    private static final String EXTRACTS = "EXTRACTS";
    private static final String OUTPUT = "OUTPUT";
    private static final String INFO = "INFO";
    
    /* turns out overall log file is created in build repo directly and the individual build plans put theirs in INFO
       private static final String LOG = "LOG";
     */
    private static final String WORK = "WORK";

    private static final String BUILD_ID = "BUILD_ID";
    private static final String SITE_ASSET = "SITE_ASSET";
    private static final String GENERATION = "GENERATION";

    // In the end we need both to process the 'toc files'.
    private static final String BUILD_LOCATION = "BUILD_LOCATION";
    private static final String LOGICAL_BUILD_LOCATION = "LOGICAL_BUILD_LOCATION";

    private static final String BUILD_SYSTEM_HOST_NAME = "BUILD_SYSTEM_HOST_NAME";
    /**
     * Well known name for the manifest file. Yes, we have no extension.
     */
    public static final String MANIFEST_NAME = "MANIFEST";
    /**
     * The is the name for the standard build log, all builds should leave one of these. 
     */
    public static final String BUILD_LOG = "BUILD.LOG";
    /**
     * Name for where we keep the errors in the case of a bad build (that completed).
     */
    public static final String ERROR_LOG = "ERROR.LOG";
    /**
     * The standard name for a build plan level log file. The individual build plans will leave this the INFO directory
     * (not log) just to confuse you.
     */
    public static final String BUILD_PLAN_LOG_NAME = "log.txt";

    /**
     * The name of the file holding the serialized form of the build order that made this build. 
     */
    public static final String BUILD_ORDER_JSON_FILE = "BUILD_ORDER.JSON";
    /**
     * Universally agreed on text marker/signal from a build step saying everything is groovy and the results should be
     * taken seriously by interested parties. And by "Universally" I mean that anything that runs as a build command,
     * has to know about it.
     */
    public static final String BUILD_STEP_SUCCESS_MARKER = "OK";
    // Experimental
    // public static final String COMPLETION_TIMESTAMP_PREFIX = "Completion Timestamp:";
    // public static final String INITIATION_TIMESTAMP_PREFIX = "Initiation Timestamp";
    /**
     * Marker for the line with the string holding coded performance info from the manifest.
     *  "Build Times:start:extract cpu:extract user;build cpu:build step"
     */
    public static final String BUILD_PERFORMANCE_PREFIX = "BUILD PERFORMANCE";
    /**
     * Marker for the beginning of the overall build status line.. in the Manifest. You know the SUCCESS or FAILURE thing everyone talks about?
     */
    public static final String BUILD_SUCCESS_PREFIX = "BUILD STATUS:";

    /**
     * Marker for the use line in the manifest.
     */
    public static final String USER_PREFIX = "USER:";
    private static final String IMPORT_INFO_FILE = "importinfo.txt";

    private static final String IMPORT_INFO_FILE_FIELD_SEPARATOR = " ";
    private static final String ENCODING = "UTF-8";

    /**
     * Not used publicly but does create a file directory in the extract working dir of this name that is used to hold file
     * based results when we can be more specific about where they should live, (rather than just letting it happen in
     * the system temp dir by default).
     */
    private static final String TMP = "tmp";
    
    @Override
    public void afterPropertiesSet() throws Exception {
        if (artifactRepository == null || extractManager == null
                || workingRootDir == null || buildSystemHome == null 
                || numBuildThreads == 0   || importScriptPath == null
                || tempDir == null 
                ) {
            throw new BuildServiceException("Not all required properties are set." + toString());

        }

        // Lets not allow this at all.
        //TODO this doesn't ever fire, find out how to set empty strings in jetty-env.xml
//        if (buildSystemHostName.isEmpty()) {
//            buildSystemHostName = java.net.InetAddress.getLocalHost().getHostName();
//            LOGGER.warn("Build system host name not set, using default local host name '" + buildSystemHostName + "'"); 
//        } 
        
        // Clean tempDir in case somebody is not cleaning up. Not a solution but a help.
        if (tempDir.exists()) {
            FileUtil.removeDirectory(tempDir);
        }
        
        LOGGER.info("Setting temp directory: {}", tempDir.getAbsoluteFile());
        tempDir.mkdirs();
        FileUtil.checkDirExistsRW(tempDir);
        CommandResultInfo.setDefaultTempDirectory(tempDir);

        if (buildSystemHostName.isEmpty()) {
            throw new BuildServiceException("Host name is empty, it must be set.");
        }
        
        LOGGER.info("Build system host name is '" + buildSystemHostName + "'"); 

        buildSystemHomeDir = new File(buildSystemHome);
        FileUtil.checkDirExistsReadable(buildSystemHomeDir);
        executorService = Executors.newFixedThreadPool(numBuildThreads);
    }

    /**
     * Moves build artifacts to their repo locations, keeping track of the events in a {@link StringBuilder} for 
     * use as a manifest.
     * 
     * @param buildInfo the {@link BuildInfo} that created the build.
     * @param allOutputFiles a map of output files keyed by their build plan id 
     * @return the manifest string.
     * @throws BuildManagerException for just about any reason short of perfect success or manageable build failure.
     */
    private String processAtrifactsAndBuildManifest(BuildInfo buildInfo, Map<String, Set<File>> allOutputFiles)
            throws BuildManagerException {

        StringBuilder manifestBuilder = new StringBuilder();
        //List<BuildRequestResult> buildRequestResults = buildInfo.getBuildRequestResults();
        Set<BuildRequestResult> buildRequestResults = buildInfo.getBuildRequestResults();

        try {

            // For each build type that was run,
            for (BuildRequestResult buildRequestResult : buildRequestResults) {
                Set<File> buildRequestOutputFiles = new HashSet<File>();
                buildRequestOutputFiles.addAll(buildRequestResult.getOutputFiles());

                // This check was missing for at least a month and then only noticed via checkstyle.
                checkLogForSuccess(buildRequestResult.getInfoDir());
                
                File buildPlanLog = new File(buildRequestResult.getInfoDir(), BUILD_PLAN_LOG_NAME);
                if (!buildPlanLog.renameTo(new File(buildRequestResult.getInfoDir(), buildRequestResult.getId() + "_"
                        + BUILD_PLAN_LOG_NAME))) {
                    LOGGER.warn("Attempt to rename log file:" + buildPlanLog.getAbsolutePath() + " reported failure.");
                }
                /*
                 * if you don't reassign the object to the new named version it uses the old name even if it is 'renamed' successfully.
                 */
                buildPlanLog = new File(buildRequestResult.getInfoDir(), buildRequestResult.getId() + "_"
                        + BUILD_PLAN_LOG_NAME);
                buildRequestOutputFiles.add(buildPlanLog);

                Set<File> buildRequestArtifacts = new HashSet<File>();

                for (File buildOutputFile : buildRequestOutputFiles) {

                    FileUtil.checkFileExistsRW(buildOutputFile);
                    // sanity check the file name against a white-list of features.
                    checkBuildArtifactFileName(buildOutputFile.getName());

                    // insert build id into file name
                    String oldName = buildOutputFile.getName();
                    int suffixIndex = oldName.lastIndexOf('.');
                    String newName = oldName.substring(0, suffixIndex) + "-" + buildInfo.getBuildId()
                            + oldName.substring(suffixIndex);

                    /*
                     * move the build artifact to the main build work dir.
                     */
                    File renamedBuildArtifact = new File(buildInfo.getWorkingDir(), newName);

                    /*
                     * A correct project definition means no two artifacts should have the same name in the same build.
                     */
                    if (renamedBuildArtifact.exists()) {
                        throw new BuildManagerException("Duplicate Artifact Found: Can not rename "
                                + buildOutputFile.getAbsolutePath() + " to " + renamedBuildArtifact.getAbsolutePath()
                                + " because it already exists.");
                    }

                    // You have just renamed a build artifact in the build working dir but have not yet moved it anywhere.
                    boolean renameSuccess = buildOutputFile.renameTo(renamedBuildArtifact);

                    if (!renameSuccess) {
                        throw new BuildManagerException("Failed to rename build artifact. File:"
                                + buildOutputFile.getAbsolutePath() + " new name:"
                                + renamedBuildArtifact.getAbsolutePath());
                    }

                    FileUtil.checkFileExistsReadableNotEmpty(renamedBuildArtifact);

                    String hash = HashUtil.md5Hash(renamedBuildArtifact);
                    manifestBuilder.append(
                            renamedBuildArtifact.getName()).append(" ").append(renamedBuildArtifact.length());
                    manifestBuilder.append("-").append(hash).append('\n');

                    if (buildRequestArtifacts.contains(renamedBuildArtifact)) {
                        throw new BuildManagerException(
                                "Attempt to add duplicate file to build request artifacts set. File:"
                                        + renamedBuildArtifact);
                    }
                    buildRequestArtifacts.add(renamedBuildArtifact);

                }

                allOutputFiles.put(buildRequestResult.getId(), buildRequestArtifacts);

            }

        } catch (Exception e) {
            // Catch and wrap all exceptions in BuildManagerRuntimeException 
            buildMonitor.setBuildJobStatusFailed(buildInfo.getBuildId());
            buildInfo.addException(
                    new BuildManagerException("Failure while collecting build artifacts. Reason:" + e, e));
        }

        if (manifestBuilder.toString().isEmpty()) {
            manifestBuilder.append("no build artifacts found");
        }
        return manifestBuilder.toString();
    }
    
    /** Determine the elapsed time per builds element. Experimental. Probably useful for predictive retrieval strategy.
     * @param buildInfo the {@link BuildInfo} holding all the result sets.
     * @return the performance string ready for writing out to the manifest.
     */
    private String calculateBuildPerformanceString(BuildInfo buildInfo) {

        long totalExtractCPUTime = 0;
        long totalExtractRealTime = 0;
        long totalBuildProcessCPUTime = 0;
        long totalBuildProcessRealTime = 0;

        long earliestExtractStart = Long.MAX_VALUE;
        long earliestBuildProcessStart = Long.MAX_VALUE;
        long latestExtractEnd = 0;
        long latestBuildProcessEnd = 0;

        for (BuildRequestResult buildRequestResult : buildInfo.getBuildRequestResults()) {

            for (SourceRetrievalDetails sourceRetrievalDetails : buildRequestResult.getSourceRetrievalDetails()) {
                long startExtract = sourceRetrievalDetails.getStartTime();
                long endExtract = sourceRetrievalDetails.getEndTime();
                long durationExtract = endExtract - startExtract;

                if (startExtract < earliestExtractStart) {
                    earliestExtractStart = startExtract;
                }
                if (endExtract > latestExtractEnd) {
                    latestExtractEnd = endExtract;
                }
                totalExtractCPUTime += durationExtract;
            }

            totalExtractRealTime = latestExtractEnd - earliestExtractStart;

            for (CommandResultInfo commandResultInfo : buildRequestResult.getCommandResultInfos()) {
                long startBuildProcess = commandResultInfo.getStartTime();
                long endBuildProcess = commandResultInfo.getEndTime();
                long durationBuildProcess = endBuildProcess - startBuildProcess;

                if (startBuildProcess < earliestBuildProcessStart) {
                    earliestBuildProcessStart = startBuildProcess;
                }
                if (endBuildProcess > latestBuildProcessEnd) {
                    latestBuildProcessEnd = endBuildProcess;
                }
                totalExtractCPUTime += durationBuildProcess;
            }

            totalBuildProcessRealTime = latestBuildProcessEnd - earliestBuildProcessStart;

        }

        String performanceData = BUILD_PERFORMANCE_PREFIX + ":" + buildInfo.getCreationTimestamp() + ":"
                + totalExtractCPUTime + ":" + totalExtractRealTime + ":" + totalBuildProcessCPUTime + ":"
                + totalBuildProcessRealTime + ":" + buildInfo.getCompletionTimestamp();

        return performanceData;
    }

    /**
     * There was a requirement to do some kind of sanity check on the build artifacts, this is as far as it got. The one check 
     * is to be sure we don't accidentally pick up temp files from the build request processing. These are supposed to always be created 
     * with a trailing "_" so we can tell.
     * 
     * 
     * @param name name of a build artifact file
     * @throws BuildManagerException if it doesn't pass a white list of conditions. The only one so far is that it not
     * end in "_"
     */
    private void checkBuildArtifactFileName(String name) throws BuildManagerException {

        // does it have a name and a suffix?
        // ??
        //String[] fields = name.split(".");

        // should not end in _
        if (name.endsWith("_")) {
            throw new BuildManagerException("Artifact name must not end in '_");
        }

    }

    /**
     * 
     * Reads the end of the build plan level log file for success marker {@link #BUILD_STEP_SUCCESS_MARKER} to help tell
     * the difference between 'we stopped writing the log file' from "we are done writing the log file".
     * 
     * @param buildPlanWorkingInfoDir used to be the LOG directory but really just has to be where the {@link #BUILD_PLAN_LOG_NAME} is
     * @throws BuildManagerException if the marker is not found
     */
    private void checkLogForSuccess(File buildPlanWorkingInfoDir) throws BuildManagerException {
        /*
         * We need to look at the last line of the log file. The solutions to doing that with a random access file in
         * order to avoid reading the whole file are not pleasingly simple to me. -- We accept brute force for our
         * presumably tiny log files. FileUtil will be the place to put such a method when that guess is proven wrong.
         */
        File logFile = new File(buildPlanWorkingInfoDir, BUILD_PLAN_LOG_NAME);
        String lastLine = null;
        BufferedReader br = null;
        
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(logFile)));

            String line = null;

            while ((line = br.readLine()) != null) {
                lastLine = line;
            }
            if (!lastLine.equals(BUILD_STEP_SUCCESS_MARKER)) {
                throw new BuildManagerException("Log file success marker '" + BUILD_STEP_SUCCESS_MARKER
                        + "' was not found at the last line in log file. Log:" + logFile.getAbsolutePath());
            }
        } catch (Exception ioe) {
            // Wrap IOException with BuildManagerException
            throw new BuildManagerException("IOException while validating build request log. Reason:" + ioe, ioe);
        } finally {
            if (br != null) {
                try {
                br.close();
            } catch (IOException ioe) {
                LOGGER.error("Ignoring exception closing reader after checking log for success.  Reason:" + ioe, ioe);
            } finally {
                br = null;
            }
          }
        }
    }

    /** {@inheritDoc} */
    @Override
    protected void finalize() throws Throwable {
        if (executorService != null) {
            executorService.shutdown();
        }
        super.finalize();

    }
//    // TODO is this used? no...WHY NOT?
//    @Override
//    public Set<BuildReference> getBuildReferences(BuildInfo buildInfo) throws ArtifiactRepostitoryException {
//        return artifactRepository.getBuildReferences(buildInfo);
//    }
    
    /**
     * @return the build system bin script exe directory.
     */
    /**
     * @return the build system exe/script/home directory depending on who you talk to
     */
    public String getBuildSystemHome() {
        return buildSystemHome;
    }
    /**
     * @return the bgbImportScriptPath
     */
    public String getImportScriptPath() {
        return importScriptPath;
    }
    
    /**
     * Helper method to read import info formatted lines. Well, more of a custom Assert statement than a helper in that
     * it will just throw an exception if any of your predictions are not found. 
     * <br>That sort of helps.
     * 
     * @param line
     *            the {@link String} to parse
     * @param key
     *            such as of {@link ImportInfoBean#PROVIDES}
     * @param numExpectedFields
     *            the number of files you expect with that key, used for sanity checking
     *            
     * @return TODO I have a bimodal return going on here.... ugly needs more comments if you don't get rid of value, its used to parse site id
     *
     * @throws IOException if the number of fields is not seen
     * @see {@link ImportInfoBean}
     */
    private String getLineValueByKey(String line, String key, int numExpectedFields) throws IOException {
        if (line == null) {
            throw new IOException("End of file reached before finding key '" + key + "'");
        }

        String[] fields = line.split(IMPORT_INFO_FILE_FIELD_SEPARATOR);
        if (fields.length != numExpectedFields) {
            throw new IOException("Error parsing line '" + line + "' expecting " + numExpectedFields
                    + " fields but found " + fields.length);
        }

        if (!fields[0].equals(key)) {
            throw new IOException("Error parsing line '" + line + "' expecting key '" + key + " but didn't find it.");
        }

        String value = null;
        if (numExpectedFields  == 1) {
            value = "";
        } else {
            value =  line.substring(fields[0].length() + IMPORT_INFO_FILE_FIELD_SEPARATOR.length());
        }
        return value;
    }
    /**
     * @return the numBuildThreads
     */
    public int getNumBuildThreads() {
        return numBuildThreads;
    }

    /**
     * @return the siteAssetsDir
     */
    public String getSiteAssetsDir() {
        return siteAssetDir;
    }

    /**
     * Reads a build plan directory and updates {@link ImportInfoBean} reference with the relevant 'requires' 'provides'
     * found there.
     * 
     * @param buildPlanDir the extract working directory where the build plan was processed
     * @param importInfoBean a running total of the entire build process import data
     * @throws BuildManagerException for errors including the fact these processes have no sense of humor about unexpected fields or line sequence.
     */
    private void processBuildPlanImportInfo(File buildPlanDir, ImportInfoBean importInfoBean)
            throws BuildManagerException {

        File buildPlanImportInfoFile = new File(buildPlanDir, OUTPUT + File.separator + IMPORT_INFO_FILE);

        try {

            FileUtil.checkFileExistsReadable(buildPlanImportInfoFile);

            LOGGER.debug("Processing build plan level import information file '{}'", buildPlanImportInfoFile.getAbsolutePath());
           
            BufferedReader readerIn = new BufferedReader(new FileReader(buildPlanImportInfoFile));

            /**
             * ImportInfo header must be at the beginning of the file so readHeader gets first crack at the shared input stream.
             */
            readHeader(readerIn, importInfoBean);

            readProvidesRequires(readerIn, importInfoBean, buildPlanDir);

        } catch (Exception e) {
            throw new BuildManagerException("Failure processing build plan import info file:" + buildPlanImportInfoFile
                    + " Reason:" + e, e);
        }

    }

    /**
     * Helper method to capture the header information from a build plan level import info result.
     * 
     * @param fileIn file to parse
     * @param importInfoBean {@link ImportInfoBean} reference to populate
     * @throws IOException if format does not exactly match expectations
     */
    private void readHeader(BufferedReader fileIn, ImportInfoBean importInfoBean) throws IOException {

        String line = fileIn.readLine();

        String value = getLineValueByKey(line, ImportInfoBean.SITE, 2);
        /*
         * Verify the value can be converted to an int but discard the results. We use the whole original line instead.
         */
        try {
            String.valueOf(Integer.parseInt(value));
        } catch (NumberFormatException nfe) {
            throw new IOException("Can not find numeric " + ImportInfoBean.SITE + " field in '" + line + "'", nfe);
        }
        String site = line;

        line = fileIn.readLine();
        value = getLineValueByKey(line, ImportInfoBean.BUILD, 2);
        // possible TODO, check field values for reasonable numbers not just format.
        //        if (!value.matches(BUILD_ID_REGEX)) {
        //            throw new IOException("Unable to parse build id string. Expecting format '" + BUILD_ID_REGEX + " found '"
        //                    + value);
        //        }

        String build = line;

        line = fileIn.readLine();

        /**
         * Current advice is we are not using "label".
         */
        value = getLineValueByKey(line, ImportInfoBean.LABEL, 3);
        // Label seems to have no restrictions as to content. If we find something at all, keep it.
        String label = line;

        //line = fileIn.readLine();
        // Must have one provides line and it has to be generation. We don't validate the format of the generation string. No promises it's eternal.
        // value = getLineValueByKey(line, ImportInfoBean.PROVIDES, 3);
        // if (!value.startsWith(ImportInfoBean.GENERATION)) {
        // throw new IOException("Unable to parse '" + ImportInfoBean.PROVIDES + "' line for '"
        // + ImportInfoBean.GENERATION + "' Line '" + line + "'");
        // }

        StringBuilder sb = new StringBuilder();
        String newHeader = sb.append(site).append("\n").append(build).append("\n").append(label).toString();

        if (importInfoBean.getHeader() == null) {
            importInfoBean.setHeader(newHeader);
        } else {
            if (!importInfoBean.getHeader().equals(newHeader)) {
                throw new IllegalArgumentException("Build plan import info header mismatch. Expecting:"
                        + importInfoBean.getHeader() + " Found:" + newHeader);
            }
        }
    }

    /**
     * 
     * Helper method to parse both provides and requires sections of a build plan level import info file.
     * 
     * @param reader
     *            a reader pointing at sub-importInfo.txt file to assimilate
     * @param importInfoBean
     *            the {@link ImportInfoBean} reference to add this files info to
     * @param buildPlanDir
     *            the location of the import info file that the reader is pointing to
     * @throws IOException
     *             for things ranging from bad disk sectors to seeing lines and fields out of expected sequence TODO:
     *             Someone should write down the spec for importInfo.txt since its been in use since build system 1 and
     *             the original BGB, it is probably 'on the lan somewhere'.
     */
    private void readProvidesRequires(BufferedReader reader, ImportInfoBean importInfoBean, File buildPlanDir)
            throws IOException {

        String line = reader.readLine();

        /**
         * Not using value here at all, works with site id, should be refactored.
         */
        @SuppressWarnings("unused")
        String value =  getLineValueByKey(line, ImportInfoBean.PROVIDES, 3);
        importInfoBean.addProvides(line);
        line = reader.readLine();

        while (line.startsWith(ImportInfoBean.PROVIDES)) {
            value = getLineValueByKey(line, ImportInfoBean.PROVIDES, 3);
            importInfoBean.addProvides(line);
            line = reader.readLine();
        }

        value = getLineValueByKey(line, ImportInfoBean.REQUIRES, 3);
        importInfoBean.putRequires(buildPlanDir.getAbsolutePath(), line);

        line = reader.readLine();

        while (line.startsWith(ImportInfoBean.REQUIRES)) {
            value = getLineValueByKey(line, ImportInfoBean.REQUIRES, 3);
            importInfoBean.putRequires(buildPlanDir.getAbsolutePath(), line);
            line = reader.readLine();
        }

        // validate but discard
        getLineValueByKey(line, BUILD_STEP_SUCCESS_MARKER, 1);

        // make sure its the last line in the file.
        line = reader.readLine();
        if (line != null) {
            throw new IOException(BUILD_STEP_SUCCESS_MARKER
                    + " was not the last line in input file. Additional line found was '" + line + "'");
        }

    }

    /**
     * 
     * This is the last thing the build system attempts to do. Any activity from here to the user seeing a home page on their browser has 
     * to do with downstream systems like BigGreenButton. This is our attempt to notify BGB that a build exists. Other processes will stage and 
     * active a build once it has been "imported" to BGB.
     * 
     * This is how it gets imported.
     * 
     * @param buildTmpDir your builds working directory
     * @param buildReference the repo object that hold your build.
     * @throws BuildManagerException if the import script
     */
    private void ringLittleGreenDoorBell(File buildTmpDir, BuildReference buildReference) throws BuildManagerException {

        //TODO clean this up, um ok.. in what way?
        File importScript = new File(importScriptPath);
        File importScriptDir = importScript.getParentFile().getAbsoluteFile();
        File importResultsFile = null;

        try {
            importResultsFile = File.createTempFile("importscript_", "." + FileBasedResultsHolder.RESULTS_FILE_SUFFIX, buildTmpDir);
            buildMonitor.setBuildJobStatus(buildReference.getBuildId(), JobStatus.IMPORTING);
            if (importScriptDir == null) {
                throw new BuildManagerException("Unable to determine working directory from import script path '" 
                        + importScriptPath);
            }
            FileUtil.checkDirExists(importScriptDir);
            FileUtil.checkFileExistsExectable(importScript);
        } catch (Exception e) {
            // Wrap all Exceptions with BuildManagerException
            throw new BuildManagerException("Unable to execute import script path '" 
                    + importScriptPath + "' Reason:" + e, e);
        }

        List<String> command = new ArrayList<String>(1);

        command.add(importScript.getAbsolutePath());
        String importInfoPath = buildReference.getBuildLocation().getAbsolutePath() + File.separator + IMPORT_INFO_FILE; 
        command.add(importInfoPath);

        Map<String, String> env = new HashMap<String, String>();

        LOGGER.debug("####################################################################");
        LOGGER.debug("# Ringing the little green doorbell for build {} #", buildReference.getBuildId());
        LOGGER.debug("####################################################################");
        LOGGER.debug("Executing command '{}'", command);
        // note runCommand not runBuildCommand.
        CommandResultInfo commandResultInfo = ProcessUtil.runCommand(new CommandResultInfo(importResultsFile), command, importScriptDir, env);

        try {
            CommandResultInfo.validate(commandResultInfo);
        } catch (Exception e) {
            /*
             * Set status to fail, but it should be redundant as the thrown exception should get further processing..
             * Wrap IOException with BuildManagerException
             */
            buildMonitor.setBuildJobStatusFailed(buildReference.getBuildId());
            throw new BuildManagerException("BGB import FAILED. Reason:" + e, e);
        }
        LOGGER.debug("Import script execution complete for build id:{}", buildReference.getBuildId());
    }

    /** {@inheritDoc} 
     * TODO Too long, start 'methodizing'.
     */
    @Override
    public BuildReference runBuild(BuildInfo buildInfo) throws BuildManagerException {
        CompletionService<BuildRequestResult> completionService = new ExecutorCompletionService<BuildRequestResult>(
                executorService);

        File buildWorkingDir = new File(new File(workingRootDir), buildInfo.getBuildId());
        buildWorkingDir.mkdirs();
        
        // used to hold file base results holders
        File buildTmpDir = new File(buildWorkingDir, TMP);
        buildTmpDir.mkdirs();

        // Futures for all submitted Callables that have not yet been checked
        Set<Future<BuildRequestResult>> futures = new HashSet<Future<BuildRequestResult>>();

        try {
            FileUtil.checkDirExistsRW(buildWorkingDir);
            FileUtil.checkDirExistsRW(buildTmpDir);
            buildInfo.setBuildWorkingDir(buildWorkingDir);

            int debugIndex = buildInfo.getIndex();
            LOGGER.trace("Before build BuildId.getIndex():{} buildInfo:", debugIndex, buildInfo.toString());

            buildMonitor.setBuildJobStatus(buildInfo.getBuildId(), JobStatus.PROCESSING);

            for (BuildRequest buildRequest : buildInfo.getBuildOrder().getRequestSet()) {
                final BuildRequest finalBuildRequest = buildRequest;
                final File finalBuildWorkDir = buildWorkingDir;
                buildMonitor.setBuildJobStatusMessage(buildInfo.getBuildId(),
                        "Running build request '" + buildRequest.getId() + "'");

                /*
                 * This is where your number of build threads affects performance.
                 */
                // keep track of the futures that get created so we can cancel them if necessary
                futures.add(completionService.submit(new Callable<BuildRequestResult>() {
                    @Override
                    public BuildRequestResult call() {
                        return runBuildRequest(finalBuildWorkDir, finalBuildRequest);
                    }
                }));
            }

        } catch (Exception e) {
            /**
             * TODO deeply consider the wisdom of trying to catch the runtime exceptions possible with this call. We
             * need to test the failure path either way. Currently we catch and wrap all Exceptions with BuildManagerException
             */
            //LOGGER.error("Exception while processing build request thread tasks. Reason:" + e, e);
            buildMonitor.setBuildJobStatusFailed(buildInfo.getBuildId());
            buildInfo.addException(new BuildManagerException(
                    "Exception while processing build request thread tasks. Reason:" + e, e));
        }

        Future<BuildRequestResult> completedFuture = null;
        BuildRequestResult returnedBuildRequestResult = null;

        // TODO move the try block to the outside of this loop.
        while (futures.size() > 0) {
            try {
                // block until a callable completes or throws and exception.
                completedFuture = completionService.take();
                futures.remove(completedFuture);
                returnedBuildRequestResult = completedFuture.get();

                buildInfo.registerBuildRequestResult(returnedBuildRequestResult);

                if (!returnedBuildRequestResult.getSuccessStatus()) {
                    LOGGER.warn("BuildRequest FAILED. Reason: " + returnedBuildRequestResult.getLastException(),
                            returnedBuildRequestResult.getLastException());
                    // Shutdown anyone still working, this build has already failed.
                    //stopBuild(futures);
                    break;
                }

            } catch (Exception e) {
                /* This exception should not prevent us from
                 * getting other pending results. 
                    stopBuild(futures);  likely not resource safe
                
                    catch and wrap all Exceptions with BuildManagerException
                
                */
                buildMonitor.setBuildJobStatusFailed(buildInfo.getBuildId());
                buildInfo.addException(new BuildManagerException(
                        "Exception while collecting build request thread results. Reason:" + e, e));
            }
        }

        // Set 'completion time' in manifest before you load build in to repo... (load build reads the manifest)
        buildInfo.setCompletionTimestamp(System.currentTimeMillis());

        BuildReference buildReference = null;
        Map<String, Set<File>> buildRequestArtifacts = new HashMap<String, Set<File>>();
        String manifestContents = null;

        boolean errorlogWritten = false;
        try {
            buildMonitor.setBuildJobStatus(buildInfo.getBuildId(), 
                    buildInfo.getSuccessStatus() ? JobStatus.ARCHIVING_SUCCESSFUL_BUILD : JobStatus.ARCHIVING_FAILED_BUILD);
            manifestContents = processAtrifactsAndBuildManifest(buildInfo, buildRequestArtifacts);
            serializeBuildOrder(buildInfo);
            writeBuildLog(buildInfo, buildInfo.getWorkingDir());
            writeManifest(buildInfo, manifestContents, buildInfo.getWorkingDir());            
            buildReference = artifactRepository.loadBuild(buildInfo);
            LOGGER.debug("BuildReference created, {}", buildReference);

            /*
             * the only implementation we have at the time of writing, will not do this but lets check in case the future is more creative.
             */
            if (buildReference == null) {
                throw new BuildManagerException("Build load in to repository returned a null reference.");
            }

            if (buildInfo.getSuccessStatus()) {
                runPostBuildCommands(buildWorkingDir, buildReference, buildRequestArtifacts);
            }

            if (buildInfo.getSuccessStatus()) {
                ringLittleGreenDoorBell(buildTmpDir, buildReference);
            }

        } catch (Exception e) {
           /*We catch and wrap all Exceptions with BuildManagerException */
            buildMonitor.setBuildJobStatusFailed(buildInfo.getBuildId());
            buildInfo.addException(e);
            LOGGER.error("Build " + buildInfo.getBuildId() + " FAILED. Reason:" + e, e);

            /**
             * 
             * TODO move if statement to separate method
             * 
             */

            /*
             * Update the manifest and logs with our new surprising disappointments. One of reasons we
             * are in this catch block may (or may not) be the fact we can't do things like write the manifest
             * or logs with details of the original error. So we guard every attempt to follow and continue if at
             * all possible. If the repo load process left us a buildReference we try to update the repo version. 
             *
             * If there is no build reference we write the logs to the build working directory and throw at the 
             * end to notify the build failed without generating a build reference (even to a failed build) and
             * to warn everyone we tried to put the crash data in the working directory.
             */

            if (buildReference != null) {    

                //serializeBuildOrder(buildInfo);
                writeBuildLog(buildInfo, buildReference.getBuildLocation());
                // write error log here in case it turns out to be impossible to write manifest later.
                writeErrorLog(buildInfo, buildReference.getBuildLocation()); 
                errorlogWritten = true;
                /*
                 *  This can always fail, (and depending on why we are in a catch block, this may be the second time we are trying).
                 *  By this time we might have a error log of the original failure when the 500 internal service error is generated.
                 */
                writeManifest(buildInfo, manifestContents, buildReference.getBuildLocation());

                //refresh the repo record but leave the collection of files as is.
                //                SimpleBuildReference newBuildReference = new SimpleBuildReference(buildInfo.getBuildId(), buildReference.getLocation());
                //                artifactRepository.deleteReference(buildReference);
                //                artifactRepository.addReference(newBuildReference);
                //                buildReference = newBuildReference;

                //                buildReference = artifactRepository.updateReference(buildReference.getBuildId());

            } else {
                //truly a bad day is underway. Dump to log file seems the best solution.
                dumpErrorsToLogger(buildInfo);
                String logwarning = "Build " + buildInfo.getBuildId() + " FAILED with no repository reference to log errors to.\n";                 
                throw new BuildManagerException(logwarning + "Check log for any available error information."); 
            }
            //If we made it this far, fall through.
        }   // catch BuildManagerException block 

        //If we are here because we fell through the previous catch block, only write one error log.
        if (!buildInfo.getSuccessStatus() && !errorlogWritten) {
            /*
             * if this throws an exception, we give up, its going escape this method and wind up as a 500 error.
             */
            writeErrorLog(buildInfo,  buildReference.getBuildLocation());
        }


        if (cleanExtractWorkingDir) {
            FileUtil.removeDirectory(buildWorkingDir);
        }

        if (buildWorkingDir.exists()) {
            if (!cleanExtractWorkingDir) {
                LOGGER.warn("Clean up process disabled. Folder not deleted: " + buildWorkingDir.getAbsolutePath());
            } else {
                LOGGER.warn("Failed to delete folder: " + buildWorkingDir.getAbsolutePath());
            }
        }

        return buildReference;
    }

    /**
     * TODO started as an experimental hack added to patch the forensic record in the worst case. There is another method
     * somewhere that needs to be quarantined/refactored with this one but I can't find it right now.
     * 
     * ... Ah Look at {@link CommandResultInfo#readResultsToErrorLog(Logger, CommandResultInfo)} These should be combined
     * 
     * 
     * @param buildInfo {@link BuildInfo} with the build history about to be thrown in to a sequence of scary build log entries.
     * @throws BuildManagerException if {@link StandardBuildManager#ENCODING} is not supported
     */
    private void dumpErrorsToLogger(BuildInfo buildInfo) throws BuildManagerException {
        String logwarning = "Build " + buildInfo.getBuildId() + " FAILED with no repository reference to log errors to.\n"; 

        // Dynamically resizes, but not sure this is a very safe idea anyway.
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        
        writeLog(buildInfo, true, baos);
        try {
            LOGGER.error(logwarning + "ERROR LOG:\n" + baos.toString(ENCODING) + "\n");
        } catch (UnsupportedEncodingException usee) {
            throw new BuildManagerException(usee);
        }                
    }

    /**
     * 
     * We always want to know what happened in a build request ... so this method always returns an object with an error state 
     * (possibility set to 'none')
     *  
     * Its up to someone else to read it and throw exceptions if needed. 
     * 
     * @param buildWorkingDir the working directory for this build request
     * @param buildRequest the {@link BuildRequest} holding all build commands and specs
     * @return {@link BuildRequestResult} of the attempt
     */
    public BuildRequestResult runBuildRequest(File buildWorkingDir, BuildRequest buildRequest) {

        BuildRequestResult buildRequestResult = new BuildRequestResult(buildRequest);
        buildRequestResult.setStartTime(System.currentTimeMillis());
        CommandResultInfo commandResultInfo = null;

        File buildPlanWorkingDir = null;
        File buildPlanWorkingOutputDir = null;
        File buildPlanTmpDir = null;
        
        try {

            buildPlanWorkingDir = new File(buildWorkingDir, buildRequest.getId());
            buildPlanWorkingDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanWorkingDir);

            buildPlanWorkingOutputDir = new File(buildPlanWorkingDir, OUTPUT);
            buildPlanWorkingOutputDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanWorkingOutputDir);

            File buildPlanWorkingExtractsDir = new File(buildPlanWorkingDir, EXTRACTS);
            buildPlanWorkingExtractsDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanWorkingExtractsDir);

            File buildPlanWorkingInfoDir = new File(buildPlanWorkingDir, INFO);
            buildPlanWorkingInfoDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanWorkingInfoDir);
            buildRequestResult.setInfoDir(buildPlanWorkingInfoDir);

            // Worst name ever ( ..... so far).
            File buildPlanWorkingWorkDir = new File(buildPlanWorkingDir, WORK);
            buildPlanWorkingWorkDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanWorkingWorkDir);

            buildPlanTmpDir = new File(buildWorkingDir, TMP);
            buildPlanTmpDir.mkdirs();
            FileUtil.checkDirExistsRW(buildPlanTmpDir);

            List<ExtractTargetMapping> extractTargets = extractManager.getExtractTargets(buildPlanWorkingExtractsDir,
                    buildRequest);

            buildMonitor.setBuildRequestStatus(buildRequest, BuildRequestStatus.EXTRACTING);

            List<SourceRetrievalDetails> sourceRetrievalDetails = extractManager.performExtracts(extractTargets);
            buildRequestResult.addSourceDetails(sourceRetrievalDetails);

        } catch (Exception e) {
            /*We catch and store all Exceptions
             * DEBATABLE, should be throwable if you are going this far. 
             */
            buildMonitor.setBuildRequestStatusFailed(buildRequest);
            buildRequestResult.setSuccessStatus(false);
            buildRequestResult.setLastException(e);
            return buildRequestResult;
        }

        try {

            File resultsFile = File.createTempFile(buildRequest.getId() + "_buildcommand",
                    "." + FileBasedResultsHolder.RESULTS_FILE_SUFFIX, buildPlanTmpDir);
            FileUtil.checkFileExistsRW(resultsFile);

            Map<String, String> env = new HashMap<String, String>();
            env.put(BUILD_ID, buildRequest.getBuildId());
            env.put(GENERATION, buildRequest.getGenerationId());
            env.put(SITE_ASSET, siteAssetDir);

            buildMonitor.setBuildRequestStatus(buildRequest, BuildRequestStatus.BUILDING);

            commandResultInfo = ProcessUtil.runBuildCommand(new CommandResultInfo(resultsFile),
                    buildRequest.getBuildCommand(), buildPlanWorkingDir, buildSystemHomeDir.getAbsolutePath(), env);

            // commandResultInfo.getLog());

            if (LOGGER.isDebugEnabled()) {
                CommandResultInfo.readResultsToDebugLog(LOGGER, commandResultInfo);
            }

            buildRequestResult.addCommandInfo(commandResultInfo);

            CommandResultInfo.validate(commandResultInfo);
            buildRequestResult.addAllOutputFiles(buildPlanWorkingOutputDir);

            buildRequestResult.setEndTime(System.currentTimeMillis());
            buildMonitor.setBuildRequestStatus(buildRequest, BuildRequestStatus.SUCCEEDED);

        } catch (Exception e) {
            /* We catch and store all Exceptions */
            buildMonitor.setBuildRequestStatusFailed(buildRequest);
            buildRequestResult.setSuccessStatus(false);
            buildRequestResult.setLastException(e);
        }

        return buildRequestResult;
    }

    /**
     * Transfers the contents of the internal {@link ResultsHolder} to a {@link PrintWriter}.
     * Preserves new lines in original results.
     * 
     * @param printWriter the {@link PrintWriter} to write to
     * @param commandResultInfo the {@link CommandResultInfo} to read
     * @throws IOException for the usual reader, writer IO failures
     */
    private static void writeResults(PrintWriter printWriter, CommandResultInfo commandResultInfo) throws IOException {
        BufferedReader resultsReader = commandResultInfo.getResultsReader();
        LOGGER.debug("Using BufferedResultsReader {}", resultsReader);
        String line = resultsReader.readLine();
        while (line != null) {
            printWriter.println(line);
            line = resultsReader.readLine();
        }
        resultsReader.close();        
    }


    /**
     * Create the import info file from build plan level sub files and write the collection to disk.
     * 
     *  TODO reduce params to buildRef
     *  
     * @param buildWorkingDir the build level working directory where all your build plans have been running
     * @param buildPlanDirs a list of build plan dirs
     * @param buildRef the {@link BuildReference} of your otherwise completed build
     * @throws IOException if the file system is found to be missing ..etc. 
     * @throws BuildManagerException if the import info sub files are malformed
     */
    private void runImportInfoProcessing(File buildWorkingDir, Set<File> buildPlanDirs, BuildReference buildRef)
            throws IOException, BuildManagerException {
  
        LOGGER.debug("###############################################");
        LOGGER.debug("# Processing build request {} files.", IMPORT_INFO_FILE);
        LOGGER.debug("###############################################");
  
        /**
         *  Collect import info sub-file from all build types and append 
         *  them to a single file. Place a copy in the repo.
         */
        File importInfoFile = new File(buildWorkingDir, IMPORT_INFO_FILE);
        File repoImportInfoFile = new File(buildRef.getBuildLocation(), IMPORT_INFO_FILE);

        if (importInfoFile.exists()) {
            throw new IOException("File already exists. File:" + importInfoFile.getAbsolutePath());
        }

        ImportInfoBean importInfoBean = new ImportInfoBean();

        for (File buildPlanDir : buildPlanDirs) {
            processBuildPlanImportInfo(buildPlanDir, importInfoBean);
        }

        writeImportInfoFile(importInfoBean, importInfoFile);
        FileUtil.copyFile(importInfoFile, repoImportInfoFile);

        LOGGER.debug("######################################");
        LOGGER.debug("# {} processing finished #", IMPORT_INFO_FILE);
        LOGGER.debug("######################################");
        //            double fate = Math.random();
        //            if (fate > 0.9999) {
        //                LOGGER.debug("History is made in the night. Character is what you are in the dark.");
        //            }

    }

    /**  
     * This originally meant just run any command that was not "the" build command. The environmental variables evolved as needed.
     * What actually happens here depends on the project definition files use of the post build command section.
     * 
     * @param buildWorkingDir the build working directory
     * @param buildReference the {@link BuildReference} of your build
     * @param buildRequestArtifacts a {@link Set} of files aka your build artifacts
     * @throws BuildManagerException any surprises
     */
    private void runPostBuildCommands(File buildWorkingDir, BuildReference buildReference,
            Map<String, Set<File>> buildRequestArtifacts) throws BuildManagerException {
        try {
            
            // could be a method argument, could be implicit, was added at last minute.
            File buildTmpDir = new File(buildWorkingDir, TMP);
            FileUtil.checkDirExistsRW(buildTmpDir);
            
            BuildOrder buildOrder = buildReference.getBuildOrder();
            Set<BuildRequest> buildRequests = buildOrder.getRequestSet();
            Set<File> buildPlanDirs = new HashSet<File>();

            Map<String, String> env = new HashMap<String, String>();
            env.put(BUILD_ID, buildOrder.getBuildId());
            env.put(GENERATION, buildOrder.getGenerationId());
            env.put(SITE_ASSET, siteAssetDir);
            env.put(BUILD_LOCATION, buildReference.getBuildLocation().getAbsolutePath());
            env.put(LOGICAL_BUILD_LOCATION, buildReference.getLogicalLocation());
            env.put(BUILD_SYSTEM_HOST_NAME, buildSystemHostName);

            // Suggestion: multi-thread this?

            for (BuildRequest buildRequest : buildRequests) {
                //if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("#########################################################################");
                LOGGER.debug(" RUNNING POST BUILD COMMAND for build request:{}", buildRequest.getId());
                LOGGER.debug("#########################################################################");
                //}
                File buildPlanWorkingDir = new File(buildWorkingDir, buildRequest.getId());
                buildPlanDirs.add(buildPlanWorkingDir);

                List<String> postBuildCommandArgs = new ArrayList<String>();
                postBuildCommandArgs.addAll(buildRequest.getPostBuildCommand());

                for (File file : buildRequestArtifacts.get(buildRequest.getId())) {
                    postBuildCommandArgs.add(file.getName());
                }

                File resultsFile = File.createTempFile(buildRequest.getId() + "_postbuild", 
                        FileBasedResultsHolder.RESULTS_FILE_SUFFIX, buildTmpDir); 

                CommandResultInfo commandResultInfo = ProcessUtil.runBuildCommand(new CommandResultInfo(resultsFile),
                        postBuildCommandArgs, buildPlanWorkingDir, buildSystemHomeDir.getAbsolutePath(), env);
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("POST BUILD COMMAND results log:");
                    CommandResultInfo.readResultsToDebugLog(LOGGER, commandResultInfo);
                }
                CommandResultInfo.validate(commandResultInfo);
            }
            runImportInfoProcessing(buildWorkingDir, buildPlanDirs, buildReference);

        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildManagerException */
            throw new BuildManagerException("Failure during post build processing. Reason:" + e, e);
        }
    }


    /**
     * Leaves a serialized json copy of the build order used in the provided {@link BuildInfo}
     * 
     * @param buildInfo the {@link BuildInfo} with the {@link BuildOrder} to serialize
     * @throws BuildManagerException for any exception thrown by the process
     */
    private void serializeBuildOrder(BuildInfo buildInfo) throws BuildManagerException {
        try {
            File jsonFile = new File(buildInfo.getWorkingDir(), BUILD_ORDER_JSON_FILE);

            OutputStream os = new FileOutputStream(jsonFile);
            JsonFactory jsonFactory = new JsonFactory();
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(os, JsonEncoding.UTF8);
            jsonGen.useDefaultPrettyPrinter();
            JsonObjectOutputStream jsonOut = JsonJacksonUtilities.createObjectOutputStream(jsonGen, null);

            jsonOut.writeObject(buildInfo.getBuildOrder());

            jsonOut.close();
            os.close();

        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildManagerException */
            throw new BuildManagerException("Failed to serialize BuildOrder. Reason:" + e, e);
        }

    }

    /**
     * @param artifactRepository duh
     */
    public void setArtifactRepository(ArtifactRepository artifactRepository) {
        this.artifactRepository = artifactRepository;
    }

    /**
     * @param buildMonitor
     *            the buildMonitor to set
     */
    public void setBuildMonitor(BuildMonitor buildMonitor) {
        this.buildMonitor = buildMonitor;
    }

    /**
     * @param buildSystemHostName the buildSystemHostName to set
     */
    public void setBuildSystemHostName(String buildSystemHostName) {
        this.buildSystemHostName = buildSystemHostName;
    }

    /**
     * Hold extract directory for forensic look-see.
     *  
     * @param cleanExtractWorkingDir
     *            the cleanWorkingDir to set
     */
    public void setCleanExtractWorkingDir(boolean cleanExtractWorkingDir) {
        this.cleanExtractWorkingDir = cleanExtractWorkingDir;
    }

    /**
     * @param buildSystemHome
     *            the commandPath to set
     */
    public void setBuildSystemHome(String buildSystemHome) {
        this.buildSystemHome = buildSystemHome;
    }

    /**
     * @param commandPathDir
     *            the commandPathDir to set
     */
//    public void setCommandPathDir(File commandPathDir) {
//        this.commandPathDir = commandPathDir;
//    }

    /**
     * @param executorService
     *            the executorService to set
     */
    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    /**
     * @param extractManager
     *            the extractManager to set
     */
    public void setExtractManager(ExtractManager extractManager) {
        this.extractManager = extractManager;
    }

    /**
     * @param importScriptPath the bgbImportScriptPath to set
     */
    public void setImportScriptPath(String importScriptPath) {
        this.importScriptPath = importScriptPath;
    }

    /**
     * @param numBuildThreads
     *            the numBuildThreads to set
     */
    public void setNumBuildThreads(int numBuildThreads) {
        this.numBuildThreads = numBuildThreads;
    }
    
    /** Creates (or cleans and recreates) the default temporary directory that will later be referenced to store temp files.
     * @param tempDirString a String specifying the path you want things to live at.
     */
    public void setTempDir(String tempDirString) {
        if (tempDirString.endsWith(File.separator)) {
            LOGGER.warn("Temp directory setting should not end in '" + File.separator + "'. Ignoring last character in '"
                    + tempDirString + "'");
            tempDirString = tempDirString.substring(0, tempDirString.length() - 1);
        }
        
        tempDir = new File(tempDirString);
        
    }
    
    /**
     * @param siteAssetDir
     *            the siteAssetsDir to set
     */
    public void setSiteAssetDir(String siteAssetDir) {
        if (siteAssetDir.endsWith(File.separator)) {
            LOGGER.warn("Site asset directory setting should not end in '" + File.separator + "'. Ignoring last character in '"
                    + siteAssetDir + "'");
            siteAssetDir = siteAssetDir.substring(0, siteAssetDir.length() - 1);
        }
        this.siteAssetDir = siteAssetDir;
    }

    /**
     * @param workingRootDir
     *            the workingRootDir to set
     */
    public void setWorkingRootDir(String workingRootDir) {
        this.workingRootDir = workingRootDir;
    }

    /**
     * This is probably a very very very bad idea. 
     * DEBATABLE this could be made to work with a little care but why bother?
     * 
     * @param futures xx
     * @deprecated xx
     */
    @SuppressWarnings("unused")
    @Deprecated
    private void stopBuild(Set<Future<BuildRequestResult>> futures) {
        return;
        // Due to circumstances within our control, the future has been canceled.
        // Cover blurb, "The End of Eternity, I. Asimov."
        //        for (Future<BuildRequestResult> f : futures) {
        //            f.cancel(true);
        //            /*
        //             * if (!f.cancel(true)) { not aware of anything meaningful to report in this case. 
        //             *      logger.warn("Attempt to cancel build request failed, ignoring.");
        //             * Its worse than that. True doesn't mean the task actually stopped either. }
        //             */
        //        }
    }

    /** {@inheritDoc}  */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("StandardBuildManager [logger=").append(LOGGER).append(", artifactRepository=")
                .append(artifactRepository).append(", extractManager=").append(extractManager)
                .append(", workingRootDir=").append(workingRootDir).append(", buildSystemHome=")
                .append(buildSystemHome).append(", tempDir=").append(tempDir).append(", commandPathDir=")
                .append(buildSystemHomeDir).append("]");
        return builder.toString();
    }

    /**
     * Wrapper for happy version of 'what happened', that is always left in the repo if the build completes.
     * File is called {@link #BUILD_LOG}
     * 
     * @param buildInfo
     *            the whole build story as it happened
     * @param outputDir
     *            where to place the saga
     * @throws BuildManagerException
     *             whoa... that shouldn't happen.
     */
    private void writeBuildLog(BuildInfo buildInfo, File outputDir) throws BuildManagerException {
        writeLogFile(buildInfo, false, BUILD_LOG, outputDir);
    }

    /**
     * Wrapper for exciting version of what happen (the error log)  that is always left in the repo if the build completes and the build was a failure.
     * File is left in the output directory under the name {@link #ERROR_LOG}
     * 
     * @param buildInfo
     *            the whole build story as it happened
     * @param outputDir
     *            where to place the saga
     * @throws BuildManagerException
     *             whoa... that shouldn't happen.
     */
    private void writeErrorLog(BuildInfo buildInfo, File outputDir) throws BuildManagerException {
        writeLogFile(buildInfo, true, ERROR_LOG, outputDir);
    }

    /**
     * Sort of a serializer for the {@link ImportInfoBean} but without a specification. 
     * TODO make it a method of {@link ImportInfoBean}? 
     *  
     * @param importInfoBean the import info data
     * @param importInfoFile the {@link File} to write to.
     * @throws IOException for IOExceptions... duh.
     */
    private void writeImportInfoFile(ImportInfoBean importInfoBean, File importInfoFile) throws IOException {

        PrintWriter importInfoFileWriter = new PrintWriter(new BufferedOutputStream(new FileOutputStream(importInfoFile)));
        importInfoFileWriter.write(importInfoBean.getHeader() + "\n");

        for (String line : importInfoBean.getProvides()) {
            importInfoFileWriter.write(line + "\n");   
        }

        for (String key : importInfoBean.getRequires().keySet()) {
            SortedSet<String> requires = importInfoBean.getRequires().get(key);
            for (String line : requires) {
                importInfoFileWriter.write(line + "\n");   
            }            
        }

        importInfoFileWriter.write(BUILD_STEP_SUCCESS_MARKER /*+ "\n"*/);  

        importInfoFileWriter.close();

    }

    /**
     * Helper method extract the build history from a {@link BuildInfo}. Dubious attempt at reuse here. The idea was we always wanted a build log and 
     * then sometimes wanted an error log as well if the build was not successful but could be completed or say... finished. We tried to reuse the 
     * parsing logic to accommodate both flavors of log. 
     * 
     * 
     * @param buildInfo the {@link BuildInfo} holding the history of the build attempt
     * @param errorsOnly whether a error log or build log should be written. <code>true</code> means Error log
     * @param outStream where to write the log
     * @throws BuildManagerException for all exceptions
     */
    private void writeLog(BuildInfo buildInfo, boolean errorsOnly, OutputStream outStream) throws BuildManagerException {

        // nothing to do if we have success and are writing an error log.
        if (buildInfo.getSuccessStatus() && errorsOnly) {
            return;
        }

        try {
            PrintWriter buildLogWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outStream, ENCODING))); 


            /**
             * TODO now we see how it ended up.. there is the option to clean this up muchly, and get rid of these 3 duplicate code paths? 
             * 1) buildRequestResults per buildplan status 
             * 2) sourceRetrievalDetails for each buildRequestResults, per extract status 3) commandResults in each
             * sourceRetrievalDetail. ... log, info details.  ... now 4 with top level buildInfo exceptions that don't belong to the extract process.
             */

            // Print out exceptions that occur outside of the build request task.
            Set<Throwable> generalBuildExceptions = buildInfo.getExceptions();             
            if (generalBuildExceptions.size() != 0) {
                buildLogWriter.write("Build id:" + buildInfo.getBuildId() + " FAILED\n");
                for (Throwable throwable : generalBuildExceptions) {
                    throwable.printStackTrace(buildLogWriter);
                }
            }

            for (BuildRequestResult buildRequestResult : buildInfo.getBuildRequestResults()) {

                // For the build request....
                if (!buildRequestResult.getSuccessStatus()) {
                    buildLogWriter.write("Build request:" + buildRequestResult.getId() + " FAILED\n");
                    if (buildRequestResult.getLastException() != null) {
                        buildRequestResult.getLastException().printStackTrace(buildLogWriter);
                    } else {
                        String message = "No exception available for failed build request ...odd.";
                        buildLogWriter.write(message);
                        LOGGER.warn(message);
                    }
                    buildLogWriter.write('\n');
                    buildLogWriter.write(buildRequestResult.toString());
                    buildLogWriter.write('\n');
                } else if (!errorsOnly) {
                    buildLogWriter.write("Build Request:" + buildRequestResult.getId() + " SUCCEEDED\n");
                    buildLogWriter.write(buildRequestResult.toString());
                    buildLogWriter.write('\n');
                }

                // For each extract in the build request....print out the overall source retrieval status
                for (SourceRetrievalDetails sourceRetrievalDetails : buildRequestResult.getSourceRetrievalDetails()) {

                    if (!sourceRetrievalDetails.getSuccessStatus()) {
                        buildLogWriter.write("Source retrieval:" + sourceRetrievalDetails.getId() + " FAILED\n");
                        if (sourceRetrievalDetails.getLastException() != null) {
                            sourceRetrievalDetails.getLastException().printStackTrace(buildLogWriter);
                        } else {
                            String message = "No exception available for source retrieval request ...odd.";
                            buildLogWriter.write(message);
                            LOGGER.warn(message);
                        }
                        buildLogWriter.write('\n');                       
                        buildLogWriter.write("Source retrieval:" + sourceRetrievalDetails.getId() + " FAILED.\n");
                        buildLogWriter.write(sourceRetrievalDetails.toString() + "\n");
                    } else if (!errorsOnly) {
                        buildLogWriter.write("Source retrieval:" + sourceRetrievalDetails.getId() + " SUCCEEDED\n");
                        buildLogWriter.write(sourceRetrievalDetails.toString() + "\n");
                    }

                    // For each extract in the build request....print out the command history of the request.
                    for (CommandResultInfo commandResultInfo : buildRequestResult.getCommandResultInfos()) {
                        if (!commandResultInfo.getSuccessStatus()) {
                            buildLogWriter.write("Build command FAILED\n");
                            if (commandResultInfo.getLastException() != null) {
                                commandResultInfo.getLastException().printStackTrace(buildLogWriter);
                            } 
// turns out its less odd than we thought, a build script fails with only an error code quite often in development                            
//                            else {
//                                String message = "No exception available for command result ...odd.";
//                                buildLogWriter.write(message);
//                                LOGGER.warn(message);
//                            }
                            buildLogWriter.write('\n');
                            writeResults(buildLogWriter, commandResultInfo);
                        } else if (!errorsOnly) {
                            buildLogWriter.write("Build command SUCCEEDED ");
                            writeResults(buildLogWriter, commandResultInfo);
                        }
                    }
                }
            }

            buildLogWriter.close();
        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildManagerException */
            throw new BuildManagerException("Exception writing log output. Reason:" + e, e);
        }

    }

    /**
     * Helper method to write and verify either a log or error log record according to system constants. Basically a
     * wrapper {@link #writeLog(BuildInfo, boolean, OutputStream)} with error checking.
     * 
     * @param buildInfo the {@link BuildInfo} with a list of results
     * @param errorsOnly if <code>true</code> output is limited to errors found in the various results.
     * @param fileName the name of the output file
     * @param outputDir where you want it
     * @throws BuildManagerException if the file can not be verified as readable and has some content
     */
    private void writeLogFile(BuildInfo buildInfo, boolean errorsOnly, String fileName, File outputDir) throws BuildManagerException {
        File buildLog = new File(outputDir, fileName);  
        try {
            writeLog(buildInfo, errorsOnly, new FileOutputStream(buildLog));
            FileUtil.checkFileExistsReadableNotEmpty(buildLog);
        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildManagerException */
            throw new BuildManagerException("Exception writing build log file at " + outputDir.getAbsolutePath() 
                    + " reason: " + e, e);
        }
        LOGGER.info(buildLog.getAbsolutePath() + " created.");
    }

    /**
     * 
     * Helper method to finally write the basically complete manifest content description to disk.
     * Later a performance string seemed useful so it was added. 
     * 
     * @param buildInfo {@link BuildInfo} which will be used to collect build times.
     * @param manifestContents {@link String} built by {@link #processAtrifactsAndBuildManifest(BuildInfo, Map)} 
     * @param outputDir where to leave the manifest file named {@link StandardBuildManager#MANIFEST_NAME}.
     * @throws BuildManagerException for errors which at this point get tricky to handle
     * @see {@link #processAtrifactsAndBuildManifest(BuildInfo, Map)}
     */
    private void writeManifest(BuildInfo buildInfo, String manifestContents, File outputDir) throws BuildManagerException {
        File manifestFile = new File(outputDir, MANIFEST_NAME);
        if (manifestContents == null || manifestContents.isEmpty()) {
            throw new IllegalArgumentException("Manifest contents can not be null. or empty. Found: '" 
                    + manifestContents + "'");
        }

        try {

            PrintWriter manifestWriter = new PrintWriter(new BufferedOutputStream(new FileOutputStream(manifestFile)));

            String timeProfileString = calculateBuildPerformanceString(buildInfo);
            manifestWriter.write(timeProfileString + '\n');

            manifestWriter.write(BUILD_SUCCESS_PREFIX);
            if (buildInfo.getSuccessStatus()) {
                manifestWriter.write(JobStatus.SUCCEEDED.toString() + '\n');
            } else {
                manifestWriter.write(JobStatus.FAILED.toString() + '\n');
            }

            manifestWriter.write(USER_PREFIX + buildInfo.getUser().getName() + '\n');
            manifestWriter.write(manifestContents);

            manifestWriter.close();
            FileUtil.checkFileExistsReadableNotEmpty(manifestFile);
            LOGGER.debug("Manifest file created at {}", manifestFile.getAbsolutePath());

        } catch (Exception e) {
            /* We catch and wrap all Exceptions with BuildManagerException */
            throw new BuildManagerException("Failure creating " + MANIFEST_NAME + " Reason:" + e, e);
        }
    }

}
