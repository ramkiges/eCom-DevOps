This repo contains scripts and whatnot to help manage the mac mini Jenkins nodes

Confluence: https://confluence.wsgc.com/display/ES/Mac+Mini+Jenkins+Nodes 

GitHub: https://github.wsgc.com/eCommerce-DevOps/mac-tools

Jenkins: https://ecombuild.wsgc.com/jenkins/job/mac-scan/ 

Prerequisites:
* each node has to have passwordless sudo enabled
  %admin          ALL = (ALL) NOPASSWD: ALL

* each node has to have the Jenkins user configured for github
  $HOME/.gitconfig
  $HOME/.ssh/confif
  $HOME/.ssh/id_rsa_svcagitci
  $HOME/.ssh/id_rsa_svcagitci.pub
  
Scripts:

* mac-status 
  This script is intended to be run on the mac mini nodes via cron.  It collects info about the node, and restarts services as needed.

* mac-scan
  This script is intended to be run on the Jenkins master to poll the status of the mac mini nodes 

