#!/bin/sh
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/mead-tools
TMP=/tmp/resource-matrix/data

BailOut() {
  [[ -n $1 ]] && echo "$(hostname):$(basename $0): $*" >&2
  exit 255
}

base=$(dirname $0)
[[ -e ${base}/generate-resource.env ]] && . ${base}/generate-resource.env || . /apps/mead-tools/generate-resource.env

DATE=$(date +'%Y%m%d%H%M')
MAX=500

cd $(dirname $DATA)
git pull -q --rebase --autostash 
git stash pop -q >/dev/null 2>&1
DNS_LIST=$TMP/dns-list.txt
HOST_LIST=$TMP/host-list.txt
NODE_LIST=$TMP/node-list.txt
SCAN_LIST=$TMP/scan-list.txt
touch $DNS_LIST $HOST_LIST $NODE_LIST $SCAN_LIST

echo "*** $LOGNAME ***"

if [[ -n $1 ]]
then
  for x in $*
  do
    echo "$x" >> $HOST_LIST
    # extract this node from RunDeck
    grep -ihr "hostname=" $RUNDECK_XML | grep "$x" | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' >> $HOST_LIST
    grep -ihr "node name=" $RUNDECK_XML | grep "$x" | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' >> $NODE_LIST
  done
else
  # clear data file
  rm $DATA 

  echo "*** Generating SCAN_LIST $(date +'%Y-%m-%d %H:%M') ***"
  cat $TMP/scan-tools/Ecom_Server_Inventory.csv | awk -F, '{ print $1 }' | egrep -iv "#|^$" | sort -u > $SCAN_LIST

  echo "*** Generating SEED_LIST $(date +'%Y-%m-%d %H:%M') ***"
  # these limit the scope to non-prod
  SEED_LIST=$(grep -ihr "hostname=" $RUNDECK_XML | egrep -iv "prd|github" | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | egrep "rck-|ash-|sac-" | sed -es/[0-9]*//g | sort -u)
  grep -ihr "hostname=" $RUNDECK_XML | egrep -iv "prd" | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | sort -u > $HOST_LIST
  grep -ihr "node name=" $RUNDECK_XML | egrep -iv "prd" | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | sort -u > $NODE_LIST

  # these grab everything
  #SEED_LIST=$(grep -ihr "hostname=" $RUNDECK_XML | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | egrep "rck-|ash-|sac-" | sed -es/[0-9]*//g | sort -u)
  #grep -ihr "hostname=" $RUNDECK_XML | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | sort -u > $HOST_LIST

  SEED_LIST=$(echo $SEED_LIST | xargs -n1 | sort -u | tr '\n' ' ')
  echo "SEED_LIST: $SEED_LIST "

  echo "*** Generating DNS_LIST $(date +'%Y-%m-%d %H:%M') ***"
  for SEED in $SEED_LIST
  do
    blank=0
    for i in $(seq -f "%03g" 1 $MAX)
    do 
      dns="$SEED$i"
      dns_ip=$(host $dns 2>/dev/null | grep -i address | awk '{ print $NF }')
      [[ -n $dns_ip ]] && echo "$dns" >> $DNS_LIST || blank=$(expr $blank + 1)
      [[ $blank -gt 25 ]] && break
    done
  done
fi

echo "*** Scanning $(date +'%Y-%m-%d %H:%M') *** "
for entry in $(cat $DNS_LIST $HOST_LIST $NODE_LIST $SCAN_LIST | sort -u )
do
    entry=$(awk -F\. '{ print $1 }' <<< $entry)
    appscan=false
    rundeck=false
    k8s=
    ping=
    cname=
    cname_ip=
    tags=
    pkgs=

    alias=$(host $entry 2>/dev/null | grep -i "alias for" | awk '{ print $NF }' | awk -F\. '{ print $1 }')
    [[ -n $alias ]] && cname=$entry

    dns=$(host $entry 2>/dev/null | grep -i "has address" | awk '{ print $1 }' | awk -F\. '{ print $1 }')
    [[ -z $dns ]] && dns=$entry
    dns_ip=$(host $dns 2>/dev/null | grep -i address | awk '{ print $NF }')
    [[ $cname = "$dns" ]] && cname=
  
    # construct an expression to search for in rundeck
    key=$dns
    [[ -n $cname ]] && key="$key|$cname"

    node=$(egrep -i "$key" $RUNDECK_XML | awk -F 'node name=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | sort -u | tail -1)
    host=$(egrep -i "$key" $RUNDECK_XML | awk -F 'hostname=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | sort -u | tail -1)

    [[ -z $dns_ip ]] && dns_ip=$(host $node 2>/dev/null | grep -i address | awk '{ print $NF }')
    [[ -z $dns_ip ]] && dns_ip=$(host $host 2>/dev/null | grep -i address | awk '{ print $NF }')

    if [[ -z $cname ]]
    then
      [[ $host != "$dns" ]] && cname=$host 
      [[ $node != "$dns" ]] && cname=$node 
    fi

    # if the cname matches a dns pattern, swap them
    if echo "$cname" | egrep -i -- "-vpcn|-vicn|-vccn|-vdcn"
    then
      dns=$cname
      cname=$entry
    fi

    [[ -n $cname ]] && cname_ip=$(host $cname 2>/dev/null | grep -i address | awk '{ print $NF }')
    [[ -n $host || -n $node ]] && rundeck=true
    [[ -n $host ]] && key="$key|$host"
    [[ -n $node ]] && key="$key|$node"

    if [[ -n $dns_ip ]]
    then
      ping -c 2 $dns >/dev/null 2>&1
      [[ $? -eq 0 ]] || ping=false
    fi

    # find host in app-scan
    appscan=$(egrep -i "$key" $TMP/scan-tools/Ecom_Server_Inventory.csv | sort -u | head -1)
    [[ -n $appscan ]] && appscan=true || appscan=false

    [[ -n $host ]] && tags=$(egrep -i "$key" $RUNDECK_XML | awk -F 'tags=' '{ print $2 }' | awk '{ print $1 }' | sed -es/\"//g | awk -F\. '{ print $1 }' | tr '\n' ' ' | sed -es/','/' '/g)

    pkgs=$(/bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -q -i $SSH_KEY $SSH_USER@$dns \
        "rpm -qa | grep -i 'wsgc' | grep -i 'config' | egrep -v 'apmagents|grep|httpd|rerun|jdk'")
    [[ -z $pkgs ]] && pkgs=$(/bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -q -i $SSH_KEY $SSH_USER@$dns \
        "rpm -qa | grep -i 'wsgc' | egrep -v 'apmagents|grep|httpd|rerun|jdk'")
    pkgs=$(echo "$pkgs" | sed -es/\.noarch//g | awk -F_ '{ print $1 }' | xargs -n1 | sort -u | tr '\n' ' ')

    cpu=$(/bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -q -i $SSH_KEY $SSH_USER@$dns "cat /proc/cpuinfo | grep -i processor | wc -l | sed -r 's/\s+//g'")
    mem=$(/bin/timeout -k 30s 10s ssh -o StrictHostKeyChecking=no -q -i $SSH_KEY $SSH_USER@$dns "cat /proc/meminfo | grep -i MemTotal | awk -F: '{ print \$2 }' | sed -r 's/\s+//g'")
    [[ $mem =~ kB ]] && { mem=$(sed -es/kb//gi <<< $mem); mem=$(expr $mem / 1048576); }

    #[[ $dns = $node && $dns = $host ]] && echo "Node and host name should not be the same: $dns"

    for dns_a in $entry $cname $dns
    do
      k8s=$(host $dns_a | grep -i container | awk '{ print $NF }')
      [[ -n $k8s ]] && { k8s=true; break; }
    done

    [[ $dns =~ container ]] && continue
    echo "$DATE,$dns,$dns_ip,$cname,$cname_ip,$host,$node,$rundeck,$appscan,$pkgs,$tags,$ping,$k8s,$cpu,$mem" | tee -a $DATA
done

echo "*** Scan complete $(date +'%Y-%m-%d %H:%M') ***"

touch $DATA.new
for host in $(awk -F, '{ print $2 }' $DATA | sort -u)
do
  grep ",$host," $DATA | sort -u | tail -1 >> $DATA.new
done
mv $DATA.new $DATA

git add $DATA
git commit -q -m "Update $DATE" 
git push -q

generate-resource-matrix.sh

rm -rf $TMP

exit 0
