#!/bin/sh
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/mead-tools
TMP=/tmp/resource-matrix/report

BailOut() {
  [[ -n $1 ]] && echo "$(hostname):$(basename $0): $*" >&2
  exit 255
}

base=$(dirname $0)
[[ -e ${base}/generate-resource.env ]] && . ${base}/generate-resource.env || . /apps/mead-tools/generate-resource.env

PAGENAME="Provisioned Resource Matrix"
OUTFILE=/tmp/resource-matrix.html
rm -f $OUTFILE

RUNDECK_ERROR_COUNT=0
DNS_ERROR_COUNT=0
PING_ERROR_COUNT=0
APPSCAN_ERROR_COUNT=0
APPSCAN_CLEAR_COUNT=0
CNAME_ERROR_COUNT=0
K8S_COUNT=0
RUNDECK_REMOVE=0

DATE=$(date +'%y%m%d')

TOTAL_MEM=0
TOTAL_CPU=0

HTML "<!-- $DATE -->"

HTML "<table border='1'>"
HTML "<tr><th><font size='-1'>Total CPU</font></th><td><font size='-1'>@@TOTAL_CPU@@</font></td></tr>"
HTML "<tr><th><font size='-1'>Total Memory</font></th><td><font size='-1'>@@TOTAL_MEM@@Tb</font></td></tr>"
HTML "</table>"

HTML "<table border='1'>"
HTML "<tr><th colspan='3'>Flags</th></tr>"
HTML "<tr><td>$RUNDECK_ERROR</td><td>Host missing in RunDeck</td><td>@@RUNDECK_ERROR@@</td></tr>"
HTML "<tr><td>$DNS_ERROR</td><td>Host missing in DNS</td><td>@@DNS_ERROR@@</td></tr>"
HTML "<tr><td>$PING_ERROR</td><td>Host not reachable</td><td>@@PING_ERROR@@</td></tr>"
HTML "<tr><td>$CNAME_ERROR</td><td>CNAME missing in DNS</td><td>@@CNAME_ERROR@@</td></tr>"
HTML "<tr><td>$APPSCAN_ERROR</td><td>Host missing in AppScan</td><td>@@APPSCAN_ERROR@@</td></tr>"
HTML "<tr><td>$APPSCAN_CLEAR</td><td>Host needs to be removed from AppScan</td><td>@@APPSCAN_CLEAR@@</td></tr>"
HTML "<tr><td>$K8S_FLAG</td><td>Moved to kubernetes</td><td></td></tr>"
HTML "<tr><td><s>hostname</s></td><td>Needs to be removed from RunDeck and/or AppScan</td><td>@@RUNDECK_REMOVE@@</td></tr>"
HTML "</table>"
HTML

HTML "<h4>Non-Prod</h4>"
HTML "<table border='1'>"
HTML "<tr>"
HTML "  <th style='width:12%;text-align:center;'>DNS</th>"
HTML "  <th style='width:15%;text-align:center;'>CNAME</th>"
HTML "  <th style='width:30%;text-align:center;'>Packages</th>"
HTML "  <th style='width:35%;text-align:center;'>Tags</th>"
HTML "  <th style='width:4%;text-align:center;'>CPU</th>"
HTML "  <th style='width:4%;text-align:center;'>Memory</th>"
HTML "</tr>"
HTML

#for dns in $(awk -F, '{ print $2 }' $DATA | egrep -iv "vpcn|vccn|rk[1-9]p|rk[1-9]p|websun|vcax" | sort -u)
PATTERN="rk1p|rk2p|websun|vcax"
for dns in $(awk -F, '{ print $2 }' $DATA | egrep -iv "$PATTERN" | sort -u)
do
  STRIKE_ON=
  STRIKE_OFF=
  line=$(grep ",$dns," $DATA | sort -u | tail -1)
  #echo "line: $line"

  date=$(     awk -F, '{ print $1 }' <<< $line)
  dns=$(      awk -F, '{ print $2 }' <<< $line)
  dns_ip=$(   awk -F, '{ print $3 }' <<< $line)
  cname=$(    awk -F, '{ print $4 }' <<< $line)
  cname_ip=$( awk -F, '{ print $5 }' <<< $line)
  host=$(     awk -F, '{ print $6 }' <<< $line)
  node=$(     awk -F, '{ print $7 }' <<< $line)
  rundeck=$(  awk -F, '{ print $8 }' <<< $line)
  appscan=$(  awk -F, '{ print $9 }' <<< $line)
  pkgs=$(     awk -F, '{ print $10 }' <<< $line)
  tags=$(     awk -F, '{ print $11 }' <<< $line)
  ping=$(     awk -F, '{ print $12 }' <<< $line)
  k8s=$(      awk -F, '{ print $13 }' <<< $line)
  cpu=$(      awk -F, '{ print $14 }' <<< $line)
  mem=$(      awk -F, '{ print $15 }' <<< $line)

  # filter out hosts we don't care about (eg those from other groups)
  echo "$dns" | egrep -iq "$IGNORE_HOSTS" && continue
  echo "$cname" | egrep -iq "$IGNORE_HOSTS" && continue
  echo "$pkgs" | egrep -iq "$IGNORE_PKGS" && continue

  [[ $dns =~ container ]] && continue
  [[ $dns = perf ]] && continue
  #[[ $dns = $node && $dns = $host ]] && echo "Node and host name should not be the same: $dns"

  if [[ $dns =~ vccn || $dns =~ vpcn ]]
  then
      echo "$dns" | egrep -iq "artrck" || continue
  fi

  # convert memory to Gb
  [[ $mem =~ kB ]] && { mem=$(sed -es/kb//gi <<< $mem); mem=$(expr $mem / 1048576); }

  # update running total
  [[ -n $mem ]] && TOTAL_MEM=$(expr $TOTAL_MEM + $mem)
  [[ -n $cpu ]] && TOTAL_CPU=$(expr $TOTAL_CPU + $cpu)

  # if the app was k8s'd, then mark it for removal
  if [[ -n $k8s ]]
  then 
    k8s=$K8S_FLAG 
    if [[ $rundeck =~ true ]]
    then
      STRIKE_ON="<s>"
      STRIKE_OFF="</s>"
      RUNDECK_REMOVE=$(expr $RUNDECK_REMOVE + 1)
    fi
    appscan=
  fi

  # if it's not in DNS, mark it for removal
  if [[ -z $dns_ip ]] 
  then
    dns_ip=$DNS_ERROR 
    DNS_ERROR_COUNT=$(expr $DNS_ERROR_COUNT + 1)
    if [[ $rundeck =~ true ]]
    then
      STRIKE_ON="<s>" 
      STRIKE_OFF="</s>" 
      RUNDECK_REMOVE=$(expr $RUNDECK_REMOVE + 1)
      RUNDECK_ERROR_COUNT=$(expr $RUNDECK_ERROR_COUNT + 1)
    fi
    if [[ $appscan =~ true ]]
    then
      appscan=$APPSCAN_CLEAR
      APPSCAN_CLEAR_COUNT=$(expr $APPSCAN_CLEAR_COUNT + 1)
      STRIKE_ON="<s>" 
      STRIKE_OFF="</s>" 
    else
      appscan=
    fi
    rundeck=
  else
    # if it's in DNS, but not in AppScan, flag it
    if [[ $appscan =~ false && $rundeck =~ true ]]
    then
      appscan=$APPSCAN_ERROR
      APPSCAN_ERROR_COUNT=$(expr $APPSCAN_ERROR_COUNT + 1)
    else
      appscan=
    fi

    if [[ $ping =~ false ]]
    then
      ping=$PING_ERROR 
      PING_ERROR_COUNT=$(expr $PING_ERROR_COUNT + 1)
    else 
      ping=
    fi

    if [[ $rundeck =~ false ]] 
    then
      rundeck=$RUNDECK_ERROR 
      RUNDECK_ERROR_COUNT=$(expr $RUNDECK_ERROR_COUNT + 1)
    else
      rundeck=
    fi
    dns_ip=
  fi

  if [[ -n $cname && -z $cname_ip ]] 
  then
    cname_ip=$CNAME_ERROR 
    CNAME_ERROR_COUNT=$(expr $CNAME_ERROR_COUNT + 1)
  else
    cname_ip=
  fi

  [[ $dns = "$host" && $dns = "$node" ]] && node=

  [[ $dns = "$cname" ]] && cname=

  # remove the date string from the package names
  pkgs=$(sed -e 's/-[0-9].*\b//g' <<< $pkgs)

  HTML "<!-- $line -->"
  HTML "<tr>"
  HTML "  <td>$STRIKE_ON${dns}$STRIKE_OFF${rundeck}${dns_ip}${ping}${k8s}${appscan}</td>"
  HTML "  <td>${cname}${cname_ip}</td>"
  HTML "  <td>${pkgs}</td>"
  HTML "  <td>${tags}</td>"
  HTML "  <td>${cpu}</td>"
  HTML "  <td>${mem}</td>"
  HTML "</tr>"
  HTML
done

HTML "</table>"

sed -es/@@RUNDECK_ERROR@@/$RUNDECK_ERROR_COUNT/g -i $OUTFILE
sed -es/@@DNS_ERROR@@/$DNS_ERROR_COUNT/g -i $OUTFILE
sed -es/@@PING_ERROR@@/$PING_ERROR_COUNT/g -i $OUTFILE
sed -es/@@APPSCAN_ERROR@@/$APPSCAN_ERROR_COUNT/g -i $OUTFILE
sed -es/@@APPSCAN_CLEAR@@/$APPSCAN_CLEAR_COUNT/g -i $OUTFILE
sed -es/@@CNAME_ERROR@@/$CNAME_ERROR_COUNT/g -i $OUTFILE
sed -es/@@RUNDECK_REMOVE@@/$RUNDECK_REMOVE/g -i $OUTFILE

# update total tokens
#TOTAL_MEM=$(expr $TOTAL_MEM / 1024)
set -x
TOTAL_MEM=$(bc <<< "scale=2; $TOTAL_MEM/1024")
#TOTAL_MEM=$(printf "%.0f%%" $TOTAL_MEM)
set +x

sed -es/@@TOTAL_CPU@@/$TOTAL_CPU/g -i $OUTFILE
sed -es/@@TOTAL_MEM@@/$TOTAL_MEM/g -i $OUTFILE

echo "=== Update confluence $PAGENAME ==="

# update confluence
sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose || BailOut "Confluence update failed"

rm -rf $TMP $OUTFILE 

