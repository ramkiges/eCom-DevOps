# node-18-ci
A node 18.x container for use in CI builds.  

This configures the user in the container as the Jenkins uid/gid and adds our NPM repo configurations
    
Build locally for testing
    
    docker build . -t snapshotrepo.wsgc.com/ecommerce-docker-repo/wsgc-node-18-ci:latest
        
    docker run -it -v ${PWD}:/app -w /app --rm snapshotrepo.wsgc.com/ecommerce-docker-repo/wsgc-node-18-ci:latest bash
