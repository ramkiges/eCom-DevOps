This builds the wsgc-devops-toolchain-scm-webhooks-config RPM.

This RPM is expected to be deployed on the webhook server machine, so
that the server may be run on bootup as a system service.
