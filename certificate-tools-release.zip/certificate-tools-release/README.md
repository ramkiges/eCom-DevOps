DevOps repo for TLS/SSL certificate tooling

Please see https://confluence.wsgc.com/display/ES/HTTPS+SSL+Certificates 

cert-request - script to request a certificate via Venafi

cert-retrieve - script to retreive a certificate via Venafi

venafi.properties - properties file specific to DevOps

install-local - install scripts in $HOME/bin

--Thom

