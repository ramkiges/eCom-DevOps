# wsgc-tomcat-parent
Parent package for all WSGC tomcat service packages.
Packages requiring tomcat 8 should utilize artifacts generated from the `master` branch.
Packages requiring tomcat 6 should utilize artifacts generated from the `tomcat6` branch.
