# ecom-app-registry-helm-configs
The Helm config project to deploy the MFE for Registry Domain.

Bedrock Repo Application URL - https://github.wsgc.com/eCommerce-Bedrock/ecom-app-registry
