#!/bin/bash
#
# createCSR.sh <nodename>
#
# Create an eComm-appropriate CSR, asking to be signed by SHA-256 (but
# may be -512), with a subjectAltName extension.

set -o nounset
altnum=1

if [[ $# -lt 1 ]]; then
    echo "usage: $0 <nodename> [altname] ..." >&2
    exit 1
fi

if [[ $1 =~ \.wsgc\.com$ ]]; then
    fullname="$1"  # Great
else
    fullname="$1.wsgc.com"
fi

ALT_NAMES="DNS.$altnum = $fullname"

shift
for altname in $*
do
    altnum=$(expr $altnum + 1)
    [[ ! $altname =~ \.wsgc\.com$ ]] && altname="$altname.wsgc.com"
    ALT_NAMES="$ALT_NAMES
DNS.$altnum = $altname"
done

file_friendly_fullname="${fullname//./_}"

openssl req -newkey rsa:2048 -nodes -sha256 \
        -out "$file_friendly_fullname.csr" \
        -keyout "$file_friendly_fullname.key" \
        -subj "/C=US/ST=California/L=San Francisco/O=Williams-Sonoma, Inc./CN=$fullname" \
        -config <(echo "[req]
distinguished_name = req_distinguished_name
req_extensions = v3_req

[req_distinguished_name]
countryName = Country Name (2 letter code)
countryName_default = US
stateOrProvinceName = State or Province Name (full name)
stateOrProvinceName_default = CA
localityName = Locality Name (eg, city)
localityName_default = San Francisco
organizationalUnitName	= Organizational Unit Name (eg, section)
organizationalUnitName_default	= Williams-Sonoma, Inc
commonName = Williams-Sonoma, Inc.
commonName_max	= 64

[ v3_req ]
# Extensions to add to a certificate request
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[alt_names]
$ALT_NAMES"
)

# validation of csr
#openssl req -in "$file_friendly_fullname.csr" -noout -text

