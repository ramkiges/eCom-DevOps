#!/bin/sh

LIST="\
bpv uat1 uat2 uat3 uat4 uat5 uat6 uat7 uat8 \
cabpv cauat1 cauat2 cauat3 cauat4 cauat6 cauat7 cauat8 \
rgs1 rgs2 cargs1 \
qa1 qa3 qa4 qa10 qa11 qa12 qa31 qa32 qa34 qa41 qa52 qa56 qa54 qa99 \
caqa10 caqa11 caqa31 \
int1 int2 \
eqa4 \
"

OUT=~/Downloads/new-akamai-certs.txt
echo "Environments we need to add to an Akamai cert SAN list" > $OUT

for e in $LIST
do
  for b in $(getbrandlist $e)
  do
    [[ $e =~ ^ca && $b = mg ]] && continue
    [[ $e =~ ^ca && $b = gr ]] && continue

    [[ $e = qa99 ]] && { [[ $b = gr || $b = rj ]] || continue; }

    akamai=$(getakamai $b $e | awk -F/ '{print $3 }')
    cert=$(openssl s_client -connect $akamai:443 </dev/null 2>/dev/null | openssl x509 -noout -text 2>/dev/null | grep -i "DNS:" | grep -i $akamai)
    [[ -n $cert ]] && continue
    echo $akamai >> $OUT 
  done
done

sort -u $OUT > $OUT.tmp
mv $OUT.tmp $OUT

