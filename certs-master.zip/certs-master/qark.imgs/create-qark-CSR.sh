#!/bin/bash
#
# createCSR.sh <nodename>
#
# Create an eComm-appropriate CSR, asking to be signed by SHA-256 (but
# may be -512), with a subjectAltName extension.


set -o nounset
altnum=1
LIST="origin-rk-www.williams-sonoma.com origin-ab-www.williams-sonoma.com"
fullname=qark-images.wsimgs.com
ALT_NAMES="DNS.$altnum = $fullname"

for b in $(getbrandlist)
do
  LIST="$LIST qark-images.${b}imgs.com"
  LIST="$LIST origin-qark-images.${b}imgs.com"
  LIST="$LIST origin-qark-images.$(getdomain $b)"
  LIST="$LIST origin-qark-images.$(getdomain $b ca)"
done

for altname in $LIST
do
    altnum=$(expr $altnum + 1)
    #[[ ! $altname =~ \.wsgc\.com$ ]] && altname="$altname.wsgc.com"
    ALT_NAMES="$ALT_NAMES
DNS.$altnum = $altname"
done

file_friendly_fullname="${fullname//./_}"

LIST=$(echo "$LIST" | xargs -n1 | sort -u)
echo "SAN:
$LIST"

[[ -e qark-images_wsimgs_com.csr ]] && { echo "Already have qark-images_wsimgs_com.csr - quitting"; exit 1; }

openssl req -newkey rsa:2048 -nodes -sha256 \
        -out $file_friendly_fullname.csr \
        -keyout $file_friendly_fullname.key \
        -subj "/C=US/ST=California/L=San Francisco/O=Williams-Sonoma, Inc./CN=$fullname" \
        -config <(echo "[req]
distinguished_name = req_distinguished_name
req_extensions = v3_req

[req_distinguished_name]
countryName = Country Name (2 letter code)
countryName_default = US
stateOrProvinceName = State or Province Name (full name)
stateOrProvinceName_default = CA
localityName = Locality Name (eg, city)
localityName_default = San Francisco
organizationalUnitName	= Organizational Unit Name (eg, section)
organizationalUnitName_default	= Williams-Sonoma, Inc
commonName = Williams-Sonoma, Inc.
commonName_max	= 64

[ v3_req ]
# Extensions to add to a certificate request
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[alt_names]
$ALT_NAMES"
)

# validation of csr
#openssl req -in "$file_friendly_fullname.csr" -noout -text

