## to generate CSR with OU entry required SCCINT
## Run ./createCSR-SSC.sh [cname] [hostname]
## Pem file must contain this subject : "#CN=sccint-qa1-rk1v.wsgc.com,OU=sccint-qa,O=Williams-Sonoma\, Inc.,L=San Francisco,ST=California,C=US"
