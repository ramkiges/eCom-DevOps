#!/bin/sh

TARGETS="ws-intdev4-rk1"

for host in $TARGETS
do
set -x

    #scp -q cacerts $host:/tmp
    #ssh -q -tt $host "sudo cp /tmp/cacerts /apps/jdk1.8.0_202/jre/lib/security/cacerts"

    scp -q applepay_keystore.jks $host:/tmp
    ssh -q -tt $host "sudo cp /tmp/applepay_keystore.jks /apps/tomcat/conf/applepay_keystore.jks"
    ssh -q -tt $host "sudo service wsgc-tomcat-frontend restart"

{ set +x; } 2>/dev/null
done
