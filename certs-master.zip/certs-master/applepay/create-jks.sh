#!/bin/sh
# https://confluence.wsgc.com/display/PS/HowTo%3A+Apple+Pay+keystore+and+domain+validation
# this script takes the applepay key and cert file, and creates a fresh ApplePay JKS file
STOREPASS=applepay
DIGICERT_G2=https://cacerts.digicert.com/DigiCertGlobalRootG2.crt
JKS=applepay_keystore.jks

set -x

# create a new JKS file
rm -f $JKS

# download and import the digicert certificate
[[ -e $(basename $DIGICERT_G2) ]] || curl -sqk -O $DIGICERT_G2

openssl x509 -inform DER -outform PEM -in merchant_id.cer -out merchant_id.pem || exit 1
openssl pkcs12 -export -inkey merchant_id.key -in merchant_id.pem -out merchant_id.p12 -password pass:$STOREPASS -name ApplePayMerchant_ID || exit 1
keytool -noprompt -importkeystore -storepass $STOREPASS -srcstorepass $STOREPASS -deststorepass $STOREPASS -destkeystore $JKS -deststoretype jks -srckeystore merchant_id.p12 -srcstoretype pkcs12 || exit 1

# import external certs
keytool -noprompt -storepass $STOREPASS -import -alias DigiCertGlobalRootG2 -keystore $JKS -file $(basename $DIGICERT_G2) || exit 1

# command to convert JKS to pkcs12 - don't know if we want/need to do this
#keytool -importkeystore -srckeystore $JKS -destkeystore $JKS -deststoretype pkcs12"

# validate new JKS
keytool -storepass $STOREPASS -v -list -keystore $JKS 2>/dev/null | egrep -i "alias|owner|'certificate fingerprint'"

