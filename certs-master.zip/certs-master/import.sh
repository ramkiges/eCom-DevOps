
#cp /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk/src/main/resources/tomcat/conf/frontend_keystore.jks .
ls -l /wsgc/svn/devops/application/frontend-2.1/qa/config/app/trunk/src/main/resources/tomcat/conf/frontend_keystore.jks frontend_keystore.jks

#openssl pkcs12 -export -in img-qa1-rk1v_wsgc_com.crt -inkey img-qa1-rk1v_wsgc_com.key -name img-qa1-rk1v.wsgc.com -out img-qa1-rk1v.wsgc.com.pkcs
#keytool -storepass password -importkeystore -deststorepass password -destkeystore frontend_keystore.jks -srckeystore img-qa1-rk1v.wsgc.com.pkcs -srcstoretype PKCS12

#openssl pkcs12 -export -in imgqark1v_wsgc_com.crt -inkey imgqark1v_wsgc_com.key -name imgqark1v.wsgc.com -out imgqark1v.wsgc.com.pkcs
#keytool -storepass password -importkeystore -deststorepass password -destkeystore frontend_keystore.jks -srckeystore imgqark1v.wsgc.com.pkcs -srcstoretype PKCS12



