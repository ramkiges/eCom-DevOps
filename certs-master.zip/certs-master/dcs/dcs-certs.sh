#!/bin/sh
# this script parses device names and DNS from a CSV file and creates a cert for each one
# It assumes the cert-request and cert-retrieve scripts are installed in $HOME/bin
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:$HOME/bin

# input CSV file
CSV=device-list.csv

# convert to unix format (conver cr/lf to lf)
dos2unix $CSV

# parse out the device name and hostname, use those as inputs to a loop
awk -F, '{ print $2, $12 }' $CSV | sed -es/\"//g | egrep -iv "Type" |
while read dev
do
  # parse out the device name
  name=$(awk '{ print $1 }' <<< $dev)
  # parse out the DNS name
  dns=$(awk '{ print $3 }' <<< $dev)
  # create a cert request and download the cert
  cert-request -n $name -h $dns -w

  # magic to install the cert goes here
  
done
