#!/bin/sh
PATH=/opt/homebrew/bin:/usr/local/bin:/bin:/sbin:/usr/bin:/usr/sbin:~/bin

# example of slurping a cert with openssl
# TARGET=api.mashery.com openssl s_client -connect $TARGET:443 -servername $TARGET </dev/null | openssl x509 > $TARGET.pem

#cacerts pass: changeit

BailOut () {
  [[ -n $1 ]] && echo "$*"
  exit 255
}

[[ -z $1 ]] && BailOut "Need cert file(s)"

for cacert in cacerts-wsi-8 cacerts-wsi-11
do
  jdk_version=$(awk -F- '{ print $NF }' <<< $cacert)

  # cleanup
  rm -f cacerts-wsi-$jdk_version.zip cacerts-wsi

  # download the latest from artifactory
  curl -fsqk -o cacerts-wsi-$jdk_version.zip https://artifactory.wsgc.com/artifactory/ext-release-local/com/oracle/cacerts-wsi/$jdk_version/cacerts-wsi-$jdk_version.zip

  # unzip 
  unzip -q $cacert.zip || BailOut "Can't unzip cert file"

  for cert in $*
  do
    echo "Adding $cert to $cacert"
	  alias="$(basename $cert | sed -es/\.cer//g -es/\.wsgc\.com//g -es/\.pem//g)-$(date +'%Y%m%d')"
	  keytool -noprompt -storepass changeit -importcert -file $cert -keystore cacerts-wsi -alias $alias || BailOut "Can't import cert"
  done

  # validate
  #keytool -storepass changeit -v -list -keystore cacerts-wsi 

  # zip up the new cacerts file
  zip -q cacerts-wsi-$jdk_version.zip cacerts-wsi || BailOut "Can't zip up cert"

  # upload new cacerts-wsi files
  artifact-upload cacerts-wsi-$jdk_version.zip com/adoptopenjdk/cacerts-wsi/$jdk_version
  artifact-upload cacerts-wsi-$jdk_version.zip com/oracle/cacerts-wsi/$jdk_version

  rm -f cacerts-wsi-$jdk_version.zip cacerts-wsi
done


