#!/bin/sh
# generates a CSR for the non-prod image servers

./get-csr img-qa img-qa-rk1v img-qa-rk2v

