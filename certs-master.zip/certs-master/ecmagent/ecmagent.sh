#!/bin/sh

#for env in ca-perf1 ca-qa1 ca-qa2 ca-qa3 ca-rgs1 ca-staging ca-uat1 perf1 qa1 qa2 qa3 rgs1 staging uat1

for env in ca-perf1 ca-qa1 ca-qa2 ca-qa3 ca-rgs1 ca-staging ca-uat1 perf1 qa1 qa2 qa3 rgs1 staging uat1
do
  for a in ecmagent-$env-rk1v ecmagent-$env-sac1v 
  do
      host $a >/dev/null 2>&1 || continue
      h=$(host $a 2>/dev/null | grep -i address | awk '{ print $1 }' | awk -F\. '{ print $1 }')
      b=$(echo $a | sed -es/ecmagent-/ecmagent-bgb-/g)
      echo "$a $b $h"
      ./getcert $a $b $h
      /bin/echo -n "Go get the cert then press <ENTER> "
      read x
      ./copycert $a 
      ssh -q -tt $a "sudo /tmp/local-cert-install"
  done
done
