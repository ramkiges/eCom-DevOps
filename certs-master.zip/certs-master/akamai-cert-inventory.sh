#!/bin/sh

DATE=$(date +'%Y-%m-%d')
OUT=akamai-cert-inventory.csv

ENV_LIST=$(getenvlist)

CERT_YES=0 
CERT_NO=0

COUNT_UAT=0
COUNT_EQA=0
COUNT_DEV=0
COUNT_MOB=0

HEAD="Hostname, Cert, NoCert, UAT, EQA, MOB, DEV" 

echo "$HEAD" > $OUT

for e in $ENV_LIST
do
  [[ $e =~ jukebox ]] && continue
  echo "e: $e"

  for b in $(getbrandlist)
  do
    case $e in
      *uat* | *bpv* | qa54 ) COUNT_UAT=$(expr $COUNT_UAT + 1); env="UAT,,," ;;
      *qa10 | *qa11 | *rgs1 | *qa31 | qa32 | qa99 | qa56 ) COUNT_EQA=$(expr $COUNT_EQA + 1); env=",EQA,," ;;
      *qa34 | *qa41 ) COUNT_MOB=$(expr $COUNT_MOB + 1); env=",,MOB," ;;
      * ) COUNT_DEV=$(expr $COUNT_DEV + 1); env=",,,DEV" ;;
   esac

    akamai=$(getakamai $b $e | awk -F/ '{print $3 }')
    cert=$(openssl s_client -connect $akamai:443 </dev/null 2>/dev/null | openssl x509 -noout -text 2>/dev/null | grep -i "DNS:" | grep -i $akamai)

    if [[ -n $cert ]]
    then 
      cert="X," 
      CERT_YES=$(expr $CERT_YES + 1) 
    else
      cert=",X" 
      CERT_NO=$(expr $CERT_NO + 1)
    fi

    echo "$akamai,$cert,$env" 
    echo "$akamai,$cert,$env" >> $OUT
  done
done

echo "$HEAD" >> $OUT
echo "Total,$CERT_YES,$CERT_NO,$COUNT_UAT,$COUNT_EQA,$COUNT_MOB,$COUNT_DEV" >> $OUT

git add $OUT
git commit -a -m "Update $DATE"
git push

