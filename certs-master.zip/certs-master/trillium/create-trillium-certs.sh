#!/bin/sh

rm -f  trillium-*crt  trillium-*.key
curl -fsqk -O https://artifactory.wsgc.com/artifactory/trillium/domain-certs.zip
unzip -qo domain-certs.zip

for c in *.crt
do
  name=$(sed -es/\.crt//g <<< $c)
  echo "$name"

  SAN=$(openssl x509 -in $c -text -noout | grep "DNS:" | sed -es/"DNS:"//g -es/,//g)

  cert-request -w -n $name -h "$SAN" || exit 1

done

zip -q domain-certs.zip *.crt *.key || exit 1

ART_REPO=. artifact-upload domain-certs.zip trillium

