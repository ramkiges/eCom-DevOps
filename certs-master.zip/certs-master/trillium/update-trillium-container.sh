#!/bin/sh

VERSION=1.20
TMP=/tmp/trillium
rm -rf $TMP
mkdir -p $TMP
cd $TMP

git clone -q --depth 1 git@github.wsgc.com:eCommerce-DevOps/docker-base.git $TMP/docker-base || exit 1
cd $TMP/docker-base || exit 1

docker build -t container-registry01.nonprod.wsgc.com/edap/trillium-nginx:$VERSION-wsi -f docker/trillium/nginx/Dockerfile .

docker login container-registry01.nonprod.wsgc.com

docker push container-registry01.nonprod.wsgc.com/edap/trillium-nginx:$VERSION-wsi

