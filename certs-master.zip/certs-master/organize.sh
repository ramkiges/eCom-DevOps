#!/bin/sh
# this script organizes certs into directories by application name
# there shouldn't be any files in the base directory other than the scripts and root+intermediate certs

git pull

mkdir -p imgproc
git mv pending/imgproc-* imgproc

git add imgproc

exit

mkdir -p oss
git mv search-publisher-* oss
git mv search-orchestrator-* oss
git mv feedgen-* oss
git mv pending/search-publisher-* oss
git mv pending/search-orchestrator-* oss
git mv pending/feedgen-* oss
git add oss

mkdir -p wcm
git mv *-wcm-*.* wcm #2>/dev/null
git mv wcm*.* wcm #2>/dev/null
mv *-wcm-*.* wcm #2>/dev/null
mv wcm*.* wcm #2>/dev/null
git mv pending/*-wcm-* wcm 2>/dev/null
mv pending/*-wcm-* wcm 2>/dev/null
git add wcm

mkdir -p pricing
#git mv pending/pricing-* pricing 2>/dev/null
#mv pending/pricing-* pricing 2>/dev/null
git add pricing

mkdir -p ecm
git mv *-ecmauth-* ecm 2>/dev/null
git mv *-ecmpub-* ecm 2>/dev/null
mv *-ecmauth-* ecm 2>/dev/null
mv *-ecmpub-* ecm 2>/dev/null
git mv pending/*-ecmauth-* ecm 2>/dev/null
git mv pending/*-ecmpub-* ecm 2>/dev/null
mv pending/*-ecmauth-* pending/*-ecmpub-* ecm 2>/dev/null
git add ecm

mkdir -p oauth
#git mv archive/*webauth* oauth
#mv archive/*webauth* oauth
#git mv *webauth*.* oauth
#mv *webauth*.* oauth
#git mv pending/*webauth* oauth
#mv pending/*webauth* oauth

mkdir -p ecmagent
git mv archive/*ecmagent* ecmagent
mv archive/*ecmagent* ecmagent
git mv *ecmagent*.* ecmagent
mv *ecmagent*.* ecmagent
git mv pending/*ecmagent* ecmagent
mv pending/*ecmagent* ecmagent
