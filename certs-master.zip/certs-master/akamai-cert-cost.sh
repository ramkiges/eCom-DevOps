#!/bin/sh
#https://jira.wsgc.com/browse/MEAD-32819

DATE=$(date +'%Y-%m-%d')
OUT=akamai-cert-cost.csv
echo "Hostname, Cert, NoCert" > $OUT

CERT_YES=0 
CERT_NO=0

for e in $(getenvlist)
do
  [[ $e =~ jukebox ]] && break
  for b in $(getbrandlist)
  do
    akamai=$(getakamai $b $e | awk -F/ '{print $3 }')
    cert=$(openssl s_client -connect $akamai:443 </dev/null 2>/dev/null | openssl x509 -noout -text 2>/dev/null | grep -i "DNS:" | grep -i $akamai)
    if [[ -n $cert ]]
    then 
      cert="X," 
      CERT_YES=$(expr $CERT_YES + 1) 
    else
      cert=",X" 
      CERT_NO=$(expr $CERT_NO + 1)
    fi
    echo "$akamai,$cert" 
    echo "$akamai,$cert" >> $OUT
  done
done

echo "Total,$CERT_YES,$CERT_NO" >> $OUT

git add $OUT $0
git commit -a -m "Update $DATE"
git push

