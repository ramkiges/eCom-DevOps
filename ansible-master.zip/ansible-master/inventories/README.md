Inventories
==========

We have more than one inventory to protect production.


