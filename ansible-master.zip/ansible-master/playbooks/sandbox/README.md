WSGC Sandbox
=========

`setup.yml` is the playbook to build the sandbox machine.

`ansible-playbook playbooks/sandbox/setup.yml -i inventories/qa -u your_a_user`
