WSGC SSH Key Copy
=================

This playbook copies your public key into the target host to enable you to execute ansible roles passwordless.

This playbook relies upon an open source role, it's details can be [found here](https://github.com/GROG/ansible-role-authorized-key/tree/v1.1.3)

Example execution:

    ansible-playbook playbooks/setup_ssh/setup_ssh.yml -u a_bvale -i inventories/qa -l frontend --ask-pass --extra-vars="wsgc_admin_user=a_bvale user_public_key=~/.ssh/id_rsa.pub"

In this example it's targeting the `inventories/qa` inventory file, and limiting it to the `frontend` server group.  If you remove the `-l` you will apply your key to all hosts in the `qa` inventory.
