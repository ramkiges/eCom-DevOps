MEAD Tools
=========

`setup.yml` is the playbook to setup mead tools on a machine

`ansible-playbook playbooks/mead-tools/setup.yml -i inventories/qa -u your_a_user`

## Assumptions ##
Some expectations that must be satisfied prior to running this playbook:

