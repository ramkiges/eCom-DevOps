WSGC Image Server
=========

`setup.yml` is the playbook to build an Apache HTTPD image server machine.

`ansible-playbook playbooks/img-server/setup.yml -i inventories/prd -u your_a_user`

## Assumptions ##
Some expectations that must be satisfied prior to running this playbook:

  1. The image mounts (`/images` and `/images2`) are present and mounted with `tomcat:webadmin` as user/group owners.
  2. The host does not need to have yum repos configured for Ecom Artifactory, this is handled by the role due to Puppet not being able to do this in Azure.
