WSGC Test Rail
=========

`setup.yml` is the playbook to build Test Rail.

`ansible-playbook playbooks/testrail/setup.yml -i inventories/qa -u your_a_user`
