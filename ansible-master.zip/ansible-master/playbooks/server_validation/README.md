WSGC Server Validation
======================

This playbook is used to run some basic tests against a new VM received from TS.

Example execution:

    ansible-playbook playbooks/server_validation/server_validation.yml -u a_csjohnson3 -i inventories/qa -l frontend

In this example it's targeting the `inventories/qa` inventory file, and limiting it to the `frontend` server group.  The assumption being here that you've created a new group in the inventory file for the hosts to validate.
