import os
import requests
import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_node_exporter_running():
    r = requests.get("http://localhost:61535/")
    assert r.status_code == 200


# node_exporter service
def test_node_exporter_running_and_enabled(host):
    service = host.service("node_exporter")
    assert service.is_running
    assert service.is_enabled
