Node Exporter
=========

`node-exporter.yml` is the playbook to install node exporter on a machine.  [Node Exporter](https://github.com/prometheus/node_exporter) is a collector used behind [Prometheus](https://prometheus.io/).

This playbook relies upon an internal modified version of an open source role, its details can be [found here](https://galaxy.ansible.com/kevincoakley/ansible-role-prometheus-node-exporter/).

Since this targets inventories across the `prd` and `qa` inventory files, we'll need to invoke this a little differently.  Here's an example command which shows the merge of all the inventories `ansible -i inventories --list-hosts all`, so we'll need to run this playbook with `-i inventories` to specify a merged set of hosts.

Run with: `ansible-playbook playbooks/node-exporter/node-exporter.yml -i inventories -u your_a_user`