WSGC Project Inventory
=========

`setup.yml` is the playbook to install the project inventory app.

`ansible-playbook playbooks/project-inventory/setup.yml -i inventories/qa -u your_a_user`

If you are only interested in running the `application` part of the playbook, then just add `--tags=application` to the ansible command.

If for any reason you need to run alembic to upgrade the DB, you can add a `alembic` tag to the ansible command to get that task to run.
