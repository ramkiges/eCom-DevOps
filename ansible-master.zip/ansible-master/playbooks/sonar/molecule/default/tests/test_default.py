import os
import requests
import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_sonar_service(host):
    service = host.service("sonar")

    assert service.is_running
    assert service.is_enabled


def test_sonar_running():
    r = requests.get("http://localhost:9000/")
    assert r.status_code == 200
