WSGC Sonar
=========

`sonar.yml` is the playbook to build a SonarCube machine.

`ansible-playbook playbooks/sonar/sonar.yml -i inventories/prd -u your_a_user`

Run on the sandbox machine with 
`ansible-playbook playbooks/sonar/sonar.yml -i inventories/qa -u your_a_user`
