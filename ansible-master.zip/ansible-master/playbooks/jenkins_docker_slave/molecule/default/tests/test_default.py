import os
import testinfra.utils.ansible_runner
import pytest
import configparser


# Constants used by various tests.
JENKINS_HOME = "/var/lib/jenkins"
LOCALREPO_WSGC_ECOMMERCE = "/apps/maven/localrepo/com/wsgc/ecommerce"


testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


# docker service
def test_docker_running_and_enabled(host):
    service = host.service("docker")
    assert service.is_running
    assert service.is_enabled


# node_exporter service
def test_node_exporter_running_and_enabled(host):
    service = host.service("node_exporter")
    assert service.is_running
    assert service.is_enabled


# user id verification
def test_jenkins_user(host):
    user = host.user("jenkins")
    assert user.uid == 23082


# group id verification
def test_jenkins_group(host):
    group = host.group("jenkins")
    assert group.gid == 13002


# /var/lib/jenkins ownership
def test_jenkins_owns_var_lib_jenkins(host):
    directory = host.file(JENKINS_HOME)
    assert directory.exists
    assert directory.user == "jenkins"
    assert directory.group == "jenkins"
    assert directory.mode == 0o750


# test that the manually installed maven dependencies are in place
@pytest.mark.parametrize("path", [
    "wsgc-spring42-xml-deps/1.0.1/wsgc-spring42-xml-deps-1.0.1.pom",
    "wsgc-spring30-xml-deps/1.0.2/wsgc-spring30-xml-deps-1.0.2.pom",
    "tools/ftlverify/1.0.16/ftlverify-1.0.16.jar"
])
def test_manual_maven_dependencies(host, path):
    file = host.file(os.path.join(LOCALREPO_WSGC_ECOMMERCE, path))
    assert file.exists
    assert file.user == "jenkins"
    assert file.group == "users"


# tests that the npmrc file was created
def test_npmrc_file(host):
    file = host.file(os.path.join(JENKINS_HOME, ".npmrc"))
    assert file.exists
    assert file.user == "jenkins"


# tests to ensure pom helper was created
def test_pomhelper(host):
    file = host.file(os.path.join(JENKINS_HOME, 'bin/devscripts/pomhelper'))
    assert file.exists
    assert file.user == "jenkins"
    assert file.group == "users"


# tests to ensure ucp non prod kubectl config was created
def test_kubectl(host):
    filename = os.path.join(JENKINS_HOME,
                            '.kube/ucp_container-ucp.nonprod.wsgc.com/config')
    file = host.file(filename)
    assert file.exists
    assert file.user == "jenkins"
    assert file.group == "users"


def test_credentials_existence(host):
    file = host.file(os.path.join(JENKINS_HOME, '.credentials'))
    assert file.exists
    assert file.user == "jenkins"
    assert file.mode == 0o600


def test_credentials_contents(host):
    file = host.file(os.path.join(JENKINS_HOME, '.credentials'))

    contents = file.content_string

    # Make sure all substitutions happened.  (This could fail wrongly if there
    # are doubled curly brackets in, say, a password, but we'll cross that when
    # we get there.)
    assert '{{' not in contents
    assert '}}' not in contents

    config = configparser.RawConfigParser()
    config.read_string(contents)

    expectedKeywords = {
        'github': [
            'ghe_admin_token',
            'ciuser_org_owner_token',
        ],
        'ldap': [
            'user',
            'password',
        ],
        'jenkins': [
            'user',
            'password',
        ],
        'jira': [
            'user',
            'password',
        ],
        'artifactory_prod': [
            'username_ro',
            'username_ro_password',
        ],
        'artifactory_nonprod': [
            'username_ro',
            'username_ro_password',
            'username_rw',
            'username_rw"password',
        ],
    }

    for groupName, keywords in expectedKeywords:
        for keyword in keywords:
            assert keyword in config[groupName]
