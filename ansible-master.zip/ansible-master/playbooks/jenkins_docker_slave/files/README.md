Note: `plumber-settings.xml`'s actual home is as a Jenkins config
file.  The `withMaven` pipeline code extracts that file, populating
it with server credentials, and uses it when doing pipeline builds.

We keep a copy here in order to have a place to version-control
changes to it so we know who, why, and when it changed.

This file used to live in the `ci-maven-config` repository alongside
`settings.xml` (which lives in this playbook as a templated version
of the value it used to have).
