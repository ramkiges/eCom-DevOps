Invoke this playbook with:
```
 ansible-playbook \
     playbooks/jenkins_docker_slave/setup.yml \
     -i inventories/prd \
     -u <your a_ user>
```
