WSGC Rundeck
=========

`setup.yml` is the playbook to install rundeck enterprise on machine.

`ansible-playbook playbooks/rundeck/setup.yml -i inventories/prd -u a_bveeravalli`
