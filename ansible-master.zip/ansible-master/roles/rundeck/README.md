Role Name
=========
rundeck

This role is to setups rundeck prod ha pair
