Roles
------
WSI-authored roles are included in this directory.

External roles are listed in `requirements.yml` per playbook, as
needed.
