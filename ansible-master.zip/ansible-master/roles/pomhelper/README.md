Pomhelper
=========

Installs and configures the latest version of pomhelper/devscripts.

Role Variables
--------------

###### pomhelper_user

User that owns pomhelper scripts

###### pomhelper_group

User group of pomhelper scripts


###### pomhelper_user_home

The home directory of your user, where pomhelper scripts will be kept.


Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used for other roles.

Example Playbook
----------------

There's three ways of installing pomhelper. Installing in a specific remote user or using privillege escalation and locally in your machine.


### Local installation

```yml
    - hosts: localhost
      connection: local
      gather_facts: no
      tasks:
        - include_role:
            name: pomhelper
            vars:
              pomhelper_user: myuser
              pomhelper_group: mygroup
```

### Remote using privilege escalation

Assuming you have the following sudoers policy:
```
(root) NOPASSWD: ALL
```

Add this snippet to your `ansible.cfg`:

```
[privilege_escalation]
become_exe = sudo su -
```

```yml
- hosts: remote_host
  become: yes
  become_user: foo
  become_method: su
  tasks:
    - include_role:
       name: pomhelper
       vars:
         pomhelper_user: foo
         pomhelper_group: bar
         pomhelper_user_home: /home/foo
```

If you have direct access (`(desired_user) NOPASSWD: ALL`) to the remote user there's no need to configure `become_exe` and in that case use `become_method: sudo`.


### Remote server

```yml
- hosts: remote_host
  tasks:
    - include_role:
       name: pomhelper
       vars:
         pomhelper_user: foo
         pomhelper_group: bar
         pomhelper_user_home: /home/foo
```

Author Information
------------------

Bernardo Vale
