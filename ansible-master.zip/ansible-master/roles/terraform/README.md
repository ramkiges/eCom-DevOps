Role Name
=========
terraform

This role installs terraform + plugins from artifactory 