import os
import testinfra.utils.ansible_runner
import pytest

KUBE_BASE_DIR = "/home/imageuser/.kube/"

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_kubctl_is_installed(host):
    package = host.package("kubectl")
    assert package.is_installed
    assert package.version.startswith("1.8.15")


@pytest.mark.parametrize("name", [
    f"{KUBE_BASE_DIR}/ucp_container-ucp.nonprod.wsgc.com/config",
])
def test_check_legacy_config_file(host, name):
    c = host.file(name)
    assert c.exists
    assert c.contains("v1")


@pytest.mark.parametrize("usernameAndCluster", [
    {'username': 'ciuser',
     'cluster': 'ucp_container-api01.nonprod.wsgc.com'},
    {'username': 'ciuser',
     'cluster': 'ucp_container-api01.wsgc.com'},
    {'username': 'ciuser',
     'cluster': 'ucp_container-api02.wsgc.com'},
    {'username': 'ciuser',
     'cluster': 'ucp_container-api03.wsgc.com'},
    {'username': 'ciuser',
     'cluster': 'ts-sharedplatform-rck-nonprod'},
    {'username': 'ciuser',
     'cluster': 'ts-sharedplatform-ash-prod'},
    {'username': 'ciuser',
     'cluster': 'ts-sharedplatform-sac-prod'},
    {'username': 'svcak8sci',
     'cluster': 'ts-sharedplatform-rck-nonprod'},
    {'username': 'svcak8sci',
     'cluster': 'ts-sharedplatform-ash-prod'},
    {'username': 'svcak8sci',
     'cluster': 'ts-sharedplatform-sac-prod'},
    {'username': 'svcaedapci',
     'cluster': 'ucp_container-api01.nonprod.wsgc.com'},
    {'username': 'svcaedapci',
     'cluster': 'ts-sharedplatform-rck-nonprod'},
    {'username': 'svcaedapci',
     'cluster': 'ts-sharedplatform-sac-prod'},
    {'username': 'svcaedapci',
     'cluster': 'ts-sharedplatform-ash-prod'},
    {'username': 'svcaedapci',
     'cluster': 'edap-trillium-rck-nonprod'},
    {'username': 'svcaedapci',
     'cluster': 'edap-trillium-sac-prod'},
    {'username': 'svcaedapci',
     'cluster': 'edap-trillium-ash-prod'},
    {'username': 'svcaintlci',
     'cluster': 'ucp_container-api01.nonprod.wsgc.com'},
    {'username': 'svcaintlci',
     'cluster': 'ucp_container-api02.wsgc.com'},
    {'username': 'svcaintlci',
     'cluster': 'ucp_container-api03.wsgc.com'},
    {'username': 'svcaintlci',
     'cluster': 'ts-sharedplatform-rck-nonprod'},
    {'username': 'svcamcp',
     'cluster': 'ucp_container-api01.nonprod.wsgc.com'},
    {'username': 'svcamcp',
     'cluster': 'ts-sharedplatform-rck-nonprod'},
])
def test_check_config_file(host, usernameAndCluster):
    username = usernameAndCluster['username']
    cluster = usernameAndCluster['cluster']
    clusterFullName = f"{cluster}:6443_{username}"
    c = host.file(f"{KUBE_BASE_DIR}/{username}/{cluster}")
    assert c.exists
    assert c.contains(f"name: {clusterFullName}")
    assert c.contains(f"current-context: {clusterFullName}")
