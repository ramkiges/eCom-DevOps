Ansible Role: kubectl
=========
Install Kubernetes, and populate kubectl_user's .kube directory with credential files
for the users in kube_config_users.

Role Variables
--------------
**`kubectl_package`**
 - The version of the kubectl package to install on the target.

**`kubectl_user`**
 - The username of the user whose `.kube` directory will be populated with credentils.

**`kube_config_usernames`**
 - The list of docker enterprise usernames whose credentials will be installed.

Example Playbook
----------------
```
    - hosts: servers
      roles:
         - { role: kubectl }
      vars:
         kubectl_user: mykubeuser
         kube_config_usernames:
           - ciuser
           - svcaotherdeptmt
```
