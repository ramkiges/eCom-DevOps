import os
import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


# node_exporter service
def test_node_exporter_running_and_enabled(host):
    service = host.service("node_exporter")
    assert service.is_running
    assert service.is_enabled
