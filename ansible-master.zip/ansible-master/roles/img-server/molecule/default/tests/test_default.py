import os
import testinfra.utils.ansible_runner
import pytest

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_images_directory(host):
    directory = host.file("/images")
    assert directory.exists
    assert directory.is_directory


@pytest.mark.parametrize("apache_package", [
    "httpd", "mod_ssl"
])
def test_apache_packages(host, apache_package):
    package = host.package(apache_package)
    assert package.is_installed


def test_apache_group(host):
    apache = host.group("webadmin")
    assert apache.exists


def test_apache_user(host):
    apache = host.user("tomcat")
    assert apache.exists


def test_apache_config(host):
    path = "/etc/httpd/conf.d/img-server.conf"
    conf_file = host.file(path)
    assert conf_file.contains("/images/ecom-images")


def test_svc(host):
    service = host.service("httpd")
    assert service.is_running
    assert service.is_enabled
