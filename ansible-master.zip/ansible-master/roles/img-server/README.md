Role Name
=========
img-server

This role is to install img-server.  An Apache HTTPD static image server.
