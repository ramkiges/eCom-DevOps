Jenkins Master Role
=========

This role configures a Jenkins master server. This is a drop in translation of [toolchain-jenkins-config](https://github.wsgc.com/eCommerce-DevOps/toolchain-jenkins-config).

Requirements
------------

A TS provisioned CentOS 7

Role Variables
--------------

##### wsi_jenkins_dependencies

A list of yum packages that should be installed using a wsi yum repo:

```
yum --disablerepo=* --enablerepo=wsgc-* -y install
```

##### base_dependencies

A list of yum packages that **should not** be installed using a wsi yum repo:

```
yum -y install
```

##### jenkins_war_version

A variable that holds Jenkins version. Override it to upgrade/downgrade Jenkins version

##### jenkins_home

Jenkins root folder (env variable JENKINS_HOME)

##### jenkins_jdk_path

JAVA_HOME that should be used by jenkins.

##### jenkins_backup_path

A folder to hold backups of JENKINS_HOME

##### jenkins_maven_repos

A list of folders that hold local maven repositories.

Dependencies
------------

- [pomhelper](https://github.wsgc.com/eCommerce-DevOps/pomhelper-role)

We need `pomhelper` in the Jenkins master but since the installation process requires a different privillege escalation process, it is not included inside this role, but it should be included in jenkins configuration playbook.

Example Playbook
----------------

Sensitive data was encrypted using [Ansible Vault](docs.ansible.com/ansible/latest/vault.html). To use this role you'll need to first create a vault password file. Ask Tahoe team for the password.

Configure your ansible.cfg to always use the password file:

```
vault_password_file = /path/to/.vault_pass.txt
```

Add the password in the first line of your vault password file.

Write a simple `playbook.yml` including also `pomhelper` in a separate play:

```yml
    - hosts: jenkins2
      remote_user: your_a_user
      gather_facts: no
      tasks:
        - name: Setup Jenkins Master
          include_role:
            name: jenkins-master
          tags: jenkins
    - hosts: jenkins2
      gather_facts: no
      remote_user: your_a_user
      become: yes
      become_user: jenkins
      become_method: su
      tasks:
        - name: Configure Pomhelper
          include_role:
            name: pomhelper
          tags: pomhelper
```

Run it:

```
ansible-playbook playbook.yml
```

Author Information
------------------

Bernardo Vale
