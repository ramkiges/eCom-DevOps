AppDynamics
=========

Installs and configures the appdynamics agent

SVN: devops/application/common/service/wsgc-apmagents/trunk

Role Variables
--------------


Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used for other roles.

