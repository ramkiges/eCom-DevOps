Ansible Role: new_server_validation
=========

This role is expected to be run on a new host provided by TS to validate we have the access we need on the host, as well as any other new server requirements (connectivity, etc).

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: new_server_validation }

License
-------

Proprietary

