Role Name
=========

A role to install DataStax Enterprise Cassandra

Requirements
------------

A VM provisioned by TS running CentOS 7

Role Variables
--------------

See `defaults/main.yml`

Example Playbook
----------------

    - hosts: servers
      gather_facts: true
      roles:
        - dse

License
-------

BSD

Author Information
------------------

Blame Andy
