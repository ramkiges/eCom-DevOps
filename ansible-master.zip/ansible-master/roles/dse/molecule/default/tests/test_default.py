import os
import testinfra.utils.ansible_runner
import pytest

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


@pytest.mark.parametrize("apache_package", [
    "httpd", "mod_ssl"
])
def test_apache_packages(host, apache_package):
    package = host.package(apache_package)
    assert package.is_installed


def test_webadmin_group(host):
    webadmin = host.group("webadmin")
    assert webadmin.exists


def test_apache_user(host):
    tomcat = host.user("tomcat")
    assert tomcat.exists


def test_apache_config(host):
    path = "/etc/httpd/conf.d/dse.conf"
    conf_file = host.file(path)
    assert conf_file.contains("38667")


def test_dse_user(host):
    cassandra = host.user("cassandra")
    assert "cassandra" in cassandra.groups


@pytest.mark.parametrize("dse_package", [
    "dse-full", "datastax-agent"
])
def test_dse_packages(host, dse_package):
    package = host.package(dse_package)
    assert package.is_installed


@pytest.mark.parametrize("path", [
    "/etc/dse/", "/etc/dse/cassandra",
    "/database"
])
def test_app_directories_with_ownership(host, path):
    directory = host.file(path)
    assert directory.exists
    assert directory.user == "cassandra"


@pytest.mark.parametrize("path", [
    "/etc/default/dse", "/etc/dse/cassandra/logback.xml",
    "/etc/init.d/wsgc-dse"
])
def test_cassandra_logdir_expansion(host, path):
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("/var/log/weblogs/cassandra")


@pytest.mark.parametrize("path", [
    "/etc/datastax-agent/log4j.properties", "/etc/init.d/wsgc-datastax-agent"
])
def test_agent_logdir_expansion(host, path):
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("/var/log/weblogs/datastax-agent")


def test_address_expansion(host):
    path = "/etc/datastax-agent/address.yaml"
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("172.17.0.41")


def test_main_conf_expansion(host):
    path = "/etc/dse/cassandra/cassandra.yaml"
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("snitch: GossipingPropertyFileSnitch")


def test_env_conf_expansion(host):
    path = "/etc/dse/cassandra/cassandra-env.sh"
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("/apps/cassandra/jmxremote.password")


def test_rackdc_expansion(host):
    path = "/etc/dse/cassandra/cassandra-rackdc.properties"
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("dc=dc1")
    assert conf_file.contains("rack=rac1")
