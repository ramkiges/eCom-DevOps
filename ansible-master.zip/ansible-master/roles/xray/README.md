# Xray
The xray role will install Xray software onto the host. An Artifactory server and Postgress database is required.


## Upload Jfrog Xray package to files
Download jfrog-xray-3.11.0-linux.tar.gz file from https://releases.jfrog.io/artifactory/jfrog-xray/xray-linux/3.11.0/ and copy it to files/, and running playbook should copy this file onto server path

- name: Copy xray tar
  become: true
  copy:
    src: jfrog-xray-3.11.0-linux.tar.gz
    dest: "{{ jfrog_home_directory }}"

Ansible Role: xray
=========

A role that sets up xray 3

Requirements
------------

## Install below collections using ansible-galaxy
---
collections:
  - community.general
  - jfrog.platform

Role Variables
--------------

None

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: xray }
      become: true
