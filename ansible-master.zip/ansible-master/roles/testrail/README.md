Testrail
=========

This role installs Testrail via docker-compose

Due to currently unresolved issues with the testrail apache image, we're using our own image
built from theirs that incorporates necessary corrections.
The Dockerfile used to build said image can be found in this directory.
Details on the problems can be found in said Dockerfile.  But, in short: we will know the 
official image is sufficient on its own when apache will start by simply supplying the `SSL`
environment variable and mounting our cert/key.

Requirements
------------

This role expects the `docker` role to have been run on the machine prior to execution.

Role Variables
--------------

No user modifiable variables



Example Playbook
----------------

    - hosts: servers
      roles:
         - { role: testrail }

