mvnrelease-k8s
=========

This role installs the `mvnrelease-scripts` files for use in creating production releases of WSI eCom Kubernetes packages

Requirements
------------

Currently this role is intended to be used only as part of the Jenkins slave playbook (and thus run on a Jenkins slave host).  This role requires the mvnrelease binary itself to be installed.  The implicit presumption is that this will be fulfilled by installation of the `devscripts` tools via the role of the same name.  An otherwise "sane" WSI eCom Java environment is required for that role, and thus implied to be available by this role as well. Furthermore, a local docker environment is needed to build Kubernetes packages.  All of the above are expected --ultimately-- to come from the files and legacy RPM packages installed by the various roles therein.

Role Variables
--------------

See `defaults/main.yml`

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables
passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: mvnrelease-k8s }

License
-------

BSD

