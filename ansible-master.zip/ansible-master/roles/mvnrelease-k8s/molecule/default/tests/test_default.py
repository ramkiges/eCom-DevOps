import os
import testinfra.utils.ansible_runner
import pytest

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


@pytest.mark.parametrize("path", [
    "/apps/mavenrelease-tmp-mavenbuild", "/home/jenkins/mvnrelease-scripts",
    "/home/jenkins/.credentials.d"
])
def test_app_directories_with_ownership(host, path):
    directory = host.file(path)
    assert directory.exists
    assert directory.user == "jenkins"


@pytest.mark.parametrize("path", [
    "/home/jenkins/.credentials.d/artifactory-devopsbuild-user",
    "/home/jenkins/.credentials.d/artifactory-mavenbuild-user"
])
def test_credential_files(host, path):
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("USER")


def test_mvnrelease_template_expansion(host):
    path = "/home/jenkins/mvnrelease-scripts/lib/mvnrelease.mvntemplate"
    conf_file = host.file(path)
    assert conf_file.exists
    assert conf_file.contains("ciuser")


def test_helm_installation(host):
    path = "/usr/local/bin/helm"
    conf_file = host.file(path)
    assert conf_file.exists


def test_helm_repo_removal(host):
    path = "/home/jenkins/.helm/repository/repositories.yaml"
    repo_file = host.file(path)
    assert not repo_file.contains("name: stable")


def test_helm_jukebox_add(host):
    path = "/home/jenkins/.helm/repository/repositories.yaml"
    repo_file = host.file(path)
    assert repo_file.contains("name: jukebox")


def test_helm_service_install(host):
    path = "/etc/systemd/system/multi-user.target.wants/helm-serve.service"
    service_file = host.file(path)
    assert service_file.exists
