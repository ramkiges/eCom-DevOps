Role Name
=========
mead-tools

This role is to install mead-tools - a set of scripts for day-to-day MEAD tasks
