# postgres
The postgres role will install Postgresql software and configure a database and user to support an Artifactory or Xray server.

Ansible Role: artifactory-postgres
=========

A role that sets up postgres 13

Requirements
------------

## Install below collections using ansible-galaxy
---
collections:
  - community.postgresql
  - community.general

Role Variables
--------------

None

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: artifactory-postgres }
      become: true
