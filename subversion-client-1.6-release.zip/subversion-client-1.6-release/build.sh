#!/bin/sh
PATH=/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:~/bin

BailOut() {
  [[ -n $1 ]] && BailOut "$*"
  exit 255
}

BRANCH=$(hostname --short)
#git checkout -q $BRANCH || git checkout -q -B $BRANCH
#git push -q --set-upstream origin $BRANCH

if [[ $1 =~ clean ]]
then
  for dir in apr apr-iconv apr-util autoconf sqlite-autoconf neon subversion serf
  do
    cd $dir
    make clean
    make distclean
    cd ..
  done
  exit 0
fi

sudo yum -y install m4 neon neon-devel automake autoconf expat expat-devel zlib zlib-devel openssl openssl-devel -d0

#cd autoconf
#./configure && make && sudo make install || BailOut
#cd ..

#cd sqlite-autoconf
#./configure && make && sudo make install
#cd ..

echo "apr"
cd apr
./configure --with-apr=/usr/local/apr && make && make install || BailOut
cd ..

echo "apr-iconv"
cd apr-iconv
./configure --with-apr=/usr/local/apr && make && make install || BailOut
cd ..

echo "arp-util"
cd apr-util 
./configure --with-apr=/usr/local/apr && make && make install || BailOut
cd ..

echo "serf"
cd serf
../scons -c
../scons PREFIX=/usr/local APR=/usr/local/apr APU=/usr/local/apr || BailOut
#../scons PREFIX=/usr/local || BailOut
../scons PREFIX=/usr/local -i install || BailOut
#OPENSSL=/openssl/base 
cd ..

cd subversion
make distclean
#--with-apr-util=/usr/local/apr 
./configure --enable-plaintext-password-storage --with-serf=/usr/local --with-ssl --with-apr-util=/usr/local/apr --with-lz4=internal --with-utf8proc=internal --with-neon || BailOut
make && make install || BailOut
cd ..

