#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/scripts/env_summary:$HOME/bin:$PATH

# bring in common functions
base=$(dirname $0)
[[ -z $base ]] && base=.
. $base/k8s-audit.env || exit 1

git pull -q --rebase >/dev/null 2>&1

rm -f $NOREFS_CSV.new
touch $NOREFS_CSV

# initialize the decom file
rm -f $DECOM_CSV
decomCSV "Namespace,Pods,CPU,Memory,Suggested Decom Reason"

ORG_LIST=$(awk -F, '{ print $4 }' $NS_CSV | sort -u | grep -ivw "org" | egrep -iv "$ORG_EXCLUDE|ecommerce|devops|releasemanagement")
ORG_LIST="ecommerce releasemanagement devops $ORG_LIST"
# override for testing
#echo "ORG_LIST: $ORG_LIST"

# create a list of all of the pages
HEADER="⋅"
i=1
for org in $ORG_LIST
do
  label=$(org2Label $org)
  #echo "org: $org $label"
  url="https://confluence.wsgc.com/display/$DOC_SPACE/$TITLE - $label"
  url=$(sed -es/' '/'+'/g <<< $url)
  HEADER="$HEADER <a href='$url'>$label</a>"
  #HEADER="$HEADER $label"
  [[ $(expr $i % 15) -eq 0 ]] && HEADER="$HEADER ⋅<br/>⋅" || HEADER="$HEADER ⋅"
  i=$(expr $i + 1)
done

HEADER="$HEADER
<table border='1'>
<tr><th><font size='-1'>Key</font></th></tr>
<tr><td bgcolor='$COLOR_NOPOD'><font size='-1'>No running pods found</font></td></tr>
<tr><td bgcolor='$COLOR_NOREF'><font size='-1'>No references found</font></td></tr>
<tr><td bgcolor='$COLOR_LOGS'><font size='-1'>No recent logs found for past $LOG_WINDOW</font></td></tr>
<tr><td bgcolor='$COLOR_SKIP'><font size='-1'>Namespace less than $NS_DAYS days old</font></td></tr>
<tr><td bgcolor='$COLOR_DECOM'><font size='-1'>DeCom Candidate</font></td></tr>
<tr><td><font size='-1'>$ICON_MFT Referenced in Manifest</font></td></tr>
<tr><td><font size='-1'>$ICON_SVN Referenced in AppSetting</font></td></tr>
<tr><td><font size='-1'>$ICON_HLM Referenced in Helm Chart</font></td></tr>
</table>"

for org in $ORG_LIST
do
  label=$(org2Label $org)
  #echo "org: $org $label"
  total_cpu=0
  total_mem=0
  total_pod=0

  export PAGENAME="Kubernetes Namespace Audit - $label"
  export OUTFILE=k8s-audit-$org.html
  rm -f $OUTFILE 

  HTML "<table border='1'>"
  HTML "<tr><th><font size='-1'>Total CPU</font></th><td><font size='-1'>@@TOTAL_CPU@@ cores</font></td></tr>"
  HTML "<tr><th><font size='-1'>Total Memory</font></th><td><font size='-1'>@@TOTAL_MEM@@Tb</font></td></tr>"
  HTML "</table>"
  HTML "<p><a href='https://github.wsgc.com/eCommerce-DevOps/kubernetes-namespace-audit/blob/release/$DECOM_CSV'><b>Decom Candidates</b></a></p>"

  HTML "$HEADER"
  HTML ""

  #APP_LIST="ecom-app-shop"
  APP_LIST=$(grep -i ",$org," $NS_CSV | awk -F, '{ print $3 }' | sort -u)
  #echo "APP_LIST: $APP_LIST"
  for app in $APP_LIST
  do
    #echo "  $org:$app"
    rm -f $OUTFILE.stub
    problem=
    app_count=$(grep ",$app,$org," $NS_CSV | wc -l | awk '{ print $1 }')
    [[ $app_count -eq 0 ]] && continue

    STUB "<!-- $app -->"
    STUB "<h4>$app ($app_count)</h4>"
    STUB "<table border='1' width='55%'>"
    STUB ""
    STUB "  <tr>"
    STUB "    <th style='text-align:center' width='40%'>Namespace</th>"
    STUB "    <th style='text-align:center' width='10%'>Pods</th>"
    STUB "    <th style='text-align:center' width='10%'>CPU</th>"
    STUB "    <th style='text-align:center' width='10%'>Memory</th>"
    STUB "    <th style='text-align:center' width='10%'>Namespace<br>Age</br></th>"
    STUB "    <th style='text-align:center' width='10%'>Pod<br>Age</br></th>"
    STUB "    <th style='text-align:center' width='10%'>References</th>"
    STUB "  </tr>"

    # set a flag if this ns is referenced in a manifest or an appsetting
    refs=$(grep ",$app,$org," $NS_CSV | awk -F, '{ print $15 $16 }' | egrep -iv "^$")
    for ns in $(grep ",$app,$org," $NS_CSV | awk -F, '{ print $2 }' | egrep -iv "$NS_EXCLUDE" | sort -u)
    do
      #echo "ns: $ns"
      BGCOLOR=
      P_BGCOLOR=
      U_BGCOLOR=

      p_cnt=$(grep ",$ns," $NS_CSV | awk -F, '{ print $6 }' | tail -1)
      p_age=$(grep ",$ns," $NS_CSV | awk -F, '{ print $7 }' | tail -1)
      cpu=$(grep ",$ns," $NS_CSV | awk -F, '{ print $9 }' | tail -1)
      mem=$(grep ",$ns," $NS_CSV | awk -F, '{ print $11 }' | tail -1)
      ns_age=$(grep ",$ns," $NS_CSV | awk -F, '{ print $14 }' | tail -1)
      mft=$(grep ",$ns," $NS_CSV | awk -F, '{ print $15 }' | tail -1)
      svn=$(grep ",$ns," $NS_CSV | awk -F, '{ print $16 }' | tail -1)
      log=$(grep ",$ns," $NS_CSV | awk -F, '{ print $17 }' | tail -1)
      [[ $log = "0" ]] && log=

      [[ -z $mft ]] && mft=$(grep -i ",$ns," $ENDPOINT_CSV | head -1 | awk -F, '{ print $3 }')
      hlm=$(grep -i "$ns," $HELMINFO_CSV | head -1 | awk -F, '{ print $2 "/" $3 "/" $4}')

      [[ -n $mft ]] && mft=$ICON_MFT 
      [[ -n $svn ]] && svn=$ICON_SVN
      [[ -n $hlm ]] && hlm=$ICON_HLM

      [[ -z $cpu ]] && cpu=0
      [[ -z $mem ]] && mem=0

      # increment totals
      [[ $cpu =~ m ]] && cpu=$(sed -es/m//g <<< $cpu) || cpu=$(expr $cpu \* 1000)
      total_cpu=$(expr $total_cpu + $cpu)

      [[ $mem =~ Gi ]] && mem=$(sed -es/Gi//gi <<< $mem)
      total_mem=$(expr $total_mem + $mem)

      [[ -n $refs && -z $mft && -z $svn && -z $hlm ]] && { echo "$ns,$p_cnt,$cpu,$mem" >> $NOREFS_CSV.new; U_BGCOLOR=$COLOR_NOREF; }
      [[ $p_cnt -eq 0 ]] && P_BGCOLOR=$COLOR_NOPOD
      [[ -z $log ]] && L_BGCOLOR=$COLOR_LOGS || L_BGCOLOR=

      if [[ -z $mft && -z $svn && -z $hlm ]]
      then
        msg="$ns,$p_cnt,$cpu,$mem,"
        reason=

        if [[ -z $log || $p_cnt -eq 0 ]]
        then
          [[ -z $log ]] && reason="no-logs"
          [[ $p_cnt -eq 0 ]] && reason="no-pods" 
          #reason=$(tr ' ' '/' <<< $reason)
          decomCSV "${msg}${reason}"
          echo "$n" | egrep -iq "$DECOM_EXCLUDE|$APP_EXCLUDE" || BGCOLOR=$COLOR_DECOM
        fi
      else
        BGCOLOR=
      fi

      ns_days=$(age2days $ns_age)
      [[ $NS_DAYS_SKIP =~ true ]] && continue
      [[ $ns_days -lt $NS_DAYS ]] && { P_BGCOLOR=$COLOR_SKIP; BGCOLOR=$COLOR_SKIP; U_BGCOLOR=$COLOR_SKIP; };

      [[ $APP_EXCLUDE =~ $app ]] && continue;

      STUB "  <tr>"
      STUB "    <td bgcolor='$BGCOLOR'><font size='-1'>$ns</font></td>"
      STUB "    <td bgcolor='$P_BGCOLOR'><font size='-1'>$p_cnt</font></td>"
      STUB "    <td bgcolor='$BGCOLOR'><font size='-1'>$cpu</font></td>"
      STUB "    <td bgcolor='$BGCOLOR'><font size='-1'>$mem</font></td>"
      STUB "    <td bgcolor='$L_BGCOLOR'><font size='-1'>$ns_age</font></td>"
      STUB "    <td bgcolor='$BGCOLOR'><font size='-1'>$p_age</font></td>"
      STUB "    <td bgcolor='$U_BGCOLOR'><font size='-1'>${mft} ${svn} ${hlm}</font></td>"
      STUB "  </tr>"
      STUB 

    done # ns
    STUB "</table>"
    cat $OUTFILE.stub >> $OUTFILE
    rm -f $OUTFILE.stub
  done # app

  # update total tokens
  total_cpu=$(expr $total_cpu / 1000)
  total_mem=$(bc <<< "scale=2; $total_mem/1024")
  sed -es/@@TOTAL_CPU@@/$total_cpu/g -i $OUTFILE
  sed -es/@@TOTAL_MEM@@/$total_mem/g -i $OUTFILE

  { set +x; } 2>/dev/null
  HTML "<br/><a href='https://github.wsgc.com/eCommerce-DevOps/kubernetes-namespace-audit'>GitHub: kubernetes-namespace-audit</a>"
  HTML "<br/>Organization exclusions: <i>$(tr '|' ' ' <<< $ORG_EXCLUDE)</i>"
  HTML "<br/>Namespace exclusions: <i>$(tr '|' ' ' <<< $NS_EXCLUDE)</i>"
  HTML "<br/>Application exclusions: <i>$(tr '|' ' ' <<< $APP_EXCLUDE)</i>"
  HTML "<br/>DeCom exclusions: <i>$(tr '|' ' ' <<< $DECOM_EXCLUDE)</i>"

  echo
  echo "*** Update confluence $PAGENAME $OUTFILE"
  #set -x
  #sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert || BailOut "Confluence update failed"
  sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --parent "$PARENT" --action storepage --file $OUTFILE --noConvert || BailOut "Confluence update failed"
  { set +x; } 2>/dev/null
  rm -f $OUTFILE
  echo
done # org

sort -u $NOREFS_CSV.new > $NOREFS_CSV

# decom stats
decom_mem=0
decom_cpu=0
decom_pod=0

for line in $(sort -u $DECOM_CSV | egrep -iv "Namespace")
do
  p=$(awk -F, '{ print $2 }' <<< $line)
  c=$(awk -F, '{ print $3 }' <<< $line)
  m=$(awk -F, '{ print $4 }' <<< $line)

  [[ -z $p ]] && p=0
  [[ -z $c ]] && c=0
  [[ -z $m ]] && m=0

  if [[ $p -gt 0 ]]
  then
    #[[ $c =~ m ]] && c=$(sed -es/m//g <<< $c) || c=$(expr $c \* 1000)
    [[ $m =~ Gi ]] && m=$(sed -es/Gi//gi <<< $m)

    decom_pod=$(expr $decom_pod + $p)
    decom_mem=$(expr $decom_mem + $m)
    decom_cpu=$(expr $decom_cpu + $c)
  fi
done

decom_cpu=$(expr $decom_cpu / 1000)
decom_mem=$(bc <<< "scale=2; $decom_mem/1024")

decomCSV "Total,${decom_pod} pods,${decom_cpu} cores,${decom_mem} Tb,"

commitCSV

exit 0
