#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/scripts/env_summary:$HOME/bin:$PATH

# bring in common functions
base=$(dirname $0*save)
[[ -z $base ]] && base=.
. $base/k8s-audit.env

git pull -q --rebase >/dev/null 2>&1

#ENV_LIST="uat3"
#APP_LIST=

[[ -z $ENV_LIST ]] && ENV_LIST=$(get-env-list)

rm -f $ENDPOINT_CSV.new

for e in $ENV_LIST
do
  [[ -z $APP_LIST ]] && APP_LIST=$(get-svc-endpoint $e 2>/dev/null)

  for app in $APP_LIST
  do
    ep=$(get-svc-endpoint $e $app 2>/dev/null | awk -F/ '{ print $3 }' | awk -F. '{ print $1 }')
    echo "$app,$e,$ep," >> $ENDPOINT_CSV.new
  done
done

sort -u $ENDPOINT_CSV.new > $ENDPOINT_CSV

commitCSV

exit 0
