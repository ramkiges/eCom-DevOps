#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/scripts/env_summary:$HOME/bin:$PATH

BailOut() {
  [[ -n $1 ]] && echo "Error: $*" >&2
  exit 255
}

cleanUp() {
{ set +x; } 2>/dev/null
  cd /tmp
  [[ -e $TMP && -n $TMP ]] && rm -rf $TMP
}
#trap cleanUp EXIT

export APPSETTINGS=https://repos.wsgc.com/svn/devops/packaging/wsgc-appsettings-configuration/trunk/appsetting-properties/schema-site

#TMP=$(mktemp -d -t tmp.$(basename $0 | sed -es/\.sh//g).XXX)
TMP=/tmp/$(basename $0 | sed -es/\.sh//g)-$LOGNAME
rm -rf $TMP; mkdir -p $TMP

git clone -q --depth 1 git@github.wsgc.com:eCommerce-DevOps/kubernetes-namespace-audit.git $TMP || BailOut "Can't clone audit repo"

cd $TMP || BailOut "Unable to cd to $TMP"

cp run-k8s-data-collection.sh /apps

date
cd $TMP || BailOut "Unable to cd to $TMP"
set -x
eval ./k8s-audit-helm.sh
{ set +x; } 2>/dev/null
echo

date
cd $TMP || BailOut "Unable to cd to $TMP"
set -x
eval ./k8s-audit-endpoints.sh
{ set +x; } 2>/dev/null
echo

date
cd $TMP || BailOut "Unable to cd to $TMP"
set -x
eval ./k8s-audit-data.sh
{ set +x; } 2>/dev/null
echo

date
set -x
cd $TMP || BailOut "Unable to cd to $TMP"
eval ./k8s-audit-report.sh
{ set +x; } 2>/dev/null
echo

date

exit 0
