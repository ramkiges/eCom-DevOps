#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/scripts/env_summary:$HOME/bin:$PATH

# bring in common functions
base=$(dirname $0)
[[ -z $base ]] && base=.
. $base/k8s-audit.env

git pull -q --rebase >/dev/null 2>&1

TMP=$(mktemp -d -t tmp.$(basename $0 | sed -es/\.sh//g).XXX)
git clone -q --depth 1 $MANIFEST $TMP/mft || BailOut "Unable to clone manifest ($MANIFEST)"
svn co -q $APPSETTINGS $TMP/svn || BailOut "Unable to clone appsettings ($APPSETTINGS)"

# this gives us the option to spec a small subnet of namespaces for testing
#NS_LIST="ecommerce-osspublisher-caqa"
[[ -z $NS_LIST ]] && NS_LIST=$($KC get namespace | egrep -i "^ecom|^edap|^plat" | egrep -iv "$NS_EXCLUDE" | awk '{ print $1 }' | sort -u)

rm -f $EMPTYPOD_CSV
touch $EMPTYPOD_CSV

rm -f $ERRORFILE

rm -f $NS_CSV.new

for ns in $NS_LIST
do
  svn=
  mft=
  org=$(awk -F- '{ print $1 }' <<< $ns)
  env=$(awk -F- '{ print $NF }' <<< $ns)
  app=$(sed -es/"$org-"//g -es/"-$env"//g <<< $ns)

  # skip apps in the exclude list
  echo "$app" | egrep -iq "$APP_EXCLUDE" && continue

  # small manipulations of the org name
  [[ $org = "ecom" ]] && org="ecommerce"
  org=$(org2Label $org | tr '[:upper:]' '[:lower:]')
#echo "ns: $ns ($org)"

  pod_count=$($KC get pods -n $ns 2>/dev/null | egrep -iv "^NAME" | wc -l | awk '{ print $1 }')
  pod_age=$($KC get pods -n $ns --sort-by=.metadata.creationTimestamp 2>/dev/null | awk '{ print $NF }' | grep -iv "AGE" | head -1)
  ns_age=$($KC get namespace  2>/dev/null | grep "^$ns " | awk '{ print $NF }')

  # need to get some clarity around this bit
  for ingress in $($KC describe ingress -n $ns 2>/dev/null | egrep -i "terminates|wsgc.com" | awk '{ print $NF }' | sort -u)
  do
    echo "$ns,$ingress" >> $INGRESS_CSV

    ## look for the ingress in the manifest
    #[[ -z $mft ]] && mft=$(dirname $(grep -irl "$ingress\." $TMP/mft) 2>/dev/null)

    # look for the ingress in svn
    svn=$(grep -ihr "$ingress" $TMP/svn 2>/dev/null | egrep -iv "CORS.ALLOWED_ORIGINS" | awk -F= '{ print $1 }' | awk -F\. '{ print $1 "." $2 }' | sort -u | tr '\n' ' ')
  done

  # there are several various permuations of the namespace usage
  ns_new=$(xlateNamepace $ns)
  ns_short=$(sed -es/"^$org-"//gi <<< $ns)
  ns_short_new=$(xlateNamepace $ns_short)

  [[ -z $mft ]] && mft=$(dirname $(egrep -irl "$ns|$ns_new|$ns_short|$ns_short_new" $TMP/mft) 2>/dev/null)
  [[ -z $mft ]] && mft=$(egrep -i ",$ns,|,$ns_new,|,$ns_short,|,$ns_short_new," $ENDPOINT_CSV | head -1 | awk -F, '{ print $3 }')
  [[ -z $svn ]] && svn=$(egrep -ihr "$ns|$ns_new|$ns_short|$ns_short_new" $TMP/svn 2>/dev/null | egrep -iv "CORS.ALLOWED_ORIGINS" | awk -F= '{ print $1 }' | awk -F\. '{ print $1 "." $2 }' | sort -u | tr '\n' ' ')

  for s in $svn
  do
    echo "$ns,$s" >> $APPSETTING_CSV
  done

  [[ -n $mft ]] && mft=true

  #for pod in $($KC get pods -n $ns 2>/dev/null | egrep -iv "^NAME" | awk '{ print $1 }')
  #do
  #  echo "  $pod"
  #  $KC -n $ns describe PodMetrics $pod
  #done

  #$KC -n $ns describe quota
  cpu_used=$($KC -n $ns describe quota 2>/dev/null | grep -i "limits.cpu" | awk '{ print $2 }' | head -1)
  cpu_hard=$($KC -n $ns describe quota 2>/dev/null | grep -i "limits.cpu" | awk '{ print $3 }' | head -1)
  mem_used=$($KC -n $ns describe quota 2>/dev/null | grep -i "limits.mem" | awk '{ print $2 }' | head -1)
  mem_hard=$($KC -n $ns describe quota 2>/dev/null | grep -i "limits.mem" | awk '{ print $3 }' | head -1)
  pod_used=$($KC -n $ns describe quota 2>/dev/null | grep -i "pods" | awk '{ print $2 }' | head -1)
  pod_hard=$($KC -n $ns describe quota 2>/dev/null | grep -i "pods" | awk '{ print $3 }' | head -1)

  # grab logs - no logs is a strong indicator of non-use
  $KC -n $ns describe quota >/dev/null 2>&1
  if [[ $? -eq 0 ]]
  then
    logs=0
    for pod in $($KC get pods -n $ns 2>/dev/null | egrep -iv "^NAME" | awk '{ print $1 }')
    do
      logs=$(expr $logs + $($KC logs -n $ns $pod --since=$LOG_WINDOW 2>/dev/null | wc -l))
    done
    #echo "logs: $ns $logs"
  else
    ERROR "Can't get logs for $ns"
    logs=
  fi

  # add the new record
  echo "$TIMESTAMP,$ns,$app,$org,$env,$pod_count,$pod_age,$cpu_used,$cpu_hard,$mem_used,$mem_hard,$pod_used,$pod_hard,$ns_age,$mft,$svn,$logs" >> $NS_CSV.new

  [[ $pod_count -eq 0 ]] && echo "$ns" >> $EMPTYPOD_CSV
done

sort -u $INGRESS_CSV > $INGRESS_CSV.new

sort -u $APPSETTING_CSV > $APPSETTING_CSV.new
mv $APPSETTING_CSV.new $APPSETTING_CSV

# replace the org names with the pretty labels
for org in $(awk -F, '{ print $4 }' $NS_CSV | sort -u | grep -iv ",org,")
do
  label=$(org2Label $org | tr '[:upper:]' '[:lower:]')
  sed -es/,$org,/,$label,/gi -i $NS_CSV
done

# add the header and sort the file
echo "$NS_HEADER" > $NS_CSV
sort -u $NS_CSV.new >> $NS_CSV

commitCSV

exit 0

