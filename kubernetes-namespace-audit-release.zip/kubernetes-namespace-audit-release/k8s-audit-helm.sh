#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/apps/scripts/env_summary:$HOME/bin:$PATH

# bring in common functions
base=$(dirname $0*save)
[[ -z $base ]] && base=.
. $base/k8s-audit.env

git pull -q --rebase >/dev/null 2>&1

#ENV_LIST="qa17"
#APP_LIST="ecom-svc-checkout"

[[ -z $ENV_LIST ]] && ENV_LIST=$(get-env-list)

rm -f $HELMINFO_CSV.new
touch $HELMINFO_CSV.new

#TMP=$(mktemp -p /apps/tmp/ -d -t tmp.$(basename $0 | sed -es/\.sh//g).XXX)
WRK=/apps/tmp/$(basename $0 | sed -es/\.sh//g -es/\.save//g)

for e in $ENV_LIST
do
  [[ -z $APP_LIST ]] && APP_LIST=$(get-manifest -e $e 2>/dev/null | sort -u | egrep -iv "app-config-all")
  for app in $APP_LIST
  do
    #echo "$e -> $app"
    repo=$(get-manifest -e $e -s $app -k pkg_branch)
    [[ -z $repo ]] && continue
    org=$(awk -F/ '{ print $1 }' <<< $repo)
    ghe=$(awk -F/ '{ print $2 }' <<< $repo)
    bch=$(awk -F/ '{ print $3 }' <<< $repo)
    #[[ -n $TMP ]] && clone=$TMP/$ghe/$org/$bch
    clone=$WRK/$app/$org/$bch
    clone=$(sed -es/ecommerce-//gi <<< $clone)
    mkdir -p $clone
    [[ -e $clone/.git ]] || git clone -q --depth 1 -b $bch git@github.wsgc.com:$org/$ghe $clone || git pull -q
    for ns in $(grep "$app," $NS_CSV | awk -F, '{ print $2 }')
    do
      #echo "  ns: $ns"
      grep -q "$ns," $HELMINFO_CSV.new && continue
      helm=$(grep -ilr "$ns" $clone | sed -es%$clone/%%g -es%config/%%g | head -1)
      #[[ -n $helm ]] && echo "  helm:$helm [$ns]"
      [[ -n $helm ]] && echo "$ns,$org,$ghe,$bch,$helm" >> $HELMINFO_CSV.new
    done
  done
done

sort -u $HELMINFO_CSV.new > $HELMINFO_CSV

commitCSV

exit 0
