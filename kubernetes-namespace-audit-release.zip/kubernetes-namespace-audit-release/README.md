Jira ticket: https://jira.wsgc.com/browse/MEADPRJ-236

Git: https://github.wsgc.com/eCommerce-DevOps/kubernetes-namespace-audit

Scripts:
  k8s-audit-data.sh - generates the namespace CSV files
  k8s-audit-endpoints.sh - generates a CSV of application endpoints
  k8s-audit-report.sh - generates namespace audit confluence page
  run-k8s-data-collection.sh - script intended to be run in cron to performa a data collection and reporting run

Datafiles:
  k8s-audit-namespace.csv - list of all namespaces and various attributes
  k8s-audit-endpoint.csv - list of all namespace endpoints
  k8s-audit-ingress.csv - list of all namespace ingress points

Background:
  We needed a way to reconcile our namespaces with the applications that use them, and even more importantly,
identify namespaces which are not being used, so they may be de-provisioned.

Methodologies:
  There are multiple ways to evaluate namespace utililization.
    * search for the namespace verbatim in the Manifest
    * get the ingress(es) for namespace and query for those in the Manifest
    * get the ingress(es) for namespace and query in appsettings
    * get the ingress(es) for namespace and look in ____ ?
