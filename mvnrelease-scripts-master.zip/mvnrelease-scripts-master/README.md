## Wrapper Scripts for Mvnrelease

These scripts use `mvnrelease` to perform releases to the production
instance of Artifactory.

Historically, the wrapper script `mvnrelease` has been used to release
using Java 1.7, and `mvnrelease1.8` to release using Java 1.8.  Those
script names have been preserved to make it easy to run past
command-lines.

There is now also an explicit `mvnrelease1.7` for releasing using 1.7.
Going forward, this is preferred over plain `mvnrelease`, for clarity.

The real work is done in `lib/mvnrelease-generic`, which releases to
the wsgc-devops-releases repo if it detects a devops project being
release, and to wsgc-releases otherwise.

To use these scripts, you'll need to put the following files in place
for your user (make them readable only to the release user):

**`~/.credentials.d/artifactory-devopsbuild-user`**
```
USERNAME=devopsbuild
PASSWORD="<password>"
```

**`~/.credentials.d/artifactory-mavenbuild-user`**
```
USERNAME=mavenbuild
PASSWORD="<password>"
```

Note that these users are defined by Artifactory, not LDAP.  The
devopsbuild user is for deploying to the `wsgc-devops-releases` repo,
and the mavenbuild user is for deploying to the `wsgc-releases` (i.e.,
non-devops) repo.

`lib/cacerts-wsi` is a copy of Java's trusted root cert authority, with
the WSI root certs added.  This allows us to talk to
`artifactory.wsgc.com` using SSL without getting cert warnings or
having to disable cert checking.

### BUGS

Due to what appears to be a bug in the JGit library used by
mvnrelease, when creating a release of a Git project you must not be
in a Git repository when you invoke these scripts.  (For example, you
can't run these scripts from a checkout of this repository.)  If you
do, mvnrelease will clone the repository into the current directory
rather than switching to the proper destination work directory, and
will fail loudly when it doesn't find what it needs.

The version of JGit mvnrelease was using was 4.1.1; the behavior was
still there with 4.7.0.
