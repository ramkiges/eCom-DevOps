# etcd-bootstrap-builder
Tools for building and publishing etcd "bootstrap" records.

These records include anything necessary to exist in etcd before it can be used by eCom tools and services.

These tools are generally expected to be used via a wrapper (such as Rundeck) for one-time setup of a new (or rebuilt) etcd cluster.

RunDeck: https://rundeck.wsgc.com/rundeck/project/wsgc/job/show/update-bootstrap-records
Jenkins: https://ecombuild.wsgc.com/jenkins/job/update-bootstrap-records/ 

