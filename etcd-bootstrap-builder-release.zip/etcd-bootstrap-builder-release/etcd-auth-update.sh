#!/bin/bash -e

# A script for updating the domain auth bootstrap records in etcd for an MFE
# environment.  Takes etcd prefix (aka the "environment" to add), etcd endpoint,
# oauth hostname, profile hostname, and uses `etcdctl` to update the record in
# etcd (the instance specified by $ETCD_ENDPOINT).
# Optionally takes an authentication environment to create the OAuth ID.
# If run with $DRYRUN set to "true", will only echo what it wants to do.

ETCD_PREFIX=${ETCD_PREFIX:-localdev}
ETCD_ENDPOINT=${ETCD_ENDPOINT:-localhost:2379}
AUTH_ENV=${AUTH_ENV:-$ETCD_PREFIX}

required_params="ETCD_PREFIX ETCD_ENDPOINT BRAND AUTH_HOST AUTH_ENV PROFILE_HOST"

for varname in $required_params
do
    if [[ -z ${!varname} ]]; then
        echo "Required parameter $varname is unset" >&2
        exit 1
    fi

    echo "$varname is [${!varname}]" 1>&2
done

CTL="etcdctl --endpoints=$ETCD_ENDPOINT"
#CTL="etcdctl --user localconfig:lcpass"
CTLOUT="/dev/null"

if [[ "$DRY_RUN" == "true" || "$DRY_RUN" == "1" ]]; then
    echo "NOTE: Dry run requested! Records will not actually be created." 1>&2
    CTL=echo
    CTLOUT="/dev/stdout"
fi

PUT="$CTL put"
GET="$CTL get"

app_record='{"id":"ecommerce","name":"Ecommerce application","configPath":"app/ecommerce/","markets":{'
app_record="$(echo ${app_record} | sed 's/,$//')}}"

echo "Updating auth domain record for $ETCD_PREFIX to '${brand}${AUTH_ENV}' ..." 1>&2

set -x
$PUT -- "${ETCD_PREFIX}/auth/${BRAND}${AUTH_ENV}" "{\"id\":\"${BRAND}${AUTH_ENV}\",\"name\":\"oAuth domain for renewing user access token\",\"contract\":{\"id\":\"oauth\",\"major\":1},\"uris\":[\"https://${AUTH_HOST}/oauth/token\"],\"profile\":{\"contract\":{\"id\":\"profile\",\"major\":1},\"uris\":[\"https://${PROFILE_HOST}/v2/profiles/\"]}}" > "$CTLOUT"
{ STATUS=$? set +x; } 2>/dev/null

exit $STATUS
