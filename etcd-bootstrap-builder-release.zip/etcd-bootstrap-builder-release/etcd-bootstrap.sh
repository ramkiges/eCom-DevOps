#!/bin/bash -e
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/apps/mead-tools
export PATH
# A script for creating bootstrap records in etcd for an MFE environment.
# Takes etcd prefix (aka the "environment" to add), etcd endpoint, and auth
# envrionment (which OAuth to use), and uses `etcdctl` to add the records to
# etcd (specified by $ETCD_ENDPOINT) starting with the prefix from $ETCD_PREFIX.
# If run with $DRYRUN set to "true", will only echo what it wants to do.

ETCD_PREFIX=${ETCD_PREFIX:-localdev}
ETCD_ENDPOINT=${ETCD_ENDPOINT:-localhost:2379}
AUTH_ENV=${AUTH_ENV:-qa}
CREATE_BRAND_AUTH_ONLY=${CREATE_BRAND_AUTH_ONLY:-false}

MARKET=${MARKET:-US}
AUTH_DC=${AUTH_DC:-rk}

required_params="ETCD_PREFIX ETCD_ENDPOINT AUTH_ENV CREATE_BRAND_AUTH_ONLY"

for varname in $required_params
do
    if [[ -z ${!varname} ]]; then
        echo "Required parameter $varname is unset" >&2
        exit 1
    fi

    echo "$varname is [${!varname}]" 1>&2
done

CTL="etcdctl --endpoints=$ETCD_ENDPOINT"
PUTCTL=$CTL
#CTL="etcdctl --user localconfig:lcpass"
CTLOUT="/dev/null"

if [[ "$DRY_RUN" == "true" || "$DRY_RUN" == "1" ]]; then
    echo "NOTE: Dry run requested! Records will not actually be created." 1>&2
    PUTCTL=echo
    CTLOUT="/dev/stdout"
fi

PUT="$PUTCTL put"
GET="$CTL get"

BASE="$ETCD_PREFIX/"

AUTH_HOST="webauth-${AUTH_ENV}-${AUTH_DC}01v.wsgc.com"
if [[ $AUTH_ENV =~ "prod" ]]; then
    AUTH_HOST="webauth-${AUTH_DC}.wsgc.com"
fi
PROFILE_HOST="ecommerce-profile-${AUTH_ENV}1.services.west.nonprod.wsgc.com"
if [[ $AUTH_ENV =~ "prod" ]]; then
    PROFILE_HOST="profile-${AUTH_DC}.wsgc.com"
fi

# putApp "id" "spec"
function putApp() {
    $PUT -- "${BASE}apps/$1" "$2" > "$CTLOUT"
}

# putAuthDomain "id" "spec"
function putAuthDomain() {
    $PUT -- "${BASE}auth/$1" "$2" > "$CTLOUT"
}

echo "Creating bootstrap records for $ETCD_PREFIX..." 1>&2

if [[ $CREATE_BRAND_AUTH_ONLY =~ "false" ]]; then
    # Create legacy auth record if it doesn't exist
    # Check if legacy auth record already exists
    echo "Checking if legacy auth bootstrap record already exists..." 1>&2
    EXTANT_LEGACY_AUTH_RECORD=`$GET --write-out="simple" --print-value-only="true" "${BASE}auth/${AUTH_ENV}"`
    if [[ $EXTANT_LEGACY_AUTH_RECORD ]]; then
        echo "${BASE}auth/${AUTH_ENV} already exists with value: $EXTANT_LEGACY_AUTH_RECORD.  Exiting to prevent breaking something." 1>&2
        exit 1
    else
        echo "Creating legacy auth domain $AUTH_ENV record" 1>&2
        putAuthDomain "$AUTH_ENV" "{\"id\":\"$AUTH_ENV\",\"name\":\"$AUTH_ENV environment\",\"contract\":{\"id\":\"oauth\",\"major\":1},\"uris\":[\"https://${AUTH_HOST}/oauth/token\"]}"
        echo "Legacy auth record created:" 1>&2
        $GET --write-out="simple" "${BASE}auth/${AUTH_ENV}"
    fi
fi


# Create brand auth records if they don't exist
# Check if brand auth records already exist
echo "Checking if brand auth bootstrap records already exist..." 1>&2
brands=$(/apps/mead-tools/getbrandlist -a $ETCD_PREFIX)

for brand in $brands
do
    EXTANT_BRAND_AUTH_RECORD=`$GET --write-out="simple" --print-value-only="true" "${BASE}auth/${brand}${AUTH_ENV}"`
    if [[ $EXTANT_BRAND_AUTH_RECORD ]]; then
        echo "${BASE}auth/${brand}${AUTH_ENV} already exists with value: $EXTANT_BRAND_AUTH_RECORD.  Exiting to prevent breaking something." 1>&2
        exit 1
    else
        echo "Creating auth domain ${brand}${AUTH_ENV} record" 1>&2
        putAuthDomain "${brand}${AUTH_ENV}" "{\"id\":\"${brand}${AUTH_ENV}\",\"name\":\"oAuth domain for renewing user access token\",\"contract\":{\"id\":\"oauth\",\"major\":1},\"uris\":[\"https://${AUTH_HOST}/oauth/token\"],\"profile\":{\"contract\":{\"id\":\"profile\",\"major\":1},\"uris\":[\"https://${PROFILE_HOST}/v2/profiles/\"]}}"
        echo "Brand auth record created:" 1>&2
        $GET --write-out="simple" "${BASE}auth/${brand}${AUTH_ENV}"
    fi
done

# generate a list of brands on-the-fly
CONCEPTLIST=
for b in $(getbrandlist -a $ETCD_PREFIX | tr '[:lower:]' '[:upper:]')
do
  [[ -n $CONCEPTLIST ]] && CONCEPTLIST+=","
  CONCEPTLIST+="\"$b\""
done

if [[ $CREATE_BRAND_AUTH_ONLY =~ "false" ]]; then
    # Create app record if it doesn't exist
    # Check if app record already exists
    echo "Checking if app bootstrap record already exists..." 1>&2
    APP=`$GET --write-out="simple" --print-value-only="true" "${BASE}apps/ecommerce"`
    if [[ $APP ]]; then
        echo "${BASE}apps/ecommerce already exists with value: $APP.  Exiting to prevent breaking something." 1>&2
        exit 1
    else
        echo "Creating ecommerce app record" 1>&2
        putApp "ecommerce" '{"id":"ecommerce","name":"Ecommerce application","configPath":"app/ecommerce/","markets":{"'${MARKET}'":{"concepts":['${CONCEPTLIST}']}}}'
        echo "App record created:" 1>&2
        $GET --write-out="simple" "${BASE}apps/ecommerce"
    fi
fi
