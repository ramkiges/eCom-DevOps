#!/bin/bash -e

# A script for updating the app bootstrap record in etcd for an MFE environment.
# Takes etcd prefix (aka the "environment" to add), etcd endpoint, and colon
# separated list of brand/market pairs, and uses `etcdctl` to update the record
# in etcd (the instance specified by $ETCD_ENDPOINT).
# If run with $DRYRUN set to "true", will only echo what it wants to do.

ETCD_PREFIX=${ETCD_PREFIX:-localdev}
ETCD_ENDPOINT=${ETCD_ENDPOINT:-localhost:2379}

required_params="ETCD_PREFIX ETCD_ENDPOINT BRANDS"

for varname in $required_params
do
    if [[ -z ${!varname} ]]; then
        echo "Required parameter $varname is unset" >&2
        exit 1
    fi

    echo "$varname is [${!varname}]" 1>&2
done

for brand in $BRANDS
do
    brand_market=(${brand//:/ })
    market_for_brand=${brand_market[1]}
    if [[ !("$markets" =~ "$market_for_brand") ]]; then
      markets="$markets $market_for_brand"
    fi
    declare $market_for_brand="${!market_for_brand} ${brand_market[0]}"
done

CTL="etcdctl --endpoints=$ETCD_ENDPOINT"
#CTL="etcdctl --user localconfig:lcpass"
CTLOUT="/dev/null"

if [[ "$DRY_RUN" == "true" || "$DRY_RUN" == "1" ]]; then
    echo "NOTE: Dry run requested! Records will not actually be created." 1>&2
    CTL=echo
    CTLOUT="/dev/stdout"
fi

PUT="$CTL put"
GET="$CTL get"

app_record='{"id":"ecommerce","name":"Ecommerce application","configPath":"app/ecommerce/","markets":{'
for market in $markets
do
    for concept in ${!market}
    do
        concepts=${concepts}'"'${concept}'",'
    done
    app_record=${app_record}'"'${market}'":{"concepts":['$(echo ${concepts} | sed 's/,$//')']},'
    unset concepts
done
app_record="$(echo ${app_record} | sed 's/,$//')}}"

echo "Updating ecommerce app bootstrap record for $ETCD_PREFIX to '${app_record}' ..." 1>&2

set -x
$PUT -- "${ETCD_PREFIX}/apps/ecommerce" "${app_record}" > "$CTLOUT"
{ STATUS=$? set +x; } 2>/dev/null

exit $STATUS

