# wsgc-devops-root

Root pom.xml file for DevOps projects, defining standards for logfile
locations, plugin versions, rpm version naming, etc.

Original Subversion Location:
https://repos.wsgc.com/svn/devops/application/common/maven/wsgc-devops-root
